<?php 
	// Dernières modifications le 07/04/2022
	// Par : Laurent ASSELIN

	$module_page_name = "Serveur";
	$show_navbar = true;
	$show_creds_usr = true;
	include 'inc/header.php';
	
    if ($_SESSION['level'] == 2)  {
		$Session->setFlash(Translator('access_denied'), "close", "error");
		header('Location: /');
		exit();
	}
	
	if ($_SESSION['level'] > 3)  {
		$Session->setFlash(Translator('access_denied'), "close", "error");
		header('Location: /');
		exit();
	}
	
	if ($_SESSION['level'] < 1)  {
		$Session->setFlash(Translator('access_denied'), "close", "error");
		header('Location: /');
		exit();
	}
	
	if (($_SESSION['level'] == 1) AND ($_SESSION['corp'] != "NOT_DEFINED"))  {
		$Session->setFlash(Translator('access_denied'), "close", "error");
		header('Location: /');
		exit();
	}
	
?>

		<main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
			<iframe src="/modules/servermonitor/" frameborder="1" style="position: fixed; top: 0px; bottom: 0px; right: 0px; width: 84%; height: 95vh; border: none; margin: 0; padding: 0; overflow: hidden; z-index: auto; margin-top: 3.2rem;"></iframe>
		</div>
		<br><br>
	</div>
</main>
<?php include 'inc/footer.php'; ?>