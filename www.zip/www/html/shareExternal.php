<?php 
	// Dernière modification le : 07/07/2023
	// Par: Laurent ASSELIN
	
	require_once "inc/class.exerotp.php";
	require_once "/var/www/libs/composer/vendor/autoload.php";
	require_once "/var/www/libs/mustache/src/Mustache/Autoloader.php";
	include_once $_SERVER['DOCUMENT_ROOT'] . '/inc/translator.php';
	
	Mustache_Autoloader::register();
	$MustacheInitiator = new Mustache_Engine;

	if (isset($_GET['shareID'])) {
		$shareID = replace_special_chars(htmlspecialchars($_GET['shareID']));
	} else {
		$shareID = NULL;
	}
	
	// Objectif de récupération du client en fonction de son externalToken associé dans la base données
	$recup_user_token = $db->prepare('SELECT * FROM otp_tokens WHERE externalToken = ?');
	$recup_user_token->execute(array($shareID));
	$fetch_infos = $recup_user_token->fetch();
	$count_infos = $recup_user_token->rowCount();
	
	// On récupère le nom de l'entreprise en relation avec le corpid
	$recup_corp = $db->prepare('SELECT * FROM otp_companies WHERE corpid = ?');
	$recup_corp->execute(array($fetch_infos['corpid']));
	$fetch_corp = $recup_corp->fetch();
	
	// On récupère le nom du créateur du token depuis otp_users SQL
	$recup_owner = $db->prepare('SELECT * FROM otp_users WHERE id = ?');
	$recup_owner->execute(array($fetch_infos['userid']));
	$fetch_owner = $recup_owner->fetch();
	
	// On regénére un nouveau token afin de détruire l'accès à la page actuelle
	$token = generateToken(9999);
	$change_token = $db->prepare("UPDATE otp_tokens SET externalToken = ? WHERE externalToken = ?");
	$change_token->execute(array($token, $shareID));

	// Get Mailing template
	$CurrentMailing = $db->prepare('SELECT * FROM otp_mailing WHERE corpid = ?');
	$CurrentMailing->execute(array($fetch_infos['corpid']));
	if ($CurrentMailing->rowCount() == 0) {
		//die('<b style="color:red;">Erreur lors de la récupération des données Mailing.<br>Contactez votre administrateur pour obtenir de l\'aide</b>');
	} else {
		$Mailing = $CurrentMailing->fetch();
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="fr">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="description" content="Exer OTP - Application de génération OTP EXER">
		<meta name="author" content="Exer SAS">
		<meta name="creator" content="Exer SAS">
		<title><?= Translator('Unique_link'); ?></title>

		<link rel="canonical" href="/">
		
		<link rel="shortcut icon" type="image/x-icon" href="/assets/images/favicon.ico" /> 
		<link rel="icon" href="/assets/images/favicon.ico" />

		<link rel="stylesheet" href="/assets/styles/main.css">
		<link rel="stylesheet" href="/assets/libs/fontawesome/css/all.css">
	
		<!--Check Enable Javascript-->
		<noscript>
			<div class="bg_noscript_exerotp"></div>
			<style>body{overflow: hidden !important;}</style>
			<div class="noscript_exerotp">
				<div class="alert alert-danger" role="alert">
					<i class="fas fa-exclamation-triangle"></i> <?= Translator('javascript') ; ?>
				</div>
			</div>
		</noscript>
	
		<?php 
			//Bloquer l'acces depuis Internet Explorer (compatibilité, beugs affichage)
			$ua = htmlentities($_SERVER['HTTP_USER_AGENT'], ENT_QUOTES, 'UTF-8');
			if (preg_match('~MSIE|Internet Explorer~i', $ua) || (strpos($ua, 'Trident/7.0') !== false && strpos($ua, 'rv:11.0') !== false)) { ?>
			<div id="show_if_ie">
				<div class="bg_noscript_exerotp"></div>
				<style>body{overflow: hidden !important;}</style>
				<div class="noscript_exerotp">
					<div class="alert alert-danger" role="alert">
						<i class="fas fa-exclamation-triangle"></i> <?= Translator('no_internet_explorer') ?>
					</div>
				</div>
			</div>
		<?php } ?>
	</head>
	<body style="height: 100% !important;">
		<section class="encardexerqr py-5">
			<div class="container">
				<div class="card mb-5 mb-lg-0" style="margin: 0 auto; margin-top: -20px;">
					<div class="card-body">
						<?php if ($count_infos ==0) { ?>
							<h5 class="card-title text-muted text-uppercase text-center"><?= Translator('Unique_link') ; ?></h5>
							<h6 class="text-danger cardexer_main text-center display-4"><?= Translator('Error'); ?><span class="period"></span></h6>
							<hr>
							<div class="font-weight-light alert alert-light text-center" role="alert" style="color: black;">
								<?= Translator('Unable_retrieve') ; ?>
							</div>
						<?php } else { ?>
							<h5 class="card-title text-muted text-uppercase text-center"><?= Translator('Unique_link') ; ?></h5>
							<h6 class="text-success cardexer_main text-center display-4"><?= Translator('Congratulations'); ?><span class="period"></span></h6>
							<hr>
							<div class="renderCustomClient">
								<?php
									if (strpos($fetch_infos['qr_code'], 'data:image/png') !== false) {
										$ReturnQRCode = $fetch_infos['qr_code'];
									} else {
										$ReturnQRCode = DecodePassword($fetch_infos['qr_code']);
									}

									if ($fetch_corp['logosrc'] != "not_defined") {
										$ReturnLogo = $fetch_corp['logosrc'];
									} else {
										$ReturnLogo = "/assets/images/brandmark.png";
									}
									
									$Close_QR_code = Translator('Close_QR_code');
									$View_QR_code = Translator('View_QR_code');
									$If_QR_code_not_generated = Translator('If_QR_code_not_generated');

									$QRCode = '
									
									<!-- Preview QR_Code_OTPEXER_client -->
									<div id="viewLargeQR_code" class="modal_viewLargeQR_code">
										<span class="close_btnmodal_exerqr" title=' . $Close_QR_code . '>&times;</span>
										<img oncontextmenu="return false; return false" ondrag="return false; return false" onmousedown="return false; return false" class="modal_viewLargeQR_code__content" id="large_qrcode_img">
										<div id="legend_qrcode">' . $View_QR_code . '</div>
									</div>
									
									<img id="preview_smallqrcode_client_otpexer" style="max-height: 220px;" src="'.$ReturnQRCode.'" alt=' . $If_QR_code_not_generated . ' class="img-thumbnail qr_preview_imlg_show" oncontextmenu="return false; return false" ondrag="return false; return false" onmousedown="return false; return false">';
									$LogoCorp = '<img style="max-height: 10rem;min-height: 4rem;height: 5rem;" src="'.$ReturnLogo.'" alt="Logo">';

									if (!empty($Mailing['link_custom_btn1'])) {
										$link_custom_btn1 = $Mailing['link_custom_btn1'];
									} else {
										$link_custom_btn1 = Translator('IOS_app_link');
									}

									if (!empty($Mailing['link_custom_btn2'])) {
										$link_custom_btn2 = $Mailing['link_custom_btn2'];
									} else {
										$link_custom_btn2 = Translator('Android_app_link');
									}

									$OTPVar = array(
										'company'   	=>  $fetch_corp['name'],
										'username' 		=>  $fetch_infos['login'],
										'keyname'   	=>  $fetch_infos['key_name'],
										'issuer'   		=>  $fetch_infos['issuer'],
										'qrcode'   		=>  $QRCode,
										'logo'			=>	$LogoCorp,
										'CustomBtn1'	=>	$link_custom_btn1,
										'CustomBtn2'	=>	$link_custom_btn2
									);
									
									$LinkTemplate = htmlspecialchars_decode($Mailing['content_link']);
									echo $MustacheInitiator->render($LinkTemplate, $OTPVar);
								?>
							</div>
						<?php } ?>
					</div>
				</div>
			</div>
		</section>
	</body>
	<footerexer style="color: white;">
		&copy; <?= date('Y') ?> <?= $WhiteLabel ?> - <?= Translator('AllRightReserved'); ?>
	</footerexer>
</html>

<style>
body{background:linear-gradient(to right,#0062E6,#33AEFF)}.navbar{background:linear-gradient(to right,#0062E6,#33AEFF)}section.encardexerqr{background:#007bff;background:linear-gradient(to right,#0062E6,#33AEFF)}.encardexerqr .card{border:none;border-radius:1rem;transition:all .2s;box-shadow:0 .5rem 1rem 0 rgba(0,0,0,0.1)}.encardexerqr hr{margin:1.5rem 0}a{font-size:20px;font-weight:300;color:#000}a:hover{color:#000;text-decoration:none}.encardexerqr .card-title{margin:.5rem 0;font-size:.9rem;letter-spacing:.1rem;font-weight:700}.encardexerqr .cardexer_main{font-size:3rem;margin:0}.encardexerqr .cardexer_main .period{font-size:.8rem}.encardexerqr ul li{margin-bottom:1rem}.encardexerqr .text-muted{opacity:.7}.encardexerqr .btn{font-size:80%;border-radius:5rem;letter-spacing:.1rem;font-weight:700;padding:1rem;opacity:.7;transition:all .2s}@media (min-width: 992px){.encardexerqr .card:hover{margin-top:-.25rem;margin-bottom:.25rem;box-shadow:0 .5rem 1rem 0 rgba(0,0,0,0.3)}.encardexerqr .card:hover .btn{opacity:1}}
</style>
<script>
var modal_qr_client_exerotp = document.getElementById("viewLargeQR_code");

var qr_img = document.getElementById("preview_smallqrcode_client_otpexer");
var large_qrcode_img = document.getElementById("large_qrcode_img");
var captionText = document.getElementById("legend_qrcode");
qr_img.onclick = function() {
	modal_qr_client_exerotp.style.display = "block";
	large_qrcode_img.src = this.src;
}

var span_qr_close = document.getElementsByClassName("close_btnmodal_exerqr")[0];

span_qr_close.onclick = function() {
	modal_qr_client_exerotp.style.display = "none";
}
</script>
<?php include 'inc/footer.php'; ?>