<?php
	// Dernière modification le : 27/07/2023
	// Par: Laurent ASSELIN
	 
try {
	//Connexion a la base de donnee d'EXER OTP
	$dbexer_dbname 		= "exer_db";
	$dbexer_host 		= "127.0.0.1";
	$dbexer_username 	= "app_exerotp";
	$dbexer_password 	= trim(shell_exec('/bin/cat /etc/mysql/otp.conf'));
	
	$db = new PDO("mysql:host=$dbexer_host;dbname=$dbexer_dbname;charset=utf8", $dbexer_username, $dbexer_password);
} catch (Exception $exception) { ?>
<div align ="center">
	<p><b>⛔️ Unable to connect to the SQL Database !</b></p>
	<p>Please check server connection then try again.</p></div>
<?php 
	die('Erreur(s) rencontrée(s) : ' . $exception ->getCode() . ' ' . $exception->getMessage() . ').');
}
?>