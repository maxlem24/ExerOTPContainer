    <!--fin module-->
    <script type="text/javascript" src="/assets/scripts/init.js"></script>
</body>
</html>