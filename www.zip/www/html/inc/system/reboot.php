<?php
	// Dernières modifications le : 28/03/2022
	// Par: Laurent ASSELIN
	
	include_once $_SERVER['DOCUMENT_ROOT'] . '/inc/class.exerotp.php';

	if ($_SERVER['REQUEST_METHOD'] === 'POST') {
		if (isset($_SESSION['id'])) {
			if ($_SESSION['level'] == 3) {
				shell_exec('sudo reboot');
				exit();
			} else {
				echo 'Access denied.';
				exit();
			}
		} else {
			echo 'Connection required.';
			exit();
		}
	} else {
		die('Invalid method.');
	}
?>
