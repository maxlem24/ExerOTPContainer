<?php
$logFile = "/var/www/tmp/update.log";
$interval = 1000;

if ($interval < 100)  $interval = 100; 
if (isset($_GET['getLog'])) {
	echo "<div style='border: 1px solid #a5a5a5; background: #f7fbff; overflow: auto; padding: 5px;'>";
	echo "<pre>";
	if (file_exists($logFile)) {
		echo file_get_contents($logFile);
	}
	echo "</pre>";
	echo "</div>";
} else {
?>
<html>
	<script type="text/javascript" src="/assets/scripts/jquery.min.js"></script>
	<script>
		setInterval(readLogFile, <?php echo $interval; ?>);
		window.onload = readLogFile; 
		var pathname = window.location.pathname;
		var scrollLock = true;
		
		$(document).ready(function(){
			$('.disableScrollLock').click(function(){
				$("html,body").clearQueue()
				$(".disableScrollLock").hide();
				$(".enableScrollLock").show();
				scrollLock = false;
			});
			$('.enableScrollLock').click(function(){
				$("html,body").clearQueue()
				$(".enableScrollLock").hide();
				$(".disableScrollLock").show();
				scrollLock = true;
			});
		});
		function readLogFile(){
			$.get(pathname, { getLog : "true" }, function(data) {
				data = data.replace(new RegExp("\n", "g"), "<br />");
		        $("#log").html(data);
		        
		        if(scrollLock == true) { $('html,body').animate({scrollTop: $("#scrollLock").offset().top}, <?php echo $interval; ?>) };
		    });
		}
	</script>
	<body>
		<div id="log"></div>
		<div id="scrollLock"> <input class="disableScrollLock" style="display: none;" type="button" value="Disable Scroll Lock" /> <input class="enableScrollLock" style="display: none;" type="button" value="Enable Scroll Lock" /></div>
	</body>
</html>
<?php } ?>