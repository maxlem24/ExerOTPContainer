<?php 
    // Dernière modification le : 15/07/2022
    // Par: Laurent Asselin
   
include_once $_SERVER['DOCUMENT_ROOT'] . '/inc/class.exerotp.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/inc/translator.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_SESSION['id'])) {
        if ($_SESSION['level'] == 3) {
            if (isset($_FILES['import_maj_file_subscriber'])) {
                $ip_sub = $_COOKIE["ipsub"];
                $all_alright = false;
                $recup_otp = $db->prepare('SELECT * FROM otp_actif WHERE ip_subscriber = ?');
                $recup_otp->execute(array($ip_sub));
                $recover_data_actif = $recup_otp->fetch();
                if (!empty($_FILES['import_maj_file_subscriber'])) {
                    $extensionsValides = array('sign', 'zip.sign', 'zip');
                    $extensionUpload = strtolower(substr(strrchr($_FILES['import_maj_file_subscriber']['name'], '.'), 1));
                    $FileName = "update_otp.".$extensionUpload;
                    if (in_array($extensionUpload, $extensionsValides)) {
                        $chemin = "/var/www/tmp/".$FileName;
                        $resultat = move_uploaded_file($_FILES['import_maj_file_subscriber']['tmp_name'], $chemin);
                        if ($resultat) {
                            $escaped_version = escapeshellcmd("sudo ssh " . $recover_data_actif['ip_subscriber'] . " 'cat /etc/version'");
                            $version_otp_before = trim(shell_exec($escaped_version));
                            $escaped_command = escapeshellcmd("sudo bash /usr/local/bin/software_update_subscriber.sh -s " . $recover_data_actif['ip_subscriber'] . " -u "  . $chemin);
                            $output = shell_exec($escaped_command);
                            $get_message = strstr($output, "\n", true);
                            $answer = str_replace("\n","", $get_message);
							$real_log_last_line = trim(shell_exec("sudo ssh " . $recover_data_actif['ip_subscriber'] . " 'tail -1 /var/log/update.log | cut -d \" \" -f3-6'"));
                            $expected_log_last_line = "Upgrade done !";
                            if (strcmp($answer, "Signature is valid ") == 0) {
                                sleep(2);
                                addLogEventOTP("[INFORMATION] The update signature is valid.");
                                $RemoveTempFolder = shell_exec('sudo rm -rf /var/www/tmp/*');
                            } else {
                                addLogEventOTP("[ERROR] The update signature is invalid.");
                                $RemoveTempFolder = shell_exec('sudo rm -rf /var/www/tmp/*');
                                echo Translator('update_signature_invalid');
                                echo "<script>$('#dispatchUpdate').hide();</script>";
                                exit();
                            }
                            $version_otp_after = trim(shell_exec($escaped_version));
                            if (strcmp($real_log_last_line, $expected_log_last_line) != 0) {
                                $RemoveTempFolder = shell_exec('sudo rm -rf /var/www/tmp/*');
                                addLogEventOTP("[ERROR] Update failed.");
                                echo Translator('consult_var_log') . ' /var/log/update.log';
                                echo "<script>$('#dispatchUpdate').hide();</script>";
                                exit();
                            } else {
                                echo "upload_ok";
                                $RemoveTempFolder = shell_exec('sudo rm -rf /var/www/tmp/*');
                                addLogEventOTP("[SUCCESS] The upgrade from version " . $version_otp_before ." to " . $version_otp_after ." is done");
                                
                            }
                        } else {
                            addLogEventOTP("[ERROR] An error occurred during the software update.");
                            echo Translator('update_bug');
                            echo "<script>$('#dispatchUpdate').hide();</script>";
                            exit();
                        }
                    } else {
                        addLogEventOTP("[ERROR] Invalid update file extension.");
                        echo Translator('Extensions_MAJ_format');
                        echo "<script>$('#dispatchUpdate').hide();</script>";
                        exit();
                    }
                } else {
                    echo Translator('valid_update_file');
                    echo "<script>$('#dispatchUpdate').hide();</script>";
                    exit();
                }
            }
             else {
                echo Translator('choose_update_file');
                echo "<script>$('#dispatchUpdate').hide();</script>";
                exit();
            }
        } else {
            echo "<script>$('#dispatchUpdate').hide();</script>";
            die('Access denied.');
        }
    } else {
        echo "<script>$('#dispatchUpdate').hide();</script>";
        die('Connection required.');
    }
} else {
    die('Invalid method.');
}
?>

