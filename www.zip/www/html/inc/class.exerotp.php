<?php
/**
*   @category EXER OTP Appliance
*   @author EXER SAS <support@exer.fr>
*   @copyright 2023 EXER
*   @api EXER OTP Main File
*
*	@editedBY Laurent ASSELIN
*   @lastEdited 17/11/2023
*/

/**
 	* 
	*  /$$$$$$$$ /$$   /$$ /$$$$$$$$ /$$$$$$$         /$$$$$$  /$$$$$$$$ /$$$$$$$ 
	* | $$_____/| $$  / $$| $$_____/| $$__  $$       /$$__  $$|__  $$__/| $$__  $$
	* | $$      |  $$/ $$/| $$      | $$  \ $$      | $$  \ $$   | $$   | $$  \ $$
	* | $$$$$    \  $$$$/ | $$$$$   | $$$$$$$/      | $$  | $$   | $$   | $$$$$$$/
	* | $$__/     >$$  $$ | $$__/   | $$__  $$      | $$  | $$   | $$   | $$____/ 
	* | $$       /$$/\  $$| $$      | $$  \ $$      | $$  | $$   | $$   | $$      
	* | $$$$$$$$| $$  \ $$| $$$$$$$$| $$  | $$      |  $$$$$$/   | $$   | $$      
	* |________/|__/  |__/|________/|__/  |__/       \______/    |__/   |__/      
	*                                                            
 */


/**
*   Show PHP Errors (Developpment Usage only !)
*/
$display_php_errors		= false;


/**
*   Show EXER OTP version
*/
$display_version_otp 	= true;


/**
*   Show name of companie in license name (+ license temporary disable EXER OTP)
*/
$display_name_licence 	= true;



/**
*   Includes
*/
include_once '/usr/local/lib/phpqrcode/qrlib.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/inc/db.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/inc/class.notifications.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/inc/class.reader.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/inc/translator.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/inc/mail/config.mail.php';



/**
*   Permissions level
*/
define('OPERATOR', 1);
define('ADMIN', 2);
define('SUPERVISOR', 3);


/**
*   Check Level function in pages
*/
function checkLevel() {
	if (isset($_SESSION['id'])) {
		switch ($_SESSION['level']) {
			case 1:
				return 1;
				break;
			case 2:
				return 2;
				break;
			case 3:
				return 3;
				break;
		}
	} else {
		return false;
	}
}


/**
*   Session Management
*/
$sname = session_name();
if ($sname != 'EXEROTP_SESSID') {
	session_name('EXEROTP_SESSID');
}
$Session = new Session();
$Session->flash();
ob_start();


/**
*   Date Settings
*/
setlocale(LC_ALL, "fr_FR.UTF-8");
date_default_timezone_set('Europe/Paris');


/**
*   NextPage Camefrom Redirection
*/
if (isset($_GET['NextPage'])) {
	$NextPage = htmlspecialchars($_GET['NextPage']);
} else {
	$NextPage = NULL;
}

$basenameFile = basename($_SERVER['PHP_SELF']);



/**
*   Check if account is active
*/
if ($basenameFile != "login.php") {
	if (!isset($_SESSION['id'])) {
		if ($basenameFile == "shareExternal.php") {
			$_SESSION['id']= "ffsd545245452";
		} else {
			$NextPage = $basenameFile;
			header('Location: /login.php?NextPage=' . $NextPage);
			exit();
		}
	} elseif ($basenameFile != "disable.php") {
		if ($_SESSION['enable'] == 0) {
			addLogEventOTP("[INFORMATION] A connection attempt from a disabled account has been made by " . $_SESSION['username'] . ".");
			$Session->setFlash(Translator('account_disabled'), "close", "error");
			header('Location: /disable.php');
			exit();
		}
	}
	
	if (isset($_SESSION['id'])) {
		// Définition des valeurs de la session lors de la connexion
		$username_auth = $_SESSION['username']; //username connecté
		
		####
		## Récupération des données de la session
		####
		$req = $db->prepare('SELECT * FROM otp_users WHERE id = ?');
		$req->execute(array($_SESSION['id']));
		$info_user = $req->fetch();

		$_SESSION['id']				= $info_user['id'];
		$_SESSION['corp']			= $info_user['corp'];
		$_SESSION['lastname']		= $info_user['lastname'];
		$_SESSION['firstname']		= $info_user['firstname'];
		$_SESSION['username']		= $info_user['username'];
		$_SESSION['email']			= $info_user['email'];
		$_SESSION['password']		= $info_user['password'];
		$_SESSION['level']			= $info_user['level'];
		$_SESSION['lastip']			= $info_user['lastip'];
		$_SESSION['token']			= $info_user['token'];
		$_SESSION['last_connected']	= $info_user['last_connected'];
		$_SESSION['enable']			= $info_user['enable'];
		
		if ($_SESSION['corp'] != "NOT_DEFINED") {
			$req_corp = $db->prepare('SELECT * FROM otp_companies WHERE corpid = ?');
			$req_corp->execute(array($_SESSION['corp']));
			$info_corp = $req_corp->fetch();
			
			$_SESSION['corp_name']			= $info_corp['name'];
			$_SESSION['corp_folder']		= $info_corp['folder'];
			$_SESSION['corp_email']			= $info_corp['contact_email'];
			$_SESSION['corp_logo']			= $info_corp['logosrc'];
			$_SESSION['corp_expire_date']	= $info_corp['expire_date'];
			$_SESSION['corp_created_at']	= $info_corp['created_at'];
			$_SESSION['corp_token']			= $info_corp['token'];
		}

		if (isset($_SESSION['id'])) {
			if (checkLevel() == ADMIN && $_SESSION['corp'] == "NOT_DEFINED") {
				$_SESSION = array();
				session_destroy();
				
				header('Location: /');
				exit();
			} elseif (checkLevel() == SUPERVISOR && $_SESSION['corp'] != "NOT_DEFINED") {
				$_SESSION = array();
				session_destroy();
				
				header('Location: /');
				exit();
			}
		}


		if ($_SESSION['corp'] == "NOT_DEFINED") {
			// Get Max User with max license
			$escaped_command = escapeshellcmd("sed -n '3p' /home/otp.license");
			$in = shell_exec($escaped_command);
			$out = preg_replace('~\D~', '', $in);
			if ($out == NULL)
				$out = -1;
				$_SESSION['users_maximum'] = htmlspecialchars($out);

			$recup_users_max = $db->prepare("SELECT users_max FROM otp_companies WHERE corpid != ?");
			$recup_users_max->execute(array($_SESSION['corp']));

			$total = 0;
			$tmp = $recup_users_max->rowCount();
			$cmp = 0;

			while ($cmp < $tmp) {
				$data = $recup_users_max->fetch();
				$total = $total + $data[0];
				$cmp++;
			}

			$_SESSION['total'] 		= htmlspecialchars($total);
			$_SESSION['remaining'] 	= $_SESSION['users_maximum'] - $total;

			if ($_SESSION['remaining'] <= 0) {
				$_SESSION['remaining'] = "0";
			} else {
				$_SESSION['remaining'];
			}
		} else {
			$RecupMaxUsers = $db->prepare('SELECT * FROM otp_companies WHERE corpid = ?');
			$RecupMaxUsers->execute(array($_SESSION['corp']));
			$queryMaxUsers = $RecupMaxUsers->fetch();

			$RecupTokensCorp = $db->prepare('SELECT * FROM otp_tokens WHERE corpid = ?');
			$RecupTokensCorp->execute(array($_SESSION['corp']));
			$countTokensCorp = $RecupTokensCorp->rowCount();

			if ($_SESSION['users_maximum'] > 1) {
				$_SESSION['users_maximum'] = $queryMaxUsers['users_max'] . Translator('Users');
			} else {
				$_SESSION['users_maximum'] = $queryMaxUsers['users_max'] . Translator('user');
			}

			$remainTokens = $_SESSION['users_maximum'] - $countTokensCorp;

			if ($remainTokens > 1) {
				$GetRemainTokens =  $remainTokens . Translator('remaining');
			} else {
				$GetRemainTokens = $remainTokens . Translator('remaining');
			}
			
			if ($remainTokens <= 0) {
				$_SESSION['remaining'] =  "<label class='badge badge-danger'>0</label>";
			} elseif ($remainTokens  <= 3) {
				$_SESSION['remaining'] = "<label class='badge badge-warning'>".$GetRemainTokens."</label>";
			} else {
				$_SESSION['remaining'] = $GetRemainTokens;
			}
		}
	} else {
		if ($NextPage == "logout.php") {
			header('Location: /');
			exit();
		} elseif ($NextPage == "disable.php") {
			header('Location: /');
			exit();
		}
	}
}


/**
*   Auto-Redirection with argument
*/
if (isset($_GET['NextPage'])) {
	$NextPage = htmlspecialchars($_GET['NextPage']);

	if ($NextPage == "index.php" || $NextPage == "login.php" || $NextPage == "logout.php" || $NextPage == "disable.php") {
		header('Location: /login.php');
		exit();
	}
}


/**
*   Disconnection
*/
if ($_SESSION['id'] && ($_SESSION['level'] == 2 && ($_SESSION['corp'] == "NOT_DEFINED" || $_SESSION['corp'] == "choseCorp"))) {
	$Session->setFlash(Translator('successful_disconnection'), "check", "success");
	
	addLogEventOTP("[ERROR] Admin/compagny configuration error for " . $_SESSION['username'] . ".");
	
	//Suppresion des donnees de la session
	$_SESSION = array();
	session_destroy();


	header('Location: /login.php');
	exit();
}


/**
*  PHP Show Errors if function is activated
*/
if ($display_php_errors == true) {
	error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
} else {
	error_reporting(E_ERROR | E_WARNING | E_PARSE );
}



/**
*   Mailing Template
*/
$Mailing_link_custom_btn1 = Translator('IOS_app_link');
$Mailing_link_custom_btn2 = Translator('Android_app_link');



$Mailing_DefaultContent = Translator('default_email');
$Mailing_DefaultContentLink = Translator('Mailing_DefaultContentLink');
$Mailing_Subject = Translator('Unique_link');
$Mailing_CustomFQDN = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]";


/**
*   Get postfix Informations from new configuration
*/
$ProgGetRelayHost 	= shell_exec('grep "relayhost" /etc/postfix/main.cf');
$GetRelayHost 		= str_replace("relayhost = ", "", $ProgGetRelayHost);


/**
*   Make auto no replying address
*/
$SendMail = "no-reply@";
$SendMail.= shell_exec('cat /etc/mailname');



/**
*   Reset Mailing Configuration Function
*/
function ResetMailingConf($token = "undefined") {
	global $db;
	global $_SESSION;
	global $Mailing_CustomFQDN;
	global $Mailing_DefaultContent;
	global $Mailing_DefaultContentLink;
	global $Mailing_link_custom_btn1;
	global $Mailing_link_custom_btn2;
	global $Mailing_Subject;
	global $GetRelayHost;
	global $SendMail;

	// Get companies infos
	$CustomgetCompanyInfos = $db->prepare('SELECT * FROM otp_companies WHERE corpid = ?');
	$CustomgetCompanyInfos->execute(array($token));
	$getInfosCorp = $CustomgetCompanyInfos->fetch();
	$Sender = $getInfosCorp['name'];

	$DefaultMailing = $db->prepare('UPDATE otp_mailing SET host = ?, transport = ?, port = ?, fqdn = ?, issuer = ?, sendmail = ?, auth_user = ?, auth_password = ?, content = ?, content_link = ?, link_custom_btn1 = ?, link_custom_btn2 = ?, created_at = ?, token = ?, subject = ? WHERE corpid = ?');
	$DefaultMailing->execute(array($GetRelayHost, 0, "25", $Mailing_CustomFQDN, $Sender, $SendMail, NULL, NULL, $Mailing_DefaultContent, $Mailing_DefaultContentLink, $Mailing_link_custom_btn1, $Mailing_link_custom_btn2, CurrentDateTime(), GenerateToken(), $Mailing_Subject, $token));
}



/**
*   Get License owner
*/
$license_required = false;
$licenceOK = false;
if ($display_name_licence == true) {
	$pathLicenceSrv = "/home/otp.license";
	if (file_exists($pathLicenceSrv)) {
		$escaped_command = escapeshellcmd('grep -Z -E License ' . $pathLicenceSrv);
		$licence_req = shell_exec($escaped_command);

		$GetExpireDate = escapeshellcmd('grep -Z -E date ' . $pathLicenceSrv);
		$DumpExpireDateold = str_replace("End date: ", "", shell_exec($GetExpireDate));
		$DumpExpireDate = trim($DumpExpireDateold);
		$ArrayDate = explode("/", $DumpExpireDate);

		$CurrentDate = mktime(0, 0, 0, date("m"), date("d"), date("Y"));
		$FinalExpireDate = mktime(0, 0, 0, $ArrayDate[1], $ArrayDate[0], $ArrayDate[2]);
		if ($FinalExpireDate < $CurrentDate) {
			$licence = '<b class="badge navbarstatus navbarstatus-warning text-middle" style="padding: 5px 10px 1px 15px;"><h6><i class="far fa-exclamation-triangle"></i>'.Translator('your_licence_exp') .'</h6></b>';
			$licence_home = "No license.";
			$license_required = true;
			$_SESSION['total'] 			= "N/A";
			$_SESSION['remaining'] 		= "N/A";
			$_SESSION['users_maximum'] 	= "N/A";
			$licenceOK = true;	
		} else {
			// put the current month here, deduct it from 2 if negative in this case draw in December ect, but before display to see what format it is but normally it is 1 2 3 etc..
			$month = date("m") + 2;
			$years = date("Y");
			if ($month > 12) {
				$years = $years + 1;
				if ($month == 13) 
					$month = 1;
				else if ($month == 14)
					$month = 2;
				else
					$month = 1;
			}
			$CurrentDate = mktime(0, 0, 0, $month, date("d"), $years);
			$FinalExpireDate = mktime(0, 0, 0, $ArrayDate[1], $ArrayDate[0], $ArrayDate[2]);
			if ($FinalExpireDate < $CurrentDate) {
				$CurrentDate = mktime(0, 0, 0, date("m"), date("d"), date("Y"));
				$HowManyDaysRemain = $FinalExpireDate - $CurrentDate;
				$HowManyDaysRemain = round($HowManyDaysRemain * 0.000011574075);
				$WritingDay = Translator('day');
				if ($HowManyDaysRemain > 1)
					$WritingDay = Translator('days');
				if ($HowManyDaysRemain == 0)
					$licence = '<b class="badge navbarstatus navbarstatus-warning text-middle" style="padding: 5px 10px 1px 15px;"><h6><i class="far fa-exclamation-triangle"></i>' .Translator('your_licence_just_exp').' </h6></b>';
				else
					$licence = '<b class="badge navbarstatus navbarstatus-warning text-middle" style="padding: 5px 10px 1px 15px;"><h6><i class="far fa-exclamation-triangle"></i>'.Translator('your_licence_date_exp'). $HowManyDaysRemain . ' ' . $WritingDay .'  </h6></b>';
				
				$licencefile = str_replace('License assigned to: ', Translator('HeaderMsgLicense'), htmlspecialchars($licence_req));
				if (checkLevel() == SUPERVISOR) {
					$licence_home = str_replace(Translator('HeaderMsgLicense'), ' ', htmlspecialchars($licencefile));
				} else {
					$licence_home = $_SESSION['corp_name'];
				}
			} else {
				if (isset($_SESSION['id'])) {
					if (checkLevel() == SUPERVISOR) {
						$licence = str_replace('License assigned to: ', Translator('HeaderMsgLicense'), htmlspecialchars($licence_req));
						$licence_home = str_replace(Translator('HeaderMsgLicense'), ' ', htmlspecialchars($licence));
					} else {
						if (isset($_SESSION['id'])) {
							if (isset($_SESSION['corp_name'])) {
								$licence = Translator('HeaderMsgLicense') ." ". htmlspecialchars($_SESSION['corp_name']);
								} else {
								$licence = str_replace('License assigned to: ', Translator('HeaderMsgLicense'), htmlspecialchars($licence_req));
								}
							$licence_home = str_replace(Translator('HeaderMsgLicense'), ' ', htmlspecialchars($licence));
						} else {
							$licence = Translator('licence_retrieve');
							$licence_home = $licence;
						}
					}
				} else {
					$licence = str_replace('License assigned to: ', Translator('HeaderMsgLicense'), htmlspecialchars($licence_req));
					$licence_home = str_replace(Translator('HeaderMsgLicense'), ' ', htmlspecialchars($licence));
				}
			}	
			$licenceOK = true;
		}
	} else {
		$licence = '<b class="badge navbarstatus navbarstatus-error text-middle" style="padding: 5px 10px 1px 15px;"><h6><i class="far fa-exclamation-triangle"></i>'. Translator('Product_not_actv').'</h6></b>';
		$licence_home = Translator('No_licence');
		$license_required = true;
		$_SESSION['total'] 			= "N/A";
		$_SESSION['remaining'] 		= "N/A";
		$_SESSION['users_maximum'] 	= "N/A";
		$licenceOK = false;
	}
} else {
	$licence = " ";
}



/**
*   Check if license is valid
*/
if (($licenceOK == false) AND ($basenameFile == "companies.php" OR $basenameFile == "customizations.php" OR $basenameFile == "account.php" OR $basenameFile == "firewall.php" OR $basenameFile == "ldap.php" OR $basenameFile == "audits.php" OR $basenameFile == "users.php" OR $basenameFile == "cluster.php")) {
	$Session->setFlash(Translator('unvailable_module'). Translator('Product_not_actv'), "close", "error");
	
	if (checkLevel() != SUPERVISOR) {
		header('Location: /');
	} else {
		header('Location: /maintenance.php');
	}
	exit();
}


/**
*   Check Module access by level
*/
if (checkLevel() != SUPERVISOR) {
	if (($licenceOK == false) && $basenameFile == "maintenance.php") {
		$Session->setFlash(Translator('unvailable_module'). Translator('Product_not_actv'), "close", "error");
		header('Location: /');
		exit();
	}
}


/**
*   Get OTP Version
*/
if ($display_version_otp == true) {
	$escaped_command = shell_exec("sed 's/^Exer OTP v//' /etc/version");
	$version_otp = $WhiteLabel . ' ' . $escaped_command;
} else {
	$version_otp = $WhiteLabel ; 
}


/**
*   Get IP Address
*/
function GetIPAddress() {
    if (isset($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    } elseif(isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
		return $_SERVER['HTTP_X_FORWARDED_FOR'];
	} else {
        return (isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '');
    }
}
$ip_get = GetIPAddress();


/**
*   Maintenance.php - Function to get storage of current disk
*/
class DiskStatus {
	const RAW_OUTPUT = true;
		private $diskPath;

		function __construct($diskPath) {
			$this->diskPath = $diskPath;
		}

		public
			function totalSpace($rawOutput = false) {
				$diskTotalSpace = @disk_total_space($this -> diskPath);
					if ($diskTotalSpace === FALSE) {
						throw new Exception('totalSpace(): '.Translator('invalid_path_disk'));
					}
				return $rawOutput ? $diskTotalSpace : $this -> addUnits($diskTotalSpace);
			}

		public
			function freeSpace($rawOutput = false) {
				$diskFreeSpace = @disk_free_space($this -> diskPath);
					if ($diskFreeSpace === FALSE) {
						throw new Exception('freeSpace(): '. Translator('invalid_path_disk'));
					}
				return $rawOutput ? $diskFreeSpace : $this -> addUnits($diskFreeSpace);
			}

		public
			function usedSpace($precision = 1) {
				try {
					return round((100 - ($this -> freeSpace(self::RAW_OUTPUT) / $this -> totalSpace(self::RAW_OUTPUT)) * 100), $precision);
				} catch (Exception $e) {
					throw $e;
				}
			}

		public
			function getDiskPath() {
				return $this -> diskPath;
			}

		private
			function addUnits($bytes) {
				$units = array(
					'O',
					'Ko',
					'Mo',
					'Go',
					'To'
			);
			
			for ($i = 0; $bytes >= 1024 && $i < count($units) - 1; $i++) {
				$bytes /= 1024;
			}
			
			return round($bytes, 1).
				' '.$units[$i];
			}
}


/**
*   OTP Action Monitoring - Add log events
*/
function addLogEventOTP($event){
	$time = date("D, d M Y H:i:s");
	$time = "[".$time."]";
	$namepage = basename($_SERVER['PHP_SELF']);
	$namepage = " [".$namepage."] ";
	$event = trim($event);
	$event = $time.$namepage.$event."\n";
 
	file_put_contents("/var/www/logs_otp/actions_otp.log", $event, FILE_APPEND);
}


/**
*   Check if the string contain as letter
*/
function _s_has_letters($string) {
	return preg_match('/[a-zA-Z]/', $string);
}


/**
*   Check if the string contain as number
*/
function _s_has_numbers($string) {
	return preg_match('/\d/', $string);
}


/**
*   Check if the string contains a special chars
*/
function _s_has_special_chars($string) {
	return preg_match('/[^a-zA-Z\d_\-\@.]/', $string);
}


/**
*   Remove accents from string
*/
function remove_accents($string, $charset='utf-8') {
    $string = htmlentities($string, ENT_NOQUOTES, $charset);
    
    $string = preg_replace('#&([A-za-z])(?:acute|cedil|caron|circ|grave|orn|ring|slash|th|tilde|uml);#', '\1', $string);
    $string = preg_replace('#&([A-za-z]{2})(?:lig);#', '\1', $string);
    $string = preg_replace('#&[^;]+;#', '', $string);
    
    return $string;
}


/**
*   Remove special chars from string
*/
function remove_special_chars($string) {
	$string = preg_replace("#[^a-zA-Z_]#", "", $string);
	
	return $string;
}


/**
*   Replace special chars in string
*/
function replace_special_chars($string) {
	$string = iconv('UTF-8', 'US-ASCII//TRANSLIT//IGNORE', $string);
	$string = preg_replace('#[^a-zA-Z0-9_]+#i', '', $string);
	$string = strtolower($string);
  
	return utf8_encode($string);
}


/**
*   Get Encoding Type of Page
*/
function detect_encoding_file($string) {
	return mb_detect_encoding($string);
}


/**
*   Return current date from server
*/
function return_date_all_actuelle() {
	return date('Y-m-d H:i:s');
}


/**
*   Function to generate a simple random password by specifying the desired number of characters
*	Usage : generatePassword(25);
*	Default : 10
*/
function generatePassword($length = 10) {
    $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $count = mb_strlen($chars);

    for ($i = 0, $result = ''; $i < $length; $i++) {
        $index = rand(0, $count - 1);
        $result .= mb_substr($chars, $index, 1);
    }
    return $result;
}


/**
*   Generate random Bin2hex SHA256 token
*	Default : 512
*/
function generateToken($length = 512) {
    $a = bin2hex(random_bytes($length));
	return hash('sha256', $a);
}

// Fonction permettant d'obtenir la charge CPU - Ne fonctionne pas correctement !!
function get_server_cpu_usage() {
	$stat1 = file('/proc/stat'); 
	$info1 = explode(" ", preg_replace("!cpu +!", "", $stat1[0]));
	$cpu_total = $info1[0] + $info1[1] + $info1[2] + $info1[3] + $info1[4] + $info1[5] + $info1[6];
	$cpu_idle = round(100*$info1[3]/$cpu_total, 2);
	return 100 - $cpu_idle; 
}


/**
*   Get usage of Random Access Memory from server in pourcentage
*/
function get_server_memory_usage() {
	$escaped_command = escapeshellcmd('free');
    $free = shell_exec($escaped_command);
    $free = (string)trim($free);
    $free_arr = explode("\n", $free);
    $mem = explode(" ", $free_arr[1]);
    $mem = array_filter($mem);
    $mem = array_merge($mem);
    $memory_usage = $mem[2]/$mem[1]*100;

    return $memory_usage;
}


/**
*   Get usage of Random Access Memory from server in octale value
*/
function shapeSpace_memory_usage() {
	$mem = memory_get_usage(true);
	
	if ($mem < 1024) {
		$$memory = $mem .' o'; 
	} elseif ($mem < 1048576) {
		$memory = round($mem / 1024, 2) .' Ko';
	} else {
		$memory = round($mem / 1048576, 2) .' Mo';
	}
	
	return $memory;
}


/**
*   Get system usage from server
*/
function shapeSpace_system_load() {
	$rs = sys_getloadavg();
	return $rs[0];
}


/**
*  Get Processors and Cores from server
*/
function shapeSpace_system_cores() {
    $cmd = "uname";
    $OS = strtolower(trim(shell_exec($cmd)));
 
    switch($OS) {
       case('linux'):
          $cmd = "cat /proc/cpuinfo | grep processor | wc -l";
          break;
       case('freebsd'):
          $cmd = "sysctl -a | grep 'hw.ncpu' | cut -d ':' -f2";
          break;
       default:
          unset($cmd);
    }
 
    if ($cmd != '') {
       $cpuCoreNo = intval(trim(shell_exec($cmd)));
    }
    return empty($cpuCoreNo) ? 1 : $cpuCoreNo;
}


/**
*   Get number of HTTP connection on server
*/

function shapeSpace_http_connections() {
	if (function_exists('exec')) {
		$www_total_count = 0;
		$www_unique_count = 0;
		$unique = array();
		@exec ('netstat -an | egrep \':80|:443\' | awk \'{print $5}\' | grep -v \':::\*\' |  grep -v \'0.0.0.0\'', $results);
		
		foreach ($results as $result) {
			$array = explode(':', $result);
			$www_total_count ++;
			
			if (preg_match('/^::/', $result)) {
				$ipaddr = $array[3];
			} else {
				$ipaddr = $array[0];
			}
			
			if (!in_array($ipaddr, $unique)) {
				$unique[] = $ipaddr;
				$www_unique_count ++;
			}
		}
		
		unset ($results);
		return count($unique);
	}
}


/**
*   Get live usage of disk from server
*/
function shapeSpace_disk_usage() {
	$disktotal = disk_total_space ('/');
	$diskfree  = disk_free_space  ('/');
	$diskuse   = round (100 - (($diskfree / $disktotal) * 100)) .'%';
	
	return $diskuse;
}


/**
*   Get time of availability on server
*/
function shapeSpace_server_uptime() {
	$str   = @file_get_contents('/proc/uptime');
	$num   = floatval($str);
	$secs  = fmod($num, 60); $num = (int)($num / 60);
	$mins  = $num % 60;      $num = (int)($num / 60);
	$hours = $num % 24;      $num = (int)($num / 24);
	$days  = $num;
	$uptime = floor(preg_replace ('/\.[0-9]+/', '', file_get_contents('/proc/uptime')) / 86400);
	
	return sprintf("%03d days, %02d hours, %02d min, %02d sec", $days, $hours, $mins, $secs); 
}


/**
*   Get Linux Kernel Version
*/
function shapeSpace_kernel_version() {
	$kernel = explode(' ', file_get_contents('/proc/version'));
	$kernel = $kernel[2];
	
	return $kernel;
}


/**
*   Get usage of memory
*/
function shapeSpace_server_memory_usage() {
	$free = shell_exec('free');
	$free = (string)trim($free);
	$free_arr = explode("\n", $free);
	$mem = explode(" ", $free_arr[1]);
	$mem = array_filter($mem);
	$mem = array_merge($mem);
	$memory_usage = $mem[2] / $mem[1] * 100;
 
	return $memory_usage;
}


/**
*   Get process number in server
*/
function shapeSpace_number_processes() {
	$proc_count = 0;
	$dh = opendir('/proc');
	
	while ($dir = readdir($dh)) {
		if (is_dir('/proc/' . $dir)) {
			if (preg_match('/^[0-9]+$/', $dir)) {
				$proc_count ++;
			}
		}
	}
	
	return $proc_count;
}


/**
*   Send Ping connection to destination Host
*/
function ping($host) {
    exec(sprintf('ping -c 1 -W 1 %s', escapeshellarg($host)), $res, $rval);
    return $rval === 0;
}


/**
*   Maintenance - Create OTP Zip for Backup
*/
function OTPZip($source, $destination) {
    if (!extension_loaded('zip') || !file_exists($source)) {
        return false;
    }

    $zip = new ZipArchive();
    if (!$zip->open($destination, ZIPARCHIVE::CREATE)) {
        return false;
    }

    $source = str_replace('\\', '/', realpath($source));

    if (is_dir($source) === true) {
        $files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($source), RecursiveIteratorIterator::SELF_FIRST);

        foreach ($files as $file) {
            $file = str_replace('\\', '/', $file);

            // Ignorer les dossiers commencants par "." et ".."
            if( in_array(substr($file, strrpos($file, '/')+1), array('.', '..')))
                continue;

            $file = realpath($file);

            if (is_dir($file) === true) {
                $zip->addEmptyDir(str_replace($source . '/', '', $file . '/'));
            } else if (is_file($file) === true) {
                $zip->addFromString(str_replace($source . '/', '', $file), file_get_contents($file));
            }
        }
    } else if (is_file($source) === true) {
        $zip->addFromString(basename($source), file_get_contents($source));
    }
    return $zip->close();
}


/**
*  	Get current link of page
*/
$actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";


/**
*   Customizations - Get Mailname of Linux Server
*/
$ProcGetMailName = shell_exec('cat /etc/mailname');
$GetMailName = str_replace("\n","", $ProcGetMailName);

/**
*   OTP Token & QR Code encoding functions
*/
$Pwd_PassPhrase = hash('md5', "dNk*`h)H&pYT2/Z9C%q_ktf;S/w>F_");

function EncodePassword($string) {
	global $Pwd_PassPhrase;

	$key = $Pwd_PassPhrase;
	$ivlen = openssl_cipher_iv_length($cipher="AES-128-CBC");
	$iv = openssl_random_pseudo_bytes($ivlen);
	$ciphertext_raw = openssl_encrypt($string, $cipher, $key, $options=OPENSSL_RAW_DATA, $iv);
	$hmac = hash_hmac('sha256', $ciphertext_raw, $key, $as_binary=true);
	return $ciphertext = base64_encode($iv.$hmac.$ciphertext_raw);
}

function DecodePassword($string) {
	global $Pwd_PassPhrase;

	$key = $Pwd_PassPhrase;
	$c = base64_decode($string);
	$ivlen = openssl_cipher_iv_length($cipher="AES-128-CBC");
	$iv = substr($c, 0, $ivlen);
	$hmac = substr($c, $ivlen, $sha2len=32);
	$ciphertext_raw = substr($c, $ivlen+$sha2len);
	$original_plaintext = openssl_decrypt($ciphertext_raw, $cipher, $key, $options=OPENSSL_RAW_DATA, $iv);
	$calcmac = hash_hmac('sha256', $ciphertext_raw, $key, $as_binary=true);
	if (hash_equals($hmac, $calcmac)) {
		return $original_plaintext;
	}
}


/**
*   Get Current date time from server
*/
function CurrentDateTime() {
	return date('Y-m-d h:i:s', time());
}


/**
*   Picture convertion to Base64 format
*/
function convertImageToBase64($imagePath) {
    $image = file_get_contents($imagePath);
    $base64String = base64_encode($image);
    return $base64String;   
}


/**
*   Check if a specific word exist in string
*/
function containsWord($str, $word) {
    return !!preg_match('#\b' . preg_quote($word, '#') . '\b#i', $str);
}


/**
*   Send Socket connection to resolve LDAP server
* 	Default Port : 636 for SSL, 389 non SSL
*	Default timeout value : 3
*/
function serviceping($host, $ssl, $timeout=3) {
	if ($ssl == "on") {
		$port = 636;
	} else {
		$port = 389;
	}

	$op = fsockopen($host, $port, $errno, $errstr, $timeout);
	if (!$op) {
		addLogEventOTP("[ERROR] Unable to open a TCP socket with " .$host . ":" . $port . " (". $errstr .")");
		return 0;
	} else {
		fclose($op); 
		addLogEventOTP("[SUCCESS] TCP socket opened with " . $host . ":".$port);
		return 1;
	}
}


/**
*   Test connectivity of destination SSH Server
* 	Default Port : SSH (22)
*	Default timeout value : 3
*/
function testopenssh($host, $timeout=3) {
	$port=22;
	$op = fsockopen($host, $port, $errno, $errstr, $timeout);
	
	if (!$op) {
		addLogEventOTP("[ERROR] Unable to open a TCP socket with " . $host . ":" . $port . " (". $errstr .")");
		return 0;
	} else {
		fclose($op); 
		addLogEventOTP("[SUCCESS] TCP socket opened with " . $host . ":".$port);
		return 1;
	}
}
?>