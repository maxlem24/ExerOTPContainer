<?php 
	// Dernières modifications le : 28/03/2022
	// Par : Laurent ASSELIN
	
include_once $_SERVER['DOCUMENT_ROOT'] . '/inc/translator.php';
class Session {
	public function __construct() {
		@session_start();
	}

	public function setFlash($message, $icon, $type = 'info') {
		$_SESSION['flash'] = array(
			'message'		=>		$message,
			'icon'			=>		$icon,
			'type'			=>		$type
		);
	}

	public function flash() {
		if (isset($_SESSION['flash'])) { ?>
			<!DOCTYPE html>
			<link rel="shortcut icon" type = "image/x-icon" href = "/assets/images/favicon.ico" /> 
			<link rel="icon" href = "/assets/images/favicon.ico" />
		
			<div id="notifyExerParent_<?= $_SESSION['flash']['type'] ?>" class="alert sjhd notexer-message-box notexer notexer-message-box-style--<?= $_SESSION['flash']['type'] ?>">
				<div class="notexer-message-box-inner">
					<span class="notexer-message-box-icon material-icons"><?= $_SESSION['flash']['icon'] ?></span>
					<span class="notexer-message-box-text">
						<p>
							<?= $_SESSION['flash']['message'] ?>
							<button id="close_notify_<?= $_SESSION['flash']['type'] ?>" type="button" class="close" title="<?= Translator('hide_notifications'); ?>">
								<span aria-hidden="true"><i class="far fa-times"></i></span>
							</button>
						</p>
					</span>
				</div>
			</div>
		<?php
			unset($_SESSION['flash']);
		}
	}
}
?>