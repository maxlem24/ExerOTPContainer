<?php
/**
*   @category EXER OTP Appliance
*   @author EXER SAS <support@exer.fr>
*   @copyright 2023 EXER
*   @api Header Component
*
*	@editedBY Laurent Asselin
*   @lastEdited 27/11/2023
*/
	
	include_once $_SERVER['DOCUMENT_ROOT'] . '/inc/class.exerotp.php';
?>

<!--	███████╗██╗  ██╗███████╗██████╗     -->
<!--	██╔════╝╚██╗██╔╝██╔════╝██╔══██╗    -->
<!--	█████╗   ╚███╔╝ █████╗  ██████╔╝    -->
<!--	██╔══╝   ██╔██╗ ██╔══╝  ██╔══██╗    -->
<!--	███████╗██╔╝ ██╗███████╗██║  ██║    -->
<!--	╚══════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝    -->
<!--	                                    -->
<!--	 ██████╗ ████████╗██████╗           -->
<!--	██╔═══██╗╚══██╔══╝██╔══██╗          -->
<!--	██║   ██║   ██║   ██████╔╝          -->
<!--	██║   ██║   ██║   ██╔═══╝           -->
<!--	╚██████╔╝   ██║   ██║               -->
<!--	 ╚═════╝    ╚═╝   ╚═╝               -->
<!--	      EXER OTP - www.exer.fr		-->
<!--	           EXER SAS			        -->

<!DOCTYPE html>
<html lang="fr">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="description" content="Exer OTP - Strong Authentication / MFA Solution">
		<meta name="author" content="Exer SAS">
		<meta name="creator" content="Exer SAS">
		<meta name="robots" content="noindex">
		<title><?= $WhiteLabel ?> - <?= $module_page_name ?></title>

		<link rel="canonical" href="/">
		
		<link rel="shortcut icon" type="image/x-icon" href="/assets/images/favicon.ico" /> 
		<link rel="icon" href="/assets/images/favicon.ico" />

		<link rel="stylesheet" href="/assets/styles/main.css">
		<link rel="stylesheet" href="/assets/styles/notexer.css">
		<link rel="stylesheet" href="/assets/libs/fontawesome/css/all.css">
		<link rel="stylesheet" href="/assets/libs/flag-icon-css/css/flag-icon.min.css">
		
		<!--Scripts-->
		<script type="text/javascript" src="/assets/scripts/jquery.min.js"></script>
		<script type="text/javascript" src="/assets/scripts/app.js"></script>
		<script type="text/javascript" src="/assets/scripts/scripts.js"></script>
		
		<!--Check Enable Javascript-->
		<noscript>
			<div class="bg_noscript_exerotp"></div>
			<style>body{overflow: hidden !important;}</style>
			<div class="noscript_exerotp">
				<div class="alert alert-danger" style="z-index:999999999" role="alert">
					<i class="fas fa-exclamation-triangle"></i> <?= Translator('javascript'); ?>
				</div>
			</div>
		</noscript>
		
		<?php 
			//Bloquer l'acces depuis Internet Explorer (compatibilité, beugs affichage)
			$ua = htmlentities($_SERVER['HTTP_USER_AGENT'], ENT_QUOTES, 'UTF-8');
			if (preg_match('~MSIE|Internet Explorer~i', $ua) || (strpos($ua, 'Trident/7.0') !== false && strpos($ua, 'rv:11.0') !== false)) { ?>
				<div id="show_if_ie">
					<div class="bg_noscript_exerotp"></div>
					<style>body{overflow: hidden !important;}</style>
					<div class="noscript_exerotp">
						<div class="alert alert-danger" style="z-index:999999999" role="alert">
							<i class="fas fa-exclamation-triangle"></i> <?= Translator('no_internet_explorer'); ?><br>
						</div>
					</div>
				</div>
		<?php } ?>
	</head>
	<body <?php if (basename($_SERVER['PHP_SELF']) != "firewall.php") { ?>onload="preloaderExerOtp();"<?php } ?>>
		<!--Loader Exer OTP-->
		<module-principal id="loader_exerotp" <?php if (basename($_SERVER['PHP_SELF']) == "firewall.php") { ?>style="display: none;"<?php } ?>>
		<div class="bg_noscript_exerotp" style="background: white; z-index: 0;"></div>
			<div class="text-center">
				<div class="container-spinner ng-busy">
					<span class="circle-spinner">
						<span class="left"><span class="anim"></span></span>
						<span class="right"><span class="anim"></span></span>
					</span>
					<exer class="txtLoaderExer"><?= Translator('LoadUI'); ?>...</exer>
				</div>
			</div>
		</module-principal>
	
		<nav class="navbar navbar-exerotp navbar-dark fixed-top bg-dark flex-md-nowrap p-0 shadow" <?php if (basename($_SERVER['PHP_SELF']) != "firewall.php") { ?>id ="navbarExerOtp" style="display: none;"<?php } ?>>
		
		<?php if (isset($_SESSION['id']) && (checkLevel() == ADMIN && $_SESSION['corp_logo'] != "not_defined") || (checkLevel() == OPERATOR && $_SESSION['corp'] != "NOT_DEFINED" && $_SESSION['corp_logo'] != "not_defined")) { ?>
		<a class="navbar-exer col-sm-3 col-md-2 mr-0" title="<?= $WhiteLabel ?> - <?= $_SESSION['corp_name'] ?>">
			<img src="<?= $_SESSION['corp_logo'] ?>" alt="Logo <?= $_SESSION['corp_name'] ?>" height="25">
		</a>
		<?php } elseif (isset($_SESSION['id'])) { ?>
		<?php if ($_SESSION['corp'] == "NOT_DEFINED" || $_SESSION['corp_logo'] != "not_defined" || checkLevel() != SUPERVISOR &&  $_SESSION['corp_logo'] == "not_defined") { ?>
		<a class="navbar-exer col-sm-3 col-md-2 mr-0" title="<?= $WhiteLabel ?>">
			<img src="/assets/images/brandmark.png" alt="Logo entreprise" height="25">
		</a>
		<?php } } ?>
		
		<?php if ($show_creds_usr == true) { ?>
		<label class="licence_corp_exer_otp">
			<?= $licence; ?>
		</label>
		<?php } ?>


	<ul class="navbar-nav px-3 aedsZA">
		<li class="nav-item ripple-effect ripple-dark text-nowrap bordernav__user_name">
			<?php if ($show_creds_usr == true) {
				$firstname 	= substr($_SESSION['firstname'], 0,15);
				$lastname 	= substr($_SESSION['lastname'], 0,7);
				$email 		= substr($_SESSION['email'], 0,15);
			?>
			<div class="dropdown">
				<a title='Connecté en tant que "<?= $username_auth ?>"<?= "\n\n" ?>Appuyer ici pour ouvrir le menu utilisateur.' class="nav-link dropdown-toggle fdhuj" href="javascript:void();" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					<img src="/assets/images/exer_user_default.png" class="rounded-circle default_avatar_exer" alt="default user exer" height="40" style="position: relative; top: -2px; margin-right: -9px;">
					<strong style="position: relative; top: 0px;" class="username_is_connected_appexerotpbtn"><?php echo $firstname; if (strlen($firstname) >= 15) { echo "..."; } echo " " . $lastname; if (strlen($lastname) >= 7) { echo "..."; } ?></strong>	
				</a>
				
				<ul class="dropdown-menu" style="position: absolute; left: -158px; top: 53px; border-radius: 0px; width: 325px; min-width: 0px; padding-left: 20px;">
					<li>
						<div class="navbar-content">
							<div class="row">
								<div class="col-md-5">
									<img src="/assets/images/exer_user_default.png" class="rounded-circle default_avatar_exer" alt="default user exer" alt="Avatar Utilisateur" class="img-responsive" style="position: relative; top: -1px; left: -5px; max-height: 7rem; border: 1px solid #D5E3EC;">
									<p class="text-center small">
										<a style="display:none;" href="javascript:void();">@<?= $_SESSION['username'] ?></a>
									</p>
								</div>
								<div class="col-md-7">
									<span title="<?= $_SESSION['firstname'] . " " . $_SESSION['lastname'] ?>">
										<?php echo $firstname; if (strlen($firstname) >= 15) { echo "..."; } echo " " . $lastname; if (strlen($lastname) >= 7) { echo "..."; } ?>
									</span>
									<p class="text-muted small" title="<?= $_SESSION['email'] ?>">
										<?php echo $email; if (strlen($email) >= 15) { echo "..."; } ?>
									</p>
									<p>
										<span class="text-bold text-secondary"><?php if ($_SESSION['level'] == 1) { echo Translator('Help-Desk_op'); } elseif ($_SESSION['level'] ==2 ) { echo Translator('Admin'); } elseif ($_SESSION['level'] == 3) { echo Translator('supervisor'); } ?></span>	
									</p>
									<div class="divider">
									</div>
									<a href="/account.php" class="exerotpbtn btn-defaultexer btn-sm ripple-effect ripple-white" style="margin-top: 10px;"><i class="fas fa-user dwnl_small_addelement_icon"></i> <?= Translator('MyAccount'); ?></a>
								</div>
							</div>
						</div>
						<div class="navbar-footer" style="background-color: #DDD; margin-left: -20px; margin-bottom: -8px; margin-top: 10px; padding-left: 30px;">
							<div class="navbar-footer-content">
								<a href="/logout.php" style="border-radius: 0px; margin-left: -30px; width: 110.5%;" class="btn btn-danger btn-sm pull-right"><?= Translator('Logout'); ?></a>
							</div>
						</div>
					</li>
				</ul>
			</div>
			<?php } ?>
		</li>
	</ul>
	
	<form method="post">
		<div class="dropdown nav-translator">
		
			<button class="nav-translator-btn dropdown-toggle ripple-effect ripple-white" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				<span class="flag-icon flag-icon-<?= $lang ?>"></span>
			</button>
			<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
				<button type="submit" class="dropdown-item" name="lang-fr"><span class="flag-icon flag-icon-fr"></span> Français</a>
				<button type="submit" class="dropdown-item" name="lang-en"><span class="flag-icon flag-icon-en"></span> English</a>
			</div>
			
		</div>
	</form>
	</nav>

	<div class="container-fluid" <?php if (basename($_SERVER['PHP_SELF']) != "firewall.php") { ?>id="showContentAfterLoader" style="display:none;"<?php } ?>>
		<div class="row">
			<?php if ($show_navbar == true) { ?>
				<nav class="col-md-2 d-none d-md-block bg-light sidebar">
				<div class="sidebar-sticky">
					<ul class="nav flex-column">
						<li class="nav-item ripple-effect ripple-dark">
							<a class="nav-link <?php if (basename($_SERVER['PHP_SELF']) == "index.php") { echo"active"; } ?>" href="/">
								<i class="feather feather-layers far fa-th"></i>
								<?= Translator('Overview'); ?> <span class="sr-only">(current)</span>
							</a>
						</li>
						<li class="nav-item ripple-effect ripple-dark">
							<?php if (checkLevel() != SUPERVISOR) { ?>
							<a class="nav-link <?php if (basename($_SERVER['PHP_SELF']) == "companies.php" AND $_SERVER['REQUEST_URI'] != "/companies.php?page=AddThisCorpUser") { echo"active"; } ?> <?php if ($licenceOK == false) { ?> disable_toggleexerbar<?php } ?>" <?php if ($licenceOK == false) { echo 'title=' . Translator('licence_module'); } ?> href="/companies.php">
							<?php } else { ?>
							<a class="nav-link <?php if (basename($_SERVER['PHP_SELF']) == "companies.php") { echo"active"; } ?> <?php if ($licenceOK == false) { ?> disable_toggleexerbar<?php } ?>" <?php if ($licenceOK == false) { echo 'title='.Translator('licence_module'); } ?> href="/companies.php">
							<?php } ?>
							<i class="feather feather-layers far fa-building"></i>
							<?php if ($_SESSION['corp'] != "NOT_DEFINED") { ?><?= Translator('Company'); ?> : <?= $_SESSION['corp_name'] ?><?php } else { ?><?= Translator('Companies'); ?><?php } ?>
							</a>
						</li>

						<?php if ($_SESSION['corp'] != "NOT_DEFINED" && checkLevel() != OPERATOR) { ?>
						<li class="nav-item ripple-effect ripple-dark">
							<a class="nav-link <?php if ($_SERVER['REQUEST_URI'] == "/companies.php?page=AddThisCorpUser") { echo"active"; } ?> <?php if ($licenceOK == false) { ?> disable_toggleexerbar<?php } ?>" <?php if ($licenceOK == false) { echo 'title='.Translator('licence_module'); } ?> href="/companies.php?page=AddThisCorpUser">
								<i class="feather feather-layers far fa-layer-plus"></i>
								<?= Translator('Create_user'); ?>
							</a>
						</li>
						<?php } ?>

						<li class="nav-item ripple-effect ripple-dark">
							<a class="nav-link <?php if (basename($_SERVER['PHP_SELF']) == "firewall.php") { echo"active"; } ?> <?php if ($licenceOK == false) { ?> disable_toggleexerbar<?php } ?>" <?php if ($licenceOK == false) { echo 'title='.Translator('licence_module'); } ?> href="/firewall.php">
								<i class="feather feather-layers far fa-shield-alt"></i>
								<?= Translator('Firewall'); ?>
							</a>
						</li>
						
						<li class="nav-item ripple-effect ripple-dark">
							<a class="nav-link <?php if (basename($_SERVER['PHP_SELF']) == "ldap.php") { echo"active"; } ?> <?php if ($licenceOK == false) { ?> disable_toggleexerbar<?php } ?>" <?php if ($licenceOK == false) { echo 'title='.Translator('licence_module'); } ?> href="/ldap.php">
								<i class="feather feather-layers far fa-book-open"></i>
								<?php 
									if ($_SESSION['level'] == SUPERVISOR) {
										echo Translator('LDAPInterconnections');
									} else {
										echo Translator('LDAPInterconnection');
									}
								?>
							</a>
						</li>

						<li class="nav-item ripple-effect ripple-dark">
							<a class="nav-link <?php if (basename($_SERVER['PHP_SELF']) == "customizations.php") { echo"active"; } ?> <?php if ($licenceOK == false) { ?> disable_toggleexerbar<?php } ?>" <?php if ($licenceOK == false) { echo 'title='.Translator('licence_module'); } ?> href="/customizations.php">
								<i class="feather feather-layers far fa-paint-brush"></i>
								<?= Translator('Customizations'); ?>
							</a>
						</li>
						
						<?php if ((checkLevel() == OPERATOR && $_SESSION['corp'] == "NOT_DEFINED") || checkLevel() == SUPERVISOR) { ?>
						<li class="nav-item ripple-effect ripple-dark">
							<a class="nav-link <?php if (basename($_SERVER['PHP_SELF']) == "audits.php") { echo"active"; } ?> <?php if ($licenceOK == false) { ?> disable_toggleexerbar<?php } ?>" <?php if ($licenceOK == false) { echo 'title='.Translator('licence_module'); } ?> href="/audits.php">
								<i class="feather feather-layers far fa-scroll"></i>
								<?= Translator('OTPAudit'); ?>
							</a>
						</li>
						<?php } ?>
					
						<?php if (checkLevel() != OPERATOR) { ?>
						<li class="nav-item ripple-effect ripple-dark">
							<a class="nav-link <?php if (basename($_SERVER['PHP_SELF']) == "users.php") { echo"active"; } ?> <?php if ($licenceOK == false) { ?> disable_toggleexerbar<?php } ?>" <?php if ($licenceOK == false) { echo 'title='.Translator('licence_module'); } ?> href="/users.php">
								<i class="feather feather-layers far fa-users"></i>
								<?= Translator('Administrators'); ?>
							</a>
						</li>
						<?php } ?>

						<?php if ((checkLevel() == ADMIN) OR ((checkLevel() == OPERATOR) AND ($_SESSION['corp'] != "NOT_DEFINED"))) { ?>
						<li class="nav-item ripple-effect ripple-dark">
							<a class="nav-link <?php if (basename($_SERVER['PHP_SELF']) == "maintenance.php") { echo"active"; } ?> <?php if ($licenceOK == false) { ?> disable_toggleexerbar<?php } ?>" <?php if ($licenceOK == false) { echo 'title='.Translator('licence_module'); } ?> href="/maintenance.php">
								<i class="feather feather-layers far fa-tools"></i>
								<?= Translator('Maintenance'); ?>
							</a>
						</li>
						<?php } ?>

						<?php if ((checkLevel() == SUPERVISOR) OR ((checkLevel() == OPERATOR) AND ($_SESSION['corp'] == "NOT_DEFINED"))) { ?>
						<li class="nav-item ripple-effect ripple-dark">
							<a class="nav-link <?php if (basename($_SERVER['PHP_SELF']) == "maintenance.php") { echo"active"; } ?>" href="/maintenance.php">
								<i class="feather feather-layers far fa-tools"></i>
								<?= Translator('Maintenance'); ?>
							</a>
						</li>
						<li class="nav-item ripple-effect ripple-dark">
							<a class="nav-link <?php if (basename($_SERVER['PHP_SELF']) == "server.php") { echo"active"; } ?>" href="/server.php">
								<i class="feather feather-layers far fa-server"></i>
								<?= Translator('Server'); ?>
							</a>
						</li>


						 <li class="nav-item ripple-effect ripple-dark">
                           	<a class="nav-link <?php if (basename($_SERVER['PHP_SELF']) == "cluster.php") { echo"active"; } ?> <?php if ($licenceOK == false) { ?> disable_toggleexerbar<?php } ?>" <?php if ($licenceOK == false) { echo 'title='.Translator('licence_module'); } ?> href="/cluster.php">
                            	<i class="feather feather-layers far fa-copy"></i>
                                <?= Translator('HA'); ?> <span class="sr-only">(current)</span>
                            </a>
                         </li>
						<?php } ?>
					</ul>

					<h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
						<span>
							<br>
							<?= $version_otp; ?>
							<br>
							&copy; <?= date('Y') ?> - <?= Translator('AllRightReserved'); ?>
						</span>
					</h6>
				</div>
				</nav>
			<?php } ?>

		<!--debut module-->
