<?php 
	$module_page_name = "403 Accès refusé...";
	$show_navbar = false;
	$show_creds_usr = false;
	include $_SERVER['DOCUMENT_ROOT'] . '/inc/header.php'; 
	
	$actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
?>

	<main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
		<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
			<h1 class="h2"><?= $module_page_name ?></h1>
		</div>
			<exer>Vous ne disposez pas des autorisations suffisante pour accéder au contenu.</b></exer><br>
			<label>Si nécessaire, veuillez contacter le support technique pour obtenir de l'aide.</label><br><br>
			
			Contact : <a href="mailto://<?= htmlspecialchars($_SERVER['SERVER_ADMIN']) ?>"><?= htmlspecialchars($_SERVER['SERVER_ADMIN']) ?></a>
			
			<form action="/" method="POST">
				<p>
				<br>
					<button type="submit" name="reloggin_exerotp" class="exerotpbtn btn-defaultexer ripple-effect ripple-white"><i class="far fa-home"></i> Accueil</button> 
					<a href="<?= $actual_link ?>"><button type="button" class="exerotpbtn btn-defaultexer ripple-effect ripple-white"><i class="far fa-sync"></i> Actualiser</button></a>
				</p>
			</form>
	</main>
<?php include $_SERVER['DOCUMENT_ROOT'] . '/inc/footer.php'; ?>