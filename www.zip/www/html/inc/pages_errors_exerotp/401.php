<?php 
	$module_page_name = "Erreur lors de l'authentification du client...";
	$show_navbar = false;
	$show_creds_usr = false;
	include $_SERVER['DOCUMENT_ROOT'] . '/inc/header.php'; 
?>

	<main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
		<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
			<h1 class="h2"><?= $module_page_name ?></h1>
		</div>
			<strong>Oups... Quelque chose ne s'est pas bien passé...</strong><br>
			
			Le serveur n'a pas pu vérifier l'authentification...<br>
			Vous avez fourni des informations d'identification incorrectes comme un mot de passe incorrect par exemple.<br><br>

			Si le problème persiste, veuillez nous contacter <a href="https://support.exer.fr" target="_blank" title="Contacter le support technique d'EXER">ici</a>.
			
			<br><br>
			
			Contact : <a href="mailto://<?= htmlspecialchars($_SERVER['SERVER_ADMIN']) ?>"><?= htmlspecialchars($_SERVER['SERVER_ADMIN']) ?></a>
			<form action="/" method="POST">
				<p>
				<br>
					<button type="submit" name="reloggin_exerotp" class="exerotpbtn btn-defaultexer ripple-effect ripple-white">Réessayer...</button>
				</p>
			</form>
	</main>
<?php include $_SERVER['DOCUMENT_ROOT'] . '/inc/footer.php'; ?>