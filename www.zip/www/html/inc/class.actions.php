<?php
	// Dernière modification le :02/05/2022
	// Par: Laurent ASSELIN
	
	include $_SERVER['DOCUMENT_ROOT'] . '/inc/class.exerotp.php';

	if (isset($_GET['VerbAction'])) {
		$VerbAction = htmlspecialchars($_GET['VerbAction']);
	} else {
		$VerbAction = NULL;
	}
	include_once $_SERVER['DOCUMENT_ROOT'] . '/inc/translator.php';
	
	?>
	<?php
		if ($VerbAction == "ExportAll") {
			if ($_SESSION['level'] == 3) {
				//obligée de mettre sudo
				$verification = shell_exec("sudo bachup.sh");
				$verification = str_replace("\n","",$verification);
				if (strcmp($verification, "done") == 0) {
					$dirupdate = shell_exec("cd /var/www/backup/global_backup ; ls -1t | head -1");
					$dirupdate = str_replace("\n","",$dirupdate); 
					$filename 		= $dirupdate .".zip";
					$filepath 		= "/var/www/backup/global_backup/" . $dirupdate . "/".$filename;

					header('Content-Description: File Transfer');
					header('Content-Type: application/octet-stream');
					header('Content-Disposition: attachment; filename="'.$filename.'"');
					header('Content-Transfer-Encoding: binary');
					header('Connection: Keep-Alive');
					header('Expires: 0');
					header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
					header('Pragma: public');
					header('Content-Length: ' . filesize($filepath));
					ob_end_clean();
					addLogEventOTP("[SUCCESS] The file " . $filename . " has been downloaded by " . $_SESSION['username'] . ".");
					readfile($filepath);
					exit();
				} else {
					addLogEventOTP("[ERROR] There was a problem while downloading " . $filename . " by ".  $_SESSION['username'] . ".");
					$Session->setFlash(Translator('problem_downloading'), "close", "error");
					header('Location: /maintenance.php');
					exit();
				}
			} else {
				addLogEventOTP("[ERROR] You do not have the required permissions to perform this action ". $_SESSION['username'] . ".");
				$Session->setFlash(Translator('access_denied'), "close", "error");
				header('Location: /maintenance.php');
				exit();
			}
		} elseif ($VerbAction == "DeleteCompany") {
			if (!isset($_SESSION['token_access_deletecorp'])) {
				header('Location: /companies.php');
				exit();
			} else {
				$RefTokenID = htmlspecialchars($_SESSION['token_access_deletecorp']);
				$recup_corps = $db->prepare('SELECT * FROM otp_companies WHERE token = ? ORDER BY id DESC');
				$recup_corps->execute(array($RefTokenID));
				$ft_corp = $recup_corps->fetch();
				$countCorp = $recup_corps->rowCount();
				
				if ($countCorp ==0) {
					$Session->setFlash(Translator('compagny_not_found'), "close", "error");
					header('Location: /companies.php');
					exit();
				} else {
					//recupération du nom du fichier de l'entreprise
					$folder_name_corp_req = $db->prepare('SELECT folder FROM otp_companies WHERE token = ? ORDER BY id DESC');
					$folder_name_corp_req->execute(array($RefTokenID));
					$fold_name_corp_rec = $folder_name_corp_req->fetch();
					$folder_name_corp = $fold_name_corp_rec['folder'];

					//Suppression de la personnalisation du mailing de l'entreprise
					$DelCustom = $db->prepare('DELETE FROM otp_mailing WHERE corpid = ?');
					$DelCustom->execute(array($ft_corp['corpid']));

					//Supression SQL de l'entreprises
					$del_corp = $db->prepare('DELETE FROM otp_companies WHERE token = ? ORDER BY id DESC');
					$del_corp->execute(array($RefTokenID));
					$nomclient = $ft_corp['folder'];
					
					//Récupration des éventuels utilisateurs appartenant à l'entreprise
					$recup_all_user_corp = $db->prepare('SELECT * FROM otp_tokens WHERE corpid = ?');
					$recup_all_user_corp->execute(array($ft_corp['corpid']));
					
					while ($proc_del_usr = $recup_all_user_corp->fetch()) {
						// Supression SQL de des éventuels utilisateurs appartenant à l'entreprise
						$del_usr_corp = $db->prepare('DELETE FROM otp_tokens WHERE corpid = ?');
						$del_usr_corp->execute(array($ft_corp['corpid']));
					}
					
					// Suppression de l'entreprise sur linux
					$escaped_command = escapeshellcmd("sudo rm -rf /home/'$folder_name_corp'");
					shell_exec($escaped_command);

					// Delete all data (fixed)
					shell_exec("sudo rm -rf /etc/pam.d/radiusd_'$folder_name_corp'");
					shell_exec("sudo rm -rf /etc/freeradius/mods-available/pam_'$folder_name_corp'");
					shell_exec("sudo rm -rf /etc/freeradius/mods-enabled/pam_'$folder_name_corp'");
					shell_exec("sudo rm -rf /etc/freeradius/sites-available/'$folder_name_corp'");
					shell_exec("sudo rm -rf /etc/freeradius/sites-enabled/'$folder_name_corp'");
					
					// Delete MFA
					shell_exec("sudo rm -rf /etc/pam.d/radiusd_'$folder_name_corp'_mfa");
					shell_exec("sudo rm -rf /etc/freeradius/mods-available/pam_'$folder_name_corp'_mfa");
					shell_exec("sudo rm -rf /etc/freeradius/mods-enabled/pam_'$folder_name_corp'_mfa");
					shell_exec("sudo rm -rf /etc/freeradius/sites-available/'$folder_name_corp'_mfa");
					shell_exec("sudo rm -rf /etc/freeradius/sites-enabled/'$folder_name_corp'_mfa");
					
      			  	$escaped_command = escapeshellcmd($escaped_command);
      			  	shell_exec("sudo service freeradius restart");

					// Supression de l'administrateur SQL associé
					$del_admin_sql = $db->prepare('DELETE FROM otp_users WHERE corp = ?');
					$del_admin_sql->execute(array($ft_corp['corpid']));

					// Supression des connexions LDAP associées à l'entreprise à supprimer
					$req_ldap_del = $db->prepare('SELECT * FROM otp_ldap WHERE corpid = ?');
					$req_ldap_del->execute(array($ft_corp['corpid']));
					
					while ($dumpInfLdapDel = $req_ldap_del->fetch()) {
						$del_admin_sql = $db->prepare('DELETE FROM otp_ldap WHERE corpid = ?');
						$del_admin_sql->execute(array($ft_corp['corpid']));

						$nas_name = $ft_corp['folder'];

						//Commande suppression fichier LDAP sur le serveur
						$escaped_command = escapeshellcmd('sudo rm /etc/pam_ldap_'.$nas_name.'.conf');
						shell_exec($escaped_command);
					}

					// Supression des pares-feux associées à l'entreprise à supprimer
					$req_firewall_del = $db->prepare('SELECT * FROM otp_firewall WHERE corpid = ?');
					$req_firewall_del->execute(array($ft_corp['corpid']));
					
					while ($dumpInfLdapDel = $req_firewall_del->fetch()) {
						$array_spaces 		= 	array(" ", " ", " ");
						$firename_get		=	strtolower(str_replace($array_spaces, "_", $dumpInfLdapDel['short_name']));
						
						//Appel au script de supression du pare feu
						shell_exec("cd /usr/local/bin/ && ./rm_nas_client.sh -f '$firename_get'");

						//Supression SQL du pare feu sélectionné
						$del_firewall = $db->prepare('DELETE FROM otp_firewall WHERE corpid = ?');
						$del_firewall->execute(array($dumpInfLdapDel['corpid']));
						
						//Ajout action dans les logs d'EXER otp si l'action a réussie
						addLogEventOTP("[SUCCESS] The RADIUS client " . $dumpInfLdapDel['short_name'] . " has been successfully deleted by " . $_SESSION['username'] . ".");
					
						// Vérifier si il s'agit d'un pare feu + d'un LDAP
						if ($dumpInfLdapDel['2auth'] == 1) {
							$recupCorpInfos = $db->prepare('SELECT * FROM otp_companies WHERE corpid = ?');
							$recupCorpInfos->execute(array($ft_firewall['corpid']));
							$ftCorpInfos = $recupCorpInfos->fetch();

							// Suppression SQL de l'authentification LDAP sélectionnée
							$del_this_ldap = $db->prepare('DELETE FROM otp_ldap WHERE corpid = ?');
							$del_this_ldap->execute(array($ft_firewall['corpid']));
							$nas_name = htmlspecialchars($ftCorpInfos['folder']);
							
							// Commande suppression fichier LDAP sur le serveur
							$escaped_command = escapeshellcmd('sudo rm /etc/pam_ldap_'.$nas_name.'.conf');
							shell_exec($escaped_command);

						}
					}

					// Ajout actions dans les logs d'EXER otp si les actions ont réussies
					addLogEventOTP("[SUCCESS] Company " . $ft_corp['name'] . " and its associated data have been deleted by " . $_SESSION['username']);
					$Session->setFlash(Translator('deleted_compagny'), "check", "success");
					
					unset($_SESSION['token_access_deletecorp']);
					header('Location: /companies.php');

					exit();
				}
			}
		} elseif ($VerbAction == "DeleteUserCorp") {
			if (!isset($_SESSION['token_access_deleteusrcorp'])) {
				header('Location: /companies.php');
				exit();
			} else {
				$RefTokenIDFireWall = htmlspecialchars($_SESSION['token_access_deleteusrcorp']);
				$RefLoginIDFireWall = htmlspecialchars($_SESSION['login_access_deleteusrcorp']);
				$recup_flw = $db->prepare('SELECT * FROM otp_tokens WHERE token = ?');
				$recup_flw->execute(array($RefTokenIDFireWall));
				$recup_data = $recup_flw->fetch();
				$countUsrFwl = $recup_flw->rowCount();
				
				if ($countUsrFwl ==0) {
					$Session->setFlash(Translator('User_cannot_found'), "close", "error");
					header('Location: /companies.php');
					exit();
				} else {
					//Suppression SQL de l'utilisateur
					$del_corp = $db->prepare('DELETE FROM otp_tokens WHERE login = ? AND id = ?');
					$del_corp->execute(array($RefLoginIDFireWall, $recup_data['id']));
					
					$recup_corp = $db->prepare('SELECT * FROM otp_companies WHERE corpid = ?');
					$recup_corp->execute(array($recup_data['corpid']));
					$recup_name_corpfolder = $recup_corp->fetch();
					$del_user = strtolower($recup_data['login']);
					
					//Suppression du dossier de l'utilisateur
					$escaped_command = escapeshellcmd("sudo rm -rf /home/" . $recup_name_corpfolder['folder'] . "/" . $del_user);
					shell_exec($escaped_command);
					
					//Ajout actions dans les logs d'EXER otp si les actions ont réussies
					addLogEventOTP("[SUCCESS] The user " . $recup_data['login'] . " has been successful deleted by " . $_SESSION['username'] . ".");
					
					$Session->setFlash(Translator('the_Username') ." " . $recup_data['login'] ." ". Translator('successful-delete'), "check", "success");
					
					if ($_SESSION['redirect_url'] == "/companies.php?page=ViewUser") {
						header('Location: /companies.php');
						exit();
					} else {
						$page = $_SERVER["HTTP_REFERER"];
						header('Location: ' . $page);
						exit();
					}
					
					unset($_SESSION['token_access_deleteusrcorp']);
					unset($_SESSION['login_access_deleteusrcorp']);
					unset($_SESSION['redirect_url']);

					exit();
				}
			}
		} elseif ($VerbAction == "DeleteLdapAuth") {
			if (!isset($_SESSION['token_access_deleteldap'])) {
				header('Location: /companies.php');
				exit();
			} else {
				$RefTokenIDLdap = htmlspecialchars($_SESSION['token_access_deleteldap']);
				$recup_ldap = $db->prepare('SELECT * FROM otp_ldap WHERE token = ?');
				$recup_ldap->execute(array($RefTokenIDLdap));
				$ft_ldapauth = $recup_ldap->fetch();

				$recupCorpInfos = $db->prepare('SELECT * FROM otp_companies WHERE corpid = ?');
				$recupCorpInfos->execute(array($ft_ldapauth['corpid']));
				$ftCorpInfos = $recupCorpInfos->fetch();

				$countLdapAuth = $recup_ldap->rowCount();
				
				if ($countLdapAuth == 0) {
					$Session->setFlash(Translator('cannot_found_ldap_connection'), "close", "error");
					header('Location: /ldap.php');
				} else {
					// Suppression SQL de l'authentification LDAP sélectionnée
					$del_this_ldap = $db->prepare('DELETE FROM otp_ldap WHERE token = ?');
					$del_this_ldap->execute(array($RefTokenIDLdap));
					$nas_name = htmlspecialchars($ftCorpInfos['folder']);
					
					// Commande suppression fichier LDAP sur le serveur
					$escaped_command = escapeshellcmd('sudo rm /etc/pam_ldap_'.$nas_name.'.conf');
					shell_exec($escaped_command);
					
					// Ajout action dans les logs d'EXER otp si l'action a réussie
					addLogEventOTP("[SUCCESS] The LDAP authentication " . $ft_ldapauth['base_dn'] . " has been successful deleted by " . $_SESSION['username'] . ".");
					
					$Session->setFlash(Translator('auth_ldap_delted'), "check", "success");
					
					unset($_SESSION['clientname_se']);
					$page = $_SERVER["HTTP_REFERER"];
					header('Location: ' . $page);

					exit();
				}
			}
		} elseif ($VerbAction == "DeleteActif") {
			$recup_actif = $db->prepare('SELECT * FROM otp_actif WHERE id = ?');
			$recup_actif->execute(array($_SESSION['subscriber_to_delete']));
			$ft_actif = $recup_actif->fetch();
			$countActif = $recup_actif->rowCount();
			
			if ($countActif == 0) {
				$Session->setFlash(Translator('vm_otp_not_found'), "close", "error");
				header('Location: /cluster.php');
				exit();
			} else {
				//Supression SQL du pare feu sélectionné
				$del_actif = $db->prepare('DELETE FROM otp_actif WHERE id = ?');
				$del_actif->execute(array($ft_actif['id']));	
				//Appel au script de supression de la VM
				$output = null;
				$retval = null;
				exec("sudo bash /usr/local/bin/deletesub.sh -H " . $ft_actif['ip_publisher']. " -s " . $ft_actif['ip_subscriber'], $output, $retval);
				if($retval == 0){
					//Ajout action dans les logs d'EXER otp si l'action a réussie
					addLogEventOTP("[SUCCESS] The OTP VM " . $ft_actif['ip_subscriber'] . " has been successful deleted by " . $_SESSION['username']);
					$Session->setFlash(Translator('vm_deleted_ok'), "check", "success");
					unset($_SESSION['subscriber_to_delete']);
					$page = $_SERVER["HTTP_REFERER"];
					header('Location: ' . $page);
					exit();
				}
				else{
					$Session->setFlash(Translator('vm_deleted'), "close", "error");
					unset($_SESSION['subscriber_to_delete']);
					$page = $_SERVER["HTTP_REFERER"];
					header('Location: ' . $page);
					exit();
				}
				}
		}
		 elseif ($VerbAction == "DeleteFirewall") {
			if (!isset($_SESSION['token_access_deletefirewall'])) {
				header('Location: /companies.php');
				exit();
			} else {
				$RefTokenID = htmlspecialchars($_SESSION['token_access_deletefirewall']);
				$RefFolderName = htmlspecialchars($_SESSION['folderFireDelete']);
				$recup_firewall = $db->prepare('SELECT * FROM otp_firewall WHERE tokenID = ?');
				$recup_firewall->execute(array($RefTokenID));
				$ft_firewall = $recup_firewall->fetch();
				$countFirewall = $recup_firewall->rowCount();
				
				if ($countFirewall == 0) {
					$Session->setFlash(Translator('cant_find_firewall'), "close", "error");
					header('Location: /firewall.php');
					exit();
				} else {
					//Supression SQL du pare feu sélectionné
					$del_firewall = $db->prepare('DELETE FROM otp_firewall WHERE tokenID = ?');
					$del_firewall->execute(array($RefTokenID));
					$nas_name = $ft_firewall['client'];

					$array_spaces 		= 	array(" ", " ", " ");
					$firename_get		=	strtolower(str_replace($array_spaces, "_", $ft_firewall['short_name']));
					
					//Appel au script de supression du pare feu
					shell_exec("cd /usr/local/bin/ && ./rm_nas_client.sh -f '$firename_get'");
					
					//Ajout action dans les logs d'EXER otp si l'action a réussie
					addLogEventOTP("[SUCCESS] The RADIUS client " . $ft_firewall['short_name'] .  " has been successfully deleted by " . $_SESSION['username'] . ".");
					
					$Session->setFlash(Translator('firewall_deleted_ok'), "check", "success");
					
					unset($_SESSION['token_access_deletefirewall']);
					
					$page = $_SERVER["HTTP_REFERER"];
					header('Location: ' . $page);
					exit();
				}
			}
		} else {
			$Session->setFlash(Translator('invalid_argument'), "close", "error");
			header('Location: /');
			exit();
		}
	?>