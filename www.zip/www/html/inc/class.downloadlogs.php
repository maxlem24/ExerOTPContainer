<?php
// Dernières modifications le 12/04/2022
// Par : Laurent ASSELIN

	include 'class.exerotp.php';
	include_once $_SERVER['DOCUMENT_ROOT'] . '/inc/translator.php';

	if ($_SESSION['level'] == 2)  {
		$Session->setFlash(Translator('access_denied'), "close", "error");
		header('Location: /');
		exit();
	}
	
	if ($_SESSION['level'] > 3)  {
		$Session->setFlash(Translator('access_denied'), "close", "error");
		header('Location: /');
		exit();
	}
	
	if ($_SESSION['level'] < 1)  {
		$Session->setFlash(Translator('access_denied'), "close", "error");
		header('Location: /');
		exit();
	}
	
	if (($_SESSION['level'] == 1) AND ($_SESSION['corp'] != "NOT_DEFINED"))  {
		$Session->setFlash(Translator('access_denied'), "close", "error");
		header('Location: /');
		exit();
	}
	

	if (isset($_GET['verb'])) {
		$verb = htmlspecialchars($_GET['verb']);
	} else {
		$verb = NULL;
	}

	if (isset($_GET['filelog'])) {
		$filelog = htmlspecialchars($_GET['filelog']);
	} else {
		$filelog = NULL;
	}

	if (!isset($_SESSION['crftoken_dnwl_logs']) && $_SESSION['crftoken_dnwl_logs'] != "NsFjZVuu6SJYKVqXknt4pJEhtHnq9umGArkk5Je7UcVaZFEzH3UAwYsfvt5RJKNhTFtYeHzVb9MnGHFSyhZMw6hKEATfvS7ycDC4ZjrHexdeJMJtZmM7tcnJyWaucxsd") {
		$Session->setFlash(Translator('transfer_token'), "close", "error");
		header('Location: /maintenance.php');
	}

	if (!empty($_GET['verb'])) {
		if ($verb == "download") {
			if ($filelog == "EventsAuth") {
				// Create archiver
				$CurrentDate = date("dmYHi");
				$FullPath = "/var/www/tmp/AuthLogs_".$CurrentDate.".zip";
				shell_exec("zip -r ".$FullPath." /var/log/auth.log*");

				// Download file
				$FileName = basename($FullPath);
				$date = gmdate(DATE_RFC1123);
				ini_set('zlib.output_compression', 0);
				
				// Headers
				header('Content-Description: File Transfer');
				header('Content-Type: application/octet-stream');
				header('Content-Disposition: attachment; filename="'.$FileName.'"');
				header('Content-Transfer-Encoding: binary');
				header('Connection: Keep-Alive');
				header('Expires: 0');
				header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
				header('Pragma: public');
				header('Content-Length: ' . filesize($FullPath));
				ob_end_clean();
				
				readfile($FullPath);
				shell_exec("rm ".$FullPath."");

				unset($_SESSION['crftoken_dnwl_logs']);
				addLogEventOTP("[INFORMATION] The WebUI user " . $_SESSION['username'] . " has downloaded the WebUI Audit log file");
				exit();
			} elseif ($filelog == "EventsFreeradius") {
				// Create archiver
				$CurrentDate = date("dmYHi");
				$FullPath = "/var/www/tmp/FreeradiusLogs_".$CurrentDate.".zip";
				shell_exec("zip -r ".$FullPath." /var/log/radius.log*");

				// Download file
				$FileName = basename($FullPath);
				$date = gmdate(DATE_RFC1123);
				ini_set('zlib.output_compression', 0);
				
				// Headers
				header('Content-Description: File Transfer');
				header('Content-Type: application/octet-stream');
				header('Content-Disposition: attachment; filename="'.$FileName.'"');
				header('Content-Transfer-Encoding: binary');
				header('Connection: Keep-Alive');
				header('Expires: 0');
				header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
				header('Pragma: public');
				header('Content-Length: ' . filesize($FullPath));
				ob_end_clean();
				
				readfile($FullPath);
				shell_exec("rm ".$FullPath."");

				unset($_SESSION['crftoken_dnwl_logs']);
				addLogEventOTP("[INFORMATION] The WebUI user " . $_SESSION['username'] . " has downloaded Freeradius Server log files.");
				exit();
			} elseif ($filelog == "EventsOTP") {
				// Create archiver
				$CurrentDate = date("dmYHi");
				$FullPath = "/var/www/tmp/OTPEventsLogs_".$CurrentDate.".zip";
				shell_exec("zip -r ".$FullPath." /var/www/logs_otp/actions_otp.log*");

				// Download file
				$FileName = basename($FullPath);
				$date = gmdate(DATE_RFC1123);
				ini_set('zlib.output_compression', 0);
				
				// Headers
				header('Content-Description: File Transfer');
				header('Content-Type: application/octet-stream');
				header('Content-Disposition: attachment; filename="'.$FileName.'"');
				header('Content-Transfer-Encoding: binary');
				header('Connection: Keep-Alive');
				header('Expires: 0');
				header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
				header('Pragma: public');
				header('Content-Length: ' . filesize($FullPath));
				ob_end_clean();

				readfile($FullPath);
				shell_exec("rm ".$FullPath."");

				unset($_SESSION['crftoken_dnwl_logs']);
				addLogEventOTP("[INFORMATION] The WebUI user " . $_SESSION['username'] . " has downloaded the authentication log files.");
				exit();
			} else {
				$Session->setFlash(Translator('invalid_argument'), "close", "error");
				header('Location: /maintenance.php');
				exit();
			}
		} else {
			$Session->setFlash(Translator('invalid_argument'), "close", "error");
			header('Location: /maintenance.php');
			exit();
		}
	}
?>