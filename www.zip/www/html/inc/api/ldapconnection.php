<?php
// Dernières modifications effectuées le 27/11/2023
// par Laurent ASSELIN 

include $_SERVER['DOCUMENT_ROOT'] . '/inc/class.exerotp.php';
include_once $_SERVER['DOCUMENT_ROOT'] . '/inc/translator.php';

if (!isset($_SESSION['id'])) {
    die('<label style="color:red;">Forbidden... Please log in</label>');
} else {
    if (!isset($_SESSION['BindParamsLDAPclient'])) {
        die('<label style="color:red;">Invalid request from client</label>');
    } else {
        $BindTokenLDAP = htmlspecialchars($_SESSION['BindParamsLDAPclient']);

        $Ldaps = $db->prepare('SELECT * FROM otp_ldap WHERE token = ?');
        $Ldaps->execute(array($BindTokenLDAP));
        $CountLdap = $Ldaps->rowCount();
        $Ldap = $Ldaps->fetch();

        $Companies = $db->prepare('SELECT * FROM otp_companies WHERE corpid = ?');
        $Companies->execute(array($Ldap['corpid']));
        $Company = $Companies->fetch();

        $InsertCmdlet = 'grep -r bindpw /etc/pam_ldap_' . $Company['folder'] . '.conf';
        $RunCmdlet = escapeshellcmd($InsertCmdlet);
        $GetLdapPassword = shell_exec($RunCmdlet);
        $ldap_password = trim(preg_replace('/\s+/', ' ', str_replace('bindpw ', "", $GetLdapPassword)));

        if ($CountLdap == 0) {
            die("<label style=\"color:red;\">" . Translator('LDAP_interconnect_not_found') . "</label>");
        } else {

            $ldap_columns       = NULL;
            $ldap_connection    = NULL;
            $ldap_username      = $Ldap['binddn'];
            $sslproto            = $Ldap['sslproto'];

            //------------------------------------------------------------------------------
            // Connect to the LDAP server.
            //------------------------------------------------------------------------------
            if ($sslproto == "on") {
                $ldapproto = "ldaps://";
            } else {
                $ldapproto = "ldap://";
            }

            $LDAP_reachable = "";

            if (serviceping($Ldap['ldap_uri'], $sslproto) == true) {
                $LDAP_reachable = $ldapproto . $Ldap['ldap_uri'];
            } elseif (!empty($Ldap['ldap_uri2'])) {
                if (serviceping($Ldap['ldap_uri2'], $sslproto) == true) {
                    $LDAP_reachable = $ldapproto . $Ldap['ldap_uri2'];
                }
            }

            if ($LDAP_reachable == "") {
                echo '<div class="alert alert-danger" role="alert"><i class="fas fa-exclamation-triangle"></i> ';
                echo Translator('unable_TCP_connection_to_LDAP') . $ldapproto . $Ldap['ldap_uri'] . '<br>';
                if (!empty($Ldap['ldap_uri2'])) {
                    echo '<i class="fas fa-exclamation-triangle"></i> ';
                    echo Translator('unable_TCP_connection_to_LDAP') . $ldapproto . $Ldap['ldap_uri2'] . '<br>';
                }
                echo Translator('check_availability');
                echo '</div>';
                exit();
            }

            $ldap_connection = ldap_connect($LDAP_reachable);
            ldap_set_option($ldap_connection, LDAP_OPT_PROTOCOL_VERSION, 3) or die('Error: Unable to determine ldap server version.');
            ldap_set_option($ldap_connection, LDAP_OPT_REFERRALS, 0);
            //ldap_set_option($ldap_connection, LDAP_OPT_SIZELIMIT, 3000);  

            if (ldap_bind($ldap_connection, $ldap_username, $ldap_password) !== true) {
                echo '<div class="alert alert-danger" role="alert"><i class="fas fa-exclamation-triangle"></i> ';
                echo Translator('Cannot_connect_LDAP');
                echo '</div>';
                echo Translator('Server') . $LDAP_reachable . " - " . ldap_error($ldap_connection) . " (error code : " . ldap_errno($ldap_connection) . ")";
                addLogEventOTP("[ERROR] LDAP Authentication failed : " . $LDAP_reachable . " - " . ldap_error($ldap_connection) . " (error code : " . ldap_errno($ldap_connection) . "");
                exit();
            }

            //------------------------------------------------------------------------------
            // Get a list of all Active Directory users.
            //------------------------------------------------------------------------------
            $ldap_base_dn = $Ldap['base_dn'];
            $search_filter = htmlspecialchars_decode($_SESSION['tra_ldapfilter']);
            $result = @ldap_search($ldap_connection, $ldap_base_dn, $search_filter);

            if (ldap_errno($ldap_connection) == "-1") {
                echo '<div class="alert alert-danger" role="alert"><i class="fas fa-exclamation-triangle"></i> ';
                echo Translator('syntax_incorrect_ldap');
                echo '</div>';
                exit();
            } elseif (!$result) {
                echo '<div class="alert alert-danger" role="alert"><i class="fas fa-exclamation-triangle"></i> ';
                echo Translator('LDAP_directory_login');
                echo '</div>';

                echo "Détails : " . ldap_error($ldap_connection) . " (error code : " . ldap_errno($ldap_connection) . ")";
                exit();
            }

            $entries = ldap_get_entries($ldap_connection, $result);

            if ($entries['count'] > 0) { ?>
                <div class="row">
                    <div class="col-md-9">
                        <div class="alert alert-info" role="alert">
                            <i class="far fa-info-circle"></i>
                            <?= Translator('Display'); ?><strong><?= $entries['count'] ?></strong> <?php if ($entries['count'] > 1) {
                                                                                                        echo Translator('Users');
                                                                                                    } else {
                                                                                                        echo Translator('user');
                                                                                                    } ?><?= Translator('LDAP_directory_in'); ?>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <button type="button" class="exerotpbtn dsjh btn-default btn-sm btneditnusr ripple-effect ripple-white" onclick="loadLdapUsers();"><i class="far fa-redo"></i> <?php echo Translator('Refresh'); ?></button>
                    </div>
                </div>

                <?php
                if ($entries['count'] >= 150) {
                    echo "
                <style>
                    .pgnt_tab.pagination.justify-content-center {
                        overflow: auto !important;
                        max-width: 100% !important;
                        justify-content: normal !important;
                    }
                </style>
                ";
                }
                ?>

                <input type="text" id="searchboxTable" placeholder="<?php echo Translator('Find_user_directory'); ?>" title="<?php echo Translator('Perform_a_search'); ?>">

                <div class="modal" id="myModal" tabindex="-1" role="dialog" aria-labelledby="confirm_overwrite" aria-hidden="true">
                    <div class="modal-dialog modal-lg" role="document">
                        <div class="modal-content" style="color:black !important;">
                            <div class="modal-header">
                                <h5 class="modal-title" id="lblconfirm_view_ldapedit"><?php echo Translator('confirm_action'); ?></h5>
                            </div>
                            <div class="modal-body">
                                <p><?php echo Translator('alert_import_usr'); ?>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-primary" onclick="closeModal()"><?= Translator('ok'); ?></button>
                            </div>
                        </div>
                    </div>
                </div>

                <script>
                    function closeModal() {
                        var modal = document.getElementById("myModal");
                        modal.style.display = "none";
                    }
                </script>





                <script>
                   function toggle2(source) {
                    var checkboxes = document.querySelectorAll('input[type="checkbox"]');
                    var modal = document.getElementById("myModal");
                    var modalIsOpen = modal.style.display === "block";
                    var importedCheckboxes = document.querySelectorAll('.already_imported_ldap input[type="checkbox"]');
                    var importedCheckedVisible = false; // Indicateur pour vérifier si au moins un utilisateur importé coché est visible
                    for (var i = 0; i < checkboxes.length; i++) {
                        if (checkboxes[i] != source && checkboxes[i].className != "allCheck2" && checkboxes[i].className != "selectAllUsers") {
                            var userRow = checkboxes[i].parentNode.parentNode;

                            if (userRow.classList.contains("already_imported_ldap") && userRow.style.display == "none") {
                                continue;
                            }
                            // Vérifie si la modale est ouverte ou fermée avant de cocher ou décocher les cases à cocher
                            if (!modalIsOpen) {
                                checkboxes[i].checked = source.checked;
                            }
                        }
                    }

                    // Décoche les cases à cocher des utilisateurs importés si l'on a choisi de masquer les utilisateurs
                    var MaskAlreadyImportedCheckBox = document.getElementById("MaskAlreadyImported");
                    if (MaskAlreadyImportedCheckBox.checked) {
                        var alreadyImported = document.querySelectorAll('#byValDataT tr.already_imported_ldap');
                        for (var j = 0; j < alreadyImported.length; j++) {
                                alreadyImported[j].style.display = 'none';
                                var checkboxes = alreadyImported[j].querySelectorAll('input[type="checkbox"]');
                                for (var k = 0; k < checkboxes.length; k++) {
                                    checkboxes[k].checked = false;
                                }
                        }
                    }

    // Vérifie si au moins un utilisateur importé est coché et visible
    var atLeastOneImportedChecked = false;

    for (var j = 0; j < importedCheckboxes.length; j++) {
        if (importedCheckboxes[j].checked && importedCheckboxes[j].parentNode.parentNode.style.display != "none") {
            atLeastOneImportedChecked = true;
            importedCheckedVisible = true;
            break;
        }
    }
    // Coche ou décoche la case "Tout cocher" en fonction de l'état des cases des utilisateurs importés
    var allCheckCheckbox = document.querySelector('.allCheck2');
    allCheckCheckbox.checked = atLeastOneImportedChecked &&
     importedCheckboxes.length === document.querySelectorAll('.already_imported_ldap').length;

    // Ouvre la modale si au moins un utilisateur importé est coché et visible,
    // et si les utilisateurs importés ne sont pas masqués avec la fonction toggle
    var alreadyImportedRows = document.querySelectorAll('#byValDataT tr.already_imported_ldap');
    var importedVisible = Array.from(alreadyImportedRows).some(row => row.style.display !== 'none');

    if (atLeastOneImportedChecked && importedCheckedVisible && importedVisible) {
        modal.style.display = "block";
        var closeBtn = modal.querySelector(".close");
        closeBtn.addEventListener("click", function() {
            modal.style.display = "none";
        });
    }
}



                    // Fonction pour masquer les utilisateurs déjà importés et leurs cases à cocher
                    function toggle3(source) {
                          // Décoche les cases à cocher des utilisateurs importés qui sont masqués
                        var alreadyImported = document.querySelectorAll('#byValDataT tr.already_imported_ldap');
                        for (var j = 0; j < alreadyImported.length; j++) {
                                var checkboxes = alreadyImported[j].querySelectorAll('input[type="checkbox"]');
                                for (var k = 0; k < checkboxes.length; k++) {
                                    checkboxes[k].checked = false;
                                }
                        }

                        // Masque les lignes d'utilisateurs déjà importés si la case à cocher "source" est cochée
                        var alreadyImported = document.querySelectorAll('#byValDataT tr.already_imported_ldap');
                            for (var j = 0; j < alreadyImported.length; j++) {
                            alreadyImported[j].style.display = source.checked ? 'none' : '';
                        }
                    }





                    // Fonction pour la recherche et la pagination de la table
                    $(document).ready(function() {


                        // Masque les utilisateurs déjà importés (désolé pas trouvé mieux)
                        $("#container_table").on("click", function() {
                            var MaskAlreadyImportedCheckBox = document.getElementById("MaskAlreadyImported");
                            if (MaskAlreadyImportedCheckBox.checked) {
                                var alreadyImported = document.querySelectorAll('#byValDataT tr.already_imported_ldap');
                                for (var j = 0; j < alreadyImported.length; j++) {
                                        alreadyImported[j].style.display = 'none';
                                }
                            }
                        });
                        
                        // Fonction pour la recherche dans la table
                        $("#searchboxTable").on("keyup", function() {
                            var e = $(this).val().toLowerCase();
                            $("#byValDataT tr").filter(function() {
                                $(this).toggle($(this).text().toLowerCase().indexOf(e) > -1);
                            });
                            // Masque les utilisateurs déjà importés (désolé pas trouvé mieux)
                            var MaskAlreadyImportedCheckBox = document.getElementById("MaskAlreadyImported");
                            if (MaskAlreadyImportedCheckBox.checked) {
                                var alreadyImported = document.querySelectorAll('#byValDataT tr.already_imported_ldap');
                                for (var j = 0; j < alreadyImported.length; j++) {
                                        alreadyImported[j].style.display = 'none';
                                }
                            }
                        });

                        // Fonction pour la pagination de la table                   
                        $("#searchboxTable").on("keyup", function() {
                            if ($(this).val().length >= 1) {
                                // Si une recherche est en cours, cache les boutons de sélection et de pagination
                                paginator({
                                    table: document.getElementById("container_table").getElementsByTagName("table")[0],
                                    box_mode: "list",
                                    rows_per_page: "0",
                                    get_rows: function() {
                                        return document.getElementById("table_otpexer").getElementsByTagName("tbody");
                                    },
                                });
                                return $(".pgnt_tab").hide(), $(".allCheck").hide(), $(".allCheck2").hide(), !1;
                            }
                            // Sinon, affiche les boutons de sélection et de pagination
                            paginator({
                                table: document.getElementById("container_table").getElementsByTagName("table")[0],
                                box_mode: "list",
                                rows_per_page: "10"
                            });
                            // Masque les utilisateurs déjà importés (désolé pas trouvé mieux)
                            var MaskAlreadyImportedCheckBox = document.getElementById("MaskAlreadyImported");
                            if (MaskAlreadyImportedCheckBox.checked) {
                                var alreadyImported = document.querySelectorAll('#byValDataT tr.already_imported_ldap');
                                for (var j = 0; j < alreadyImported.length; j++) {
                                        alreadyImported[j].style.display = 'none';
                                }
                            }
                            return $(".pgnt_tab").show(), $(".allCheck").show(), $(".allCheck2").show(), !1;
                        });

                        // Initialise la pagination de la table
                        var e = paginator({
                            table: document.getElementById("container_table").getElementsByTagName("table")[0],
                            box_mode: "list",
                            rows_per_page: "10"
                        });
                        document.getElementById("container_table").appendChild(e);
                    });
                </script>

                <div class="table-responsive ms-h-50" id="container_table">
                    <table id="table_otpexer" class="sortable-theme-bootstrap table-striped" data-sortable>
                        <label class="pure-material-checkbox allCheck ml-2">
                            <input type="checkbox" name="MaskAlreadyImported" id="MaskAlreadyImported" onclick="toggle3(this);" class="selectAllUsers">
                            <span><strong><?php echo Translator('hide_ldapuser') ?></strong></span>
                        </label>




                        <thead>
                            <tr>
                                <th data-sortable="false">
                                    <label class="pure-material-checkbox allCheck2" style="margin-bottom: -5px;">
                                        <input type="checkbox" name="CheckAllUsers" id="CheckAllUsers" onclick="toggle2(this);">
                                        <span><?php echo Translator('All_check') ?></span>

                                    </label>
                                </th>


                            <th data-sorted="true" data-sorted-direction="descending"><?php echo Translator('full_name'); ?></th>
                                <th><?php echo Translator('user'); ?></th>
                                <th><?php echo Translator('Email'); ?></th>
                                <th>userPrincipalName</th>
                                <th><?php echo Translator('group'); ?></th>
                                <th><?php echo Translator('last_logins'); ?></th>
                            </tr>
                        </thead>

                        <tbody id="byValDataT">
                            <?php for ($i = 0; $i < $entries['count']; $i++) {
                                /**
                                 *   Full name
                                 **/
                                $FullName = NULL;
                                if (isset($entries[$i]['cn'][0])) {
                                    $FullName = $entries[$i]['cn'][0];
                                    if ($FullName == "NULL") {
                                        $FullName = "";
                                    }
                                } else {
                                    $FullName = "N/A";
                                }

                                /**
                                 *   Utilisateur
                                 **/
                                $getCurrentLoginAttr = $Ldap['loginattribute']; //on essait avec l'attribut configuré, sinon on essait avec les "classiques"
                                if (!empty($entries[$i][$getCurrentLoginAttr][0])) {
                                    $Username = $entries[$i][$getCurrentLoginAttr][0];
                                } elseif (!empty($entries[$i]['samaccountname'][0])) {
                                    $Username = $entries[$i]['samaccountname'][0];
                                } elseif (!empty($entries[$i]['uid'][0])) {
                                    $Username = $entries[$i]['uid'][0];
                                } else {
                                    $Username = "";
                                }
                                if ($Username == "NULL") {
                                    $Username = "";
                                }



                                $ClientAlreadyRegister = $db->prepare('SELECT * FROM otp_tokens WHERE login = ? AND corpid = ?');
                                $ClientAlreadyRegister->execute(array($Username, $Ldap['corpid']));

                                /**
                                 *   Email
                                 **/
                                $Email = NULL;
                                if (isset($entries[$i]['mail'][0])) {
                                    $Email = $entries[$i]['mail'][0];
                                    if ($Email == "NULL") {
                                        $Email = "";
                                    }
                                } else {
                                    $Email = "N/A";
                                }


                                /**
                                 *   userPrincipalName
                                 **/
                                $userPrincipalName = NULL;
                                if (isset($entries[$i]['userprincipalname'][0])) {
                                    $userPrincipalName = $entries[$i]['userprincipalname'][0];
                                    if ($userPrincipalName == "NULL") {
                                        $userPrincipalName = "";
                                    }
                                } else {
                                    $userPrincipalName = "N/A";
                                }


                                /**
                                 *   LastConnection
                                 **/
                                $LastConnection = NULL;
                                if (isset($entries[$i]['lastlogon'][0])) {
                                    $LastConnection = date('d/m/Y à H:i', ($entries[$i]['lastlogon'][0] / 10000000) - 11644473600);
                                    if ($LastConnection == "NULL") {
                                        $LastConnection = "";
                                    }
                                } else {
                                    $LastConnection = "N/A";
                                }


                                /**
                                 *   Dump rows
                                 **/
                            ?>


                                <tr <?php if ($ClientAlreadyRegister->rowCount() == 1) {
                                        echo 'class="already_imported_ldap"';
                                    } ?>>

                                    <?php
                                    echo '<td>';
                                    if ($ClientAlreadyRegister->rowCount() == 1) {
                                        $tokGFH = generateToken(9999);
                                    ?>
                                        <!-- Modal_confirm_overwrite -->
                                        <div class="modal fade" id="confirm_overwrite__<?= $tokGFH ?>" tabindex="-1" role="dialog" aria-labelledby="confirm_overwrite" aria-hidden="true">
                                            <div class="modal-dialog modal-lg" role="document">
                                                <div class="modal-content" style="color:black !important;">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="lblconfirm_view_ldapedit"><?php echo Translator('confirm_action'); ?>
                                                    </div>

                                                    <div class="modal-body">
                                                        <label><?php echo Translator('re_import_user'); ?> <b><?= htmlspecialchars($LDAP_samaccountname); ?></b> ? <br>
                                                            <?php echo Translator('overwrite_current_user'); ?></label>
                                                    </div>

                                                    <div class="modal-footer">
                                                        <form method="POST">
                                                            <button type="button" class="exerotpbtn btn-cancel ripple-effect ripple-white" onclick="uncheck___<?= $tokGFH ?>()" data-dismiss="modal"><?php echo Translator('Cancel'); ?></button>
                                                            <button type="button" name="del_this_firewall__<?= $tokGFH ?>" onclick="applyModifLdap___<?= $tokGFH ?>()" data-dismiss="modal" class="exerotpbtn btn-green ripple-effect ripple-white"><?php echo Translator('Confirm'); ?></button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <label class="pure-material-checkbox check-importedldap sds4545" id="importedldap__<?= $tokGFH ?>" data-backdrop="static" data-keyboard="false" data-toggle="modal" data-target="#confirm_overwrite__<?= $tokGFH ?>" style="margin-bottom: -5px;">
                                            <input type="checkbox" name="check_this_ldapusr[]" id="ldapregister_usr__<?= $tokGFH ?>" value="<?= $Username ?>">
                                            <span></span>
                                        </label>

                                        <button type="button" class="exerotpbtn btn-sm btn-red ldap_delbtn ripple-effect ripple-white" onclick="cancelapplyModifLdap___<?= $tokGFH ?>()" id="ldap_delbtn__<?= $tokGFH ?>" title="<?php echo Translator('Delete_selection'); ?>"><i class="far fa-trash-alt dwnl_small_addelement_icon delete_action_button_item"></i></button>

                                        <script>
                                            function uncheck___<?= $tokGFH ?>() {
                                                document.getElementById("ldapregister_usr__<?= $tokGFH ?>").checked = false;
                                            }

                                            function applyModifLdap___<?= $tokGFH ?>() {
                                                $('#ldap_delbtn__<?= $tokGFH ?>').show();
                                                $('#importedldap__<?= $tokGFH ?>').hide();
                                            }

                                            function cancelapplyModifLdap___<?= $tokGFH ?>() {
                                                document.getElementById("ldapregister_usr__<?= $tokGFH ?>").checked = false;
                                                $('#ldap_delbtn__<?= $tokGFH ?>').hide();
                                                $('#importedldap__<?= $tokGFH ?>').show();
                                            }
                                        </script>
                                    <?php } else { ?>
                                        <label class="pure-material-checkbox sds4545" style="margin-bottom: -5px;">
                                            <input type="checkbox" name="check_this_ldapusr[]" id="djj__<?= $tokGFH ?>" value="<?= $Username ?>">
                                            <span></span>
                                        </label>
                                    <?php } ?>

                                <?php
                                if ($ClientAlreadyRegister->rowCount() == 1) {
                                    echo '<i class="icoldapalimp fas fa-user-check ico-importedldap" title="' . Translator('User_already_imported') . '"></i>';
                                }
                                echo '</td>';
                                echo '<td>' . $FullName . '</td>';
                                echo '<td>' . $Username . '</td>';
                                echo '<td>' . $Email . '</td>';
                                echo '<td>' . $userPrincipalName . '</td>';
                                echo '<td><label title="';
                                $AccountType = NULL;
                                if (isset($entries[$i]['memberof'][0])) {
                                    $items = $entries[$i]['memberof'];
                                    foreach ($items as $AccountType) {
                                        $words = preg_replace('/[0-9]+/', '', $AccountType);
                                        print_r($words . "\n");
                                    }
                                } else {
                                    print_r(Translator('group_is_available'));
                                }
                                echo '" data-toggle="tooltip" data-placement="bottom"><i class="fas fa-info-circle"></i>
                    <span class="text-hidden">';
                                $AccountType = NULL;
                                if (!empty($entries[$i]['memberof'][0])) {
                                    $items = $entries[$i]['memberof'];
                                    foreach ($items as $AccountType) {
                                        $words = preg_replace('/[0-9]+/', '', $AccountType);
                                        print_r($words . "\n");
                                    }
                                } else {
                                    print_r(Translator('group_is_available'));
                                }
                                echo '</span></td>';
                                echo '<td>' . $LastConnection . '</td>';
                                echo '</tr>';
                            } ?>
                        </tbody>
                    </table>
                </div>
<?php } else {
                echo '<div class="alert alert-warning" role="alert"><i class="fas fa-info-circle"></i> ';
                echo Translator('no_user_to_display_ldap');
                echo '</div>';
                exit();
            }

            ldap_unbind($ldap_connection); // Clean up after ourselves.
        }
    }
}
?>