<?php
	// Dernière modification le : 12/02/2022
	// Par: Laurent ASSELIN
	$module_page_name = "Secret Key Change Module";
	$show_navbar = false;
	$show_creds_usr = false;
	include 'header.php';
	include_once $_SERVER['DOCUMENT_ROOT'] . '/inc/translator.php';
	
	if (!isset($_SESSION['id'])) {
		header('Location: /');
		exit();
	}
	
	if ($_SESSION['level'] == 1) {
		header('Location: /?accessdenied_for_users');
		exit();
	}
	
	if (!isset($_SESSION['ch_token_usr'])) {
		$page = htmlspecialchars($_SERVER["HTTP_REFERER"]);
		header('Location: /companies.php');
		exit();
	}
	
	if ($_SESSION['level'] == 3) {
		if (isset($_GET['TokenID'])) {
			$TokenID = htmlspecialchars($_GET['TokenID']);
		} else {
			$TokenID = NULL;
		}
		
		if (isset($_GET['CorpID'])) {
			$CorpID = htmlspecialchars($_GET['CorpID']);
		} else {
			$CorpID = NULL;
		}
		
		if (isset($_GET['Method'])) {
			$Method = htmlspecialchars($_GET['Method']);
		} else {
			$Method = NULL;
		}
	}
	
	if ($Method == "EditSpecificUser") {
		//acces supervisor seulement
		$recup_otp_corp_clients = $db->prepare('SELECT * FROM otp_companies WHERE corpid = ?');
		$recup_otp_corp_clients->execute(array($CorpID));
		$client_corp = $recup_otp_corp_clients->fetch();
					
		$recup_otp_tokens_rec = $db->prepare('SELECT * FROM otp_tokens WHERE corpid = ? AND token = ?');
		$recup_otp_tokens_rec->execute(array($CorpID, $TokenID));
		$tokens_clients = $recup_otp_tokens_rec->fetch();
		
		$log = $tokens_clients['login'];
		$cli = $client_corp['folder'];
	} else {
		//acces admins seulement
		$recup_otp_corp_clients = $db->prepare('SELECT * FROM otp_companies WHERE corpid = ?');
		$recup_otp_corp_clients->execute(array($_SESSION['corp']));
		$client_corp = $recup_otp_corp_clients->fetch();
					
		$recup_otp_tokens_rec = $db->prepare('SELECT * FROM otp_tokens WHERE corpid = ? AND login = ?');
		$recup_otp_tokens_rec->execute(array($_SESSION['corp'], $_SESSION['ch_token_usr']));
		$tokens_clients = $recup_otp_tokens_rec->fetch();
		
		$log = $tokens_clients['login'];
		$cli = $client_corp['folder'];
	}
				
	//changement du secret pour cet utilisateur
	$escaped_command = escapeshellcmd('cat /home/'.$cli.'/'.$log.'/.nameandissuer');
	$escaped_remove = escapeshellcmd('rm /home/'.$cli.'/'.$log.'/.exer_authenticator');
	$nameandissuer = shell_exec($escaped_command);
	$arraynameandissuer_chsecret = preg_split("/[\s,]+/", $nameandissuer);
				
	if ($arraynameandissuer_chsecret[1] != null && $arraynameandissuer_chsecret[3] != null) {
		$escaped_command = escapeshellcmd('token.sh -l '.$log.' -c '.$cli.' -i '.$arraynameandissuer_chsecret[1].' -n '.$arraynameandissuer_chsecret[3].' ');
		shell_exec($escaped_remove);
		shell_exec($escaped_command);
	} elseif ($arraynameandissuer_chsecret[1] != null) {
		$escaped_command = escapeshellcmd('token.sh -l '.$log.' -c '.$cli.' -i '.$arraynameandissuer_chsecret[1].' ');
		shell_exec($escaped_remove);
		shell_exec($escaped_command);
	} elseif ($arraynameandissuer_chsecret[3] != null) {
		$escaped_command = escapeshellcmd('token.sh -l '.$log.' -c '.$cli.' -n '.$arraynameandissuer_chsecret[3].' ');
		shell_exec($escaped_remove);
		shell_exec($escaped_command);
	} else {
		$escaped_command = escapeshellcmd('token.sh -l '.$log.' -c '.$cli.' ');
		shell_exec($escaped_remove);
		shell_exec($escaped_command);
	}
	
	$nomclient 	= 	$cli;
	$nomuser	=	$log;
	$handle 	= 	fopen('/home/'.$nomclient.'/'.$nomuser.'/.exer_authenticator', "r");
																			
	if ($handle) {
		if (($buffer = fgets($handle)) != "e") {
			$secretkey = rtrim($buffer);
				if ($boolnameandissuer == true) {
					$set = 'otpauth://totp/'.$arraynameandissuer[3].'?secret='.$secretkey.'&issuer='.$arraynameandissuer[1].'';
				} elseif ($boolissuer == true) {
					$set = 'otpauth://totp/'.$nomuser.'?secret='.$secretkey.'&issuer='.$arraynameandissuer[1].'';
				} elseif ($boolnametoken == true) {
					$set = 'otpauth://totp/'.$arraynameandissuer[3].'?secret='.$secretkey.'&issuer='.$nomclient.'';
				} else {
					$set = 'otpauth://totp/'.$nomuser.'?secret='.$secretkey.'&issuer='.$nomclient.'';
				}
		}
		fclose($handle);
	}
																			
	//génération du qr code dans le fichier utilisateur
	$codeText = $set;
	ob_start();
	QRCode::png($codeText, null, QR_ECLEVEL_L, 8);
	$imageString = base64_encode(ob_get_contents());
	ob_end_clean();
	echo "<img class='QrCode' src='data:image/png;base64,$imageString'>";
																			
	$base64_qrcode = "data:image/png;base64,$imageString";
	$ProtectQRCode =  EncodePassword($base64_qrcode);
	
	$renew_qrcode = $db->prepare("UPDATE otp_tokens SET qr_code = ? WHERE token = ?");
    $renew_qrcode->execute(array($ProtectQRCode, $_SESSION['ch_token_tk']));
	
	//supression des variables de sessions
	unset($_SESSION['ch_token_usr']);
	unset($_SESSION['ch_token_tk']);
	
	addLogEventOTP("[INFORMATION] The WebUI user " . $_SESSION['username'] . " renewed the secret key of " . $log . " (folder ". $cli .").");
	
	$Session->setFlash(Translator('renewed_the_key'), "check", "success");
	
	$page = $_SERVER["HTTP_REFERER"];
	header('Location: ' . $page);
	exit();
	
	include 'footer.php';
?>