<?php 
// Dernières modifications le 21/07/2023
// Par Laurent ASSELIN
// PHP Mailing Class - EXER OTP

include_once $_SERVER['DOCUMENT_ROOT'] . '/inc/translator.php';

if (checkLevel() == ADMIN && $_SESSION['corp_logo'] != "not_defined") {
    $CorpLogo       = $_SESSION['corp_logo'];
} else {
    $CurrentHost = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]";
    $url = $CurrentHost . '/assets/images/brandmark.png';

    $stream_opts = [
        "ssl" => [
            "verify_peer"=>false,
            "verify_peer_name"=>false,
        ]
    ];
    
    $response   = file_get_contents($url, false, stream_context_create($stream_opts));
    $CorpLogo   = 'data:image/png;base64,' . base64_encode($response);
}

$CustomContent = $MailingSettings['content'];
$CustomContent1 = Translator('Unique_link');
$CustomContent2 = Translator('If_it_is_a_mistake');
$CustomContent3 = Translator('This_message_was_automatically');
$CustomContent4 = Translator('Please_do_not_reply');
$CustomContent5 = Translator('Access_Link');

$content = '
<div style="cursor: auto; color: #333; font-family: Corbel; font-size: 18px; line-height: 1.44;">
    '.$CustomContent.'
</div>
<tr>
    <td style="word-wrap: break-word; font-size: 0px; padding: 10px 25px; padding-bottom: 30px;" align="center">
        <table role="presentation" cellpadding="0" cellspacing="0" style="border-collapse: separate;" align="center" border="0">
            <tbody>
                <tr>
                    <td style="border: none; border-radius: 2px; color: #fff; cursor: auto; padding: 12px 30px;" align="center" valign="middle" bgcolor="#3a529b">
                        <a
                            href="{{link}}"
                            style="
                                text-decoration: none;
                                background: #3a529b;
                                color: #fff;
                                font-family: Ubuntu, Helvetica, Arial, sans-serif;
                                font-size: 14px;
                                font-weight: 500;
                                line-height: 120%;
                                text-transform: none;
                                margin: 0px;
                            "
                            target="_blank"
                        >
                            '.$CustomContent5.'
                        </a>
                    </td>
                </tr>
            </tbody>
        </table>
    </td>
</tr>
';

$MailTemplate = '
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
    <head>
        <!--[if !mso]><!-- -->
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <!--<![endif]-->
        <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta charset="utf-8">

        <style type="text/css">
            #outlook a {
                padding: 0;
            }
            .ReadMsgBody {
                width: 100%;
            }
            .ExternalClass {
                width: 100%;
            }
            .ExternalClass * {
                line-height: 100%;
            }
            body {
                margin: 0;
                padding: 0;
                -webkit-text-size-adjust: 100%;
                -ms-text-size-adjust: 100%;
            }
            table,
            td {
                border-collapse: collapse;
                mso-table-lspace: 0pt;
                mso-table-rspace: 0pt;
            }
            img {
                border: 0;
                height: auto;
                line-height: 100%;
                outline: none;
                text-decoration: none;
                -ms-interpolation-mode: bicubic;
            }
            p {
                display: block;
                margin: 13px 0;
            }
        </style>
        <!--[if !mso]><!-->
        <style type="text/css">
            @media only screen and (max-width: 480px) {
                @-ms-viewport {
                    width: 320px;
                }
                @viewport {
                    width: 320px;
                }
            }
        </style>
        <!--<![endif]-->
        <!--[if mso]>
            <xml>
                <o:OfficeDocumentSettings> <o:AllowPNG /> <o:PixelsPerInch>96</o:PixelsPerInch> </o:OfficeDocumentSettings>
            </xml>
        <![endif]-->
        <!--[if lte mso 11]>
            <style type="text/css">
                .outlook-group-fix {
                    width: 100% !important;
                }
            </style>
        <![endif]-->
        <!--[if !mso]><!-->
        <link href="https://fonts.googleapis.com/css?family=Corbel" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Ubuntu:300,400,500,700" rel="stylesheet" type="text/css" />
        <style type="text/css">
            @import url(https://fonts.googleapis.com/css?family=Corbel);
            @import url(https://fonts.googleapis.com/css?family=Ubuntu:300, 400, 500, 700);
        </style>
        <!--<![endif]-->
        <style type="text/css">
            .exer_logo {
                font-size: 18px;
                text-decoration: none;
                color: #3a529b;
                font-weight: bold;
            }
            .exer_link {
                color: #22a7f0;
                text-decoration: none;
            }
        </style>
        <style type="text/css">
            @media only screen and (min-width: 480px) {
                .mj-column-per-100 {
                    width: 100% !important;
                }
            }
        </style>
    </head>
    <body style="background: #f5f6fa;">
        <div class="mj-container" style="background-color: #f5f6fa;">
            <!--[if mso | IE]> <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="600" align="center" style="width:600px;"> <tr> <td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;"> <![endif]-->
            <div style="margin: 0px auto; max-width: 600px;">
                <table role="presentation" cellpadding="0" cellspacing="0" style="font-size: 0px; width: 100%;" align="center" border="0">
                    <tbody>
                        <tr>
                            <td style="text-align: center; vertical-align: top; direction: ltr; font-size: 0px; padding: 20px 0px; padding-bottom: 20px; padding-top: 30px;">
                                <!--[if mso | IE]> <table role="presentation" border="0" cellpadding="0" cellspacing="0"> <tr> <td style="vertical-align:undefined;width:600px;"> <![endif]-->
                                <!--[if mso | IE]> </td></tr></table> <![endif]-->
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <!--[if mso | IE]> </td></tr></table> <![endif]-->
            <!--[if mso | IE]> <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="600" align="center" style="width:600px;"> <tr> <td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;"> <![endif]-->
            <div style="margin: 0px auto; max-width: 600px; background: #fff;">
                <table role="presentation" cellpadding="0" cellspacing="0" style="font-size: 0px; width: 100%; background: #fff;" align="center" border="0">
                    <tbody>
                        <tr>
                            <td style="text-align: center; vertical-align: top; direction: ltr; font-size: 0px; padding: 20px 0px;">
                                <!--[if mso | IE]> <table role="presentation" border="0" cellpadding="0" cellspacing="0"> <tr> <td style="vertical-align:top;width:600px;"> <![endif]-->
                                <div class="mj-column-per-100 outlook-group-fix" style="vertical-align: top; display: inline-block; direction: ltr; font-size: 13px; text-align: left; width: 100%;">
                                    <br><br>
                                    <table role="presentation" cellpadding="0" cellspacing="0" width="100%" border="0">
                                        <tbody>
                                            <tr>
                                                <td style="padding: 4rem 25px 20px; font-size: 0px; -ms-word-wrap: break-word;" align="center">
                                                    <div style="cursor: auto; color: #333; font-family: Corbel; font-size: 30px; font-weight: bold;text-align: center;"> ' . $CustomContent1 . '</div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="word-wrap: break-word; font-size: 0px; padding: 10px 25px; padding-bottom: 20px;">
                                                    '.$content.'
                                                    <tr>
                                                        <td style="word-wrap: break-word; font-size: 0px; padding: 10px 25px; padding-bottom: 20px;" align="center">
                                                            <div style="cursor: auto; color: #333; font-family: Corbel; font-size: 13px; line-height: 1.44; text-align: center;">
                                                                <b>' . $CustomContent2 . '
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td style="word-wrap: break-word; font-size: 0px; padding: 10px 25px; padding-bottom: 10px;">
                                                            <p style="font-size: 1px; margin: 0px auto; border-top: 1px solid #e6e6e6; width: 100%;"></p>
                                                            <!--[if mso | IE]>
                                                                <table
                                                                    role="presentation"
                                                                    align="center"
                                                                    border="0"
                                                                    cellpadding="0"
                                                                    cellspacing="0"
                                                                    style="font-size: 1px; margin: 0px auto; border-top: 1px solid #e6e6e6; width: 100%;"
                                                                    width="600"
                                                                >
                                                                    <tr>
                                                                        <td style="height: 0; line-height: 0;"></td>
                                                                    </tr>
                                                                </table>
                                                            <![endif]-->
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td style="word-wrap: break-word; font-size: 0px; padding: 10px 25px;" align="left">
                                                            <div style="cursor: auto; color: #858585; font-family: Ubuntu, Helvetica, Arial, sans-serif; font-size: 13px; line-height: 22px; text-align: left;">
                                                                ' . $CustomContent3 . ' <b>'.$recipient.'</b>. <br />
                                                                ' . $CustomContent4 . '
                                                            </div>
                                                        </td>
                                                    </tr>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <!--[if mso | IE]> </td></tr></table> <![endif]-->
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <!--[if mso | IE]> </td></tr></table> <![endif]-->
        </div>
    </body>
</html>
';
?>