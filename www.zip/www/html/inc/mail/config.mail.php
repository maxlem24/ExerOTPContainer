<?php 
	// Dernière modification le : 20/07/2023
	// Par: Laurent ASSELIN
	
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

include_once $_SERVER['DOCUMENT_ROOT'] . '/inc/translator.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/inc/class.exerotp.php';
require_once '/var/www/libs/composer/vendor/autoload.php';
require_once "/var/www/libs/mustache/src/Mustache/Autoloader.php";


Mustache_Autoloader::register();
$MustacheInitiator = new Mustache_Engine;

if (isset($_SESSION['id'])) {
    function SendMail($recipient, $TestMessage = NULL, $LoadConf = false, $var_data = NULL) {
        global $db;
        global $MailingExist;
        global $MailingSettings;
        global $MustacheInitiator;
        global $Session;
        global $actual_link;

        // Get Company info
        $recup_corp = $db->prepare('SELECT * FROM otp_companies WHERE corpid = ?');
		$recup_corp->execute(array($LoadConf));
		$crp_data = $recup_corp->fetch();

        // Get Current Settings in company
        $Mailing = $db->prepare('SELECT * FROM otp_mailing WHERE corpid = ?');
        $Mailing->execute(array($LoadConf));
        $MailingExist = $Mailing->rowCount();
        $MailingSettings = $Mailing->fetch();

        require $_SERVER['DOCUMENT_ROOT'] . '/inc/mail/mail.template.php';

        if ($MailingExist == 1) {
            $mail = new PHPMailer(true);

            // Check server auth
            if (!empty($MailingSettings['auth_user']) && !empty($MailingSettings['auth_password'])) {
                $requireAuth = true;

                $Auth = $MailingSettings['auth_user'];
                $Pass = DecodePassword($MailingSettings['auth_password']);
            } else {
                $requireAuth = false;

                $Auth = NULL;
                $Pass = NULL;
            }

            // Check encryption
            if ($MailingSettings['transport'] == 1) {
                $mail->SMTPSecure   = PHPMailer::ENCRYPTION_SMTPS;
            } elseif ($MailingSettings['transport'] == 2) {
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            }

            try {
                // Server settings
                $mail->SMTPDebug   = SMTP::DEBUG_OFF;
                $mail->isSMTP();

                $mail->SMTPOptions = array(
                    'ssl' => array(
                        'verify_peer' => false,
                        'verify_peer_name' => false,
                        'allow_self_signed' => true
                    )
                );

                $mail->Host         = $MailingSettings['host'];
                $mail->SMTPAuth     = $requireAuth;
                $mail->Username     = $Auth;
                $mail->Password     = $Pass;
                $mail->SMTPAutoTLS  = false;
                $mail->Port         = $MailingSettings['port'];
                $mail->CharSet      = 'UTF-8';
                
                $mail->addCustomHeader("Organization" , $crp_data['name']); 
                //$mail->addCustomHeader("Content-Transfer-encoding" , "8bit");
                //$mail->addCustomHeader("Message-ID" , "<".md5(uniqid(time()))."@{$_SERVER['SERVER_NAME']}>");
                $mail->addCustomHeader("X-MSmail-Priority" , "High");
                $mail->addCustomHeader('X-Priority', '1 (Highest)');
                $mail->addCustomHeader("X-MimeOLE" , "Produced By EXER MimeOLE V6.00.2800.1441");
                $mail->addCustomHeader("X-Sender" , $MailingSettings['issuer']);
                $mail->addCustomHeader("X-AntiAbuse" , "This is a solicited email for - ". Translator('Exer_OTP') ." mailing list.");
                $mail->addCustomHeader("X-AntiAbuse" , Translator('Exer_OTP') . " - {$MailingSettings['issuer']}");
                $mail->addCustomHeader("X-AntiAbuse" , "Company unique identifier : " . $crp_data['folder']);

                // Recipients
                $mail->setFrom($MailingSettings['sendmail'], $MailingSettings['issuer']);
                $mail->addAddress($recipient, $_SESSION['username']);

                // Content
                $mail->isHTML(true);
                if ($TestMessage == true && $TestMessage != NULL) {
                    $mail->Subject  = Translator('Test_email_subject');
                    $mail->Body     = Translator('Test_email_body');
                } else {
                    if (!empty($MailingSettings['subject'])) { $mail->Subject  =  $MailingSettings['subject']; } else { $mail->Subject  = Translator('Unique_link'); }
                    $RenderVars     = $MustacheInitiator->render($MailTemplate, $var_data);
                    $mail->Body     = htmlspecialchars_decode($RenderVars);
                }

                $mail->AltBody = strip_tags(htmlspecialchars_decode($RenderVars));
                $mail->send();

                addLogEventOTP("[SUCCESS] An OTP Welcome E-mail was sent to " . $recipient . " by " . $_SESSION['username']);
            } catch (Exception $e) {
                $ErrorInfos = htmlspecialchars($mail->ErrorInfo);
                addLogEventOTP("[ERROR] The OTP Welcome E-mail could not be send to " . $recipient . " : {$ErrorInfos}");
                $Session->setFlash(Translator('not_EMAIL_send').$recipient." : {$ErrorInfos}", "close", "error");
                header('Location: ' . $actual_link);
                exit();
            }
        } else {
            addLogEventOTP("[ERROR] Unable to send E-mail : The configuration of your mail server was not found");
            $Session->setFlash(Translator('config_email_not_found'), "close", "error");
            header('Location: ' . $actual_link);
            exit();
        }
    }
}
?>