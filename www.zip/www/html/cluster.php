<?php
// Dernières modifications le 26/07/2023
// Par : Laurent ASSELIN

include_once $_SERVER['DOCUMENT_ROOT'] . '/inc/translator.php';
$module_page_name = Translator('HA');
$show_navbar = true;
$show_creds_usr = true;
include 'inc/header.php';
?>
<?php
if (isset($_GET['page']))
{
	$page = htmlspecialchars($_GET['page']);
} 
else 
{
	$page = NULL;
}
if ($_SESSION['level'] == 3 || (checkLevel() == OPERATOR) AND ($_SESSION['corp'] == "NOT_DEFINED"))
{
	if ($page != "Addactifactif")
	{
	//Première page avec ajouter VM en haut à droite
	?>
		<main role="main" class="col-md-10 ml-sm-auto col-lg-10">
		<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
			<h1 class="h2"><?= $module_page_name ?></h1>
			<?php if ($_SESSION['level'] == 3)
			 	  { ?>
				<div class="btn-group">
					<a href="?page=Addactifactif"><button id="add_actif_actif" class="exerotpbtn btn-defaultexer btn-sm ripple-effect ripple-white"><i class="far fa-plus dwnl_small_addelement_icon"></i><?= Translator('Add_a_VM_OTP');?></button></a>
				</div>
			<?php } ?>
		</div>
		
		<?php
		//Ajout d'un check pour savoir s'il y a des vm otp 
		$recup_all_otp = $db->query('SELECT * FROM otp_actif ORDER BY id DESC');
		$recup_all_otp->execute(array());
		$count_all_otp = $recup_all_otp->rowCount();
		if ($count_all_otp == 0) { ?>
			
			<div class="alert alert-danger" role="alert">
			<i class="fas fa-exclamation-triangle"></i> <?= Translator('Add_a_VM_OTP');?>
			</div>

		<?php 
		} 
		else 
		{ ?>
			<div class="alert alert-info" role="alert">
			<i class="far fa-info-circle"></i>
			<?= Translator('Display') ;?><?php if ($count_all_otp > 1) { echo "<strong>".Translator('of') . $count_all_otp; } else { echo "<strong>".Translator('of_a3'); } ?> </strong><?= Translator('OTP_VM'); ?>
			</div>

			 	         

			<div id="starttable"> 


			
			<input type="text" id="searchboxTable" placeholder="<?= Translator('find_a_vm_otp');?>" title="<?= Translator('fill_this_field_with_name_valid');?>">

			 <div id="refresh"></div>
			 <div id="scriptpag">
			<script>
				$(document).ready(function() {
					$("#searchboxTable").on("keyup", function() {
						var value = $(this).val().toLowerCase();
						$("#byValDataT tr").filter(function() {
							$(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
						});
					});

					$("#searchboxTable").on("keyup", function() {
						var name = $(this).val();
						if (name.length >= 1) {
						var box = paginator({
							table: document.getElementById("container_table").getElementsByTagName("table")[0],
							box_mode: "list",
							rows_per_page: "0",
							get_rows: function () {
								return document.getElementById("table_otp_actif").getElementsByTagName("tbody");
							},
						});
						$('.pgnt_tab').hide();
						return false;
						} else {
						var box = paginator({
							table: document.getElementById("container_table").getElementsByTagName("table")[0],
							box_mode: "list",
							rows_per_page: "10",
						});
						$('.pgnt_tab').show();
						return false;
						}
					});

					var box = paginator({
						table: document.getElementById("container_table").getElementsByTagName("table")[0],
						box_mode: "list",
						rows_per_page: "10",
					});
					document.getElementById("container_table").appendChild(box);
				});
			</script>
			</div>

			<div class="table-responsive " id="container_table">
							<table  id="table_otp_actif" class="sortable-theme-bootstrap table-striped " data-sortable>
								<thead>
									<tr>
										<th class="vt-default-th" data-sorted-direction="descending">Publisher</th>
										<th>Subscriber</th>
										<th><?= Translator('Creation_date') ;?></th>
										<?php if ($_SESSION['level'] == 3) { ?>
										<th><?= Translator('manual_synchronization') ;?></th>
										<?php } ?>
										<th><?= Translator('Status') ;?></th>
										<th><?= Translator('last_synchronization') ;?></th>
										<th><?= Translator('Time') ;?></th>
										<th data-sortable="false"> </th>
									</tr>

								</thead>
								<tbody id="byValDataT">
								<?php 
									while ($recorver_datas_actifclient = $recup_all_otp->fetch()) { ?>
										<?php
										$rand_client_modal = generateToken(9999);
										?>
									<tr>
										<td><?= $recorver_datas_actifclient['ip_publisher']; ?></td>
										<td><?= $recorver_datas_actifclient['ip_subscriber']; ?></td>
										<td><?php echo   date_format(date_create($recorver_datas_actifclient['created_at']),"d/m/Y")?></td>		
										 <?php if ($_SESSION['level'] == 3) { ?>
										 <td><button type="submit" class="exerotpbtn btn-defaultexer ripple-effect ripple-white"  data-toggle="modal" data-target="#confirm_synchro_actif__<?= $rand_client_modal ?>"  style="margin-left: auto; margin-right: auto; width: 80%; "><?= Translator('synchronize') ;?></button></td>
										 <?php } ?>
										 <td>					
											<?php
											$date_to_compare = date("Y-m-d H:i:s");
											$source_ip_log = $recorver_datas_actifclient['ip_publisher'];
											$sub_ip_log = $recorver_datas_actifclient['ip_subscriber'];

											$sortie = null;
											$returnvalue = null;
											$output = null;
											$return = null;

											
											if ( strtotime($date_to_compare) - strtotime($recorver_datas_actifclient['last_synchro']) < 360 && testopenssh($recorver_datas_actifclient['ip_subscriber']) == 1)  { ?>
											<label class="badge badge-success"><?= Translator('Statue_active') ;?></label>
											<?php } 
											else
											{ ?>
											<label class="badge badge-danger"><?= Translator('inactive') ;?></label>
											<?php
											} 
												

											?>
										</td>
										<td>
										<?php
						
										 echo date_format(date_create($recorver_datas_actifclient['last_synchro']),"d/m/Y  H:i");
											
										?>
										 </td>
										 <td>
										 	<?php
										 	$output = null;
											$returnvalue = null;
											$subscriber = $recorver_datas_actifclient['ip_subscriber'];
											
											if (testopenssh($subscriber) == 1) {
											        $sub_hour = shell_exec("sudo ssh $subscriber 'date '\''+%d/%m/%Y %H:%M:%S'\'' '");
											        echo $sub_hour;
											}
											else {
											        echo Translator('Login_error');
											}
											?>
										 </td>
										
										<?php if ($_SESSION['level'] == 3) { ?>
											<!-- Modal_confirm suppression actifclient -->
										<div class="modal fade" id="confirm_delete_actif__<?= $rand_client_modal ?>" tabindex="-1" role="dialog" aria-labelledby="lblconfirm_delete_actif" aria-hidden="true">
												<div class="modal-dialog modal-lg" role="document">
													<div class="modal-content">
														<div class="modal-header">
															<h5 class="modal-title" id="lblconfirm_delete_actif"><i class="far fa-trash-alt"></i> <?= Translator('delete_otp') ;?></h5>
															<button type="button" class="close" data-dismiss="modal" aria-label="Close">
																<span aria-hidden="true"><i class="far fa-times"></i></span>
															</button>
														</div>
																
														<div class="modal-body">
															<label><?= Translator('confirm_the-deletion_of_the_OTP') ;?><b> <?= $recorver_datas_actifclient['ip_subscriber']; ?></b>?</label>
															

														</div>
																
														<div class="modal-footer">
															<?php
																if (isset($_POST['del_this_actif__' . $recorver_datas_actifclient['id']])) {
																	unset($_SESSION['subscriber_to_delete']);
																	$_SESSION['subscriber_to_delete'] = $recorver_datas_actifclient['id'];
																	header('Location: inc/class.actions.php?VerbAction=DeleteActif');
																	exit();
																}
															?>
																
															<form method="POST">
																<button type="button" class="exerotpbtn btn-cancel ripple-effect ripple-white" data-dismiss="modal"><?= Translator('Cancel') ;?></button>
																<button type="submit" name="del_this_actif__<?= $recorver_datas_actifclient['id'] ?>" class="exerotpbtn btn-green ripple-effect ripple-white"><?= Translator('Confirm') ;?></button>
															</form>
														</div>
													</div>
												</div>
											</div>
											<div class="modal fade" id="confirm_synchro_actif__<?= $rand_client_modal ?>" tabindex="-1" role="dialog" aria-labelledby="lblconfirm_synchro_actif" aria-hidden="true">
												<div class="modal-dialog modal-lg" role="document">
													<div class="modal-content">
														<div class="modal-header">
															<h5 class="modal-title" id="lblconfirm_synchro_actif"><i class="far fa-trash-alt"></i><?= Translator('Force_synchronisation') ;?></h5>
															<button type="button" class="close" data-dismiss="modal" aria-label="Close">
																<span aria-hidden="true"><i class="far fa-times"></i></span>
															</button>
														</div>
																
														<div class="modal-body">
															<label><?= Translator('Confirm_the_synchronization_of_OTP') ;?><b><?= $recorver_datas_actifclient['ip_subscriber']; ?> </b> ? </label>
														</div>
														
														<div class="modal-footer">
															<?php
															$sortie = null;
															$returnvalue = null;
																if (isset($_POST['force_publisher' . $recorver_datas_actifclient['id']])){
																	$ip_source = $recorver_datas_actifclient['ip_publisher'];
																	$ip_sub = $recorver_datas_actifclient['ip_subscriber'];
																	exec("sudo bash /usr/local/bin/publisher.sh -H $ip_source -s $ip_sub", $sortie, $returnvalue);
																	if($returnvalue == 2){
																		$Session->setFlash(Translator('sync_already_running'), "close", "error");
																		header('Location: '.$actual_link);
																		exit();
																	}
																	if($returnvalue == 0){
																		$date = date('M j H:i:s');
																		$hostname = trim(shell_exec("hostname"));
																		$cron_echo=shell_exec("sudo echo '$date $hostname CRON[MANUAL_SYNC]: (root) CMD (sleep x; /bin/bash /usr/local/bin/publisher.sh -H $ip_source -s $ip_sub)' >> /var/log/cron.log");
																		addLogEventOTP("[SUCCESS] The OTP VM " . $recorver_datas_actifclient['ip_subscriber'] . " has been manually synchronized by " . $_SESSION['username'] );
																		$Session->setFlash(Translator('manual_sync_ok') ,$debug, "check", "success");
																		header('Location: /cluster.php');
																		exit();
																	}
																	else{
																		$Session->setFlash(Translator('manual_sync_impossible'), "close", "error");
																		header('Location: /cluster.php');
																		exit();
																	}
																	exit();
																}
															?>
																
															<form method="POST">
																<button type="button" class="exerotpbtn btn-cancel ripple-effect ripple-white" data-dismiss="modal"><?= Translator('Cancel') ;?></button>
																<button type="submit" name="force_publisher<?= $recorver_datas_actifclient['id'] ?>" class="exerotpbtn btn-green ripple-effect ripple-white"><?= Translator('Confirm') ;?></button>
															</form>
														</div>
													</div>
												</div>
											</div>
										
											
											<td>
												
											
												<button type="button" class="exerotpbtn btn-sm btn-red ripple-effect ripple-white" data-toggle="modal" data-target="#confirm_delete_actif__<?= $rand_client_modal ?>" title= <?= Translator('Delete'); ?>><i class="far fa-trash-alt dwnl_small_addelement_icon delete_action_button_item"></i></button>
											<?php } ?>
											</td>
										</tr>
										
								<?php

								 } ?>
								</tbody>
							</table>
						</div>

		</div>
		

		<?php 
		}
	}

	else if ($page == "Addactifactif")
	{
		if ($_SESSION['level'] == 3) {
		?>
		</main>
		<main role="main" class="col-md-10 ml-sm-auto col-lg-10">
		<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
			<h1 class="h2"><?= $module_page_name ?> <exer class="text-secondary"><i class="far fa-chevron-right chevronexer_openform"></i></exer> <i><?= Translator('Add_a_VM_OTP') ;?></i></h1>
			<div class="btn-group">
				<form method="POST">
				<button id="nextsubmit_add_actif" type="submit" name="nextsubmit_add_actif" class="exerotpbtn btn-green btn-sm ripple-effect ripple-white"><i class="far fa-arrow-right dwnl_small_addelement_icon"></i> <?= Translator('next') ;?></button>
				<a href="/cluster.php"><button type="button" id="nextcancel_add_actif" class="exerotpbtn btn-red btn-sm ripple-effect ripple-white" style="margin-left:10px;"><i class="far fa-times dwnl_small_addelement_icon"></i> <?= Translator('Cancel') ;?></button></a>
			</div>
		</div>
		<script>
			 $("#nextsubmit_add_actif").click(function(){
			 	$("#loader_actif").css("display", "block");
			 	$("#submit_formactif_user").css("display", "none");
			 	$("#nextsubmit_add_actif").css("display", "none");
			 	$("#nextcancel_add_actif").css("display", "none");
			  });
		</script>

		<div class="text-center" id="loader_actif" style="display: none">
														<h4 class="text-blink"><?= Translator('Cluster_creation_in_progress') ;?></h4>
														<div class="ldap-loader">
															<div>
																<ul>
																	<li>
																		<svg viewBox="0 0 90 120" fill="currentColor">
																		<path d="M90,0 L90,120 L11,120 C4.92486775,120 0,115.075132 0,109 L0,11 C0,4.92486775 4.92486775,0 11,0 L90,0 Z M71.5,81 L18.5,81 C17.1192881,81 16,82.1192881 16,83.5 C16,84.8254834 17.0315359,85.9100387 18.3356243,85.9946823 L18.5,86 L71.5,86 C72.8807119,86 74,84.8807119 74,83.5 C74,82.1745166 72.9684641,81.0899613 71.6643757,81.0053177 L71.5,81 Z M71.5,57 L18.5,57 C17.1192881,57 16,58.1192881 16,59.5 C16,60.8254834 17.0315359,61.9100387 18.3356243,61.9946823 L18.5,62 L71.5,62 C72.8807119,62 74,60.8807119 74,59.5 C74,58.1192881 72.8807119,57 71.5,57 Z M71.5,33 L18.5,33 C17.1192881,33 16,34.1192881 16,35.5 C16,36.8254834 17.0315359,37.9100387 18.3356243,37.9946823 L18.5,38 L71.5,38 C72.8807119,38 74,36.8807119 74,35.5 C74,34.1192881 72.8807119,33 71.5,33 Z"></path>
																		</svg>
																	</li>
																	<li>
																		<svg viewBox="0 0 90 120" fill="currentColor">
																		<path d="M90,0 L90,120 L11,120 C4.92486775,120 0,115.075132 0,109 L0,11 C0,4.92486775 4.92486775,0 11,0 L90,0 Z M71.5,81 L18.5,81 C17.1192881,81 16,82.1192881 16,83.5 C16,84.8254834 17.0315359,85.9100387 18.3356243,85.9946823 L18.5,86 L71.5,86 C72.8807119,86 74,84.8807119 74,83.5 C74,82.1745166 72.9684641,81.0899613 71.6643757,81.0053177 L71.5,81 Z M71.5,57 L18.5,57 C17.1192881,57 16,58.1192881 16,59.5 C16,60.8254834 17.0315359,61.9100387 18.3356243,61.9946823 L18.5,62 L71.5,62 C72.8807119,62 74,60.8807119 74,59.5 C74,58.1192881 72.8807119,57 71.5,57 Z M71.5,33 L18.5,33 C17.1192881,33 16,34.1192881 16,35.5 C16,36.8254834 17.0315359,37.9100387 18.3356243,37.9946823 L18.5,38 L71.5,38 C72.8807119,38 74,36.8807119 74,35.5 C74,34.1192881 72.8807119,33 71.5,33 Z"></path>
																		</svg>
																	</li>
																	<li>
																		<svg viewBox="0 0 90 120" fill="currentColor">
																		<path d="M90,0 L90,120 L11,120 C4.92486775,120 0,115.075132 0,109 L0,11 C0,4.92486775 4.92486775,0 11,0 L90,0 Z M71.5,81 L18.5,81 C17.1192881,81 16,82.1192881 16,83.5 C16,84.8254834 17.0315359,85.9100387 18.3356243,85.9946823 L18.5,86 L71.5,86 C72.8807119,86 74,84.8807119 74,83.5 C74,82.1745166 72.9684641,81.0899613 71.6643757,81.0053177 L71.5,81 Z M71.5,57 L18.5,57 C17.1192881,57 16,58.1192881 16,59.5 C16,60.8254834 17.0315359,61.9100387 18.3356243,61.9946823 L18.5,62 L71.5,62 C72.8807119,62 74,60.8807119 74,59.5 C74,58.1192881 72.8807119,57 71.5,57 Z M71.5,33 L18.5,33 C17.1192881,33 16,34.1192881 16,35.5 C16,36.8254834 17.0315359,37.9100387 18.3356243,37.9946823 L18.5,38 L71.5,38 C72.8807119,38 74,36.8807119 74,35.5 C74,34.1192881 72.8807119,33 71.5,33 Z"></path>
																		</svg>
																	</li>
																	<li>
																		<svg viewBox="0 0 90 120" fill="currentColor">
																		<path d="M90,0 L90,120 L11,120 C4.92486775,120 0,115.075132 0,109 L0,11 C0,4.92486775 4.92486775,0 11,0 L90,0 Z M71.5,81 L18.5,81 C17.1192881,81 16,82.1192881 16,83.5 C16,84.8254834 17.0315359,85.9100387 18.3356243,85.9946823 L18.5,86 L71.5,86 C72.8807119,86 74,84.8807119 74,83.5 C74,82.1745166 72.9684641,81.0899613 71.6643757,81.0053177 L71.5,81 Z M71.5,57 L18.5,57 C17.1192881,57 16,58.1192881 16,59.5 C16,60.8254834 17.0315359,61.9100387 18.3356243,61.9946823 L18.5,62 L71.5,62 C72.8807119,62 74,60.8807119 74,59.5 C74,58.1192881 72.8807119,57 71.5,57 Z M71.5,33 L18.5,33 C17.1192881,33 16,34.1192881 16,35.5 C16,36.8254834 17.0315359,37.9100387 18.3356243,37.9946823 L18.5,38 L71.5,38 C72.8807119,38 74,36.8807119 74,35.5 C74,34.1192881 72.8807119,33 71.5,33 Z"></path>
																		</svg>
																	</li>
																	<li>
																		<svg viewBox="0 0 90 120" fill="currentColor">
																		<path d="M90,0 L90,120 L11,120 C4.92486775,120 0,115.075132 0,109 L0,11 C0,4.92486775 4.92486775,0 11,0 L90,0 Z M71.5,81 L18.5,81 C17.1192881,81 16,82.1192881 16,83.5 C16,84.8254834 17.0315359,85.9100387 18.3356243,85.9946823 L18.5,86 L71.5,86 C72.8807119,86 74,84.8807119 74,83.5 C74,82.1745166 72.9684641,81.0899613 71.6643757,81.0053177 L71.5,81 Z M71.5,57 L18.5,57 C17.1192881,57 16,58.1192881 16,59.5 C16,60.8254834 17.0315359,61.9100387 18.3356243,61.9946823 L18.5,62 L71.5,62 C72.8807119,62 74,60.8807119 74,59.5 C74,58.1192881 72.8807119,57 71.5,57 Z M71.5,33 L18.5,33 C17.1192881,33 16,34.1192881 16,35.5 C16,36.8254834 17.0315359,37.9100387 18.3356243,37.9946823 L18.5,38 L71.5,38 C72.8807119,38 74,36.8807119 74,35.5 C74,34.1192881 72.8807119,33 71.5,33 Z"></path>
																		</svg>
																	</li>
																	<li>
																		<svg viewBox="0 0 90 120" fill="currentColor">
																		<path d="M90,0 L90,120 L11,120 C4.92486775,120 0,115.075132 0,109 L0,11 C0,4.92486775 4.92486775,0 11,0 L90,0 Z M71.5,81 L18.5,81 C17.1192881,81 16,82.1192881 16,83.5 C16,84.8254834 17.0315359,85.9100387 18.3356243,85.9946823 L18.5,86 L71.5,86 C72.8807119,86 74,84.8807119 74,83.5 C74,82.1745166 72.9684641,81.0899613 71.6643757,81.0053177 L71.5,81 Z M71.5,57 L18.5,57 C17.1192881,57 16,58.1192881 16,59.5 C16,60.8254834 17.0315359,61.9100387 18.3356243,61.9946823 L18.5,62 L71.5,62 C72.8807119,62 74,60.8807119 74,59.5 C74,58.1192881 72.8807119,57 71.5,57 Z M71.5,33 L18.5,33 C17.1192881,33 16,34.1192881 16,35.5 C16,36.8254834 17.0315359,37.9100387 18.3356243,37.9946823 L18.5,38 L71.5,38 C72.8807119,38 74,36.8807119 74,35.5 C74,34.1192881 72.8807119,33 71.5,33 Z"></path>
																		</svg>
																	</li>
																</ul>
															</div>
														</div>
		</div>
		<div id="submit_formactif_user">
		<fieldset class="fieldset_exerotp">
		<legend class="legend_exerotp"><?= Translator('details') ;?></legend>
		<?php $supposed_ip_publisher = trim(shell_exec("ip a | grep inet | grep -v inet6 | grep -v 'inet 127.0.0.1' | cut -d ' ' -f6 | cut -d '/' -f1"));?>
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label for="source_ip_or_fqdn_addr"><?= Translator('IP_or_FQDN_Publisher') ;?>: <b class="text-danger" title="Ce champ est obligatoire" data-toggle="tooltip" data-placement="right"><i class="far fa-asterisk"></i></b></label>
							<input type="text" name="source_ip_or_fqdn_addr" autocomplete="off" class="form-control" id="source_ip_or_fqdn_addr" value="<?php if (isset($source_ip_or_fqdn_addr)) { echo $source_ip_or_fqdn_addr; } ?>" placeholder="ex : <?php echo $supposed_ip_publisher; ?>">  
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label for="sub_ip_or_fqdn_addr"><?= Translator('IP_or_FQDN_Subscriber') ;?> : <b class="text-danger" title="Ce champ est obligatoire" data-toggle="tooltip" data-placement="right"><i class="far fa-asterisk"></i></b></label>
							<input type="text" name="sub_ip_or_fqdn_addr" autocomplete="off" class="form-control" id="sub_ip_or_fqdn_addr" value="<?php if (isset($sub_ip_or_fqdn_addr)) { echo $sub_ip_or_fqdn_addr; } ?>" placeholder="ex : A.B.C.D">
						</div>
					</div>
				</div>	
				<div class="form-group">
					<label for="mdp_root_subscriber"><?= Translator('Password_Subscriber') ;?> : <b class="text-danger" title="Ce champ est obligatoire" data-toggle="tooltip" data-placement="right"><i class="far fa-asterisk"></i></b></label>
					
					<div class="row">
						<div class="col-lg-8">
							<input type="password" name="mdp_root_subscriber" autocomplete="off" class="form-control" id="mdp_root_subscriber" value="<?php if (isset($mdp_root_subscriber)) { echo $mdp_root_subscriber; } ?>">
						</div>
					</div>
				</div>
		</div>
				</form>
		</fieldset>
		<?php
		//Si on clique sur suivant après avoir rempli le formulaire 
		if (isset($_POST['nextsubmit_add_actif'])) {
			if (empty($_POST['source_ip_or_fqdn_addr']) OR empty($_POST['sub_ip_or_fqdn_addr']) OR empty($_POST['mdp_root_subscriber'])){
				$Session->setFlash(Translator('Fill_all_fields'), "close", "error");
				header('Location: '.$actual_link);
				exit();
			}
			else
			{
				if (filter_var($_POST['source_ip_or_fqdn_addr'], FILTER_VALIDATE_IP) || filter_var($_POST['source_ip_or_fqdn_addr'], FILTER_VALIDATE_DOMAIN)) {
					$source_ip_or_fqdn_addr 	= 	htmlspecialchars($_POST['source_ip_or_fqdn_addr']);
				} 
				elseif ($_POST['sub_ip_or_fqdn_addr'] == "127.0.0.1" || $_POST['source_ip_or_fqdn_addr'] == "127.0.0.1") {
					$Session->setFlash(Translator('No_localhost_ip'), "close", "error");
					header('Location: '.$actual_link);
					exit();
				}
				else {
					$Session->setFlash(Translator('Correct_ip'), "close", "error");
					header('Location: '.$actual_link);
					exit();
				}
				if (filter_var($_POST['sub_ip_or_fqdn_addr'], FILTER_VALIDATE_IP) || filter_var($_POST['sub_ip_or_fqdn_addr'], FILTER_VALIDATE_DOMAIN)) {
					$sub_ip_or_fqdn_addr 	= 	htmlspecialchars($_POST['sub_ip_or_fqdn_addr']);
				}
				else {
					$Session->setFlash(Translator('Correct_ip'), "close", "error");
					header('Location: '.$actual_link);
					exit();
				}
				$mdp_root_subscriber = $_POST['mdp_root_subscriber'];
				//Special encode "'" character in password
				$mdp_root_subscriber   = str_replace("'", "'\"'\"'", $mdp_root_subscriber);
				
				//Appel au script d'ajout de la VM
				$output = null;
				$retval = null;
				if (testopenssh($sub_ip_or_fqdn_addr) == 1) {
					exec("sudo bash /usr/local/bin/cluster.sh -H " . $source_ip_or_fqdn_addr . " -s " . $sub_ip_or_fqdn_addr . " -p '" . $mdp_root_subscriber . "'" , $output, $retval);
					if($retval == 2){
						$Session->setFlash(Translator('Different_ip_address'), "close", "error");
						header('Location: '.$actual_link);
						exit();
					}
					if($retval == 3){
						$Session->setFlash(Translator('Different_version'), "close", "error");
						header('Location: '.$actual_link);
						exit();
					}
					if($retval == 4){
						$Session->setFlash(Translator('Unable_to_reach_subscriber'), "close", "error");
						header('Location: '.$actual_link);
						exit();
					}
					if($retval == 5){
						$Session->setFlash(Translator('Bad_password'), "close", "error");
						header('Location: '.$actual_link);
						exit();
					}
					if($retval == 6){
						$Session->setFlash(Translator('active_active_already_set_up'), "close", "error");
						header('Location: /cluster.php');
						exit();
					}
					if($retval == 7){
						$Session->setFlash(Translator('Ssh_not_effective'), "close", "error");
						header('Location: '.$actual_link);
						exit();
					}
					if($retval == 8){
						$Session->setFlash(Translator('Unable_to_reach_publisher'), "close", "error");
						header('Location: '.$actual_link);
						exit();
					}
					if($retval == 0){
						//Ajout dans la bdd
						$first_synchro = date("Y-m-d H:i:s");
						$created_at	= 	return_date_all_actuelle();
						$insert_actif = $db->prepare("INSERT INTO otp_actif(ip_publisher, ip_subscriber, status, created_at, last_synchro) VALUES(?, ?, ?, ?, ?)");
						$insert_actif->execute(array($source_ip_or_fqdn_addr, $sub_ip_or_fqdn_addr, "Actif", $created_at, $first_synchro ));
						//Ajout action dans les logs d'EXER otp si l'action a réussie
						addLogEventOTP("[SUCCESS] The VM OTP " . $sub_ip_or_fqdn_addr . " has been added by " . $_SESSION['username'] );
						$Session->setFlash(Translator('VM_add'), "check", "success");
						header('Location: /cluster.php');
						exit();
					}
				}
				else
				{
					$Session->setFlash( Translator('Error_socket'), "close", "error");
						header('Location: '.$actual_link);
						exit();
				}
				
			}
			
		}


		}
		else
		{
		$Session->setFlash("Translator('Error_rights') " . $_SESSION['level'] , "close", "error");
		header('Location: /index.php');
		exit();
		}
	}
	
}
else
{
	$Session->setFlash("Translator('Error_rights')", "close", "error");
	header('Location: /index.php');
	exit();
}

include 'inc/footer.php'; 
?>
</main>


