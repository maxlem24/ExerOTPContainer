$('#home-tab').removeClass('active');
$('#mail-tab').addClass('active');
$('#set_home').removeClass('active');
$('#set_mail').addClass('active');
$('#set_mail').removeClass('fade');