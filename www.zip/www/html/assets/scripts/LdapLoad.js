$('.reloadUsersTable').click(function() {
	$('.loadLdapUsers').load('/inc/api/ldapconnection.php');
});