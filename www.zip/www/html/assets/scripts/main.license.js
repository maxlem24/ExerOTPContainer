$('#home-tab').removeClass('active');
$('#license-tab').addClass('active');
$('#set_home').removeClass('active');
$('#set_licence_file').addClass('active');
$('#set_licence_file').removeClass('fade');