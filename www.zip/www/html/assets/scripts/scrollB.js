var objDiv = document.getElementById("table_logsexer");
objDiv.scrollTop = objDiv.scrollHeight;