<?php 
/**
*   @category EXER OTP Appliance
*   @author EXER SAS <support@exer.fr>
*   @copyright 2022 EXER
*   @api Account Page
*
*	@editedBY Laurent Asselin
*   @lastEdited 07/10/2022
*/

	include 'inc/translator.php';
	
	$module_page_name 	= Translator('MyAccount');
	$show_navbar 		= true;
	$show_creds_usr 	= true;

	include_once 'inc/header.php'; 
	
	if (isset($_GET['Interface'])) {
		$Interface = htmlspecialchars($_GET['Interface']);
	} else {
		$Interface = NULL;
	}
?>

	<main role="main" class="col-md-10 ml-sm-auto col-lg-10">
		<form method="POST">
			<?php if ($Interface == "EditAccount") { ?>
			<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
				<h1 class="h2"><?= $module_page_name ?></h1>
			</div>
				<?php
					if (isset($_POST['save_formeditusr'])) {
						$recup_passw = $db->prepare('SELECT * FROM otp_users WHERE id = ?');
						$recup_passw->execute(array($_SESSION['id']));
						$pass = $recup_passw->fetch();
						
						$confirm_password_save = $_POST['confirm_password_save'];
						
						if (password_verify($_POST['confirm_password_save'], $pass['password'])) {
							$requser = $db->prepare("SELECT * FROM otp_users WHERE token = ?");
							$requser->execute(array($_SESSION['token']));
							$user = $requser->fetch();
											
								if (isset($_POST['lastname_inp_adduser']) AND !empty($_POST['lastname_inp_adduser']) AND $_POST['lastname_inp_adduser'] != $user['lastname']) {
									$lastname_inp_adduser = htmlspecialchars($_POST['lastname_inp_adduser']);
												
									if ($lastnameexist == 0) {
										$insertname = $db->prepare("UPDATE otp_users SET lastname = ? WHERE token = ?");
										$insertname->execute(array($lastname_inp_adduser, $_SESSION['token']));
													
										addLogEventOTP("[INFORMATION] Account " . $_SESSION['username'] . " has successfully modified " . $user['username'] . "details. (lastname)");
										$Session->setFlash(Translator('Save_change2'), "check", "success");
										header('Location: /account.php');
									}
								}
											
								if (isset($_POST['firstname_inp_adduser']) AND !empty($_POST['firstname_inp_adduser']) AND $_POST['firstname_inp_adduser'] != $user['firstname']) {
									$firstname_inp_adduser = htmlspecialchars($_POST['firstname_inp_adduser']);
												
									$insertlstname = $db->prepare("UPDATE otp_users SET firstname = ? WHERE token = ?");
									$insertlstname->execute(array($firstname_inp_adduser, $_SESSION['token']));
													
									addLogEventOTP("[INFORMATION] Account " . $_SESSION['username'] . " has successfully modified " . $user['username'] . "details. (firstname)");
									$Session->setFlash(Translator('Save_change2'), "check", "success");
									header('Location: /account.php');
								}
											
								if (isset($_POST['username_inp_adduser']) AND !empty($_POST['username_inp_adduser']) AND $_POST['username_inp_adduser'] != $user['username']) {
									$username_inp_adduser = htmlspecialchars($_POST['username_inp_adduser']);
									$req_usrname = $db->prepare("SELECT * FROM otp_users WHERE username = ?");
									$req_usrname->execute(array($username_inp_adduser));
									$CountRecThisU = $req_usrname->rowCount();
													
									if ($CountRecThisU == 0) {
										$insertusrname = $db->prepare("UPDATE otp_users SET username = ? WHERE token = ?");
										$insertusrname->execute(array($username_inp_adduser, $_SESSION['token']));
													
										addLogEventOTP("[INFORMATION] Account " . $_SESSION['username'] . " has successfully modified " . $user['username'] ."details. (username)");
										$Session->setFlash(Translator('Save_change2'), "check", "success");
										header('Location: /account.php');
									} else {
										$Session->setFlash(Translator('user_already_exists'), "close", "error");
										header('Location: /account.php');
										exit();
									}
								}
											
								if (isset($_POST['email_inp_adduser']) AND !empty($_POST['email_inp_adduser']) AND $_POST['email_inp_adduser'] != $user['email']) {
									$email_inp_adduser = htmlspecialchars($_POST['email_inp_adduser']);
									$req_email = $db->prepare("SELECT * FROM otp_users WHERE email = ?");
									$req_email->execute(array($email_inp_adduser));
									$emailexist = $req_email->rowCount();
													
									if ($emailexist == 0) {
										$insertemail = $db->prepare("UPDATE otp_users SET email = ? WHERE token = ?");
										$insertemail->execute(array($email_inp_adduser, $_SESSION['token']));
													
										addLogEventOTP("[INFORMATION] Account " . $_SESSION['username'] . " has successfully modified " . $user['username'] . "details. (email)");
										$Session->setFlash(Translator('Save_change2'), "check", "success");
										header('Location: /account.php');
									} else {
										$Session->setFlash(Translator('email-already-exists'), "close", "error");
										header('Location: /account.php');
										exit();
									}
								}
											
								if (isset($_POST['confirm_password_inp_adduser']) AND !empty($_POST['confirm_password_inp_adduser'])) {
									if ($_POST['password_inp_adduser'] == $_POST['confirm_password_inp_adduser']) {
										$confirm_password_inp_adduser = $_POST['confirm_password_inp_adduser'];
										$encrypt_password = password_hash($confirm_password_inp_adduser, PASSWORD_BCRYPT);
													
										$update_password = $db->prepare("UPDATE otp_users SET password = ? WHERE token = ?");
										$update_password->execute(array($encrypt_password, $_SESSION['token']));
													
										addLogEventOTP("[INFORMATION] Account " . $_SESSION['username'] . "  has successfully modified " . $user['username'] . "details. (password)");
										$Session->setFlash(Translator('Save_change2'), "check", "success");
										header('Location: /account.php');
									} else {
										$Session->setFlash(Translator('password_no_match'), "close", "error");
										header('Location: /account.php');
										exit();
									}
								}
											
								if (isset($_POST['level_inp_adduser']) AND !empty($_POST['level_inp_adduser']) AND $_POST['level_inp_adduser'] != $user['level']) {
									$level_inp_adduser = htmlspecialchars($_POST['level_inp_adduser']);
												
									$update_level = $db->prepare("UPDATE otp_users SET level = ? WHERE token = ?");
									$update_level->execute(array($level_inp_adduser, $_SESSION['token']));
												
									addLogEventOTP("[INFORMATION] Account " . $_SESSION['username'] . "  has successfully modified " . $user['username'] . "details. (level.account)");
									$Session->setFlash(Translator('Save_change2'), "check", "success");
									header('Location: /account.php');
								}
											
								if (isset($_POST['enable_inp_adduser']) AND !empty($_POST['enable_inp_adduser']) AND $_POST['enable_inp_adduser'] != $user['enable']) {
									$enable_inp_adduser = htmlspecialchars($_POST['enable_inp_adduser']);
												
									$update_level = $db->prepare("UPDATE otp_users SET enable = ? WHERE token = ?");
									$update_level->execute(array($enable_inp_adduser, $_SESSION['token']));
												
									addLogEventOTP("[INFORMATION] Account " . $_SESSION['username'] . "  has successfully modified " . $user['username'] . "details. (enable.account)");
									$Session->setFlash(Translator('Save_change2'), "check", "success");
									header('Location: /account.php');
								}
											
								$token 	= generateToken(9999);		
								$change_token = $db->prepare("UPDATE otp_users SET token = ? WHERE token = ?");
								$change_token->execute(array($token, $_SESSION['token']));
						} else {
							$Session->setFlash(Translator('Bad_password'), "close", "error");
							header('Location: /account.php');
							exit();
						}
					}			
				?>
				
				<div class="modal fade" id="modal_save_editusr" tabindex="-1" role="dialog" aria-labelledby="modal_save_editusr" aria-hidden="true">
					<div class="modal-dialog modal-lg" role="document">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title" id="lblconfirm_view_fireclient"><i class="far fa-user"></i> <?= Translator('Confirm_identity');?></b></h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true"><i class="far fa-times"></i></span>
								</button>
							</div>
							
							<div class="modal-body" id="modal_save_editusr">
								<?= Translator('Save_change');?><br>	<br>
								<div class="form-group">
									<input type="password" name="confirm_password_save" autofocus="true" autocomplete="off" class="form-control" id="confirm_password_save" placeholder=<?= Translator('Password');?>>
								</div>
							</div>

							<div class="modal-footer">
								<button type="submit" name="save_formeditusr" class="exerotpbtn btn-green ripple-effect ripple-white"><?= Translator('Confirm');?></button>
								<button type="button" class="exerotpbtn btn-cancel ripple-effect ripple-white" data-dismiss="modal"><?= Translator('Cancel');?></button>
							</div>
						</div>
					</div>
				</div>
				<br>		
				<div class="contain_controlbtns__editusr" id="section_editusr__btncontrols__4e0eea5570c37ba1620c91284799da" style="display: block; position: absolute; top: 150px; left: 77%;">
					<button data-toggle="modal" data-target="#modal_save_editusr" id="save_editusr" type="button" class="exerotpbtn btn-fab-mini btn-save ripple-effect ripple-white" title=<?= Translator('Save');?>>
						<i class="far fa-save" style="margin-bottom: 3px;"></i>
					</button>
					
					<a href="/account.php"><button type="button" id="cancel_editusr" class="exerotpbtn btn-fab-mini btn-cancel ripple-effect ripple-white" title=<?= Translator('Cancel');?>>
						<i class="far fa-times" style="margin-bottom: 3px;"></i>
					</button></a>
				</div>
								
				<fieldset class="fieldset_exerotp">
					<legend class="legend_exerotp"><?= Translator('Edit_account');?></legend>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label for="lastname_inp_adduser"><?= Translator('name');?>:</label>
								<input type="text" name="lastname_inp_adduser" autocomplete="off" class="form-control" id="lastname_inp_adduser" value="<?= $_SESSION['lastname'] ?>" placeholder="<?= $_SESSION['lastname'] ?>">
							</div>
						</div>
									
						<div class="col-md-6">
							<div class="form-group">
								<label for="firstname_inp_adduser"><?= Translator('First_name');?>:</label>
								<input type="text" name="firstname_inp_adduser" autocomplete="off" class="form-control" id="firstname_inp_adduser" value="<?= $_SESSION['firstname'] ?>" placeholder="<?= $_SESSION['firstname'] ?>">
							</div>
						</div>
					</div>
							
					<div class="form-group">
						<label for="username_inp_adduser"><?= Translator('User_name');?> :</label>
						<input type="text" name="username_inp_adduser" autocomplete="off" class="form-control" id="username_inp_adduser" value="<?= $_SESSION['username'] ?>" placeholder="<?= $_SESSION['username'] ?>">
					</div>
								
					<div class="form-group">
						<label for="email_inp_adduser"><?= Translator('Email');?> </label>
						<input type="text" name="email_inp_adduser" autocomplete="off" class="form-control" id="email_inp_adduser" value="<?= $_SESSION['email'] ?>" placeholder="<?= $_SESSION['email'] ?>">
					</div>
					
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label for="password_inp_adduser"><?= Translator('Password');?> : </label>
								<input type="password" name="password_inp_adduser" autocomplete="off" class="form-control" id="password_inp_adduser" placeholder="••••••">
							</div>
						</div>
									
						<div class="col-md-6">
							<div class="form-group">
								<label for="confirm_password_inp_adduser"><?= Translator('Confirm_password');?></label>
								<input type="password" name="confirm_password_inp_adduser" autocomplete="off" class="form-control" id="confirm_password_inp_adduser" placeholder="••••••">
							</div>
						</div>
					</div>
				</fieldset>
			<?php } else { ?>
			<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
				<h1 class="h3"><?= $module_page_name ?></h1>

				<?php
					if (isset($_POST['editUserAccountInfos'])) {
						header('Location: /account.php?Interface=EditAccount');
						exit();
					}
				?>
				
				<form method="post">
					<button class="exerotpbtn btn-white btn-sm ripple-effect ripple-dark" name="editUserAccountInfos" title=<?= Translator('edit_user_file');?>><i class="far fa-user-edit dwnl_small_addelement_icon"></i> <?= Translator('Edit_info');?></button>
				</form>
			</div>
			
			<?php if (!isset($_SESSION['id'])) { ?>
			<div class="alert alert-danger" role="alert">
				<i class="fas fa-exclamation-triangle"></i> <?= Translator('No_user_has_been_found');?>
			</div>
			<?php } else { ?>
			<ul class="nav nav-pills nav-fill">
				<li class="nav-item active">
					<a href="" data-target="#profile" data-toggle="tab" class="nav-link active"><?= Translator('view');?></a>
				</li>
				<li class="nav-item">
					<a href="" data-target="#connections" data-toggle="tab" class="nav-link"><?= Translator('Connections');?></a>
				</li>
			</ul>

			<div class="tab-content">
				<div class="tab-pane active" id="profile">
					<style>
					html {
						overflow-x:hidden;
					}
					</style>


					<div class="row" style="margin-top: 5rem;width: 117%;">
						<div class="card-exer col-md-5">
							<div style="margin-left: auto; margin-right: auto; width: 5em;">
								<img src="/assets/images/exer_user_default.png" class="rounded-circle default_avatar_exer" alt="default user exer" style="position: relative; top: -5rem; max-height: 7rem; border: 1px solid #D5E3EC;">
							</div>
							
							<div class="text-center" style="margin-top: -4rem;">
								<h1 class="text-truncate"><?= $_SESSION['firstname'] ?> <?= $_SESSION['lastname'] ?></h1>
							</div>
							<p>
								<label>
									<i class="fal fa-envelope"></i>
									<?= Translator('Email');?> <a title=<?= Translator('send_a_email_to');?> <?= $_SESSION['email'] ?>" href="mailto://<?= $_SESSION['email'] ?>"><?= $_SESSION['email'] ?></a>
								</label><br>
								<label>
									<i class="fal fa-user"></i>
									<?= Translator('user');?>: <?= $_SESSION['username'] ?>
								</label><br>
								<label>
									<i class="fal fa-crown"></i>
									<?= Translator('Access_rights');?> <?php if ($_SESSION['level'] ==1 ) { echo "Opérateur Help-Desk"; } elseif ($_SESSION['level'] ==2 ) { echo Translator('Administrators'); } elseif ($_SESSION['level'] ==3 ) { echo Translator('Supervisor'); } ?>
								</label>
							</p>
							<hr>
							<p>
								<label>
									<i class="fal fa-clock"></i>
									<?= Translator('last_connection');?> <?php if ($_SESSION['last_connected'] != "0000-00-00 00:00:00") { echo date_format(date_create($_SESSION['last_connected']),"d/m/Y H:i"); } else { echo Translator('date_last_conenction'); } ?>
								</label>
							</p>
							<p>
								<label>
									<i class="fal fa-chart-network"></i>
									<?= Translator('IPAddressConnection');?> : <?php if (!empty($_SESSION['lastip'])) { echo $_SESSION['lastip']; } else { echo Translator('last_connection'); } ?>
								</label>
							</p>
						</div>
						<div class="card-exer col-md-5">
							<div class="text-center">
								<?php
									// Recup des données de l'entreprise
									$recup_corp = $db->prepare('SELECT * FROM otp_companies WHERE corpid = ?');
									$recup_corp->execute(array($_SESSION['corp']));
									
									$crp_data = $recup_corp->fetch();

									if ($crp_data['logosrc'] == "not_defined" || $_SESSION['corp'] == "NOT_DEFINED") {
										$LogoCompany = "/assets/images/exer_logo_black.png";
									} else {
										$LogoCompany = $crp_data['logosrc'];
									}
								?>
								<img src="<?= $LogoCompany ?>" style="min-height: 3.5rem;max-height: 3.5rem;margin-bottom:1rem;" alt="Logo <?= $crp_data['name'] ?>">
								<br>

								<?php 
									if($_SESSION['corp'] != "NOT_DEFINED") {
										echo "<h1 class=\"text-truncate\">".$crp_data['name']."</h1>";
									} else {
										echo "<hr><p>".Translator('global_system').'<br>'.Translator('user_licence'). $licence_home."</p>";
									}
								?>
							</div>

							<?php if($_SESSION['corp'] != "NOT_DEFINED") { ?>
							<p>
								<label>
									<i class="fal fa-envelope"></i>
									<?= Translator('EmailContact');?> <a title=<?= Translator('send_a_email_to');?> <?= $crp_data['contact_email'] ?>" href="mailto://<?= $crp_data['contact_email'] ?>"><?= $crp_data['contact_email'] ?></a>
								</label><br>
							</p>
							<hr>

							<?php 
								// Licence informations
								$OTPusersCounter = $db->prepare('SELECT * FROM otp_tokens WHERE corpid = ?');
								$OTPusersCounter->execute(array($crp_data['corpid']));
								$countOTPUsers = $OTPusersCounter->rowCount();
							?>
							<p>
								<label>
									<i class="fal fa-file-certificate"></i>
									<?= Translator('Licensee');?> <?= $crp_data['name'] ?>
									
								</label><br>
								<label>
									<i class="fal fa-users"></i>
									<?= Translator('AccessUsage');?> <?= $countOTPUsers ?>/<?= $crp_data['users_max'] ?>
								</label><br>
								<label>
									<i class="fal fa-clock"></i>
									<?= Translator('LicenseExpiryDate');?><?= $DumpExpireDateold ?>
								</label>
							</p>
							<?php } ?>
						</div>
					</div>
				</div>
				<div class="tab-pane" id="connections">
					<br>
					<?php 
						//Recuperation des connexions effectuées sur le système pour cet utilisateur
						$recup_connections_usr = $db->prepare('SELECT * FROM otp_connections WHERE userid = ? ORDER BY id DESC');
						$recup_connections_usr->execute(array($_SESSION['id']));
						$count_connections = $recup_connections_usr->rowCount();
					?>
					<?php if ($count_connections == 0) { ?>
					<div class="alert alert-danger" role="alert">
						<i class="far fa-exclamation-circle"></i> <?= Translator('No_connec_syst');?>
					</div>
					<?php } else { ?>
					<div class="alert alert-info" role="alert">
						<i class="far fa-exclamation-circle"></i> <strong><?= $count_connections ?> </strong> <?php if ($count_connections > 1) { echo Translator('Connections'); } else { echo Translator('Connection'); } ?>
					</div>

					<input type="text" id="searchboxTable" placeholder="<?= Translator('Search_for_a_connection');?>" title="<?= Translator('fill_this_field_with_keyword');?>" >

					<script>
						$(document).ready(function() {
							$("#searchboxTable").on("keyup", function() {
								var value = $(this).val().toLowerCase();
								$("#byValDataT tr").filter(function() {
									$(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
								});
							});

							$("#searchboxTable").on("keyup", function() {
								var name = $(this).val();
								if (name.length >= 1) {
								var box = paginator({
									table: document.getElementById("container_table").getElementsByTagName("table")[0],
									box_mode: "list",
									rows_per_page: "0",
									get_rows: function () {
										return document.getElementById("table_otpexer").getElementsByTagName("tbody");
									},
								});
								$('.pgnt_tab').hide();
								return false;
								} else {
								var box = paginator({
									table: document.getElementById("container_table").getElementsByTagName("table")[0],
									box_mode: "list",
									rows_per_page: "10",
								});
								$('.pgnt_tab').show();
								return false;
								}
							});

							var box = paginator({
								table: document.getElementById("container_table").getElementsByTagName("table")[0],
								box_mode: "list",
								rows_per_page: "10",
							});
							document.getElementById("container_table").appendChild(box);
						});
					</script>
					
					<div class="table-responsive" id="container_table">
						<div class="table-responsive">
							<table id="table_otpexer" class="sortable-theme-bootstrap table-striped" data-sortable style="max-height: 170px;">
								<thead class="thead-light">
									<tr>
										<th class="vt-default-th" data-sorted-direction="descending"><?= Translator('IP_addr');?></th>
										<th><?= Translator('Login_date');?></th>
									</tr>
								</thead>
								<tbody id="byValDataT">
									<?php while ($recorver_connections = $recup_connections_usr->fetch()) { ?>
										<tr>
											<td><?= $recorver_connections['ipaddress'] ?></td>
											<td><?php if ($recorver_connections['connected_at'] != "0000-00-00 00:00:00") { echo date_format(date_create($recorver_connections['connected_at']),"d/m/Y H:i"); } else { echo Translator('no_connection_date'); } ?></td>
										</tr>
									<?php } ?>
								</tbody>
							</table>
						</div>
					</div>
					<br><br>
					<?php } ?>
				</div>
			</div>
			<?php } ?>
		</form>
		<?php } ?>
	</main>

<?php include 'inc/footer.php'; ?>