<?php 
//  Last modified on 23/03/2022
// 	by Laurent Asselin

	$module_page_name = "Utilisateur désactivé...";
	$show_navbar = false;
	$show_creds_usr = false;
	include 'inc/header.php';
	include_once $_SERVER['DOCUMENT_ROOT'] . '/inc/translator.php';
	
	if ($_SESSION['enable'] ==0) {
		if (isset($_POST['reloggin_exerotp'])) {
			header('Location: /');
			exit();
		}
		
		//Enregistrement date
		$date_actuelle  =   date('Y-m-d H:i:s');
		$recovery_last_connection = $db->prepare("UPDATE otp_users SET last_connected = NOW() WHERE id = {$_SESSION['id']} LIMIT 1");
		$recovery_last_connection->execute(array($date_actuelle, $_SESSION['id']));
		
		//Enregitrement connexion dans le journal des connexions 'otp_connections'
		$query = @unserialize(file_get_contents('http://ip-api.com/php/'.$recorver_connections['ipaddress']));
		if($query && $query['status'] == 'success') {
			$location = $query['city'].", ".$query['regionName'] . " (" . $query['region'] . ") - ".$query['country'];
		
			$insert_this_connection = $db->prepare("INSERT INTO otp_connections(userid, ipaddress, location, connected_at) VALUES(?, ?, ?, ?)");
			$insert_this_connection->execute(array($_SESSION['id'], $ip_get, $location, return_date_all_actuelle()));
		}														
		
		//Enregistrement adresse ip du client
		$recovery_last_connection = $db->prepare("UPDATE otp_users SET lastip = ? WHERE id = ?");
		$recovery_last_connection->execute(array($ip_get, $_SESSION['id']));

		//Suppresion des donnees de la session
		$_SESSION = array();
		session_destroy();
		exit();

		header('Location: /');
	} else {
		header('Location: /');
		exit();
	}
?>

	<main role="main" class="col-md-10 ml-sm-auto col-lg-10">
		<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
			<h1 class="h2"><?= $module_page_name ?></h1>
		</div>
		
		<div class="alert alert-danger" role="alert">
			<i class="fas fa-info-circle"></i> <?= Translator('Your_acc_has_been_deac') ; ?>
			<br>
			<?= Translator('As_a_result') ; ?>
		</div>
		<form action="index.php">
			<p>
				<button type="submit" name="reloggin_exerotp" class="exerotpbtn btn-defaultexer ripple-effect ripple-white"><?= Translator('Log_in...') ;?></button>
			</p>
		</form>
	</main>

<?php include 'inc/footer.php'; ?>