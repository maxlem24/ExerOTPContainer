<?php
	// Dernières modifications le : 03/05/2022
	// Par: Laurent ASSELIN

include_once $_SERVER['DOCUMENT_ROOT'] . '/inc/translator.php';

$module_page_name 	= Translator('Maintenance');
$show_navbar 		= true;
$show_creds_usr 	= true;

include_once 'inc/header.php';

if (isset($_POST['download_logs_exerotp__auth'])) {
	$_SESSION['crftoken_dnwl_logs'] = "NsFjZVuu6SJYKVqXknt4pJEhtHnq9umGArkk5Je7UcVaZFEzH3UAwYsfvt5RJKNhTFtYeHzVb9MnGHFSyhZMw6hKEATfvS7ycDC4ZjrHexdeJMJtZmM7tcnJyWaucxsd";
	header('Location: inc/class.downloadlogs.php?verb=download&filelog=EventsAuth');
}

if (isset($_POST['download_logs_exerotp__freeradius'])) {
	$_SESSION['crftoken_dnwl_logs'] = "NsFjZVuu6SJYKVqXknt4pJEhtHnq9umGArkk5Je7UcVaZFEzH3UAwYsfvt5RJKNhTFtYeHzVb9MnGHFSyhZMw6hKEATfvS7ycDC4ZjrHexdeJMJtZmM7tcnJyWaucxsd";
	header('Location: inc/class.downloadlogs.php?verb=download&filelog=EventsFreeradius');
}

if (isset($_POST['download_logs_exerotp__otp'])) {
	$_SESSION['crftoken_dnwl_logs'] = "NsFjZVuu6SJYKVqXknt4pJEhtHnq9umGArkk5Je7UcVaZFEzH3UAwYsfvt5RJKNhTFtYeHzVb9MnGHFSyhZMw6hKEATfvS7ycDC4ZjrHexdeJMJtZmM7tcnJyWaucxsd";
	header('Location: inc/class.downloadlogs.php?verb=download&filelog=EventsOTP');
}
	
	if ((checkLevel() == ADMIN) OR ((checkLevel() == OPERATOR) AND ($_SESSION['corp'] != "NOT_DEFINED"))) { ?>
		<main role="main" class="col-md-10 ml-sm-auto col-lg-10">
			<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
				<h1 class="h2"><?= $module_page_name; ?></h1>
			</div>

			<fieldset class="fieldset_exerotp">
			<legend class="legend_exerotp"><i class="far fa-file"></i> <?php echo Translator('Auth_log_files'); ?></legend>
			<div class="view_logs_servotp car_exerlogs" id="logs_auth">
				<?php
					$fp = @fopen ('/var/log/auth.log','r');
					if ($fp) {
						echo "<pre style='margin-bottom: -5px; margin-right: -5px; margin-left: -5px;'>";
						while (($newline = fgets($fp, 4096)) !== false) {
							$pos = containsWord($newline, ' radiusd_'.$_SESSION['corp_folder'].'(');
							$pos2 = containsWord($newline, ' radiusd_'.$_SESSION['corp_folder'].'_mfa(');
							
							if (($pos || $pos2) || ($pos && $pos2)) {
								echo $newline;
							}
						}
						echo "</pre>";
						fclose ($fp);
					}	
				?>
			</div>
		</fieldset>
		<br>
		<fieldset class="fieldset_exerotp">
			<legend class="legend_exerotp"><i class="far fa-file"></i> <?php echo Translator('Radius_log'); ?></legend>
			<div class="view_logs_servotp car_exerlogs">
				<?php 
				$fp = @fopen ('/var/log/radius.log','r');
				if ($fp) {
					$recup_all_firewall = $db->prepare('SELECT * FROM otp_firewall WHERE corpid = ? ORDER BY id DESC');
					$recup_all_firewall->execute(array($_SESSION['corp']));
					$count_firewall = $recup_all_firewall->rowCount();
					if ($count_firewall != 0) {
						while ($recorver_datas_fireclient = $recup_all_firewall->fetch()) {
							$fw_sname[] = $recorver_datas_fireclient['short_name'];
						}

						$count = count($fw_sname);
						echo "<pre style='margin-bottom: -5px; margin-right: -5px; margin-left: -5px;'>";
							while (($newline = fgets($fp, 4096)) !== false) {
								for ($i = 0; $i < $count; $i++) {
								$pos = containsWord($newline, 'from client '. $fw_sname[$i]);
									if ($pos !== false) {
										echo $newline;
									}
								}
							}
						echo "</pre>";
					} else {
						echo "<pre style='margin-bottom: -5px; margin-right: -5px; margin-left: -5px;'>";
						echo Translator('No_firewall_config');
						echo "</pre>";
					}
						
				}
				fclose ($fp);
				?>
			</div>
		</fieldset>
		</main>
	<?php } else { ?>
		<main role="main" class="col-md-10 ml-sm-auto col-lg-10">
			<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
				<h1 class="h2"><?= $module_page_name ?></h1>
			</div>
			
			<div <?php if ($licenceOK == true) { echo 'class="row"'; } ?>>
				<div class="col-2">
					<div class="list-group" style="position: fixed;" id="list-tab_maintenance" role="tablist">
					<?php if ($licenceOK == true) { ?>
						<a class="list-group-item ripple-effect list-group-item-action<?php if ($licenceOK == true) { ?> active<?php } ?>" id="home-tab" data-toggle="list" href="#set_home" role="tab" aria-controls="itemexer"><i class="far fa-dot-circle"></i> <?php echo Translator('general'); ?></a>
						<a class="list-group-item ripple-effect list-group-item-action" id="license-tab" data-toggle="list" href="#set_licence_file" role="tab" aria-controls="itemexer"><i class="far fa-file-certificate"></i> <?php echo Translator('Licence_2'); ?></a>
						<?php if (checkLevel() != OPERATOR) { ?>
						<a class="list-group-item ripple-effect list-group-item-action" id="mail-tab" data-toggle="list" href="#set_mail" role="tab" aria-controls="itemexer"><i class="far fa-paint-brush"></i> <?php echo Translator('Customizations'); ?></a>
						<a class="list-group-item ripple-effect list-group-item-action" id="backup-tab" data-toggle="list" href="#set_backup" role="tab" aria-controls="itemexer"><i class="far fa-archive"></i> <?php echo Translator('backup'); ?></a>
						<a class="list-group-item ripple-effect list-group-item-action" id="restaure-tab" data-toggle="list" href="#set_imports" role="tab" aria-controls="itemexer"><i class="far fa-arrow-from-bottom"></i> <?php echo Translator('Restor'); ?></a>
						<?php } ?>
						<a class="list-group-item ripple-effect list-group-item-action" id="logs-events-maint" data-toggle="list" href="#set_logs" role="tab" aria-controls="home"><i class="far fa-scroll"></i> <?php echo Translator('Log_files'); ?></a>
						<a class="list-group-item ripple-effect list-group-item-action" id="downloads-tab" data-toggle="list" href="#set_downloads" role="tab" aria-controls="itemexer"><i class="far fa-file-download"></i> <?php echo Translator('downloads'); ?></a>
						<?php if (checkLevel() != OPERATOR) { ?>
						<a class="list-group-item ripple-effect list-group-item-action" id="update-tab" data-toggle="list" href="#set_maj" role="tab" aria-controls="itemexer"><i class="far fa-wrench"></i> <?php echo Translator('update'); ?></a>
						<?php } ?>
					<?php } ?>
					</div>
				</div>
				<?php if ($licenceOK == true) { ?>
				<div class="col-10">
				<?php } ?>
				<div class="tab-content" id="nav-tabContent">
					<?php if ($licenceOK == true) { ?>
					<div class="tab-pane fade<?php if ($licenceOK == true) { ?> show active<?php } ?>" id="set_home" role="tabpanel" aria-labelledby="list-home-list">
						<!--Container homeinfos-->
						<fieldset class="fieldset_exerotp">
							<legend class="legend_exerotp"><i class="far fa-dot-circle"></i> <?php echo Translator('info_serv'); ?></legend>
							
							<b><?php echo Translator('Serv_name'); ?> : </b> <?= exec('/bin/hostname'); ?>.<?= exec('/bin/dnsdomainname') ?> <br>
							<b><?php echo Translator('System'); ?> : </b> <?= PHP_OS ?><br />
							<b><?php echo Translator('IP_addr'); ?> : </b> <?= $_SERVER['SERVER_ADDR'] ?> <br>
							<b><?php echo Translator('Start_on'); ?> : </b> <?= exec('/usr/bin/who -b'); ?> - <?= exec('/usr/bin/uptime -p'); ?><br>
							<hr>
							<b><?php echo Translator('Host'); ?> : </b> <?= $_SERVER['SERVER_NAME']; ?> <br>
							<b><?php echo Translator('Server'); ?> : </b> <?= $_SERVER['SERVER_SOFTWARE'] ?><br>	
							<b><?php echo Translator('http_list'); ?> : </b> <?= $_SERVER['SERVER_PORT'] ?>
						</fieldset>
						<br>
						<script>
							$(document).ready(function() {
								$('#rebootBtnBox').click(function() {
									$(this).hide();
									$('#Gvh5Fa').show();

									$('#preloaderRebootSrv').modal({backdrop: 'static', keyboard: false})
									
									setTimeout(function() {
										location.replace(window.location.href);
									}, 30000);
								});

								$('#FormRebootSrv').submit(function(e) {
									e.preventDefault();
									$(this).ajaxSubmit({
										url: '/inc/system/reboot.php',
										type: 'POST',
										target: '#rebootLayerForm',
										resetForm: true
									}); 
									return false;
								});
							});
						</script>

						<div class="modal fade" id="preloaderRebootSrv" tabindex="-1" role="dialog" aria-labelledby="lblspreloaderRebootSrv" aria-hidden="true">
							<div class="modal-dialog modal-lg" role="document">
								<div class="modal-content">
									<div class="modal-body text-center">
										<i class="far fa-redo faa-spin animated text-primary" style="font-size: 5rem;margin-bottom: 20px;"></i>
										<h4 class="text-blink"><?php echo Translator('Restart_EXER'); ?></h4>
										<label><?php echo Translator('Redirect_home'); ?></label>
										<div id="rebootLayerForm"></div>
									</div>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-6">
								<fieldset class="fieldset_exerotp" style="max-height:10rem">
									<legend class="legend_exerotp"><i class="far fa-server"></i> <?php echo Translator('System'); ?></legend>
									<?php if (checkLevel() != OPERATOR) { ?>
									<form method="post" id="FormRebootSrv" style="display: contents;">
										<button type="button" id="Gvh5Fa" class="exerotpbtn btn-green btn-sm ripple-effect ripple-white w-100" title=<?php echo Translator('Restart_serv'); ?>><i class="far fa-redo dwnl_small_addelement_icon"></i> <?php echo Translator('Restart_serv'); ?></button>
										<button type="submit" id="rebootBtnBox" style="display:none;" class="exerotpbtn btn-red btn-sm ripple-effect ripple-white w-100" title=<?php echo Translator('Restart_serv'); ?>><i class="fas fa-question dwnl_small_addelement_icon"></i> <?php echo Translator('Confirm'); ?> ?</button>
									</form>
									<?php } ?>
									<button type="button" class="exerotpbtn btn-defaultexer btn-sm ripple-effect ripple-white w-100" style="margin-top:1rem;" title=<?php echo Translator('browser_cache'); ?> onclick="clearBrowserCache();"><i class="far fa-broom dwnl_small_addelement_icon"></i> <?php echo Translator('Clear_browser'); ?></button>
								</fieldset>
							</div>
							<div class="col-md-6">
								<fieldset class="fieldset_exerotp" style="max-height:8.9rem">
									<legend class="legend_exerotp"><i class="far fa-clock"></i> <?php echo Translator('Time'); ?></legend>
									<div class="text-center">
										<div class="text-secondary">
											<?php echo Translator('Server_time'); ?>
										</div>
										<h1>
										<div id="GetHoureTimer"><div class="loader"></div></div>
										<script type="text/javascript">
											var RefreshHours = setInterval(GetHoureTimer, 1000);
											function GetHoureTimer() {
												$('#GetHoureTimer').load('/modules/sysinfos.php?ElementGet=TimeNow');
											}
										</script>
										</h1>
									</div>
								</fieldset>
							</div>
						</div>

						<script>
							$('#Gvh5Fa').click(function() {
								$(this).hide();
								$('#rebootBtnBox').show();
								setTimeout(function() {
									$('#rebootBtnBox').hide();
									$('#Gvh5Fa').show();
								}, 2500);
							});
						</script>
						<br>
						<fieldset class="fieldset_exerotp">
						<legend class="legend_exerotp"><i class="far fa-server"></i> <?php echo Translator('Server'); ?> </legend>
							<div class="row">
								<div class="col-md-12">
									<div class="row">
											<div class="col-md-6" style="margin-bottom: 1rem;">
											<?php
												try {
													$diskStatus = new DiskStatus('/');
																						
													$freeSpace  = $diskStatus->freeSpace();
													$totalSpace = $diskStatus->totalSpace();
													$barWidth   = round(($diskStatus->usedSpace() / 100) * 400);  
												} catch (Exception $e) {
													echo 'Error while fetching data =>(' . $e->getMessage() . ')';
													exit();
												}
											?>
											<div class="progress progressexer">
												<div class="progress-bar barexer bg-info" role="progressbar" style="width: <?= $barWidth; ?>px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"><?= round($diskStatus->usedSpace()) ?>%&nbsp;</div>
											</div>
										</div>
										<div class="col-md-6">
											<b><?php echo Translator('Storage'); ?> : </b><?= $freeSpace ?> <?php echo Translator('Free'); ?> <?= $totalSpace ?> - <?php echo Translator('Used'); ?> : <?= $totalSpace - $freeSpace ?> GB <br>
										</div>
									</div>
								</div>
								<div class="col-md-6">
									<!--Container load_server_percentage-->
									<div id="load_server_percentage"><div class="loader sm"></div> <?php echo Translator('Recovery...'); ?></div>

									<script type="text/javascript">
										var RefreshServer = setInterval(load_server_percentage, 2000);
										function load_server_percentage() {
											$('#load_server_percentage').load('/modules/sysinfos.php?ElementGet=SystemLoad');
										}
									</script>
								</div>
								
								<div class="col-md-6">
									<!--Container SystemCores-->
									<div id="SystemCores"><div class="loader sm"></div> <?php echo Translator('Recovery...'); ?></div>

									<script type="text/javascript">
										var RefreshCores = setInterval(SystemCores, 2000);
										function SystemCores() {
											$('#SystemCores').load('/modules/sysinfos.php?ElementGet=SystemCores');
										}
									</script>
								</div>
								
								<div class="col-md-6">
									<div id="query_ramcpu_usages"><div class="loader sm"></div> <?php echo Translator('Recovery...'); ?></div>
									<script type="text/javascript">
										var RefreshRamCpu = setInterval(query_ramcpu_usages, 2000);
										function query_ramcpu_usages() {
											$('#query_ramcpu_usages').load('/modules/sysinfos.php?ElementGet=CpuRamUsage');
										}
									</script>
								</div>
								
								<div class="col-md-6">
									<!--Container ServerUptime-->
									<div id="ServerUptime"><div class="loader sm"></div> <?php echo Translator('Recovery...'); ?></div>

									<script type="text/javascript">
										var RefreshUptime = setInterval(ServerUptime, 1000);
										function ServerUptime() {
											$('#ServerUptime').load('/modules/sysinfos.php?ElementGet=ServerUptime');
										}
									</script>
								</div>
								
								<div class="col-md-6">
									<!--Container KernelVersion-->
									<div id="KernelVersion"><div class="loader sm"></div> <?php echo Translator('Recovery...'); ?></div>

									<script type="text/javascript">
										var RefreshVersion = setInterval(KernelVersion, 2000);
										function KernelVersion() {
											$('#KernelVersion').load('/modules/sysinfos.php?ElementGet=KernelVersion');
										}
									</script>
								</div>
							</div>
						</fieldset>
						<br>
					</div>
					
					<div class="tab-pane fade show" id="set_logs" role="tabpanel" aria-labelledby="list-home-list">
						<div class="text-right">
							<a href="#" id="btn-logs-events-maint">
								<i class="fas fa-arrow-from-bottom"></i> <?php echo Translator('Last_record'); ?>
							</a>
						</div>
						<fieldset class="fieldset_exerotp">
							<legend class="legend_exerotp"><i class="far fa-scroll"></i> <?php echo Translator('Auth_log_files'); ?></legend>
								<div class="view_logs_servotp car_exerlogs" id="logs_auth">
									<?php
										$fp = @fopen ('/var/log/auth.log','r');
										if ($fp) {
											echo "<pre style='margin-bottom: -5px; margin-right: -5px; margin-left: -5px;'>";
											while (($newline = fgets($fp, 4096)) !== false) {
												$pos = stripos($newline, ' radiusd_');
												if ($pos !== false) {
													echo $newline;
												}
												$pos = stripos($newline, 'freeradius');
												if ($pos !== false) {
													echo $newline;
												}
											}
											echo "</pre>";
											fclose ($fp);
										}
									?>
								</div>
							</fieldset>
							<br>
							<fieldset class="fieldset_exerotp">
								<legend class="legend_exerotp"><i class="far fa-scroll"></i> <?php echo Translator('Radius_log'); ?></legend>
								<div class="view_logs_servotp car_exerlogs">
									<?php 
										$fp = @fopen ('/var/log/radius.log','r');
										if ($fp) {
											echo "<pre style='margin-bottom: -5px; margin-right: -5px; margin-left: -5px;'>";
											while (($newline = fgets($fp, 4096)) !== false) {
												$pos = stripos($newline, 'Info:');
												if ($pos !== false) {
													echo $newline;
												}
												$pos = stripos($newline, 'ERROR:');
												if ($pos !== false) {
													echo $newline;
												}
												$pos = stripos($newline, 'Auth:');
												if ($pos !== false) {
													echo $newline;
												}
											}
											echo "</pre>";
											fclose ($fp);
										}			
									?>
								</div>
							</fieldset>
						<br><br>
					</div>
					
					<div class="tab-pane fade" id="set_downloads" role="tabpanel" aria-labelledby="list-messages-list">
						<!--Container downloads logs all-->
						<fieldset class="fieldset_exerotp">
							<legend class="legend_exerotp"><i class="far fa-file-download"></i> <?php echo Translator('downloads'); ?></legend>
							
							<form method="POST" name="downloads_logs">
								<label><?php echo Translator('Obtain_auth'); ?></label>                
								<button type="submit" style="margin-left:2.8rem;" name="download_logs_exerotp__auth" class="exerotpbtn btn-white btn-sm ripple-effect ripple-dark"><i class="far fa-download dwnl_maintenanceexer_icon"></i> <?php echo Translator('download'); ?></button><br>
								
								<label><?php echo Translator('Get_RADIUS'); ?></label>                                
								<button type="submit" style="margin-left:5rem;" name="download_logs_exerotp__freeradius" class="exerotpbtn btn-white btn-sm ripple-effect ripple-dark"><i class="far fa-download dwnl_maintenanceexer_icon"></i> <?php echo Translator('download'); ?></button><br>
								
								<label><?php echo Translator('Obtain_WebUI'); ?></label>      
								<button type="submit" style="margin-left:8.7rem;" name="download_logs_exerotp__otp" class="exerotpbtn btn-white btn-sm ripple-effect ripple-dark"><i class="far fa-download dwnl_maintenanceexer_icon"></i> <?php echo Translator('download'); ?></button>
							</form>
						</fieldset>
						<br>
					</div>
					<?php } ?>
					
					<div class="tab-pane fade <?php if ($licenceOK == false) { ?> show active<?php } ?>" id="set_licence_file" role="tabpanel" aria-labelledby="list-messages-list">
						<form method="POST" enctype="multipart/form-data">
							<?php
								if (isset($_POST['import_element_import_licence'])) {
									$all_alright = false;
									if ($_FILES["import_filelicence_import"]["name"] != '') {
										if ($_FILES["import_filelicence_import"]["error"] == UPLOAD_ERR_OK) {
											$Verify_Sign = shell_exec('cd /usr/local/bin/ && sudo ./verify_sign ' . $_FILES["import_filelicence_import"]["tmp_name"]);
											
											if ($Verify_Sign == "done") {
												$all_alright = true;
												$escaped_command = escapeshellcmd("sudo mv " . $_FILES["import_filelicence_import"]["tmp_name"] . " /home/otp.license");
												shell_exec($escaped_command);
											} else {
												addLogEventOTP("[ERROR] Invalid License");
												$Session->setFlash(Translator('licence_invalid'), "close", "error");
												header('Location: /maintenance.php');
												exit();
											}
										} else {
											$all_alright = false;
										}
									}

									if ($all_alright) {
										addLogEventOTP("[SUCCESS] The product license has been imported successfully");
										$Session->setFlash(Translator('valid_licence'), "check", "success");
										header('Location: /maintenance.php');
										exit();
									} else {
										addLogEventOTP("[ERROR] The product license has not been imported");
										$Session->setFlash(Translator('no_imported_licence'), "close", "error");
										header('Location: /maintenance.php');
										exit();
									}
								}

								if (isset($_POST['modify_licensefile'])) {
									echo "<script>include('/assets/scripts/main.license.js');</script>";

									$all_alright = false;
									if ($_FILES["import_filelicence_import"]["name"] != '') {
										if ($_FILES["import_filelicence_import"]["error"] == UPLOAD_ERR_OK) {
											$Verify_Sign = shell_exec('cd /usr/local/bin/ && sudo ./verify_sign ' . $_FILES["import_filelicence_import"]["tmp_name"]);
											
											if ($Verify_Sign == "done") {
												$all_alright = true;
												$escaped_command = escapeshellcmd("sudo mv " . $_FILES["import_filelicence_import"]["tmp_name"] . " /home/otp.license");
												shell_exec($escaped_command);
											} else {
												addLogEventOTP("[ERROR] Invalid License");
												$error = Translator('invalid_licence');
											}
										} else {
											$all_alright = false;
										}
									}

									if ($all_alright) {
										// Calcul du nombre d'entreprise cliente
										
										$recup_corp = $db->prepare('SELECT * FROM `otp_companies`');
										$recup_corp->execute();
										$corp_count = $recup_corp->rowCount();
																			
										if ($corp_count == 1) {
											// Si une seule entreprise, alors on affecte toute la licence à celle-ci et on affecte la nouvelle date d'expiration
											//Récupération du nouveau volume de licence
											$escaped_command = escapeshellcmd("/bin/sed -n '3p' /home/otp.license");
											$in = shell_exec($escaped_command);
											$out = preg_replace('~\D~', '', $in);
											if ($out == NULL)
												$out = -1;
											$new_lic = htmlspecialchars($out) + 0;
											$expire_date_licence_from_file = trim(shell_exec("/bin/grep 'End date' /home/otp.license | /usr/bin/cut -d ' ' -f3"));
											$expire_date_licence = DateTime::createFromFormat('d/m/Y', $expire_date_licence_from_file);
											$expire_date_licence_output = $expire_date_licence->format('Y-m-d');
											if ($new_lic >= 1) {
												$query_corp = $recup_corp->fetch();
												$corp_id = $query_corp['corpid'];
												// Modification des données dans la base 'otp_companies'
												$insertname = $db->prepare("UPDATE otp_companies SET users_max = ?, expire_date = ? WHERE corpid = ?");
												$insertname->execute(array($new_lic, $expire_date_licence_output, $corp_id));

												// Modification du fichier otp.license contenue dans /home/companie
												$escaped_command = escapeshellcmd("/bin/rm /home/" . $query_corp['folder'] . "/otp.license");
												shell_exec($escaped_command);
												$escaped_command = escapeshellcmd("/bin/touch /home/" . $query_corp['folder'] . "/otp.license");
												shell_exec($escaped_command);

												shell_exec("/bin/echo 'Number of licenses max : " . $new_lic . "' > /home/" . $query_corp['folder'] . "/otp.license");
																
												// Ajout dans les logs EXER OTP si tout est ok lors de la creation ==> otp_exer
												addLogEventOTP("[SUCCESS] Maximum number of users for " . $query_corp['name'] . " has been modified (" . $new_lic .")");
												addLogEventOTP("[SUCCESS] License expiration date for " . $query_corp['name'] . " has been modified (" . $expire_date_licence_from_file .")");

											} else {
												addLogEventOTP("[ERROR] Cannot change the maximum number of users for " . $query_corp['name']);
												addLogEventOTP("[ERROR] Cannot change the license expiration date for ". $query_corp['name']);
											}
										}
										addLogEventOTP("[SUCCESS] The license has been replaced");
										$Session->setFlash(Translator('remplaced_licence'), "check", "success");
										header('Location: /maintenance.php');
										exit();
									} else {
										addLogEventOTP("[ERROR] The license has not been imported ...");
										$error = Translator('invalid_licence');
									}
								}	
							?>
						
							<?php if (isset($error)) { ?>
							<div class="alert alert-danger" role="alert">
								<i class="fas fa-exclamation-triangle"></i> <?= $error ?>
							</div>
							<?php } ?>
							<?php if (isset($success)) { ?>
							<div class="alert alert-success" role="alert">
								<i class="fas fa-check-circle"></i> <?= $success ?>
							</div>
							<?php } ?>
							<fieldset class="fieldset_exerotp">
								<legend class="legend_exerotp"><i class="far fa-file-certificate"></i> <?php echo Translator('Product_manag'); ?></legend>
								<hr style="margin-top: -8px; margin-left: 218px;">
								
								<p>
								<?php if ($licenceOK == true) {
								echo '<strong class="text-success"><i class="far fa-check-circle"></i>'.Translator('activated_product').'</strong>';
								} else { ?>
								<div class="alert alert-danger">
									<i class="far fa-times-circle"></i> <?php echo Translator('Product_not_actv'); ?></strong>
								</div>
								<?php } ?>
								</p>

								<?php if ($licenceOK == true) { ?>
								<div class="alert alert-secondary">
									<strong><?php echo Translator('Licence_assign'); ?> :</strong> <?= $licence_home ?><br>
									<strong><?php echo Translator('Max_user_cap'); ?> :</strong> <?= $_SESSION['users_maximum'] ?><br>
									<strong><?php echo Translator('Expiry_date'); ?> :</strong> <?= $DumpExpireDateold ?><br>
								</div>
								<?php if (checkLevel() != OPERATOR) { ?>
									<div class="text-center">
										<div class="row">
											<div class="col-md-6 text-right">
												<button type="button" class="exerotpbtn btn-defaultexer ripple-effect ripple-white" data-toggle="modal" data-backdrop="static" data-keyboard="false" data-target="#changeLicenseFile"><i class="fas fa-file-certificate"></i> <?php echo Translator('Change_license'); ?></button>
											</div>

											<div class="col-md-4 text-left">
												<button type="button" class="exerotpbtn btn-cancel ripple-effect ripple-white" data-toggle="modal" data-backdrop="static" data-keyboard="false" data-target="#confirmrevoquelicense"><i class="fas fa-times"></i> <?php echo Translator('Delete_license'); ?></button>
											</div>
										</div>
									</div>

									<div class="modal fade" id="changeLicenseFile" tabindex="-1" role="dialog" aria-labelledby="lblchangeLicenseFile" aria-hidden="true">
										<div class="modal-dialog modal-lg" role="document">
											<div class="modal-content">
												<div class="modal-header">
													<h5 class="modal-title" id="lblchangeLicenseFile"><i class="far fa-file-certificate"></i> <?php echo Translator('Change_license'); ?></h5>
													<button type="button" class="close" data-dismiss="modal" aria-label="Close">
														<span aria-hidden="true"><i class="far fa-times"></i></span>
													</button>
												</div>
																	
												<form method="POST">
													<div class="modal-body">	
														<label><?php echo Translator('Modify_product'); ?> :</label>
														<div class="col-auto">
															<div class="input-group mb-2">
																<div class="input-group-prepend" style="margin-left: -15px;">
																	<div class="input-group-text"><i class="far fa-upload"></i></div>
																</div>
																				
																<input type="file" name="import_filelicence_import" accept=".license" autocomplete="off" class="form-control" style="height: 38px; font-size: 12px">
															</div>
														</div>
													</div>
																										
													<div class="modal-footer">	
														<button type="button" class="exerotpbtn btn-cancel ripple-effect ripple-white" data-dismiss="modal"><?php echo Translator('Cancel'); ?></button>
														<button type="submit" name="modify_licensefile" class="exerotpbtn btn-green ripple-effect ripple-white"><i class="fas fa-key dwnl_maintenanceexer_icon"></i> <?php echo Translator('Modify'); ?></button>
													</div>
												</form>
											</div>
										</div>
									</div>

									<div class="modal fade" id="confirmrevoquelicense" tabindex="-1" role="dialog" aria-labelledby="lblconfirmrevoquelicense" aria-hidden="true">
										<div class="modal-dialog modal-lg" role="document">
											<div class="modal-content">
												<?php 
													if (isset($_POST['del_licensefile'])) {
														$req_deleteLicense = escapeshellcmd('rm /home/otp.license');
														$proc_deleteLicense = shell_exec($req_deleteLicense);

														$Session->setFlash(Translator('licence_removed'), "check", "success");
														header('Location: /maintenance.php');
														exit();
													}
												?>
												
												<div class="modal-body text-center">
													<i class="fas fa-eraser text-danger" style="font-size: 5rem;margin-bottom: 20px;"></i>
													<h4 class="dfdslf12 text-danger"><?php echo Translator('Remove_product'); ?> ?</h4>
													<p>
														<?php echo Translator('Sure_remove_prod'); ?> <b><?= $licence_home ?> ?</b>
													</p>

													<div style="margin-top: 2rem;">
														<button type="button" class="exerotpbtn btn-white w-20 ripple-effect ripple-dark" data-dismiss="modal">
															<?php echo Translator('Cancel'); ?>
														</button>
														<button type="submit" name="del_licensefile" class="exerotpbtn btn-cancel w-20 ripple-effect ripple-white">
															<?php echo Translator('Confirm'); ?>
														</button>
													</div>
												</div>
											</div>
										</div>
									</div>
									<?php } ?>
								<?php } else { ?>
								<label><?= Translator('Import_prod_enable'); ?></label>
										
								<div class="row">
									<div class="col-md-9">
										<div class="col-auto">
											<div class="input-group mb-2">
												<div class="input-group-prepend" style="margin-left: -15px;">
													<div class="input-group-text"><i class="far fa-upload"></i></div>
												</div>
																
												<input type="file" name="import_filelicence_import" accept=".license" autocomplete="off" class="form-control" style="height: 38px; font-size: 12px">
											</div>
										</div>
									</div>
												
									<div class="col-md-3">
										<button type="submit" name="import_element_import_licence" class="exerotpbtn btn-green ripple-effect ripple-white" style="margin-left: -20px; width: 107%;"><i class="far fa-key dwnl_maintenanceexer_icon"></i> <?php echo Translator('Activate'); ?></button>
									</div>
								</div>		
								<?php } ?>
							</fieldset>
						</form>
					</div>

					<?php if ($licenceOK == true && checkLevel() != OPERATOR) { ?>
					<div class="tab-pane fade" id="set_mail" role="tabpanel" aria-labelledby="mail">
						<div class="modal fade" id="mailTester" tabindex="-1" role="dialog" aria-labelledby="lblmailTester" aria-hidden="true">
							<div class="modal-dialog modal-lg" role="document">
								<div class="modal-content">
									<div class="modal-header">
										<h5 class="modal-title" id="lblmailTester"><i class="far fa-file-envelope"></i> <?php echo Translator('Send_test_email'); ?></h5>
										<button type="button" class="close" data-dismiss="modal" aria-label="Close">
											<span aria-hidden="true"><i class="far fa-times"></i></span>
										</button>
									</div>
									
									<form name="mailtesterForm" method="post">
										<?php 
											if (isset($_POST['testMailSender'])) {
												if (isset($_POST['mailing_sendmail_test'])) {
													if (!empty($_POST['mailing_sendmail_test'])) {
														$SendMailTest = htmlspecialchars($_POST['mailing_sendmail_test']);
					
														if (filter_var($SendMailTest, FILTER_VALIDATE_EMAIL)) {
															$MailingConfs = $db->prepare('SELECT * FROM otp_mailing WHERE corpid = ?');
															$MailingConfs->execute(array($_SESSION['corp']));

															if ($MailingConfs->rowCount() == 1) {
																$MailingConf = $MailingConfs->fetch();

																if (!empty($MailingConf['host'])) {
																	SendMail($SendMailTest, true, $_SESSION['corp']);
					
																	$Session->setFlash(Translator('Send_test_email').$SendMailTest."</b>.", "check", "success");
																	header('Location: /maintenance.php');
																} else {
																	$Session->setFlash(Translator('config_email'), "close", "error");
																	header('Location: /maintenance.php');
																	exit();
																}
															} else {
																$Session->setFlash(Translator('config_email'), "close", "error");
																header('Location: /maintenance.php');
																exit();
															}
														} else {
															$Session->setFlash(Translator('specify_address_mail'), "close", "error");
															header('Location: /maintenance.php');
															exit();
														}
													} else {
														$Session->setFlash(Translator('Sending_email'), "close", "error");
														header('Location: /maintenance.php');
														exit();
													}
												}
											}
										?>
										<div class="modal-body">
											<label><?php echo Translator('Send_test_mess'); ?></label>
											<div class="form-group">
												<input type="mail" name="mailing_sendmail_test" autocomplete="off" class="form-control">
											</div>
										</div>
																							
										<div class="modal-footer">
											<button type="button" class="exerotpbtn btn-white ripple-effect ripple-white" data-dismiss="modal"><?php echo Translator('Cancel'); ?></button>
											<button type="submit" name="testMailSender" class="exerotpbtn btn-green ripple-effect ripple-white"><?php echo Translator('Send'); ?></button>
										</div>
									</form>
								</div>
							</div>
						</div>

						<div class="modal fade" id="resetConf" tabindex="-1" role="dialog" aria-labelledby="lblresetConf" aria-hidden="true">
							<div class="modal-dialog modal-lg" role="document">
								<div class="modal-content">
									<div class="modal-header">
										<h5 class="modal-title" id="lblresetConf"><i class="far fa-redo"></i> <?php echo Translator('Reset_custom_set'); ?></h5>
										<button type="button" class="close" data-dismiss="modal" aria-label="Close">
											<span aria-hidden="true"><i class="far fa-times"></i></span>
										</button>
									</div>
									
									<form name="resetConfForm" method="post">
										<?php 
											if (isset($_POST['resetMailConf'])) {
												ResetMailingConf($_SESSION['corp']);

												$Session->setFlash(Translator('parameter_reset'), "check", "success");
												header('Location: maintenance.php');
												exit();
											}
										?>
										<div class="modal-body">
											<label><?php echo Translator('Result_comp_reset'); ?></label>
										</div>
																							
										<div class="modal-footer">
											<button type="button" class="exerotpbtn btn-white ripple-effect ripple-white" data-dismiss="modal"><?php echo Translator('Cancel'); ?></button>
											<button type="submit" name="resetMailConf" class="exerotpbtn btn-red ripple-effect ripple-white"><?php echo Translator('Confirm'); ?></button>
										</div>
									</form>
								</div>
							</div>
						</div>

						<form method="POST" enctype="multipart/form-data">
							<?php
								if (isset($_POST['ChangeCorpLogo'])) {
									echo "<script>include('/assets/scripts/main.mail.js');</script>";

									// Change logo
									if (($_FILES['m-edit-form-logo']) && $_FILES['m-edit-form-logo']['error'] === 0) {
										$NomDuFichier 	= $_FILES["m-edit-form-logo"]["name"];
										$taille_max		= 104850; //==100Ko
										$taille_fichier = filesize($_FILES['m-edit-form-logo']['tmp_name']);
										$type_logo 		= $_FILES["m-edit-form-logo"]["type"];
										
										if ($taille_fichier > $taille_max) {
											$Session->setFlash(Translator('size_file').Translator('current_size_file') . $taille_fichier ." ". Translator('Bytes') .".", "close", "error");
											$actual_link = "https://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
											header('Location: '.$actual_link);
											exit();
										} else {
											$allowed = array("image/jpeg", "image/gif", "image/png", "image/jpg", "image/bmp");
											if (in_array($type_logo, $allowed)) {
												if (is_uploaded_file($_FILES["m-edit-form-logo"]["tmp_name"])) {
													$UploadPath 		= $_SERVER['DOCUMENT_ROOT']."/assets/images/brandmark.png";
													$UploadImgResult 	= move_uploaded_file($_FILES['m-edit-form-logo']['tmp_name'], $UploadPath);

													if ($UploadImgResult) {
														$Session->setFlash("Nouveau logo importé.", "check", "success");
														$actual_link = "https://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
														header('Location: '.$actual_link);
														exit();
													} else {
														$error = Translator("error_completing_form");
													}
												} else {
													$error = Translator('An_error_occu'). Translator('the_file')." ". $NomDuFichier .Translator('not_saved');
												}
											} else {
												$error = Translator('valid_image'). " " . Translator('image_format');
											}
										}
									} else {
										$error = Translator('need_a_image');
									}
								}
							?>

							<?php if (isset($error)) { ?>
							<div class="alert alert-danger" role="alert">
								<i class="fas fa-exclamation-triangle"></i> <?= $error ?>
							</div>
							<?php } ?>

							<fieldset class="fieldset_exerotp">
								<legend class="legend_exerotp"><i class="far fa-picture"></i> <?php echo Translator('Company_logo'); ?></legend>
								<div class="row">
									<div class="col-md-6">
										<label><?php echo Translator('Current_logo'); ?></label><br>
										<div class="view_logs_servotp car_exerlogs" style="background: gainsboro;">
											<img oncontextmenu="return false; return false" ondrag="return false; return false" onmousedown="return false; return false" class="preview_picture" src="/assets/images/brandmark.png" alt="Default Logo EXER OTP">
										</div>
									</div>
									<div class="col-md-6">
										<label><?php echo Translator('Modify'); ?> :</label><br>
										<form method="post" enctype="multipart/form-data">
											<div class="view_logs_servotp car_exerlogs text-center c-pointer" id="m-upload-changelogo" style="border: 2px dashed #a5a5a5;font-size: 25px;">
												<div id="c-before-upload">
													<i class="fas fa-cloud-upload" style="font-size: 40px;"></i>
													<b class="d-block"><?php echo Translator('Send'); ?></b>
												</div>
												<div id="c-preview-upload">
													<img src="#" alt="Preview upload Picture" id="m-preview-c-picture" style="max-height: 5rem;">
												</div>
											</div>
											<input type="file" name="m-edit-form-logo" id="m-edit-form-logo">
											
											<div id="m-for-p-up">
												<br>
												<button type="submit" name="ChangeCorpLogo" class="exerotpbtn btn-defaultexer btn-sm ripple-effect ripple-white"><?php echo Translator('Modify'); ?></button>
											</div>
										</form>
									</div>
								</div>
							</fieldset>
						</form>
					</div>
					<?php } ?>
						
					<?php if ($licenceOK == true) { ?>
					<div class="tab-pane fade" id="set_backup" role="tabpanel" aria-labelledby="backup">
						<!--Container backup-->
						<fieldset class="fieldset_exerotp">
							<legend class="legend_exerotp"><i class="far fa-archive"></i> <?= Translator('backup'); ?></legend>
							<strong><?= Translator('Global_backup'); ?></strong>
							<hr style="margin-top: -8px; margin-left: 140px;">
							<div class="row">
								<div class="col-md-12">
									<label><?= Translator('Action_download'); ?> :</label>
									<ul>
										<li><?= Translator('Files_SQL'); ?>,</li>
										<li><?= Translator('Company_data'); ?>,</li>
										<li><?= Translator('RADIUS_conf'); ?>,</li>
										<li><?= Translator('All_available'); ?></li>
									</ul>
									<form method="POST" class="text-center">
										<?php 
											if (isset($_POST['configExportAll'])) {
												header('Location: inc/class.actions.php?VerbAction=ExportAll');
												exit();
											}
										?>
										<button type="submit" name="configExportAll" class="exerotpbtn btn-defaultexer btn-sm ripple-effect ripple-white"><i class="far fa-running dwnl_maintenanceexer_icon"></i> <?= Translator('Start'); ?></button>
									</form>
								</div>
							</div>
						</fieldset>
						<br>
					</div>
					
					
					<div class="tab-pane fade" id="set_imports" role="tabpanel" aria-labelledby="imports">
						<form method="POST" enctype="multipart/form-data">
							<?php
								if (isset($_POST['import_element_all'])) {
									if (!empty($_FILES['import_filebckp_all'])) {
										$path = "/var/www/tmp/backupfile.zip";
										$zipFileType = strtolower(pathinfo($path, PATHINFO_EXTENSION));
										
										if ($zipFileType == "zip") {
											// Verification que les dossiers home et tmp existes et que tmp soient vide
											if (!file_exists("/var/www/")) {
												shell_exec("mkdir /var/www/tmp/");
											} else {
												if (!file_exists("/var/www/tmp/"))
													shell_exec("mkdir /var/www/tmp/");
												else
													shell_exec("sudo rm -r /var/www/tmp/*");
											}			
											if(move_uploaded_file($_FILES['import_filebckp_all']['tmp_name'], $path)) {
												$verification = shell_exec("sudo backup_restore.sh " . $path);
												$verification = str_replace("\n","",$verification);
												if (strcmp($verification, "done") == 0)  {
													addLogEventOTP("[SUCCESS] Restoration completed (" . $_FILES['import_filebckp_all']['name'] . ") uploaded by "  . $_SESSION['username']);
													$Session->setFlash(Translator('backup_files_deployed'), "check", "success");
													header('Location: /maintenance.php');
												} else if (strcmp($verification, "fail 1") == 0) {
													addLogEventOTP("[ERROR] Restore failed => Unable to restore data to the /home folder (" . $_FILES['import_filebckp_all']['name'] . ") uploaded by "  . $_SESSION['username']);
													$Session->setFlash(Translator('unable_home'), "close", "error");
												} else if (strcmp($verification, "fail 2") == 0) {
													addLogEventOTP("[ERROR] Restore failed => Cannot find restore SQL file from backup (" . $_FILES['import_filebckp_all']['name'] . ") uploaded by "  . $_SESSION['username']);
													$Session->setFlash(Translator('unable_sql'), "close", "error");
												} else if (strcmp($verification, "fail 3") == 0) {
													addLogEventOTP("[ERROR] Restore failed => Cannot find restore SQL file from backup (" . $_FILES['import_filebckp_all']['name'] . ") uploaded by "  . $_SESSION['username']);
													$Session->setFlash(Translator('unable_sql'), "close", "error");
												} else if (strcmp($verification, "fail 4") == 0) {
													addLogEventOTP("[ERROR] Restore failed => Unable to deploy SQL database file (" . $_FILES['import_filebckp_all']['name'] . ") uploaded by "  . $_SESSION['username']);
													$Session->setFlash(Translator('unable_deploy_sql'), "close", "error");
												} else if (strcmp($verification, "fail 5") == 0) {
													addLogEventOTP("[ERROR] Restore failed => Please specify a valid restore file (" . $_FILES['import_filebckp_all']['name'] . ") uploaded by "  . $_SESSION['username']);
													$Session->setFlash(translator('valid_restore_file'), "close", "error");
												} else if (strcmp($verification, "fail 6") == 0) {
													addLogEventOTP("[ERROR] Restore failed => Unable to deploy SQL database file (" . $_FILES['import_filebckp_all']['name'] . ") uploaded by "  . $_SESSION['username']);
													$Session->setFlash(Translator('empty_the_directory'), "close", "error");
												} else if (strcmp($verification, "fail 7") == 0) {
													addLogEventOTP("[ERROR] Restore failed => Error 7 (" . $_FILES['import_filebckp_all']['name'] . ") uploaded by "  . $_SESSION['username']);
													$Session->setFlash(Translator('empte_the_directory'), "close", "error");
												} else {
													addLogEventOTP("[ERROR] An error occurs while restoring the backup file (" . $_FILES['import_filebckp_all']['name'] . ") uploaded by " . $_SESSION['username'] . " (" . $verification . ")");
													$Session->setFlash(Translator("error_restore_file"), "close", "error");
												}
												
												header('Location: /maintenance.php');
												exit();
											} else {
												addLogEventOTP("[ERROR] An unknown error occurred while sending the backup file (" . $_FILES['import_filebckp_all']['name'] . ") uploaded by " . $_SESSION['username']);
												$Session->setFlash(Translator('sending_backup_error'), "close", "error");
												header('Location: /maintenance.php');
												exit();
											}	
										} else {
											$Session->setFlash(Translator('zipformat'), "close", "error");
											header('Location: /maintenance.php');
											exit();
										}									
									} else {
										$Session->setFlash(Translator('choose_file'), "close", "error");
										header('Location: /maintenance.php');
										exit();
									}
								}
							?>
						
							<!--Container Restauration-->
							<fieldset class="fieldset_exerotp">
								<legend class="legend_exerotp"><i class="far fa-arrow-from-bottom"></i> <?php echo Translator('Restor'); ?></legend>
								<b><?php echo Translator('overall'); ?></b>
								<hr style="margin-top: -8px; margin-left: 145px;">
								<div class="row">
									<div class="col-md-12">
										<label><?php echo Translator('Import_glob'); ?> :</label><br>
										<ul>
											<li><?php echo Translator('Files_SQL'); ?>,</li>
											<li><?php echo Translator('Company_data'); ?>,</li>
											<li><?php echo Translator('RADIUS_conf'); ?>,</li>
											<li><?php echo Translator('All_available'); ?></li>
										</ul>
										<form method="POST">
											<div class="row">
												<div class="col-md-8">
													<div class="col-auto">
														<div class="input-group mb-2">
															<div class="input-group-prepend" style="margin-left: -15px;">
																<div class="input-group-text"><i class="far fa-upload"></i></div>
															</div>
																	
															<input type="file" name="import_filebckp_all" autocomplete="off" class="form-control" style="height: 38px; font-size: 12px">
														</div>
													</div>
												</div>
												
												<div class="col-md-4">
													<button type="submit" name="import_element_all" class="sysbutton" style="margin-left: -20px; width: 107%; margin-top: 5px;"><i class="far fa-running dwnl_maintenanceexer_icon"></i><?php echo Translator('apply'); ?></button>
												</div>
											</div>
										<br>
									</div>
								</div>
							</fieldset>
							<br>
						</form>
					</div>

					<div class="tab-pane fade" id="set_maj" role="tabpanel" aria-labelledby="list-messages-list">
						<form id="majUploadForm" enctype="multipart/form-data">
							<fieldset class="fieldset_exerotp">
								<legend class="legend_exerotp"><i class="far fa-wrench"></i> <?php echo Translator('update'); ?></legend>
								<strong><?php echo Translator('Import_update'); ?></strong>
								<hr style="margin-top: -8px; margin-left: 260px;"> 
								
								<div class="row">
									<div class="col-md-8">
										<div class="col-auto">
											<div class="input-group mb-2">
												<div class="input-group-prepend" style="margin-left: -15px;">
													<div class="input-group-text"><i class="far fa-upload"></i></div>
												</div>			
												<input type="file" name="import_maj_file" id="import_maj_file" autocomplete="off" class="form-control" style="height: 38px; font-size: 12px">
											</div>
										</div>
									</div>
									
									<div class="col-md-4">
										<button type="submit" name="import_maj" id="import_maj" class="exerotpbtn btn-defaultexer ripple-effect ripple-white" style="margin-left: -20px; width: 107%;"><i class="fas fa-cloud-upload dwnl_maintenanceexer_icon"></i><?php echo Translator('Send'); ?></button>
									</div>
								</div>
							</fieldset>
							<?php
								//Ajout d'un check pour savoir s'il y a des vm otp 
								$recup_all_otp = $db->query('SELECT * FROM otp_actif ORDER BY id DESC');
								$recup_all_otp->execute(array());
								$count_all_otp = $recup_all_otp->rowCount();
								if ($count_all_otp != 0) { ?>
								<br>
						</form>

						<fieldset class="fieldset_exerotp">
							<legend class="legend_exerotp"><i class="far fa-scroll"></i><?= Translator('update_subscriber'); ?></legend>
							<form id="majUploadFormsubscriber" enctype="multipart/form-data" method="POST">
								<div class="table-responsive" id="container_table">
									<table id="table_otp_actif" class="sortable-theme-bootstrap table-striped" data-sortable>
										<thead>
											<tr>
												<th class="vt-default-th" data-sorted-direction="descending"><?= Translator('update_publiser'); ?></th>
												<th>Subscriber</th>
												<th><?= Translator('current_version'); ?></th>
												<th><?= Translator('File_to_import'); ?></th>
												<th><?= Translator('Send'); ?></th>
												<th data-sortable="false"> </th>
											</tr>
										</thead>
										<tbody id="byValDataT"> 
										<?php 
											while ($recorver_datas_actifclient = $recup_all_otp->fetch()) { ?>
											<tr>
												<td><?= $recorver_datas_actifclient['ip_publisher']; ?></td>
												<td class="column_ip_subscriber" id="column_ip_subscriber"><?= $recorver_datas_actifclient['ip_subscriber']; ?></td>
												<td>
													<?php
													if (testopenssh($recorver_datas_actifclient['ip_subscriber']) == 1) { 
														$version_vm = shell_exec("/usr/bin/sudo ssh " . $recorver_datas_actifclient['ip_subscriber'] . " 'cat /etc/version | cut -d \" \" -f3 | tr -d \"v\"'"); 
														echo $version_vm;
													} else {
														echo Translator('Login_error');
													}
													?>
												</td>
												<td><input type="file" name="import_maj_file_subscriber" class="import_maj_file_subscriber" id="import_maj_file_subscriber" autocomplete="off" class="form-control" style="height: 38px; width: 250px; font-size: 12px"></td>		
												<td><button type="submit" name="import_maj_subscriber" id="import_maj_subscriber<?= $recorver_datas_actifclient['ip_subscriber'] ?>" class="exerotpbtn btn-defaultexer ripple-effect ripple-white"  style="margin-left: auto; margin-right: auto; width: 55%; "><i class="fas fa-cloud-upload dwnl_maintenanceexer_icon"></i><?php echo Translator('Send'); ?></button></td>
											</tr>
											<?php } ?>
										</tbody>
									</table>
								</div>
							</form>
							<?php } ?>									
						</fieldset>

						<script>
						$('#majUploadForm').submit(function(e) {
							e.preventDefault();
							if ($('#import_maj_file').val()) {
								//Stoppe toutes les fonction SetInterval() pour permettre le bon affichage du déroulé de la MàJ

								clearInterval(RefreshHours);
								clearInterval(RefreshServer);
								clearInterval(RefreshCores);
								clearInterval(RefreshRamCpu);
								clearInterval(RefreshUptime);
								clearInterval(RefreshVersion);
								$('#wizardUploadMajBox').modal({backdrop: 'static', keyboard: false})
								
								$(this).ajaxSubmit({
									url: '/inc/process_update/upload.maj.php',
									type: 'POST',
									target: '#targetLayer',
									beforeSubmit: function() {
										$('#fsdm4154f').hide();
										$('#successUpdated').hide();
										$('.dfdslf12').hide();
										$('#sdqs4F').hide();
										$('#targetLayer').hide();
										$('#progressDivId').show();
										$("#progressBar").width('0%');
									},
									uploadProgress: function (event, position, total, percentComplete){	
										$("#progressBar").width(percentComplete + '%');
										$("#progressBar").html('<div id="progress-status">' + percentComplete +' %</div>')
										
										if (percentComplete == "100") {
											$('#uploadFileUpdate').hide();
											$('#dispatchUpdate').show();
										}

										setInterval('frames[0].scrollTo(0,9999999)',1000);
									},
									success:function(response) {
										if (response === "upload_ok") {
											$('#uploadFileUpdate').hide();
											$('#dispatchUpdate').hide();
											$('#successUpdated').show();
											$('#uploadNewMajLogs').remove();
										} else {
											$('.dfdslf12').show();
											$('#fsdm4154f').show();
											$('#dispatchUpdate').hide();
											$('#sdqs4F').show();
											$('#uploadFileUpdate').hide();
											$('#dmgh56f').show();
											$('#targetLayer').show();
											$('#targetLayer').html(response);
										}
									},
									resetForm: true
								}); 
								return false; 
							} else {
								alert('<?= Translator('choose_update_file'); ?>');
							}
						});

						$("button").click(function() {
							var idbutton = this.id
							ipsupposed = idbutton.slice(21);
						});

						$('#majUploadFormsubscriber').submit(function(e) {
							e.preventDefault();
							var tableObj = document.getElementById("table_otp_actif");
							var rows = tableObj.getElementsByTagName("tr");
							var cpt = 0;
							var indexfilled = 0;
							var isfiles = document.getElementsByClassName("import_maj_file_subscriber");
							for (var i = 0; i < isfiles.length; i++) {
								var str = isfiles[i].value;
								if (str === ''){
								}
								else
								{
									cpt++;
									indexfilled = i;
								}
							}
							
							var cells = rows[indexfilled+1].getElementsByTagName("td");
							var ipsub = cells[1].innerText;
							var version = cells[2].innerText;
							document.cookie = "ipsub = " + ipsub;
							
							if (cpt === 0){
								alert('<?= Translator('choose_update_file'); ?>');
							}
							else if (cpt > 1){
								alert('<?= Translator('one_subscriber_at_time'); ?>');
							}
							else if (version === "<?= Translator('Login_error'); ?>"){
								alert('<?= Translator('subscriber_not_reachable'); ?>');
							} 
							else if (ipsub !== ipsupposed){
								alert('<?= Translator('choose_update_file'); ?>');
							} else {

								//Stoppe toutes les fonction SetInterval() pour permettre le bon affichage du déroulé de la MàJ

								clearInterval(RefreshHours);
								clearInterval(RefreshServer);
								clearInterval(RefreshCores);
								clearInterval(RefreshRamCpu);
								clearInterval(RefreshUptime);
								clearInterval(RefreshVersion);
								$('#wizardUploadMajBox').modal({backdrop: 'static', keyboard: false})
								
								$(this).ajaxSubmit({
									url: '/inc/process_update/upload_subscriber.maj.php',
									type: 'POST',
									target: '#targetLayer',
									beforeSubmit: function() {
										$('#fsdm4154f').hide();
										$('#successUpdated').hide();
										$('.dfdslf12').hide();
										$('#sdqs4F').hide();
										$('#targetLayer').hide();
										$('#progressDivId').show();
										$("#progressBar").width('0%');
									},
									uploadProgress: function (event, position, total, percentComplete){	
										$("#progressBar").width(percentComplete + '%');
										$("#progressBar").html('<div id="progress-status">' + percentComplete +' %</div>')
										
										if (percentComplete == "100") {
											$('#uploadFileUpdate').hide();
											$('#dispatchUpdate').show();
										}

										setInterval('frames[0].scrollTo(0,9999999)',1000);
									},
									success:function(response) {

										if (response.match(/upload_ok/g)) {
											
											$('#uploadFileUpdate').hide();
											$('#dispatchUpdate').hide();
											$('#successUpdated').show();
											$('#uploadNewMajLogs').remove();
										} else {
											$('.dfdslf12').show();
											$('#fsdm4154f').show();
											$('#dispatchUpdate').hide();
											$('#sdqs4F').show();
											$('#uploadFileUpdate').hide();
											$('#dmgh56f').show();
											$('#targetLayer').show();
											$('#targetLayer').html(response);
										}
									},
									resetForm: true
								}); 
								return false; 
							}
						});

						$(document).ready(function() {
							$('#sdqs4F').click(function() {
								setTimeout(function() {
									$(this).hide();
									$('#fsdm4154f').hide();
									$('#uploadFileUpdate').show();
									$('#dmgh56f').hide();
									$('.dfdslf12').hide();
									$('#targetLayer').hide();
									$('#targetLayer').html('');
								}, 1000);
							});
						});
						</script>

						<div class="modal fade" id="wizardUploadMajBox" tabindex="-1" role="dialog" aria-labelledby="lblswizardUploadMajBox" aria-hidden="true">
							<div class="modal-dialog modal-lg" role="document">
								<div class="modal-content">
									<div class="modal-body text-center">
										<i class="fas fa-times-circle text-danger" id="fsdm4154f" style="display:none;font-size: 5rem;margin-bottom: 20px;"></i>
										<h4 class="dfdslf12 text-danger"><?php echo Translator('An_error_occu'); ?></h4>
										<div id="dmgh56f">
											<div id="targetLayer" style="display: none;"></div>
										</div>
										<button type="button" style="margin-top: 1rem;" id="sdqs4F" onclick="$('#wizardUploadMajBox').modal('hide')" class="exerotpbtn btn-white w-20 ripple-effect ripple-dark">
											<?php echo Translator('Close'); ?>
										</button>
										<div id="successUpdated">
											<i class="fas fa-check-circle text-success" style="font-size: 5rem;margin-bottom: 20px;"></i>
											<h4 class="text-success"><?php echo Translator('Update_product'); ?></h4>
											<label><?php echo Translator('Product_been_update'); ?></label><br><br>
											<a href="maintenance.php" onclick="$('#wizardUploadMajBox').modal('hide')">
												<button type="button" class="exerotpbtn btn-white w-20 ripple-effect ripple-dark">
													<?php echo Translator('Return_web'); ?>
												</button>
											</a>
										</div>
										<div id="uploadFileUpdate">
											<h4 class="text-blink"><?php echo Translator('Sending_in_prog'); ?></h4><br>
											<div class="progress progressexer" id="progressDivId" style="display: none;height: 20px;">
												<div class="progress-bar barexer bg-info" id="progressBar"></div>
											</div>
											<br>
											<a href="maintenance.php" onclick="$('#wizardUploadMajBox').modal('hide')">
												<button type="button" name="4455Hfd" class="exerotpbtn btn-red w-20 ripple-effect ripple-white">
													<?php echo Translator('Cancel_send'); ?>
												</button>
											</a>
										</div>
										<div id="dispatchUpdate" class="text-left">
											<div class="text-center">
												<h4><?php echo Translator('update'); ?>...</h4><br>
											</div>
											<iframe src="/inc/process_update/logs.php" id="iframepublisher" class="w-100" frameborder="0"></iframe>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<?php } ?>
				</div>
			</div>
		</main>
		<script>
			$('#m-upload-changelogo').click(function() {
				$('#m-edit-form-logo').click();
			});

			window.addEventListener('load', function() {
				document.getElementById('m-edit-form-logo').addEventListener('change', function() {
					if (this.files && this.files[0]) {
						document.getElementById('c-before-upload').style.display = "none";
						document.getElementById('m-for-p-up').style.display = "block";
						document.getElementById('c-preview-upload').style.display = "block";

						var img = document.getElementById('m-preview-c-picture');
						img.src = URL.createObjectURL(this.files[0]);
						img.onload = imageIsLoaded;
					}
				});
			});
		</script>
	<?php } ?>
	
<?php include 'inc/footer.php'; ?>