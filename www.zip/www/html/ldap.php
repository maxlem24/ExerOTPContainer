<?php
// Dernière modification le : 30/11/2023
// Par: Laurent ASSELIN

$sname = session_name();
if ($sname != 'EXEROTP_SESSID') {
	session_name('EXEROTP_SESSID');
}
session_start();

include_once $_SERVER['DOCUMENT_ROOT'] . '/inc/translator.php';

if ($_SESSION['level'] != 'ADMIN') {
	$module_page_name = Translator('LDAPInterconnections');
} else {
	$module_page_name = Translator('LDAPInterconnection');
}

$show_navbar 	= true;
$show_creds_usr = true;

include 'inc/header.php';

if (isset($_GET['page'])) {
	$page = htmlspecialchars($_GET['page']);
} else {
	$page = NULL;
}

if (isset($_GET['TokenID'])) {
	$TokenID = htmlspecialchars($_GET['TokenID']);
} else {
	$TokenID = NULL;
}

if (isset($_GET['camefrom'])) {
	$camefrom = htmlspecialchars($_GET['camefrom']);
} else {
	$camefrom = NULL;
}
?>

<main role="main" class="col-md-10 ml-sm-auto col-lg-10">
	<form method="POST" name="FormLDAPSystemIO">
		<div class="formaddfirewall">
			<?php
			if ($page != "AddLdap") {
				if ($page != "AddLdapFromDirectory") {
			?>
					<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
						<h1 class="h2"><?= $module_page_name ?></h1>

						<div class="btn-group">
							<?php
							$recup_all_ldap = $db->prepare('SELECT * FROM otp_ldap WHERE corpid = ?');
							$recup_all_ldap->execute(array($_SESSION['corp']));
							$count_ldap = $recup_all_ldap->rowCount();

							if (checkLevel() != OPERATOR && $count_ldap == 0) { ?>
								<a href="/ldap.php?page=AddLdap"><button type="button" class="exerotpbtn btn-defaultexer btn-sm ripple-effect ripple-white" style="margin-left:10px;"><i class="far fa-plus dwnl_small_addelement_icon"></i> <?= Translator('Create_LDAP_directory'); ?></button></a>
								<?php } elseif (checkLevel() == ADMIN || checkLevel() == SUPERVISOR) {
								if ($count_ldap == 0) { ?>
									<a href="/ldap.php?page=AddLdap"><button type="button" class="exerotpbtn btn-defaultexer btn-sm ripple-effect ripple-white" style="margin-left:10px;"><i class="far fa-plus dwnl_small_addelement_icon"></i> <?= Translator('Create_LDAP_directory'); ?></button></a>
							<?php }
							}
							?>
							<?php
							if (checkLevel() == ADMIN) {
								$recup_all_ldap2 = $db->prepare('SELECT * FROM otp_ldap WHERE corpid = ?');
								$recup_all_ldap2->execute(array($_SESSION['corp']));
								$count_ldap2 = $recup_all_ldap2->rowCount();

								if ($count_ldap2 == 1) { ?>
									<a href="/ldap.php?page=AddLdapFromDirectory"><button type="button" class="exerotpbtn btn-defaultexer btn-sm ripple-effect ripple-white" style="margin-left:10px;"><i class="far fa-book-reader dwnl_small_addelement_icon"></i> <?= Translator('Import_from_direct'); ?></button></a>
								<?php }
							} elseif (checkLevel() != OPERATOR || $count_ldap2 != 0) { ?>
								<a href="/ldap.php?page=AddLdapFromDirectory"><button type="button" class="exerotpbtn btn-defaultexer btn-sm ripple-effect ripple-white" style="margin-left:10px;"><i class="far fa-book-reader dwnl_small_addelement_icon"></i> <?= Translator('Import_from_direct'); ?></button></a>
							<?php } ?>
						</div>
					</div>
			<?php }
			} ?>

			<?php if ($page == "AddLdap") { ?>
				<?php if (checkLevel() == OPERATOR) {
					header('Location: /ldap.php');
					exit();
				} ?>
				<?php if (checkLevel() != SUPERVISOR) {
					$recup_all_ldap = $db->prepare('SELECT * FROM otp_ldap WHERE corpid = ? ORDER BY id DESC');
					$recup_all_ldap->execute(array($_SESSION['corp']));
					$count_ldap = $recup_all_ldap->rowCount();

					if ($count_ldap > 0) {
						header('Location: /ldap.php');
						exit();
					}
				?>
				<?php } ?>
				<?php
				if (isset($_POST['submitform_firewalluser'])) {
					if (isset($_POST['ldapinput_namebase'], $_POST['ldapinput_uri'], $_POST['ldapinput_uriproto'], $_POST['ldapinput_loginpam_attr'], $_POST['ldapinput_bind_all'], $_POST['ldapinput_bind_password'], $_POST['ldapinput_bind_cpassword'])) {
						$ldapinput_namebase	=	htmlspecialchars($_POST['ldapinput_namebase']);

						if (filter_var($_POST['ldapinput_uri'], FILTER_VALIDATE_IP) or filter_var($_POST['ldapinput_uri'], FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME)) {
							$ldapinput_uri	=	htmlspecialchars($_POST['ldapinput_uri']);
						} else {
							$Session->setFlash(Translator('format_ip_incorrect'), "close", "error");
							header('Location: /ldap.php');
							exit();
						}

						if (!empty($_POST['ldapinput_uri2'])) {
							if (filter_var($_POST['ldapinput_uri2'], FILTER_VALIDATE_IP) or filter_var($_POST['ldapinput_uri2'], FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME)) {
								$ldapinput_uri2	=	htmlspecialchars($_POST['ldapinput_uri2']);
							} else {
								$Session->setFlash(Translator('format_ip_ldap_secondaire'), "close", "error");
								header('Location: /ldap.php');
								exit();
							}
						} else {
							$ldapinput_uri2	=	"";
						}

						$ldapinput_uriproto	=	htmlspecialchars($_POST['ldapinput_uriproto']);

						if ($_POST['ldapinput_uriproto'] == "1") {
							$Resultldapinput_uriproto	=	"on";
						} else {
							$Resultldapinput_uriproto	=	"off";
						}

						$ldapinput_loginpam_attr		=	htmlspecialchars($_POST['ldapinput_loginpam_attr']);
						$ldapinput_bind_password		=	$_POST['ldapinput_bind_password'];
						$ldapinput_bind_cpassword		=	$_POST['ldapinput_bind_cpassword'];
						$ldapinput_bind_all				=	htmlspecialchars($_POST['ldapinput_bind_all']);

						if (!empty($_POST['ldapinput_namebase']) and !empty($_POST['ldapinput_uri']) and !empty($_POST['ldapinput_bind_all']) and !empty($_POST['ldapinput_bind_password']) and !empty($_POST['ldapinput_bind_cpassword'])) {
							// Check if not exist namebase on otp database_ldap
							$reqexistnamebase = $db->prepare("SELECT * FROM otp_ldap WHERE base_dn = ? AND corpid = ?");
							$reqexistnamebase->execute(array($ldapinput_namebase, $_SESSION['corp']));
							$namebase_exist = $reqexistnamebase->rowCount();

							if (!empty($_POST['ldapinput_loginpam_attr'])) {
								$ldapinput_loginpam_attr_req = $ldapinput_loginpam_attr;
							} else {
								$ldapinput_loginpam_attr_req = "samaccountname";
							}

							if ($namebase_exist == 0) {
								// Check if not exist loginattribute on otp database_ldap
								$reqexistloginattribute = $db->prepare("SELECT * FROM otp_ldap WHERE loginattribute = ? AND corpid = ?");
								$reqexistloginattribute->execute(array($ldapinput_loginpam_attr_req, $_SESSION['corp']));
								$login_exist = $reqexistloginattribute->rowCount();

								if ($login_exist == 0) {
									if ($ldapinput_bind_password == $ldapinput_bind_cpassword) {
										$token						= 	generateToken(9999);
										$created_at					= 	return_date_all_actuelle();
										$final_uri 					= 	$ldapinput_uri;
										$final_uri2 				= 	$ldapinput_uri2;

										$sslproto					= 	$Resultldapinput_uriproto;

										$final_bind_fin		 		= 	$ldapinput_bind_all;
										$ldapinput_namebases1 		= 	$ldapinput_namebase;

										$ldapinput_namebase_shell 	= 	$ldapinput_namebases1;
										$final_bind_fin_shell		= 	$final_bind_fin;
										
										//Special encode "'" character in password
										$ldapinput_bind_cpassword   = str_replace("'", "'\"'\"'", $ldapinput_bind_cpassword);

										if ($_SESSION['level'] == 3) {
											$getFolderLDAP = htmlspecialchars($_POST['fireinput_nameclient']);
										} else {
											$getFolderLDAP = $_SESSION['corp_folder'];
										}

										if ($getFolderLDAP != "already_imported") {
											$RecupInfosLdapCorp = $db->prepare('SELECT * FROM otp_companies WHERE folder = ?');
											$RecupInfosLdapCorp->execute(array($getFolderLDAP));
											$query_ldap = $RecupInfosLdapCorp->fetch();

											if ($_SESSION['level'] == 3) {
												$corpid = $query_ldap['corpid'];
											} else {
												$corpid = $_SESSION['corp'];
											}

											if (!empty($_POST['ldapinput_uri2'])) {
												if (filter_var($ldapinput_uri2, FILTER_VALIDATE_IP) or filter_var($ldapinput_uri2, FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME)) {
													//Creation Interco LDAP avec Annuaire de Secours
													$InsertCmdlet = "sudo /usr/local/bin/ldap_pam.sh -b '" . $ldapinput_namebase_shell . "' -u " . $final_uri . " -v " . $final_uri2 . " -s " . $sslproto . " -d '" . $final_bind_fin_shell . "' -p '" . $ldapinput_bind_cpassword . "' -c " . $query_ldap['folder'] . " -l " . $ldapinput_loginpam_attr_req;

													$RunCmdlet = $InsertCmdlet;
													$insert_srv_ldapauth = shell_exec($RunCmdlet);

													if ($insert_srv_ldapauth != 0) {
														$error = Translator('an_error_occu');
													} else {
														//Insertion des données dans la base 'otp_ldap' du nouvel utilisateur
														$InsertLDAP = $db->prepare("INSERT INTO otp_ldap(corpid, client, loginattribute, base_dn, ldap_uri, ldap_uri2, sslproto, binddn, created_at, token) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
														$InsertLDAP->execute(array($corpid, "N/A", $ldapinput_loginpam_attr_req, $ldapinput_namebase_shell, $final_uri, $final_uri2, $sslproto, $final_bind_fin_shell, $created_at, $token));

														//Ajout dans les logs de la création d'une nouvelle interconnexion LDAP
														addLogEventOTP("[SUCCESS] A new LDAP connection named " . " " . $ldapinput_namebase_shell . " " . "has been created by" . " " . $_SESSION['username'] . ".");

														$Session->setFlash(Translator('good_interconnexion_ldap'), "check", "success");
														header('Location: /ldap.php');
														exit();
													}
												} else {
													$error = Translator('Ip_fqdn_format');
												}
											} else {
												//Creation Interco LDAP sans Annuaire de Secours

												$InsertCmdlet = "sudo /usr/local/bin/ldap_pam.sh -b '" . $ldapinput_namebase_shell . "' -u " . $final_uri . " -s " . $sslproto . " -d '" . $final_bind_fin_shell . "' -p '" . $ldapinput_bind_cpassword . "' -c " . $query_ldap['folder'] . " -l " . $ldapinput_loginpam_attr_req;
												$RunCmdlet = $InsertCmdlet;
												$insert_srv_ldapauth = shell_exec($RunCmdlet);

												if ($insert_srv_ldapauth != 0) {
													$error = Translator('an_error_occu');
												} else {
													//Insertion des données dans la base 'otp_ldap' du nouvel utilisateur
													$InsertLDAP = $db->prepare("INSERT INTO otp_ldap(corpid, client, loginattribute, base_dn, ldap_uri, sslproto, binddn, created_at, token) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)");
													$InsertLDAP->execute(array($corpid, "N/A", $ldapinput_loginpam_attr_req, $ldapinput_namebase_shell, $final_uri, $sslproto, $final_bind_fin_shell, $created_at, $token));

													//Ajout dans les logs de la création d'une nouvelle interconnexion LDAP
													addLogEventOTP("[SUCCESS] A new LDAP connection named " . " " . $ldapinput_namebase_shell . " " . "has been created by" . " " . $_SESSION['username'] . ".");

													$Session->setFlash(Translator('good_interconnexion_ldap'), "check", "success");
													header('Location: /ldap.php');
													exit();
												}
											}
										} else {
											$error = Translator('Already_LDAP_connection');
										}
									} else {
										$error = Translator('password_no_match');
									}
								} else {
									$error = Translator('Pam_exist');
								}
							} else {
								$error = Translator('Already_LDAP_domain_name');
							}
						} else {
							$error = Translator('Fill_all_fields');
						}
					}
				}
				?>

				<form method="POST" name="FormLDAPSystemIO">
					<div class="formaddfirewall">
						<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
							<h1 class="h3"><?= $module_page_name ?> <exer class="text-secondary"><i class="far fa-chevron-right chevronexer_openform"></i></exer> <i><?php echo Translator('Create_LDAP_directory'); ?></i></h1>

							<div class="btn-group">
								<button type="submit" name="submitform_firewalluser" id="submitform_firewalluser" class="exerotpbtn btn-green btn-sm ripple-effect ripple-white"><i class="far fa-save dwnl_small_addelement_icon"></i> <?php echo Translator('Confirm'); ?></button>
								<a href="/ldap.php"><button type="button" class="exerotpbtn btn-red btn-sm ripple-effect ripple-white" style="margin-left:10px;"><i class="far fa-times dwnl_small_addelement_icon"></i> <?php echo Translator('Cancel'); ?></button></a>
							</div>
						</div>

						<?php if (isset($error)) { ?>
							<div class="alert alert-danger" role="alert">
								<i class="fas fa-exclamation-triangle"></i> <?= $error ?>
							</div>
						<?php } ?>

						<?php if ($_SESSION['level'] == SUPERVISOR) { ?>
							<fieldset class="fieldset_exerotp">
								<legend class="legend_exerotp"><?php echo Translator('Corporate_assign_2'); ?></legend>
								<i><?php echo Translator('Assign_register'); ?> :</i>
								<hr style="margin-top: 11px; margin-bottom: 10px;">
								<div class="form-group">
									<label for="fireinput_nameclient"><?php echo Translator('Corporate_assign'); ?> <b class="text-danger" title="Ce champ est obligatoire" data-toggle="tooltip" data-placement="right"><i class="far fa-asterisk"></i></b></label>
									<select class="form-control" name="fireinput_nameclient" id="fireinput_nameclient">
										<?php
										if (!empty($_GET['TokenID'])) {
											$corps_recorver = $db->prepare('SELECT * FROM otp_companies WHERE token = ?');
											$corps_recorver->execute(array($_GET['TokenID']));
										} else {
											$corps_recorver = $db->query('SELECT * FROM otp_companies ORDER BY name ASC');
										}
										while ($corp_recup = $corps_recorver->fetch()) {
											$ExistLdapCorp = $db->prepare('SELECT * FROM otp_ldap WHERE corpid = ?');
											$ExistLdapCorp->execute(array($corp_recup['corpid']));

											if ($ExistLdapCorp->rowCount() == 1) { ?>
												<option value="already_imported"><?php echo Translator('Installed'); ?> <?= $corp_recup['name'] ?> </option>
											<?php } else { ?>
												<option value="<?= $corp_recup['folder'] ?>"><?= $corp_recup['name'] ?> </option>
											<?php } ?>
										<?php } ?>
									</select>
								</div>
							</fieldset>
						<?php } ?><br>
						<div class="row">
							<div class="col-md-6">
								<fieldset class="fieldset_exerotp">
									<i><?php echo Translator('Assign_LDAP_Inter'); ?> :</i>
									<hr style="margin-top: 11px; margin-bottom: 10px;">
									<legend class="legend_exerotp"><?php echo Translator('general'); ?></legend>
									<div id="submit_formfirewall_user">
										<div class="form-group">
											<label for="ldapinput_namebase"><?php echo Translator('LDAP_domain_name'); ?> : <b class="text-danger" title=<?php echo Translator('Field_required'); ?> data-toggle="tooltip" data-placement="right"><i class="far fa-asterisk"></i></b></label>
											<input type="text" name="ldapinput_namebase" autocomplete="off" class="form-control" id="ldapinput_namebase" value="<?php if (isset($ldapinput_namebase)) {
																																									echo $ldapinput_namebase;
																																								} ?>" placeholder="ex : DC=mycompany,DC=com">
										</div>
										<div class="form-group">
											<label for="ldapinput_loginpam_attr"><?php echo Translator('Unique_ID'); ?> : <b class="text-danger" title=<?php echo Translator('Field_required'); ?> data-toggle="tooltip" data-placement="right"><i class="far fa-asterisk"></i></b></label>
											<input type="text" name="ldapinput_loginpam_attr" autocomplete="off" class="form-control" id="ldapinput_loginpam_attr" value="<?php if (isset($ldapinput_loginpam_attr)) {
																																												echo $ldapinput_loginpam_attr;
																																											} ?>" placeholder="<?= Translator('by_default'); ?>">
										</div>
									</div>
								</fieldset>
							</div>

							<div class="col-md-6">
								<fieldset class="fieldset_exerotp">
									<legend class="legend_exerotp"><?php echo Translator('LDAP_serv'); ?></legend>
									<hr style="margin-top: 11px; margin-bottom: 10px;">
									<div id="uriFormLdapAddresses">
										<div class="row">
											<div class="col-md-6">
												<div class="form-group">
													<label for="ldapinput_uri"><?php echo Translator('Primary_address'); ?> : <b class="text-danger" title=<?php echo Translator('Field_required'); ?> data-toggle="tooltip" data-placement="right"><i class="far fa-asterisk"></i></b></label>
													<div class="input-group mb-2">
														<input type="text" name="ldapinput_uri" autocomplete="off" class="form-control" id="ldapinput_uri" value="<?php if (isset($ldapinput_uri)) {
																																										echo $ldapinput_uri;
																																									} ?>" placeholder="ex : X.X.X.X">
													</div>
												</div>
											</div>
											<div class="col-md-6">
												<div class="form-group">
													<label for="ldapinput_uri2"><?php echo Translator('Secondary_address'); ?> : </label>
													<div class="input-group mb-2">
														<input type="text" name="ldapinput_uri2" autocomplete="off" class="form-control" id="ldapinput_uri2" value="<?php if (isset($ldapinput_uri2)) {
																																										echo $ldapinput_uri2;
																																									} ?>" placeholder="ex : X.X.X.X">
													</div>
												</div>
											</div>
										</div>
										<div class="form-group">
											<label for="ldapinput_uriproto"><?php echo Translator('SSL_protocols'); ?> : <b class="text-danger" title="<?php echo Translator('Field_required'); ?>" data-toggle="tooltip" data-placement="right"><i class="far fa-asterisk"></i></b></label>
											<div class="input-group mb-2">
												<select class="form-control" name="ldapinput_uriproto" id="ldapinput_uriproto">
													<optgroup label="Protocoles LDAP">
														<option value="0">Plaintext (LDAP)</option>
														<option value="1">TLS (LDAPS)</option>
													</optgroup>
												</select>
											</div>
										</div>
									</div>
								</fieldset>
							</div>
						</div>
						<br>
						<fieldset class="fieldset_exerotp">
							<legend class="legend_exerotp"><?php echo Translator('Bind_auth'); ?></legend>
							<i style="margin-bottom: 20px;"><?php echo Translator('DN_bind_user_autho'); ?></i>
							<hr style="margin-top: 11px; margin-bottom: 10px;">
							<div class="form-group">
								<label for="ldapinput_bind_dncn"><?php echo Translator('DN_bind'); ?> : <b class="text-danger" title=<?php echo Translator('Field_required'); ?> data-toggle="tooltip" data-placement="right"><i class="far fa-asterisk"></i></b></label>
								<input type="text" name="ldapinput_bind_all" autocomplete="off" class="form-control" id="ldapinput_bind_all" value="<?php if (isset($ldapinput_bind_all)) {
																																						echo $ldapinput_bind_all;
																																					} ?>" placeholder="ex : CN=test,CN=Users,DC=mycompany,DC=com">
							</div>

							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<label for="ldapinput_bind_password"><?php echo Translator('Password'); ?> : <b class="text-danger" title="<?php echo Translator('Field_required'); ?>" data-toggle="tooltip" data-placement="right"><i class="far fa-asterisk"></i></b></label>
										<input type="password" name="ldapinput_bind_password" autocomplete="off" class="form-control" id="ldapinput_bind_password">
									</div>
								</div>

								<div class="col-md-6">
									<div class="form-group">
										<label for="ldapinput_bind_cpassword"><?php echo Translator('Confirm_password'); ?> <b class="text-danger" title="<?php echo Translator('Field_required'); ?> data-toggle=" tooltip" data-placement="right"><i class="far fa-asterisk"></i></b></label>
										<input type="password" name="ldapinput_bind_cpassword" autocomplete="off" class="form-control" id="ldapinput_bind_cpassword">
									</div>
								</div>
							</div>
						</fieldset>
						<br><br>
					</div>
				</form>
			<?php } elseif ($page == "AddLdapFromDirectory") { ?>
				<?php if (checkLevel() == OPERATOR) {
					header('Location: /ldap.php');
					exit();
				} ?>
				<form method="POST" name="FormLDAPSystemIO">
					<div class="formaddfirewall">
						<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
							<h1 class="h3"><?= $module_page_name ?> <exer class="text-secondary"><i class="far fa-chevron-right chevronexer_openform"></i></exer> <i><?php echo Translator('Import_from_direct'); ?></i></h1>

							<div class="btn-group">
								<?php if ($camefrom == "Form2") { ?>
									<button type="submit" name="refreshlistldap_import" id="refreshldapimport" class="exerotpbtn btn-lightBlue btn-sm ripple-effect ripple-white"><i class="far fa-redo dwnl_small_addelement_icon"></i> <?php echo Translator('Refresh'); ?></button>
									<button type="submit" name="submitform_ldapusr" id="submitform_otpusr" class="exerotpbtn btn-green btn-sm ripple-effect ripple-white"><i class="far fa-save dwnl_small_addelement_icon"></i> <?php echo Translator('Confirm'); ?></button>
								<?php } else { ?>
									<button type="submit" name="nextform_ldapusr" class="exerotpbtn btn-green btn-sm ripple-effect ripple-white"><i class="far fa-arrow-right dwnl_small_addelement_icon"></i> <?php echo Translator('next'); ?></button>
								<?php } ?>
								<a href="/ldap.php"><button type="button" class="exerotpbtn btn-red btn-sm ripple-effect ripple-white" style="margin-left:10px;"><i class="far fa-times dwnl_small_addelement_icon"></i> <?php echo Translator('Cancel'); ?></button></a>
							</div>
						</div>

						<?php if (isset($error)) { ?>
							<div class="alert alert-danger" role="alert">
								<i class="fas fa-exclamation-triangle"></i> <?= $error ?>
							</div>
						<?php } ?>

						<?php if ($camefrom == "Form2") {
							$BindTokenLDAP = htmlspecialchars($_SESSION['BindParamsLDAPclient']);

							$Ldaps = $db->prepare('SELECT * FROM otp_ldap WHERE token = ?');
							$Ldaps->execute(array($BindTokenLDAP));
							$CountLdap = $Ldaps->rowCount();
							$Ldap = $Ldaps->fetch();


							// Paramètres compte LDAP de connexion
							$array_ldap_passwd 	 	= array("bindpw");
							$array_ldap_CNDC 	 	= array($Ldap['base_dn'], ",", "CN=", "cn=", " ", " ", " ");

							$texte 					= $Ldap['ldap_uri'];
							$texte2 				= $Ldap['ldap_uri2'];

							if (stripos($texte, 'ldap://') !== FALSE or stripos($texte, 'ldaps://') !== FALSE or stripos($texte2, 'ldap://') !== FALSE or stripos($texte2, 'ldaps://') !== FALSE) {
								$array_ldap_proto 	= array("ldap://", "ldaps://");
								$ldap_host	   		= str_replace($array_ldap_proto, "", $Ldap['ldap_uri']);
								$ldap_host2	   		= str_replace($array_ldap_proto, "", $Ldap['ldap_uri2']);
							} else {
								$ldap_host	   		= $Ldap['ldap_uri'];
								$ldap_host2	   		= $Ldap['ldap_uri2'];
							}

							$ldap_username 		 	= $Ldap['binddn'];

							if (empty($Ldap['sslproto'])) {
								$DefaultSSLProto = $db->prepare('UPDATE otp_ldap SET sslproto = ? WHERE token = ?');
								$DefaultSSLProto->execute(array("off", $BindTokenLDAP));
							}

							$recup_firewallclient 	= $db->prepare('SELECT * FROM otp_ldap WHERE token = ?');
							$recup_firewallclient->execute(array($BindTokenLDAP));
							$ft_recupfireclient 	= $recup_firewallclient->fetch();

							$recup_companiesinfos 	= $db->prepare('SELECT * FROM otp_companies WHERE corpid = ?');
							$recup_companiesinfos->execute(array($ft_recupfireclient['corpid']));
							$ft_recupinfoscorp 		= $recup_companiesinfos->fetch();

							$InsertCmdlet 			= 'grep -r bindpw /etc/pam_ldap_' . $ft_recupinfoscorp['folder'] . '.conf';
							$RunCmdlet 				= escapeshellcmd($InsertCmdlet);
							$ldap_password_proc 	= shell_exec($RunCmdlet);
							$ldap_password_proc2 	= str_replace($array_ldap_passwd, "", $ldap_password_proc);
							$ldap_password 		 	= trim(preg_replace('/\s+/', ' ', $ldap_password_proc2));

							if ($CountLdap == 0) {
								$Session->setFlash(Translator('LDAP_interconnect_not_found'), "change_history", "warning");
								header('Location: /ldap.php');
								exit();
							}

							if (isset($_POST['submitform_ldapusr'])) {
								if (!empty($_POST['check_this_ldapusr'])) {
									//------------------------------------------------------------------------------
									// Connect to the LDAP server.
									//------------------------------------------------------------------------------

									if (serviceping($Ldap['ldap_uri'], $Ldap['sslproto']) == true) {
										if ($Ldap['sslproto'] == "on") {
											$ldap_connection = ldap_connect("ldaps://" . $Ldap['ldap_uri']);
										} else {
											$ldap_connection = ldap_connect("ldap://" . $Ldap['ldap_uri']);
										}
									} elseif (!empty($Ldap['ldap_uri2'])) {
										if (serviceping($Ldap['ldap_uri2'], $Ldap['sslproto']) == true) {
											if ($Ldap['sslproto'] == "on") {
												$ldap_connection = ldap_connect("ldaps://" . $Ldap['ldap_uri2']);
											} else {
												$ldap_connection = ldap_connect("ldap://" . $Ldap['ldap_uri2']);
											}
										}
									} else {
										$Session->setFlash(Translator('none_ldap_servers'), "change_history", "warning");
										header('Location: /ldap.php');
										exit();
									}

									ldap_set_option($ldap_connection, LDAP_OPT_PROTOCOL_VERSION, 3) or die('<div class="alert alert-danger" role="alert"> <i class="fas fa-exclamation-triangle"></i>' . Translator('An_error_occu') . ': ' . Translator('version_protocol_error') . '</div>');
									ldap_set_option($ldap_connection, LDAP_OPT_REFERRALS, 0); // On en a besoin pour faire une recherche LDAP.

									if ($ldap_connection == FALSE) { ?>
										<div class="alert alert-danger" role="alert">
											<i class="fas fa-exclamation-triangle"></i> <?php echo Translator('Cannot_con_LDAP'); ?>
										</div>
										<?php } else {
										if (ldap_bind($ldap_connection, $ldap_username, $ldap_password) == TRUE) {
											foreach ($_POST['check_this_ldapusr'] as $check) {
												$ldap_base_dn = $Ldap['base_dn'];
												$search_filter = '(|(' . $Ldap['loginattribute'] . '=' . $check . '))';
												$result = ldap_search($ldap_connection, $ldap_base_dn, $search_filter);
												if ($result != FALSE) {
													$entries = ldap_get_entries($ldap_connection, $result);
													if ($entries["count"] == 0 ) { // Si aucune réponse, c'est que l'UID n'est certainement pas correct
														addLogEventOTP("[ERROR] No User Imported - Check UID Attribute" . " " . "(SearchFilter=" . $search_filter . "; admin=" . $_SESSION['username'] . "; company=" . $ft_recupinfoscorp['name'] . ")");
														$Session->setFlash(Translator('No_user_match') . " (" . Translator('check_LDAP_uid') . ")", "close", "error");
														$actual_link = "https://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
														header('Location: ' . $actual_link);
														exit();	
													}

													for ($i = 0; $i < $entries['count']; $i++) {
														$entries = ldap_get_entries($ldap_connection, $result);
														// Nom d'utilisateur
														$Username = "";

														$getCurrentLoginAttr = $Ldap['loginattribute']; //on essait avec l'attribut configuré, sinon on essait avec les "classiques"
														if (!empty($entries[$i][$getCurrentLoginAttr][0])) {
															$Username = $entries[$i][$getCurrentLoginAttr][0];
														} elseif (!empty($entries[$i]['samaccountname'][0])) {
															$Username = $entries[$i]['samaccountname'][0];
														} elseif (!empty($entries[$i]['uid'][0])) {
															$Username = $entries[$i]['uid'][0];
														} else {
															$Username = "";
														}
														if ($Username == "NULL") {
															$Username = "";
														}

														//Adresse E-mail
														$LDAP_Email = "";

														if (!empty($entries[$i]['mail'][0])) {
															$LDAP_Email = $entries[$i]['mail'][0];
															if ($LDAP_Email == "NULL") {
																$LDAP_Email = "";
															}
														} else {
															$LDAP_Email = "N/A";
														}

														//userPrincipalName
														$LDAP_userPrincipalName = "";

														if (!empty($entries[$i]['userprincipalname'][0])) {
															$LDAP_userPrincipalName = $entries[$i]['userprincipalname'][0];
															if ($LDAP_userPrincipalName == "NULL") {
																$LDAP_userPrincipalName = "";
															}
														} else {
															$LDAP_userPrincipalName = "N/A";
														}

														//Nom complet CN
														$LDAP_CN = "";

														if (!empty($entries[$i]['cn'][0])) {
															$LDAP_CN = $entries[$i]['cn'][0];
															if ($LDAP_CN == "NULL") {
																$LDAP_CN = "";
															}
														} else {
															$LDAP_CN = "N/A";
														}

														$login_ldap 	= htmlspecialchars($Username);
														$email_ldap 	= htmlspecialchars($LDAP_Email);
														$userprincipalname_ldap = htmlspecialchars($LDAP_userPrincipalName);
														$issuer_ldap 	= htmlspecialchars($LDAP_CN);
														$nametoken_ldap = htmlspecialchars($Username);

														//check if not user exist on otp datatbase
														$requusername = $db->prepare("SELECT * FROM otp_tokens WHERE login = ? AND corpid = ?");
														$requusername->execute(array($login_ldap, $ft_recupfireclient['corpid']));
														$gttokens = $requusername->fetch();
														$usernameexist = $requusername->rowCount();
														if ($usernameexist == 0) {
															if ($Username != "skel") {
																if ($Username != "default") {
																	$array_spaces 	= 	array(" ", " ", " ", "'");
																	$clifolid		=	$ft_recupfireclient['corpid'];

																	// transformation des variables en minuscule et remplacement des espaces par des underscores
																	$RecupCorpInfos = $db->prepare('SELECT * FROM otp_companies WHERE corpid = ?');
																	$RecupCorpInfos->execute(array($clifolid));
																	$getAllCorpInfos = $RecupCorpInfos->fetch();

																	$client 		= 	htmlspecialchars($getAllCorpInfos['folder']);
																	$issuer 		= 	str_replace(" ", "_", $getAllCorpInfos['name']);
																	$login_af 		= 	strtolower(str_replace($array_spaces, "_", $login_ldap));
																	$client_af 		= 	strtolower(str_replace($array_spaces, "_", $client));
																	$issuer_af 		= 	str_replace($array_spaces, "_", $issuer);
																	$nametoken_af 	= 	str_replace($array_spaces, "_", $nametoken_ldap);
																	$token 			= 	generateToken(9999);
																	$externalToken 	= 	generateToken(9999);
																	$datenow		=	date('Y-m-d H:i:s');

																	$nomclient 		=	$client_af;
																	$nomuser 		= 	$login_af;

																	$register_corp_sql 	= $ft_recupfireclient['corpid'];
																	$issuer_firewall 	= $getAllCorpInfos['name'];

																	// Création du token freerad depuis le script token.sh ==> /usr/local/bin/token.sh
																	$output = shell_exec("sudo token.sh -l '$nomuser' -c '$nomclient' -i '$issuer_af' -n '$nametoken_af'");

																	$answer = strstr($output, ' ', true);
																	if (strcmp($answer, "Voici") == 0) {

																		$handle = fopen('/home/' . $nomclient . '/' . $nomuser . '/.exer_authenticator', "r");

																		if ($handle) {
																			if (($buffer = fgets($handle)) != "e") {
																				$secretkey = rtrim($buffer);

																				if ($login_af != $nametoken_af) {
																					$set = 'otpauth://totp/' . str_replace(' ', '%20', trim($nametoken_ldap)) . '?secret=' . str_replace(' ', '%20', trim($secretkey)) . '&issuer=' . str_replace(' ', '%20', trim($issuer)) . '';
																				} else {
																					$set = 'otpauth://totp/' . str_replace(' ', '%20', trim($login_ldap)) . '?secret=' . str_replace(' ', '%20', trim($secretkey)) . '&issuer=' . str_replace(' ', '%20', trim($issuer)) . '';
																				}
																			}
																			fclose($handle);
																		}

																		// génération du qr code dans le fichier utilisateur
																		$codeText = $set;
																		ob_start();
																		QRCode::png($codeText, null, QR_ECLEVEL_L, 8);
																		$imageString = base64_encode(ob_get_contents());
																		ob_end_clean();
																		echo "<img class='QrCode' src='data:image/png;base64,$imageString'>";

																		$base64_qrcode = "data:image/png;base64,$imageString";

																		// insertion des données dans la base 'otp_tokens'
																		$insert_req = $db->prepare("INSERT INTO otp_tokens(userid, login, email, issuer, corpid, key_name, qr_code, created_at, token, externalToken, upn) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
																		$insert_req->execute(array($_SESSION['id'], $login_af, $email_ldap, $issuer_firewall, $register_corp_sql, $nametoken_af, $base64_qrcode, $datenow, $token, $externalToken, $userprincipalname_ldap));

																		// ajout dans les logs otp_exer si tout est ok lors de la creation ==> otp_exer
																		addLogEventOTP("[SUCCESS] This LDAP user has been created by : " . " " . $_SESSION['username'] . " (login=" . $login_af . "; company=" . $nomclient . ")");

																		$Session->setFlash(Translator('import_user_ok'), "check", "success");
																		header('Location: /companies.php?page=ManageCorp&TokenID=' . $getAllCorpInfos['token']);
																	} else {
																		addLogEventOTP("[ERROR] Users creation failed by " . " " . $_SESSION['username'] . " (login=" . $login_af . "; company=" . $nomclient . ")");

																		$Session->setFlash(Translator('user_license_not_ok'), "change_history", "warning");
																		header('Location: /companies.php?page=ManageCorp&TokenID=' . $getAllCorpInfos['token']);
																		exit();
																	}
																} else {
																	$Session->setFlash(Translator('The_name') . "<b>" . $Username . "</b>" . Translator('not_available'), "close", "error");
																	$actual_link = "https://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
																	header('Location: ' . $actual_link);
																	exit();
																}
															} else {
																$Session->setFlash(Translator('The_name') . $Username . "</b>" . Translator('not_available'), "close", "error");
																$actual_link = "https://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
																header('Location: ' . $actual_link);
																exit();
															}
														} else {
															$recup_corp = $db->prepare('SELECT * FROM otp_companies WHERE corpid = ?');
															$recup_corp->execute(array($gttokens['corpid']));
															$recup_name_corpfolder = $recup_corp->fetch();

															$DeleteActualUserLdap = $db->prepare('DELETE FROM otp_tokens  WHERE login = ? AND corpid = ?');
															$DeleteActualUserLdap->execute(array($login_ldap, $ft_recupfireclient['corpid']));

															//Appel au script de suppression de l'utilisateur
															$escaped_command = escapeshellcmd("sudo rm -rf /home/" . $recup_name_corpfolder['folder'] . "/" . $gttokens['login']);
															shell_exec($escaped_command);

															if ($Username != "skel") {
																if ($Username != "default") {
																	$array_spaces 	= 	array(" ", " ", " ", "'");
																	$clifolid		=	$ft_recupfireclient['corpid'];

																	// transformation des variables en minuscule et remplacement des espaces par des underscores
																	$RecupCorpInfos = $db->prepare('SELECT * FROM otp_companies WHERE corpid = ?');
																	$RecupCorpInfos->execute(array($clifolid));
																	$getAllCorpInfos = $RecupCorpInfos->fetch();

																	$client 		= 	htmlspecialchars($getAllCorpInfos['folder']);
																	$issuer 		= 	str_replace(" ", "_", $getAllCorpInfos['name']);
																	$login_af 		= 	strtolower(str_replace($array_spaces, "_", $login_ldap));
																	$client_af 		= 	strtolower(str_replace($array_spaces, "_", $client));
																	$issuer_af 		= 	str_replace($array_spaces, "_", $issuer);
																	$nametoken_af 	= 	str_replace($array_spaces, "_", $nametoken_ldap);
																	$token 			= 	generateToken(9999);
																	$externalToken 	= 	generateToken(9999);
																	$datenow		=	date('Y-m-d H:i:s');

																	$nomclient 		=	$client_af;
																	$nomuser 		= 	$login_af;

																	$register_corp_sql 	= $ft_recupfireclient['corpid'];
																	$issuer_firewall 	= $getAllCorpInfos['name'];

																	// Création du token freerad depuis le script token.sh ==> /usr/local/bin/token.sh
																	$output = shell_exec("sudo token.sh -l '$nomuser' -c '$nomclient' -i '$issuer_af' -n '$nametoken_af'");

																	//addLogEventOTP("[DEBUG]".$nomuser." -c ".$nomclient." -i ".$issuer_af." -n ".$nametoken_af);
																	$answer = strstr($output, ' ', true);
																	if (strcmp($answer, "Voici") == 0) {
																		
																		$handle = fopen('/home/' . $nomclient . '/' . $nomuser . '/.exer_authenticator', "r");

																		if ($handle) {
																			if (($buffer = fgets($handle)) != "e") {
																				$secretkey = rtrim($buffer);

																				if ($login_af != $nametoken_af) {
																					$set = 'otpauth://totp/' . str_replace(' ', '%20', trim($nametoken_ldap)) . '?secret=' . str_replace(' ', '%20', trim($secretkey)) . '&issuer=' . str_replace(' ', '%20', trim($issuer)) . '';
																				} else {
																					$set = 'otpauth://totp/' . str_replace(' ', '%20', trim($login_ldap)) . '?secret=' . str_replace(' ', '%20', trim($secretkey)) . '&issuer=' . str_replace(' ', '%20', trim($issuer)) . '';
																				}
																			}
																			fclose($handle);
																		}

																		// génération du qr code dans le fichier utilisateur
																		$codeText = $set;
																		ob_start();
																		QRCode::png($codeText, null, QR_ECLEVEL_L, 8);
																		$imageString = base64_encode(ob_get_contents());
																		ob_end_clean();
																		echo "<img class='QrCode' src='data:image/png;base64,$imageString'>";

																		$base64_qrcode = "data:image/png;base64,$imageString";

																		// insertion des données dans la base 'otp_tokens'
																		$insert_req = $db->prepare("INSERT INTO otp_tokens(userid, login, email, issuer, corpid, key_name, qr_code, created_at, token, externalToken, upn) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
																		$insert_req->execute(array($_SESSION['id'], $login_af, $email_ldap, $issuer_firewall, $register_corp_sql, $nametoken_af, $base64_qrcode, $datenow, $token, $externalToken, $userprincipalname_ldap));

																		// ajout dans les logs otp_exer si tout est ok lors de la creation ==> otp_exer
																		addLogEventOTP("[SUCCESS] LDAP Users imported by :" . " " . $_SESSION['username'] . " (login=" . $login_af . "; company=" . $nomclient . ")");

																		$Session->setFlash(Translator('import_user_ok'), "check", "success");
																		header('Location: /companies.php?page=ManageCorp&TokenID=' . $getAllCorpInfos['token']);
																	} else {
																		addLogEventOTP("[ERROR] Users haven't been created by" . " " . $_SESSION['username'] . " (login=" . $login_af . "; company=" . $nomclient . ")");

																		$Session->setFlash(Translator('user_cant_been_created'), "close", "error");
																		header('Location: /ldap.php');
																		exit();
																	}
																} else {
																	$Session->setFlash(Translator('The_name') . " <b>" . $Username . "</b> " . Translator('not_available'), "close", "error");
																	$actual_link = "https://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
																	header('Location: ' . $actual_link);
																	exit();
																}
															} else {
																$Session->setFlash(Translator('The_name') . $Username . Translator('not_available'), "close", "error");
																$actual_link = "https://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
																header('Location: ' . $actual_link);
																exit();
															}
														}
													}
												} else { 
													addLogEventOTP("[ERROR] Connection Fails to LDAP" . " " . $_SESSION['username'] . " (login=" . $login_af . "; company=" . $nomclient . ")");
													?>
													<div class="alert alert-danger" role="alert">
														<i class="fas fa-exclamation-triangle"></i> <?php echo Translator('No_user_match'); ?>
													</div>
											<?php }
											}
										} else { 
											addLogEventOTP("[ERROR] Cannot Connect to LDAP" . " " . $_SESSION['username'] . " (login=" . $login_af . "; company=" . $nomclient . ")");
											?>
											<div class="alert alert-danger" role="alert">
												<i class="fas fa-exclamation-triangle"></i> <?php echo Translator('Cannot_connect_LDAP'); ?>
											</div>
							<?php }
									}
								} else {
									$Session->setFlash(Translator('choose_at_least_one_user'), "change_history", "warning");
									$actual_link = "https://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
									header('Location: ' . $actual_link);
									exit();
								}
							}
							?>

							<fieldset class="fieldset_exerotp">
								<legend class="legend_exerotp">II - <?php echo Translator('L_users'); ?></legend>
								<div class="loadLdapUsers">
									<script>
										setTimeout(function() {
											$('#sqdFG4d5').fadeIn();
										}, 15000);
									</script>


									<div class="text-center">
										<h4 class="text-blink"><?php echo Translator('Connect_current_LDAP'); ?></h4>
										<div class="ldap-loader">
											<div>
												<ul>
													<li>
														<svg viewBox="0 0 90 120" fill="currentColor">
															<path d="M90,0 L90,120 L11,120 C4.92486775,120 0,115.075132 0,109 L0,11 C0,4.92486775 4.92486775,0 11,0 L90,0 Z M71.5,81 L18.5,81 C17.1192881,81 16,82.1192881 16,83.5 C16,84.8254834 17.0315359,85.9100387 18.3356243,85.9946823 L18.5,86 L71.5,86 C72.8807119,86 74,84.8807119 74,83.5 C74,82.1745166 72.9684641,81.0899613 71.6643757,81.0053177 L71.5,81 Z M71.5,57 L18.5,57 C17.1192881,57 16,58.1192881 16,59.5 C16,60.8254834 17.0315359,61.9100387 18.3356243,61.9946823 L18.5,62 L71.5,62 C72.8807119,62 74,60.8807119 74,59.5 C74,58.1192881 72.8807119,57 71.5,57 Z M71.5,33 L18.5,33 C17.1192881,33 16,34.1192881 16,35.5 C16,36.8254834 17.0315359,37.9100387 18.3356243,37.9946823 L18.5,38 L71.5,38 C72.8807119,38 74,36.8807119 74,35.5 C74,34.1192881 72.8807119,33 71.5,33 Z"></path>
														</svg>
													</li>
													<li>
														<svg viewBox="0 0 90 120" fill="currentColor">
															<path d="M90,0 L90,120 L11,120 C4.92486775,120 0,115.075132 0,109 L0,11 C0,4.92486775 4.92486775,0 11,0 L90,0 Z M71.5,81 L18.5,81 C17.1192881,81 16,82.1192881 16,83.5 C16,84.8254834 17.0315359,85.9100387 18.3356243,85.9946823 L18.5,86 L71.5,86 C72.8807119,86 74,84.8807119 74,83.5 C74,82.1745166 72.9684641,81.0899613 71.6643757,81.0053177 L71.5,81 Z M71.5,57 L18.5,57 C17.1192881,57 16,58.1192881 16,59.5 C16,60.8254834 17.0315359,61.9100387 18.3356243,61.9946823 L18.5,62 L71.5,62 C72.8807119,62 74,60.8807119 74,59.5 C74,58.1192881 72.8807119,57 71.5,57 Z M71.5,33 L18.5,33 C17.1192881,33 16,34.1192881 16,35.5 C16,36.8254834 17.0315359,37.9100387 18.3356243,37.9946823 L18.5,38 L71.5,38 C72.8807119,38 74,36.8807119 74,35.5 C74,34.1192881 72.8807119,33 71.5,33 Z"></path>
														</svg>
													</li>
													<li>
														<svg viewBox="0 0 90 120" fill="currentColor">
															<path d="M90,0 L90,120 L11,120 C4.92486775,120 0,115.075132 0,109 L0,11 C0,4.92486775 4.92486775,0 11,0 L90,0 Z M71.5,81 L18.5,81 C17.1192881,81 16,82.1192881 16,83.5 C16,84.8254834 17.0315359,85.9100387 18.3356243,85.9946823 L18.5,86 L71.5,86 C72.8807119,86 74,84.8807119 74,83.5 C74,82.1745166 72.9684641,81.0899613 71.6643757,81.0053177 L71.5,81 Z M71.5,57 L18.5,57 C17.1192881,57 16,58.1192881 16,59.5 C16,60.8254834 17.0315359,61.9100387 18.3356243,61.9946823 L18.5,62 L71.5,62 C72.8807119,62 74,60.8807119 74,59.5 C74,58.1192881 72.8807119,57 71.5,57 Z M71.5,33 L18.5,33 C17.1192881,33 16,34.1192881 16,35.5 C16,36.8254834 17.0315359,37.9100387 18.3356243,37.9946823 L18.5,38 L71.5,38 C72.8807119,38 74,36.8807119 74,35.5 C74,34.1192881 72.8807119,33 71.5,33 Z"></path>
														</svg>
													</li>
													<li>
														<svg viewBox="0 0 90 120" fill="currentColor">
															<path d="M90,0 L90,120 L11,120 C4.92486775,120 0,115.075132 0,109 L0,11 C0,4.92486775 4.92486775,0 11,0 L90,0 Z M71.5,81 L18.5,81 C17.1192881,81 16,82.1192881 16,83.5 C16,84.8254834 17.0315359,85.9100387 18.3356243,85.9946823 L18.5,86 L71.5,86 C72.8807119,86 74,84.8807119 74,83.5 C74,82.1745166 72.9684641,81.0899613 71.6643757,81.0053177 L71.5,81 Z M71.5,57 L18.5,57 C17.1192881,57 16,58.1192881 16,59.5 C16,60.8254834 17.0315359,61.9100387 18.3356243,61.9946823 L18.5,62 L71.5,62 C72.8807119,62 74,60.8807119 74,59.5 C74,58.1192881 72.8807119,57 71.5,57 Z M71.5,33 L18.5,33 C17.1192881,33 16,34.1192881 16,35.5 C16,36.8254834 17.0315359,37.9100387 18.3356243,37.9946823 L18.5,38 L71.5,38 C72.8807119,38 74,36.8807119 74,35.5 C74,34.1192881 72.8807119,33 71.5,33 Z"></path>
														</svg>
													</li>
													<li>
														<svg viewBox="0 0 90 120" fill="currentColor">
															<path d="M90,0 L90,120 L11,120 C4.92486775,120 0,115.075132 0,109 L0,11 C0,4.92486775 4.92486775,0 11,0 L90,0 Z M71.5,81 L18.5,81 C17.1192881,81 16,82.1192881 16,83.5 C16,84.8254834 17.0315359,85.9100387 18.3356243,85.9946823 L18.5,86 L71.5,86 C72.8807119,86 74,84.8807119 74,83.5 C74,82.1745166 72.9684641,81.0899613 71.6643757,81.0053177 L71.5,81 Z M71.5,57 L18.5,57 C17.1192881,57 16,58.1192881 16,59.5 C16,60.8254834 17.0315359,61.9100387 18.3356243,61.9946823 L18.5,62 L71.5,62 C72.8807119,62 74,60.8807119 74,59.5 C74,58.1192881 72.8807119,57 71.5,57 Z M71.5,33 L18.5,33 C17.1192881,33 16,34.1192881 16,35.5 C16,36.8254834 17.0315359,37.9100387 18.3356243,37.9946823 L18.5,38 L71.5,38 C72.8807119,38 74,36.8807119 74,35.5 C74,34.1192881 72.8807119,33 71.5,33 Z"></path>
														</svg>
													</li>
													<li>
														<svg viewBox="0 0 90 120" fill="currentColor">
															<path d="M90,0 L90,120 L11,120 C4.92486775,120 0,115.075132 0,109 L0,11 C0,4.92486775 4.92486775,0 11,0 L90,0 Z M71.5,81 L18.5,81 C17.1192881,81 16,82.1192881 16,83.5 C16,84.8254834 17.0315359,85.9100387 18.3356243,85.9946823 L18.5,86 L71.5,86 C72.8807119,86 74,84.8807119 74,83.5 C74,82.1745166 72.9684641,81.0899613 71.6643757,81.0053177 L71.5,81 Z M71.5,57 L18.5,57 C17.1192881,57 16,58.1192881 16,59.5 C16,60.8254834 17.0315359,61.9100387 18.3356243,61.9946823 L18.5,62 L71.5,62 C72.8807119,62 74,60.8807119 74,59.5 C74,58.1192881 72.8807119,57 71.5,57 Z M71.5,33 L18.5,33 C17.1192881,33 16,34.1192881 16,35.5 C16,36.8254834 17.0315359,37.9100387 18.3356243,37.9946823 L18.5,38 L71.5,38 C72.8807119,38 74,36.8807119 74,35.5 C74,34.1192881 72.8807119,33 71.5,33 Z"></path>
														</svg>
													</li>
												</ul>
											</div>
										</div>

										<p id="sqdFG4d5" class="text-warning dsd54fe">
											<i class="fas fa-exclamation-triangle"></i> <?php echo Translator('Your_LDAP_serv'); ?>
										</p>
									</div>
								</div>
								<script type="text/javascript">
									function loadLdapUsers() {
										$('.loadLdapUsers').load('/inc/api/ldapconnection.php');
									}
									loadLdapUsers();
								</script>
					</div>
					</fieldset>
					<br><br>
				<?php
						} elseif ($camefrom == "SummaryCreateUsers") { ?>


					<?php
							//Regeneration du token LDAP
							$token = generateToken(9999);
							$gen_token = $db->prepare("UPDATE otp_ldap SET token = ? WHERE token = ?");
							$gen_token->execute(array($token, $TokenID));
					?>
				<?php } else { ?>
					<fieldset class="fieldset_exerotp">
						<legend class="legend_exerotp">I - <?php echo Translator('Choose_LDAP'); ?></legend>
						<div id="submit_formfirewall_user">
							<div class="form-group">
								<label for="ldapinput_client"><?php echo Translator('Specify_LDAP_client'); ?> : </label>

								<select class="form-control" name="ldapinput_client" autocomplete="off" class="form-control" id="ldapinput_client">
									<?php
									if ($_SESSION['level'] == SUPERVISOR) {
										if (!empty($_GET['TokenID'])) {
											$corps_recorver = $db->prepare('SELECT * FROM otp_companies WHERE token = ?');
											$corps_recorver->execute(array($_GET['TokenID']));
										} else {
											$corps_recorver = $db->query('SELECT * FROM otp_companies ORDER BY name ASC');
										}
									} else {
										$corps_recorver = $db->prepare('SELECT * FROM otp_companies WHERE corpid = ?');
										$corps_recorver->execute(array($_SESSION['corp']));
									}
									$count_corp = $corps_recorver->rowCount();

									if ($count_corp == 0) { ?>
										<option disabled value="none"><?php echo Translator('No_business_2'); ?></option>
									<?php } else { ?>

										<?php while ($corp_recup = $corps_recorver->fetch()) {
										?>
											<optgroup label="<?= Translator('Company'); ?> : <?= $corp_recup['name'] ?>">
												<?php
												$recup_ldap = $db->prepare('SELECT * FROM otp_ldap WHERE corpid = ?');
												$recup_ldap->execute(array($corp_recup['corpid']));
												$count_ldap = $recup_ldap->rowCount();

												if ($count_ldap == 0) { ?>
													<option disabled value="none"><?php echo Translator('No_LDAP_auth'); ?></option>
												<?php } else { ?>
													<?php while ($rc_ldap = $recup_ldap->fetch()) { ?>
														<?php
														$recup_ldap_client = $db->prepare('SELECT * FROM otp_ldap WHERE token = ?');
														$recup_ldap_client->execute(array($rc_ldap['token']));

														while ($ft_clientreq = $recup_ldap_client->fetch()) { ?>
															<option value="<?= $rc_ldap['token'] ?>"><?php echo Translator('Client_2'); ?> : <?= $corp_recup['name'] ?> - Base DN : <?= $rc_ldap['base_dn'] ?></option>
														<?php }

														if (isset($_POST['nextform_ldapusr'])) {
															if (!empty($_POST['ldapinput_client']) and !empty($_POST['ldapfilter'])) {
																unset($_SESSION['tra_ldapfilter']);
																$ldapfilter = htmlspecialchars($_POST['ldapfilter']);
																$_SESSION['tra_ldapfilter'] = $ldapfilter;

																$_SESSION['BindParamsLDAPclient'] = htmlspecialchars($_POST['ldapinput_client']);
																header('Location: /ldap.php?page=AddLdapFromDirectory&camefrom=Form2');
																exit();
															} else {
																$Session->setFlash(Translator('Fill_all_fields'), "close", "error");
																header('Location: ' . $actual_link);
																exit();
															}
														}
														?>
												<?php
													}
												}
												?>
											</optgroup>
									<?php }
									} ?>
								</select>
							</div>
						</div>
					</fieldset>
					<br>
					<fieldset class="fieldset_exerotp">
							<legend class="legend_exerotp">II - <?php echo Translator('LDAP_filters'); ?></legend>
								<div id="submit_formfirewall_user">
									<div class="form-group">
										<label for="ldapinput_client">
											<?php echo Translator('syntax_filters'); ?><br><br>

											<div class="row">
												<div class="col-md-6">
													<b><?php echo Translator('Examples'); ?></b><br>
													<i><?php echo Translator('User_directory'); ?></i><br>
													<code>(&(objectCategory=person)(objectClass=User))</code><br><br>
													<i><?php echo Translator('To_members_spec'); ?> :</i><br>
													<code>(&(objectCategory=Person)(objectClass=User)(memberOf=CN=MyGroup,OU=MyOU,DC=MYDOMAIN,DC=COM))</code>
												</div>

												<div class="col-md-6">
													<div class="form-group">
														<label for="ldapfilter"><?php echo Translator('LDAP_filter'); ?>:</label>
														<?php
														// Filtre LDAP par défaut
														$ldapfilter = Translator('LDAP_search_default');
														// Récupérer la dernière recherche LDAP de l'utilisateur à partir de la base de données
															if (isset($_SESSION['token'])) {
																$token = $_SESSION['token'];
																$stmt = $db->prepare("SELECT search FROM otp_users WHERE token = ?");
																$stmt->execute([$token]);
																$last_search = $stmt->fetchColumn();
																if ($last_search) {
																	$ldapfilter = $last_search;
																}
															}
															?>

														<div class="form-check">

															<input type="text" class="form-control" name="ldapfilter" id="ldapfilter" value="<?php echo $ldapfilter ?>">
															<!-- Bouton d'effacement et de sauvegarde de la recherche-->
															<?php
															if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ldapclear'])) {
																$token = $_SESSION['token'];
																$update = $db->prepare("UPDATE otp_users SET search = '' WHERE token = ?");
																$update->execute([$token]);
																header("Location: ldap.php?page=AddLdapFromDirectory");
																exit();
															}
															if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ldapfilter']) && !empty($_POST['ldapfilter']) && isset($_POST['ldapsave'])) {
																$token = $_SESSION['token'];
																$ldapfilter = htmlspecialchars($_POST['ldapfilter']);
																$token = $_SESSION['token'];
																$update = $db->prepare("UPDATE otp_users SET search = ? WHERE token = ?");
																$update->execute(array($ldapfilter, $token));
																header("Location: ldap.php?page=AddLdapFromDirectory");
																exit();
															}
															?>
															<button type="submit" name="ldapclear" style="border: 4px;"><?php echo Translator('Clear_search') ?></button>
															<button type="submit" name="ldapsave" style="border: 4px;"><?php echo Translator('Save_search') ?></button>
														</div>
													</div>
												</div>
											</div>
										</label>
									</div>
								</div>
					</fieldset>
					<?php } ?>
		</div>
	</form>
<?php } else { ?>
	<?php
				if (checkLevel() != ADMIN) {
					if (checkLevel() == OPERATOR && $_SESSION['corp'] == "NOT_DEFINED") {
						$recup_all_ldap = $db->query('SELECT * FROM otp_ldap ORDER BY id DESC');
					} elseif (checkLevel() == OPERATOR && $_SESSION['corp'] != "NOT_DEFINED") {
						$recup_all_ldap = $db->prepare('SELECT * FROM otp_ldap WHERE corpid = ? ORDER BY id DESC');
						$recup_all_ldap->execute(array($_SESSION['corp']));
					} else {
						$recup_all_ldap = $db->query('SELECT * FROM otp_ldap ORDER BY id DESC');
					}
				} else {
					$recup_all_ldap = $db->prepare('SELECT * FROM otp_ldap WHERE corpid = ? ORDER BY id DESC');
					$recup_all_ldap->execute(array($_SESSION['corp']));
				}
				$count_ldap = $recup_all_ldap->rowCount();

				if ($count_ldap == 0) { ?>
		<div class="alert alert-danger" role="alert">
			<i class="fas fa-exclamation-triangle"></i> <?php echo Translator('No_LDAP_inter'); ?>
		</div>
	<?php } else { ?>
		<div class="alert alert-info" role="alert">
			<i class="far fa-info-circle"></i>
			<?php echo Translator('Display2');
					echo Translator('of') . "<strong>" . $count_ldap . "</strong> ";
					if ($count_ldap > 1) {
						echo Translator('authentications');
					} else {
						echo Translator('authentication');
					} ?>
		</div>

		<input type="text" id="searchboxTable" placeholder="<?php echo Translator('find_a_interconnexion'); ?>" title=<?php echo Translator('Field_valid_ldap_interconnect'); ?>>

		<script>
			$(document).ready(function() {
				$("#searchboxTable").on("keyup", function() {
					var value = $(this).val().toLowerCase();
					$("#byValDataT tr").filter(function() {
						$(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
					});
				});

				$("#searchboxTable").on("keyup", function() {
					var name = $(this).val();
					if (name.length >= 1) {
						var box = paginator({
							table: document.getElementById("container_table").getElementsByTagName("table")[0],
							box_mode: "list",
							rows_per_page: "0",
							get_rows: function() {
								return document.getElementById("table_otpexer").getElementsByTagName("tbody");
							},
						});
						$('.pgnt_tab').hide();
						return false;
					} else {
						var box = paginator({
							table: document.getElementById("container_table").getElementsByTagName("table")[0],
							box_mode: "list",
							rows_per_page: "8",
						});
						$('.pgnt_tab').show();
						return false;
					}
				});

				var box = paginator({
					table: document.getElementById("container_table").getElementsByTagName("table")[0],
					box_mode: "list",
					rows_per_page: "8",
				});
				document.getElementById("container_table").appendChild(box);
			});
		</script>

		<div class="table-responsive" id="container_table">
			<table id="table_otpexer" class="sortable-theme-bootstrap table-striped" data-sortable>
				<thead>
					<tr>
						<?php if ($_SESSION['corp'] == "NOT_DEFINED") { ?>
							<th class="vt-default-th" data-sorted-direction="descending"><?php echo Translator('Company'); ?></th>
						<?php } ?>
						<th <?php if ($_SESSION['corp'] != "NOT_DEFINED") {
								echo 'class="vt-default-th" data-sorted-direction="descending"';
							} ?>><?php echo Translator('LDAP_serv'); ?></th>
						<th><?php echo Translator('DN_attr'); ?></th>
						<th><?php echo Translator('Creation_date'); ?></th>
						<th data-sortable="false"> </th>
					</tr>
				</thead>
				<tbody id="byValDataT">
					<?php
					while ($recorver_datas_fireclient = $recup_all_ldap->fetch()) {

						if ($_SESSION['corp'] == "NOT_DEFINED") {
							$RecupCorpInfos = $db->prepare('SELECT * FROM otp_companies WHERE corpid = ?');
							$RecupCorpInfos->execute(array($recorver_datas_fireclient['corpid']));
							$ft_rcpcorp = $RecupCorpInfos->fetch();

						} else {
							$RecupCorpInfos = $db->prepare('SELECT * FROM otp_companies WHERE corpid = ?');
							$RecupCorpInfos->execute(array($_SESSION['corp']));
							$ft_rcpcorp = $RecupCorpInfos->fetch();
						}
					?>
						<tr>
							<?php if ($_SESSION['corp'] == "NOT_DEFINED") { ?>
								<td><?= $ft_rcpcorp['name'] ?></td>
							<?php } ?>
							<td>
								<?php if ($recorver_datas_fireclient['sslproto'] == "on") { ?>
									<i class="far fa-lock text-success align-middle fjh054" title="Connexion SSL"></i>
								<?php } else { ?>
									<i class="far fa-lock-open text-warning align-middle fjh054" title="Connexion Non-SSL"></i>
								<?php  } ?>
								<?= $recorver_datas_fireclient['ldap_uri'] ?>
								<?php if (!empty($recorver_datas_fireclient['ldap_uri2'])) {
									echo " / " . $recorver_datas_fireclient['ldap_uri2'];
								} ?>
							</td>

							<?php $rand_client_modal = generateToken(9999); ?>
							<?php if (checkLevel() != OPERATOR) { ?>
								<!-- Modal_confirm suppression ldap.auth -->
								<div class="modal fade" id="confirm_delete_ldap__<?= $rand_client_modal ?>" tabindex="-1" role="dialog" aria-labelledby="lblconfirm_delete_ldap" aria-hidden="true">
									<div class="modal-dialog modal-lg" role="document">
										<div class="modal-content">
											<div class="modal-header">
												<h5 class="modal-title" id="lblconfirm_delete_ldap"><i class="far fa-trash-alt"></i> <?php echo Translator('Remove_LDAP_inter'); ?> ?</h5>
												<button type="button" class="close" data-dismiss="modal" aria-label="Close">
													<span aria-hidden="true"><i class="far fa-times"></i></span>
												</button>
											</div>

											<div class="modal-body">
												<label><?php echo Translator('Confirm_LDAP_inter'); ?> <b><?= $recorver_datas_fireclient['base_dn']; ?> </b> <?php echo Translator('Belonging_client'); ?>
													<b>
														<?php
														$recup_firewallclient = $db->prepare('SELECT * FROM otp_companies WHERE corpid = ?');
														$recup_firewallclient->execute(array($recorver_datas_fireclient['corpid']));
														$ft_recupfireclient = $recup_firewallclient->fetch();

														echo $ft_recupfireclient['name'];


														?>
													</b> ?
													<br><u class="text-danger"><?php echo Translator('action_irre'); ?></u></label>
											</div>

											<div class="modal-footer">
												<?php
												if (isset($_POST['del_this_ldap__' . $recorver_datas_fireclient['token']])) {
													unset($_SESSION['token_access_deleteldap']);
													$_SESSION['token_access_deleteldap'] = $recorver_datas_fireclient['token'];

													header('Location: inc/class.actions.php?VerbAction=DeleteLdapAuth');
													exit();
												}
												?>

												<form method="POST">
													<button type="button" class="exerotpbtn btn-cancel ripple-effect ripple-white" data-dismiss="modal"><?php echo Translator('Cancel'); ?></button>
													<button type="submit" name="del_this_ldap__<?= $recorver_datas_fireclient['token'] ?>" class="exerotpbtn btn-green ripple-effect ripple-white"><?php echo Translator('Confirm'); ?></button>
												</form>
											</div>
										</div>
									</div>
								</div>
							<?php } ?>

							<!-- Modal_viewinfos ldapclient -->
							<div class="modal fade" id="view_infos_client__<?= $rand_client_modal ?>" tabindex="-1" role="dialog" aria-labelledby="lblview_ldap" aria-hidden="true">
								<div class="modal-dialog modal-lg" role="document">
									<div class="modal-content">
										<div class="modal-header">
											<h5 class="modal-title" id="lblconfirm_view_ldapview"><i class="far fa-book-open"></i> <?php echo Translator('Viewing_LDAP_inter'); ?> <b><?= $recorver_datas_fireclient['base_dn']; ?></b></h5>
											<button type="button" class="close" data-dismiss="modal" aria-label="Close">
												<span aria-hidden="true"><i class="fas fa-times"></i></span>
											</button>
										</div>

										<a href="javascript:void()" title="<?= Translator('print') ?>" class="btn_print_firewall" id="btnPrint__<?= $recorver_datas_fireclient['token'] ?>"><i class="far fa-print fa-2x"></i></a>

										<div id="printThis__<?= $recorver_datas_fireclient['token'] ?>">
											<div class="modal-body">
												<div class="card">
													<h5 class="card-header"><?php echo Translator('LDAP_domain_name'); ?> : <?= $recorver_datas_fireclient['base_dn'] ?></h5>
													<div class="card-body">
														<label><b><?php echo Translator('Company'); ?> : </b><?= $ft_rcpcorp['name'] ?></label><br>
														<label><b><?php echo Translator('DN_bind'); ?> :</b> <?= $recorver_datas_fireclient['binddn'] ?></label><br>
														<div class="row">
															<?php if ($recorver_datas_fireclient['sslproto'] == "on") { ?>
																<div class="col-md-1 text-right sslproto_lock" title="LDAPS">
																	<i class="far fa-lock text-success align-middle"></i>
																</div>
															<?php } else { ?>
																<div class="col-md-1 text-right sslproto_lock" title="LDAP">
																	<i class="far fa-lock-open text-warning align-middle"></i>
																</div>
															<?php  } ?>
															<div class="col-md-10 dfsuhdsj">
																<label><b><?php echo Translator('Primary_address'); ?> :</b> <?= $recorver_datas_fireclient['ldap_uri'] ?></label><br>
																<label><b><?php echo Translator('Secondary_address'); ?> :</b> <?php if (empty($recorver_datas_fireclient['ldap_uri2'])) {
																																	echo "N/A";
																																} else {
																																	echo $recorver_datas_fireclient['ldap_uri2'];
																																} ?></label><br>
															</div>
														</div>
														<label><b><?php echo Translator('PAM_connect'); ?> :</b> <?= $recorver_datas_fireclient['loginattribute'] ?></label><br>
														<label><b><?php echo Translator('Creation_date'); ?> :</b> <?php if ($recorver_datas_fireclient['created_at'] != "0000-00-00 00:00:00") {
																														echo date_format(date_create($recorver_datas_fireclient['created_at']), "d/m/Y  H:i");
																													} else {
																														echo Translator('no_creation_date');
																													} ?></label>
													</div>
												</div>
											</div>
										</div>

										<div class="modal-footer">
											<button type="button" class="exerotpbtn btn-white ripple-effect ripple-dark" data-dismiss="modal"><?php echo Translator('Close'); ?></button>
										</div>
									</div>
								</div>
							</div>

							<?php if (checkLevel() != OPERATOR) { ?>

								<!-- Modal_editinfos ldapclient -->
								<div class="modal fade" id="edit_infos_client__<?= $rand_client_modal ?>" tabindex="-1" role="dialog" aria-labelledby="lblview_ldap" aria-hidden="true">
									<div class="modal-dialog modal-lg" role="document">
										<div class="modal-content">
											<div class="modal-header">
												<h5 class="modal-title" id="lblconfirm_view_ldapedit"><i class="far fa-pen"></i> <?php echo Translator('Edit_LDAP_inter'); ?> <b><?= $ft_rcpcorp['name'] ?></b></h5>
												<button type="button" class="close" data-dismiss="modal" aria-label="Close">
													<span aria-hidden="true"><i class="far fa-times"></i></span>
												</button>
											</div>


											<div class="modal-body">
												<div class="card">
													<form method="POST">
														<h5 class="card-header"><?php echo Translator('LDAP_domain_name'); ?> : <?= $recorver_datas_fireclient['base_dn'] ?>
															<div class="contain_controlbtns__editusr" id="section_editldap__btncontrols__<?= $recorver_datas_fireclient['token'] ?>" style="display: contents;">
																<button id="editing_ldap__<?= $recorver_datas_fireclient['token'] ?>" type="submit" name="editing_ldap__<?= $recorver_datas_fireclient['token'] ?>" class="exerotpbtn btn-fab-mini btn-save ripple-effect ripple-dark" title="<?= Translator('Save'); ?>">
																	<i class="far fa-save" style="margin-bottom: 3px;"></i>
																</button>

																<button type="button" id="cancel_editusr__<?= $recorver_datas_fireclient['token'] ?>" data-dismiss="modal" class="exerotpbtn btn-fab-mini btn-cancel ripple-effect ripple-dark" title="<?= Translator('Cancel'); ?>">
																	<i class="far fa-times" style="margin-bottom: 3px;"></i>
																</button>
															</div>
														</h5>
														<div class="card-body">
															<?php
															if (isset($_POST['editing_ldap__' . $recorver_datas_fireclient['token']])) {
																$req_ldap_infos = $db->prepare("SELECT * FROM otp_ldap WHERE token = ?");
																$req_ldap_infos->execute(array($recorver_datas_fireclient['token']));
																$ldap = $req_ldap_infos->fetch();
																$password_updated = true;

																// Si les deux champs mot de passe ne correspondent pas, on rejete.
																if ($_POST['ldapinput_bind_password__' . $recorver_datas_fireclient['token']] == $_POST['ldapinput_bind_cpassword__' . $recorver_datas_fireclient['token']]) {
																	$ldap_password  = $_POST['ldapinput_bind_password__' . $recorver_datas_fireclient['token']];
																} else {
																	$Session->setFlash(Translator('password_no_match'), "close", "error");
																	header('Location: /ldap.php');
																	exit();
																}

																// Si les deux champs mot de passe sont vide, on réutilise le mot de passe existant.
																if (empty($_POST['ldapinput_bind_cpassword__' . $recorver_datas_fireclient['token']])) {
																		$recup_companiesinfos 	= $db->prepare('SELECT * FROM otp_companies WHERE corpid = ?');
																		$recup_companiesinfos->execute(array($ldap['corpid']));
																		$ft_recupinfoscorp 		= $recup_companiesinfos->fetch();
																		
																		$array_ldap_passwd 	 	= array("bindpw");
																		$InsertCmdlet 			= 'grep -r bindpw /etc/pam_ldap_' . $ft_recupinfoscorp['folder'] . '.conf';
																		$RunCmdlet 				= escapeshellcmd($InsertCmdlet);
																		$ldap_password_proc 	= shell_exec($RunCmdlet);
																		$ldap_password_proc2 	= str_replace($array_ldap_passwd, "", $ldap_password_proc);
																		$ldap_password 		 	= trim(preg_replace('/\s+/', ' ', $ldap_password_proc2));
																		$password_updated 		= false;																	
																}
																	
																if (($_POST['ldapinput_loginpam_attr__' . $recorver_datas_fireclient['token']] != "skel") and ($_POST['ldapinput_bind_dndcextension__' . $recorver_datas_fireclient['token']] != "skel")) {
																			$ldapinput_bind_dndcextension = htmlspecialchars($_POST['ldapinput_bind_dndcextension__' . $recorver_datas_fireclient['token']]);
																			$ldapinput_namebase = htmlspecialchars($_POST['ldapinput_namebase__' . $recorver_datas_fireclient['token']]);
																			$ldapinput_uri = strtolower(htmlspecialchars($_POST['ldapinput_uri__' . $recorver_datas_fireclient['token']]));
																			$ldapinput_uri2 = strtolower(htmlspecialchars($_POST['ldapinput_uri2__' . $recorver_datas_fireclient['token']]));

																			$ldapinput_uriproto				=	htmlspecialchars($_POST['sslproto__' . $recorver_datas_fireclient['token']]);
																			if ($_POST['sslproto__' . $recorver_datas_fireclient['token']] == "2") {
																				$sslproto		= 	"on";

																				if ($sslproto != ($ldap['sslproto'])) {
																					$inserturi = $db->prepare("UPDATE otp_ldap SET sslproto = ? WHERE token = ?");
																					$inserturi->execute(array($sslproto, $recorver_datas_fireclient['token']));

																					addLogEventOTP("[INFORMATION] Account " . " " . $_SESSION['username'] . " " . "has modified company " . $ft_rcpcorp['name'] . " LDAP settings " . "(sslproto=on)");
																					$Session->setFlash(Translator('Save_change2'), "check", "success");
																					header('Location: /ldap.php');
																				}
																			} elseif ($_POST['sslproto__' . $recorver_datas_fireclient['token']] == "1") {
																				$sslproto		= 	"off";

																				if ($sslproto != ($ldap['sslproto'])) {
																					$inserturi = $db->prepare("UPDATE otp_ldap SET sslproto = ? WHERE token = ?");
																					$inserturi->execute(array($sslproto, $recorver_datas_fireclient['token']));

																					addLogEventOTP("[INFORMATION] Account" . " " . $_SESSION['username'] . " " . "has modified company " . $ft_rcpcorp['name'] . " LDAP settings " . "(sslproto=off)");
																					$Session->setFlash(Translator('Save_change2'), "check", "success");
																					header('Location: /ldap.php');
																				}
																			}

																			$final_uri 				=	$ldapinput_uri;

																			if (!empty($final_uri2)) {
																				$final_uri2 		= 	" -v " . $ldapinput_uri2 . " ";
																			} else {
																				$final_uri2 		= 	NULL;
																			}

																			//Special encode "'" character in password
																			$ldap_password   = str_replace("'", "'\"'\"'", $ldap_password);

																			if (!empty($_POST['ldapinput_loginpam_attr__' . $recorver_datas_fireclient['token']])) {
																				$ldapinput_loginpam_attr = strtolower(htmlspecialchars($_POST['ldapinput_loginpam_attr__' . $recorver_datas_fireclient['token']]));
																			} else {
																				$ldapinput_loginpam_attr = "samaccountname";
																			}

																			if (isset($_POST['ldapinput_namebase__' . $recorver_datas_fireclient['token']]) and !empty($_POST['ldapinput_namebase__' . $recorver_datas_fireclient['token']]) and $_POST['ldapinput_namebase__' . $recorver_datas_fireclient['token']] != $ldap['base_dn']) {
																				$req_dbldap = $db->prepare("SELECT * FROM otp_ldap WHERE base_dn = ?");
																				$req_dbldap->execute(array($ldapinput_namebase));
																				$baseldap_exist = $req_dbldap->rowCount();

																				if ($baseldap_exist == 0) {
																					$insertbasedn = $db->prepare("UPDATE otp_ldap SET base_dn = ? WHERE token = ?");
																					$insertbasedn->execute(array($ldapinput_namebase, $recorver_datas_fireclient['token']));

																					addLogEventOTP("[INFORMATION] Account" . " " . $_SESSION['username'] . " " . "has modified company " . $ft_rcpcorp['name'] . " LDAP settings " . " (Base DN: ". $ldapinput_namebase .")");
																					$Session->setFlash(Translator('Save_change2'), "check", "success");
																					header('Location: /ldap.php');
																				} else {
																					$Session->setFlash(Translator('Already_LDAP_domain_name'), "close", "error");
																					header('Location: /ldap.php');
																					exit();
																				}
																			}

																			if (isset($_POST['ldapinput_uri__' . $recorver_datas_fireclient['token']]) and !empty($_POST['ldapinput_uri__' . $recorver_datas_fireclient['token']]) and ($_POST['ldapinput_uri__' . $recorver_datas_fireclient['token']] != $ldap['ldap_uri'])) {
																				if (filter_var($_POST['ldapinput_uri__' . $recorver_datas_fireclient['token']], FILTER_VALIDATE_IP) or filter_var($_POST['ldapinput_uri__' . $recorver_datas_fireclient['token']], FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME)) {
																					$inserturi = $db->prepare("UPDATE otp_ldap SET ldap_uri = ? WHERE token = ?");
																					$inserturi->execute(array($ldapinput_uri, $recorver_datas_fireclient['token']));
																					$final_uri 	=	$ldapinput_uri;

																					addLogEventOTP("[INFORMATION] Account" . " " . $_SESSION['username'] . " " . "has modified company " . $ft_rcpcorp['name'] . " LDAP settings " . " (Primary Server = ". $final_uri .")");
																					$Session->setFlash(Translator('Save_change2'), "check", "success");
																					header('Location: /ldap.php');
																				} else {
																					$final_uri 				=	" ";
																					$Session->setFlash(Translator('format_ip_incorrect'), "close", "error");
																					header('Location: /ldap.php');
																					exit();
																				}
																			}

																			if (isset($_POST['ldapinput_loginpam_attr__' . $recorver_datas_fireclient['token']]) and $_POST['ldapinput_loginpam_attr__' . $recorver_datas_fireclient['token']] != $ldap['loginattribute']) {
																				$insertsampam = $db->prepare("UPDATE otp_ldap SET loginattribute = ? WHERE token = ?");
																				$insertsampam->execute(array($ldapinput_loginpam_attr, $recorver_datas_fireclient['token']));

																				addLogEventOTP("[INFORMATION] Account" . " " . $_SESSION['username'] . " " . "has modified company " . $ft_rcpcorp['name'] . " LDAP settings " . " (Unique Attribute = ". $ldapinput_loginpam_attr .")");
																				$Session->setFlash(Translator('Save_change2'), "check", "success");
																				header('Location: /ldap.php');
																			}

																			if (isset($_POST['ldapinput_bind_dndcextension__' . $recorver_datas_fireclient['token']]) and !empty($_POST['ldapinput_bind_dndcextension__' . $recorver_datas_fireclient['token']]) and $_POST['ldapinput_bind_dndcextension__' . $recorver_datas_fireclient['token']] != $ldap['binddn']) {
																				$insertbinddn = $db->prepare("UPDATE otp_ldap SET binddn = ? WHERE token = ?");
																				$insertbinddn->execute(array($ldapinput_bind_dndcextension, $recorver_datas_fireclient['token']));

																				addLogEventOTP("[INFORMATION] Account" . " " . $_SESSION['username'] . " " . "has modified company " . $ft_rcpcorp['name'] . " LDAP settings " . " (Bind DN: ". $ldapinput_bind_dndcextension .")");
																				$Session->setFlash(Translator('Save_change2'), "check", "success");
																				header('Location: /ldap.php');
																			}


																			if (isset($_POST['ldapinput_uri2__' . $recorver_datas_fireclient['token']])) {
																				if (!empty($_POST['ldapinput_uri2__' . $recorver_datas_fireclient['token']]) and ($_POST['ldapinput_uri2__' . $recorver_datas_fireclient['token']] != $ldap['ldap_uri2'])) {
																					if (filter_var($_POST['ldapinput_uri2__' . $recorver_datas_fireclient['token']], FILTER_VALIDATE_IP) or filter_var($_POST['ldapinput_uri2__' . $recorver_datas_fireclient['token']], FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME)) {
																						$inserturi2 = $db->prepare("UPDATE otp_ldap SET ldap_uri2 = ? WHERE token = ?");
																						$inserturi2->execute(array($ldapinput_uri2, $recorver_datas_fireclient['token']));

																						addLogEventOTP("[INFORMATION] Account" . " " . $_SESSION['username'] . " " . "has modified company " . $ft_rcpcorp['name'] . " LDAP settings " . " (Backup Server = ". $ldapinput_uri2 .")");
																						$Session->setFlash(Translator('Save_change2'), "check", "success");
																						header('Location: /ldap.php');

																						$final_uri2_var = " -v " . $ldapinput_uri2;
																					} else {
																						$final_uri2_var = " ";
																						$Session->setFlash(Translator('format_ip_ldap_secondaire'), "close", "error");
																						header('Location: /ldap.php');
																						exit();
																					}
																				} 
																				if (empty($_POST['ldapinput_uri2__' . $recorver_datas_fireclient['token']]) and ($_POST['ldapinput_uri2__' . $recorver_datas_fireclient['token']] != $ldap['ldap_uri2'])) {
																					$inserturi2 = $db->prepare("UPDATE otp_ldap SET ldap_uri2 = ? WHERE token = ?");
																					$inserturi2->execute(array("", $recorver_datas_fireclient['token']));

																					addLogEventOTP("[INFORMATION] Account" . " " . $_SESSION['username'] . " " . "has modified company " . $ft_rcpcorp['name'] . " LDAP settings " . " (Backup Server removed)");
																					$Session->setFlash(Translator('Save_change2'), "check", "success");
																					header('Location: /ldap.php');

																					$final_uri2_var = "";
																				}
																			}

																			$ldapinput_namebase_shell = $ldapinput_namebase;
																			$final_bind_fin_shell = $ldapinput_bind_dndcextension;

																			$GetInfosCorp = $db->prepare('SELECT * FROM otp_companies WHERE corpid = ?');
																			$GetInfosCorp->execute(array($recorver_datas_fireclient['corpid']));
																			$gjkfdF = $GetInfosCorp->fetch();

																			$CorpFolder = $gjkfdF['folder'];

																			$InsertCmdlet = "sudo /usr/local/bin/ldap_pam.sh -b '" . $ldapinput_namebase_shell . "' -u " . $final_uri . $final_uri2_var . " -s " . $sslproto . " -d '" . $final_bind_fin_shell . "' -p '" . $ldap_password . "' -c " . $CorpFolder . " -l " . $ldapinput_loginpam_attr;
																			$RunCmdlet = $InsertCmdlet;																	
																			$insert_srv_ldapauth = shell_exec($RunCmdlet);
																			if ($password_updated) {
																				addLogEventOTP("[INFORMATION] Account" . " " . $_SESSION['username'] . " " . "has modified company " . $ft_rcpcorp['name'] . " LDAP settings " . " (password updated)");
																			}


																} else {
																	$Session->setFlash(Translator('names_unable'), "close", "error");
																	header('Location: /ldap.php');
																	exit();
																}

															}
															?>

															<div class="formeditldap">
																<?php if (isset($error)) { ?>
																	<div class="alert alert-danger" role="alert">
																		<i class="fas fa-exclamation-triangle"></i> <?= $error ?>
																	</div>
																<?php } ?>

																<fieldset class="fieldset_exerotp">
																	<legend class="legend_exerotp"><?php echo Translator('general'); ?></legend>
																	<div id="submit_formfirewall_user">
																		<div class="row">
																			<div class="col-lg-6">
																				<div class="form-group">
																					<label for="ldapinput_namebase__<?= $recorver_datas_fireclient['token'] ?>"><?php echo Translator('LDAP_domain_name'); ?> : <b class="text-danger" title="<?php echo Translator('Field_required'); ?>" data-toggle="tooltip" data-placement="right"><i class="far fa-asterisk"></i></b></label>
																					<input type="text" name="ldapinput_namebase__<?= $recorver_datas_fireclient['token'] ?>" autocomplete="off" class="form-control" id="ldapinput_namebase__<?= $recorver_datas_fireclient['token'] ?>" value="<?= $recorver_datas_fireclient['base_dn'] ?>" placeholder="ex : DC=mycompany,DC=com">
																				</div>
																			</div>							
																		</div>
																		<div class="form-group">
																			<label for="ldapinput_loginpam_attr__<?= $recorver_datas_fireclient['token'] ?>"><?php echo Translator('Unique_iden_attr'); ?> : <b class="text-danger" title="<?php echo Translator('Field_required'); ?>" data-toggle="tooltip" data-placement="right"><i class="far fa-asterisk"></i></b></label>
																			<input type="text" name="ldapinput_loginpam_attr__<?= $recorver_datas_fireclient['token'] ?>" autocomplete="off" class="form-control" id="ldapinput_loginpam_attr__<?= $recorver_datas_fireclient['token'] ?>" value="<?= $recorver_datas_fireclient['loginattribute'] ?>" placeholder="ex : sAMAccountName">
																		</div>
																	</div>
																</fieldset>
																<br>
																<fieldset class="fieldset_exerotp">
																	<legend class="legend_exerotp"><?php echo Translator('LDAP_serv'); ?></legend>
																	<hr style="margin-top: 11px; margin-bottom: 10px;">
																	<div id="uriFormLdapAddresses">
																		<div class="row">
																			<div class="col-md-6">
																				<div class="form-group">
																					<label for="ldapinput_uri__<?= $recorver_datas_fireclient['token'] ?>"><?php echo Translator('Primary_address'); ?> : <b class="text-danger" title=<?php echo Translator('Field_required'); ?> data-toggle="tooltip" data-placement="right"><i class="far fa-asterisk"></i></b></label>
																					<div class="input-group mb-2">
																						<input type="text" name="ldapinput_uri__<?= $recorver_datas_fireclient['token'] ?>" autocomplete="off" class="form-control" id="ldapinput_uri__<?= $recorver_datas_fireclient['token'] ?>" value="<?= $recorver_datas_fireclient['ldap_uri'] ?>" placeholder="ex : X.X.X.X">
																					</div>
																				</div>
																			</div>
																			<div class="col-md-6">
																				<div class="form-group">
																					<label for="ldapinput_uri2__<?= $recorver_datas_fireclient['token'] ?>"><?php echo Translator('Secondary_address'); ?> : </label>
																					<div class="input-group mb-2">
																						<input type="text" name="ldapinput_uri2__<?= $recorver_datas_fireclient['token'] ?>" autocomplete="off" class="form-control" id="ldapinput_uri2__<?= $recorver_datas_fireclient['token'] ?>" value="<?= $recorver_datas_fireclient['ldap_uri2'] ?>" placeholder="ex : X.X.X.X">
																					</div>
																				</div>
																			</div>
																		</div>
																		<div class="form-group">
																			<label for="sslproto__<?= $recorver_datas_fireclient['token'] ?>"><?php echo Translator('SSL_protocols'); ?> : <b class="text-danger" title="<?php echo Translator('Field_required'); ?>" data-toggle="tooltip" data-placement="right"><i class="far fa-asterisk"></i></b></label>
																			<div class="input-group mb-2">
																				<select class="form-control" name="sslproto__<?= $recorver_datas_fireclient['token'] ?>" id="sslproto__<?= $recorver_datas_fireclient['token'] ?>">
																					<optgroup label="Protocoles LDAP">
																						<option value="1" <?php if ($recorver_datas_fireclient['sslproto'] == "off") {
																												echo " selected";
																											} ?>>Plaintext (LDAP)</option>
																						<option value="2" <?php if ($recorver_datas_fireclient['sslproto'] == "on") {
																												echo " selected";
																											} ?>>TLS (LDAPS)</option>
																					</optgroup>
																				</select>
																			</div>
																		</div>
																	</div>
																</fieldset>
																<br>
																<fieldset class="fieldset_exerotp">
																	<legend class="legend_exerotp"><?php echo Translator('Bind_auth'); ?></legend>
																	<i style="margin-bottom: 20px;"><?php echo Translator('DN_bind_user_autho'); ?></i>
																	<hr style="margin-top: 11px; margin-bottom: 10px;">
																	<div class="form-group">
																		<label for="ldapinput_bind_dncn__<?= $recorver_datas_fireclient['token'] ?>"><?php echo Translator('DN_bind'); ?> : <b class="text-danger" title="<?php echo Translator('Field_required'); ?>" data-toggle="tooltip" data-placement="right"><i class="far fa-asterisk"></i></b></label>
																		<input type="text" name="ldapinput_bind_dndcextension__<?= $recorver_datas_fireclient['token'] ?>" autocomplete="off" class="form-control" id="ldapinput_bind_dndcextension__<?= $recorver_datas_fireclient['token'] ?>" value="<?= $recorver_datas_fireclient['binddn'] ?>" placeholder="ex : CN=test,CN=Users,DC=mycompany,DC=com">
																	</div>

																	<div class="row">
																		<div class="col-md-6">
																			<div class="form-group">
																				<label for="ldapinput_bind_password__<?= $recorver_datas_fireclient['token'] ?>"><?php echo Translator('Password'); ?> : </label>
																				<input type="password" name="ldapinput_bind_password__<?= $recorver_datas_fireclient['token'] ?>" autocomplete="off" class="form-control" id="ldapinput_bind_password__<?= $recorver_datas_fireclient['token'] ?>">
																			</div>
																		</div>

																		<div class="col-md-6">
																			<div class="form-group">
																				<label for="ldapinput_bind_cpassword__<?= $recorver_datas_fireclient['token'] ?>"><?php echo Translator('Confirm_password'); ?> : </label>
																				<input type="password" name="ldapinput_bind_cpassword__<?= $recorver_datas_fireclient['token'] ?>" autocomplete="off" class="form-control" id="ldapinput_bind_cpassword__<?= $recorver_datas_fireclient['token'] ?>">
																			</div>
																		</div>
																	</div>
																</fieldset>
															</div>
													</form>
												</div>
											</div>
										</div>
									</div>
								</div>
		</div>
	<?php } ?>

	<td><?= $recorver_datas_fireclient['binddn'] ?> </td>

	<td>
		<?php
						$datenow = date('d/m/Y');
						if ($recorver_datas_fireclient['created_at'] == $datenow) {
							echo Translator('today');
						} else {
							echo  date_format(date_create($recorver_datas_fireclient['created_at']), "d/m/Y");
						}
		?>
	</td>

	<td>
		<button type="button" title="<?php echo Translator('view_LDAP_information'); ?>" name="view_infos_client__<?= $rand_client_modal ?>" data-toggle="modal" data-target="#view_infos_client__<?= $rand_client_modal ?>" class="exerotpbtn btn-defaultexer btn-sm ripple-effect ripple-black"><i class="far fa-eye dwnl_small_addelement_icon delete_action_button_item"></i></button>
		<?php if (checkLevel() != OPERATOR) { ?>
			<button type="button" title="<?php echo Translator('Edit_LDAP_info'); ?>" name="edit_infos_client__<?= $rand_client_modal ?>" data-toggle="modal" data-target="#edit_infos_client__<?= $rand_client_modal ?>" class="exerotpbtn btn-defaultexer btn-sm ripple-effect ripple-black"><i class="far fa-pen dwnl_small_addelement_icon delete_action_button_item"></i></button>
			<button type="button" title="<?php echo Translator('delete_ldap_authentication'); ?>" class="exerotpbtn btn-sm btn-red ripple-effect ripple-white" data-toggle="modal" data-target="#confirm_delete_ldap__<?= $rand_client_modal ?>"><i class="far fa-trash-alt dwnl_small_addelement_icon delete_action_button_item"></i></button>
		<?php } ?>
	</td>
	</tr>
	<script>
		document.getElementById("btnPrint__<?= $recorver_datas_fireclient['token'] ?>").onclick = function() {
			printElement(document.getElementById("printThis__<?= $recorver_datas_fireclient['token'] ?>"));
		}

		function printElement(elem) {
			var domClone = elem.cloneNode(true);
			var $printSection = document.getElementById("printSection");

			if (!$printSection) {
				var $printSection = document.createElement("div");

				$printSection.id = "printSection";
				document.body.appendChild($printSection);
			}

			$printSection.innerHTML = "";
			$printSection.appendChild(domClone);
			window.print();
		}
	</script>
<?php } ?>
</tbody>
</table>
</div>
</div>
</div>
</div>
<?php }
			} ?>
</div>
</form>
</main>
<?php include 'inc/footer.php'; ?>