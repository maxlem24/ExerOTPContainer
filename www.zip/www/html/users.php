<?php 
/**
*   @category EXER OTP Appliance
*   @author EXER SAS <support@exer.fr>
*   @copyright 2023 EXER
*   @api Users Administration Page
*
*	@editedBY Laurent Asselin
*   @lastEdited 26/07/2023
*/

	include_once $_SERVER['DOCUMENT_ROOT'] . '/inc/translator.php';
	$module_page_name = Translator('Administrators');
	
	$show_navbar = true;
	$show_creds_usr = true;

	include_once 'inc/header.php'; 
	
	if (checkLevel() != OPERATOR) {
		if (isset($_GET['page'])) {
			$page = htmlspecialchars($_GET['page']);
			
			if (empty($page)) {
				header('Location: /users.php');
				exit();
			}
		} else {
			$page = NULL;
		}
		
		if (isset($_GET['TokenID'])) {
			$TokenID = htmlspecialchars($_GET['TokenID']);
			
			if (empty($TokenID)) {
				header('Location: /users.php');
				exit();
			}
		} else {
			$TokenID = NULL;
		}
	} else {
		header('Location: /');
		exit();
	}
?>

	<main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
		<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
			<h1 class="h2">
				<?= $module_page_name ?>  
				<?php if ($page == "AddUser") { ?>
				<exer class="text-secondary"><i class="far fa-chevron-right chevronexer_openform"></i></exer> <i><?php echo Translator('Create_admin'); ?></i><?php } ?>
			</h1>

			<?php if ($page != "AddUser") { ?>
				<?php if ($_SESSION['level'] != 1) { ?>
					<div class="btn-group">
						<a href="?page=AddUser"><button class="exerotpbtn btn-defaultexer btn-sm ripple-effect ripple-white"><i class="far fa-user-plus dwnl_small_addelement_icon"></i> <?php echo Translator('Create_admin'); ?></button></a>
					</div>
			<?php } } else { ?>
			<form method="POST">
				<div class="btn-group">
					<button type="submit" name="submitform_addusr_access" id="submitform_addusr_access" class="exerotpbtn btn-green btn-sm ripple-effect ripple-white"><i class="far fa-save dwnl_small_addelement_icon"></i> <?php echo Translator('Confirm'); ?></button>
					<a href="/users.php"><button type="button" class="exerotpbtn btn-red btn-sm ripple-effect ripple-white" style="margin-left:10px;"><i class="far fa-times dwnl_small_addelement_icon"></i> <?php echo Translator('Cancel'); ?></button></a>
				</div>
			<?php } ?>
		</div>
		<?php 
		if ($page == "AddUser") {
			//traitement du formulaire
			if (isset($_POST['submitform_addusr_access'])) {
				// Déclaration variables filtrees
				$lastname_inp_adduser 			= 	htmlspecialchars($_POST['lastname_inp_adduser']);
				$firstname_inp_adduser 			= 	htmlspecialchars($_POST['firstname_inp_adduser']);
				$username_inp_adduser 			= 	htmlspecialchars($_POST['username_inp_adduser']);
				$email_inp_adduser 				= 	htmlspecialchars($_POST['email_inp_adduser']);
				$password_inp_adduser 			= 	$_POST['password_inp_adduser'];
				$confirm_password_inp_adduser 	= 	$_POST['confirm_password_inp_adduser'];
				$level_inp_adduser 				= 	htmlspecialchars($_POST['level_inp_adduser']);
				$enable_inp_adduser 			= 	NULL;

				if (isset($_POST['enable_inp_adduser'])) {
					$enable_inp_adduser 		= 	htmlspecialchars($_POST['enable_inp_adduser']);
				} else {
					$enable_inp_adduser 		= 	"nop";
				}
				
				if (checkLevel() != SUPERVISOR) {
					$corp_inp_adduser 	= htmlspecialchars($_SESSION['corp']);
				} elseif ($level_inp_adduser == 3) {
					$corp_inp_adduser	= "NOT_DEFINED";
					$level_inp_adduser	= 3;
				} elseif ($level_inp_adduser == 1) {
					if ($_POST['corp_inp_adduser'] != "choseCorp") {
						$corp_inp_adduser	= htmlspecialchars($_POST['corp_inp_adduser']);
					} else {
						$corp_inp_adduser	= "NOT_DEFINED";
					}

					$level_inp_adduser	= 1;
				} elseif ($level_inp_adduser == 2) {
					if ($_POST['corp_inp_adduserAdmin'] != "choseCorp") {
						$corp_inp_adduser	= htmlspecialchars($_POST['corp_inp_adduserAdmin']);
					} else {
						$Session->setFlash(Translator('cannot_define_role'), "close", "error");
						
						header('Location: '.$_SERVER['HTTP_REFERER']);
						exit();
					}

					$level_inp_adduser	= 2;
				} else {
					$Session->setFlash(Translator('role_not_found'), "close", "error");
					
					header('Location: '.$_SERVER['HTTP_REFERER']);
					exit();
				}
				
				if (isset($_POST['lastname_inp_adduser'], $_POST['firstname_inp_adduser'], $_POST['username_inp_adduser'], $_POST['email_inp_adduser'], $_POST['password_inp_adduser'], $_POST['confirm_password_inp_adduser'])) {
					if (!empty($_POST['lastname_inp_adduser']) AND !empty($_POST['firstname_inp_adduser']) AND !empty($_POST['username_inp_adduser']) AND !empty($_POST['email_inp_adduser']) AND !empty($_POST['password_inp_adduser']) AND !empty($_POST['confirm_password_inp_adduser'])) {
						if (filter_var($email_inp_adduser, FILTER_VALIDATE_EMAIL)) {
							$MailChecker = $db->prepare("SELECT * FROM otp_users WHERE email = ?");
							$MailChecker->execute(array($email_inp_adduser));
							$MailExist = $MailChecker->rowCount();

							if ($MailExist == 0) {
								if (empty($_POST['corp_inp_adduser']) AND checkLevel() == SUPERVISOR) {
									$error_addusr = Translator('specify_a_company');
								} else {
									if ($level_inp_adduser == 3 AND checkLevel() == ADMIN) {
										$error_addusr = Translator('access_denied');
									} else {
										if (strlen($email_inp_adduser) < 255) {
											if (strlen($username_inp_adduser) < 255) {
												if (strlen($username_inp_adduser) > 4) {
													$requusername = $db->prepare("SELECT * FROM otp_users WHERE username = ?");
													$requusername->execute(array($username_inp_adduser));
													$usernameexist = $requusername->rowCount();
													if ($usernameexist == 0) {
														if (strlen($confirm_password_inp_adduser) >= 6) {
															if ($password_inp_adduser == $confirm_password_inp_adduser) {
																$encrypt_password 	= 	password_hash($confirm_password_inp_adduser, PASSWORD_BCRYPT);
																$token 				= 	generateToken(9999);
																$created_at 		= 	date('Y-m-d H:i:s');
																
																$insert_req = $db->prepare("INSERT INTO otp_users(corp, lastname, firstname, username, email, password, level, enable, token, created_at) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
																$insert_req->execute(array($corp_inp_adduser, $lastname_inp_adduser, $firstname_inp_adduser, $username_inp_adduser, $email_inp_adduser, $encrypt_password, $level_inp_adduser, $enable_inp_adduser, $token, $created_at));
																
																addLogEventOTP("[SUCCESS] The WebUI account " . $username_inp_adduser . " has been correctly added to the system database.");
																
																$Session->setFlash(Translator('user_created'), "check", "success");
																
																header('Location: /users.php');
																exit();
															} else {
																$error_addusr = Translator('password_no_match');
															}
														} else {
															$error_addusr = Translator('longer_password');
														}
													} else {
														$error_addusr = Translator('user_already_exists');
													}
												} else {
													$error_addusr = Translator('longer_username');
												}
											} else {
												$error_addusr = Translator('characters_user');
											}
										} else {
											$error_addusr = Translator('characters_email');
										}
									}
								}
							} else {
								$error_addusr = Translator('email-already-exists2');
							}
						} else {
							$error_addusr = Translator('invalid_email');
						}
					} else {
						$error_addusr = Translator('Fill_all_fields');
					}
				}
			}
				?>
				
				<?php if (isset($error_addusr)) { ?>
				<div class="alert alert-danger" role="alert">
					<i class="fas fa-exclamation-triangle"></i> <?= $error_addusr ?>
				</div>
				<?php } ?>
		
				<fieldset class="fieldset_exerotp">
					<legend class="legend_exerotp"><?php echo Translator('general_info'); ?></legend>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label for="lastname_inp_adduser"><?php echo Translator('Name'); ?>: <b class="text-danger" title="<?php echo Translator('Field_required'); ?>" data-toggle="tooltip" data-placement="right"><i class="far fa-asterisk"></i></b></label>
								<input type="text" name="lastname_inp_adduser" autocomplete="off" class="form-control" id="lastname_inp_adduser" value="<?php if (isset($lastname_inp_adduser)) { echo $lastname_inp_adduser; } ?>" placeholder="ex : DOE">
							</div>
						</div>
						
						<div class="col-md-6">
							<div class="form-group">
								<label for="firstname_inp_adduser"><?php echo Translator('First_name'); ?>: <b class="text-danger" title="<?php echo Translator('Field_required'); ?>" data-toggle="tooltip" data-placement="right"><i class="far fa-asterisk"></i></b></label>
								<input type="text" name="firstname_inp_adduser" autocomplete="off" class="form-control" id="firstname_inp_adduser" value="<?php if (isset($firstname_inp_adduser)) { echo $firstname_inp_adduser; } ?>" placeholder="ex : John">
							</div>
						</div>
					</div>
				
					<div class="form-group">
						<label for="username_inp_adduser"><?php echo Translator('User_name'); ?> : <b class="text-danger" title="<?php echo Translator('Field_required'); ?>" data-toggle="tooltip" data-placement="right"><i class="far fa-asterisk"></i></b></label>
						<input type="text" name="username_inp_adduser" autocomplete="off" class="form-control" id="username_inp_adduser" value="<?php if (isset($username_inp_adduser)) { echo $username_inp_adduser; } ?>" placeholder="ex : john.doe">
					</div>
					
					<div class="form-group">
						<label for="email_inp_adduser"><?php echo Translator('Email'); ?>  <b class="text-danger" title="<?php echo Translator('Field_required'); ?>" data-toggle="tooltip" data-placement="right"><i class="far fa-asterisk"></i></b></label>
						<input type="text" name="email_inp_adduser" autocomplete="off" class="form-control" id="email_inp_adduser" value="<?php if (isset($email_inp_adduser)) { echo $email_inp_adduser; } ?>" placeholder="ex : john.doe@example.com">
					</div>
					
					<div class="form-group">
						<label for="password_inp_adduser"><?php echo Translator('Password'); ?> : <b class="text-danger" title="<?php echo Translator('Field_required'); ?>" data-toggle="tooltip" data-placement="right"><i class="far fa-asterisk"></i></b></label>
						<input type="password" name="password_inp_adduser" autocomplete="off" class="form-control" id="password_inp_adduser">
					</div>
					
					<div class="form-group">
						<label for="confirm_password_inp_adduser"><?php echo Translator('Confirm_password'); ?> <b class="text-danger" title="<?php echo Translator('Field_required'); ?>" data-toggle="tooltip" data-placement="right"><i class="far fa-asterisk"></i></b></label>
						<input type="password" name="confirm_password_inp_adduser" autocomplete="off" class="form-control" id="confirm_password_inp_adduser">
					</div>
				</fieldset>
				<br>
				<fieldset class="fieldset_exerotp">
					<legend class="legend_exerotp"><?php echo Translator('Access'); ?> <b class="text-danger" title="<?php echo Translator('Field_required'); ?>" data-toggle="tooltip" data-placement="right"><i class="far fa-asterisk"></i></b></legend>
						<script>
							$(document).ready(function(){
								$('#level_inp_adduser').on('change', function() {
									if (this.value == '1') {
										$("#affCorpAddUsr").show();
										$("#affCorpAddAdm").hide();
									} else if (this.value == '2') {
										$("#affCorpAddUsr").hide();
										$("#affCorpAddAdm").show();
									} else {
										$("#affCorpAddUsr").hide();
										$("#affCorpAddAdm").hide();
									}
								});
							});
						</script>

						<div class="form-group">
							<label for="level_inp_adduser"><?php echo Translator('AccessLevel'); ?>:</label>
							<select class="form-control" name="level_inp_adduser" id="level_inp_adduser">
								<option value="2"><?php echo Translator('Admin'); ?></option>
								<option value="1"><?php echo Translator('Help-Desk_op'); ?></option>
							  
								<?php if (checkLevel() == SUPERVISOR) { ?>
								<option value="3"><?php echo Translator('Supervisor'); ?></option>
								<?php } ?>
							</select>
						</div>
						
						<?php if (checkLevel() == SUPERVISOR) { ?>
						<div class="form-group" id="affCorpAddAdm">
							<label for="corp_inp_adduserAdmin"><?php echo Translator('Corporate_assign'); ?></label>
							
							<select class="form-control" name="corp_inp_adduserAdmin" id="corp_inp_adduserAdmin">
								<optgroup label=<?php echo Translator('Company'); ?>>
								<?php 
									$corps_recorver = $db->query('SELECT * FROM otp_companies ORDER BY name ASC');
									while ($corp_recup = $corps_recorver->fetch()) {
								?>
								<option value="<?= $corp_recup['corpid'] ?>"><?= $corp_recup['name'] ?> </option>
								<?php } ?>
								</optgroup>
							</select>
						</div>
						
						<div class="form-group" id="affCorpAddUsr" style="display:none;">
							<label for="corp_inp_adduser"><?php echo Translator('Corporate_assign'); ?></label>
							
							<select class="form-control" name="corp_inp_adduser" id="corp_inp_adduser">
								<optgroup label="<?= Translator('System'); ?>">
									<option value="choseCorp">Global</option>
								</optgroup>
								<optgroup label="<?= Translator('plurial'); ?>">
								<?php 
									$corps_recorver = $db->query('SELECT * FROM otp_companies ORDER BY name ASC');
									while ($corp_recup = $corps_recorver->fetch()) {
								?>
								<option value="<?= $corp_recup['corpid'] ?>"><?= $corp_recup['name'] ?> </option>
								<?php } ?>
								</optgroup>
							</select>
						</div>
						<?php } ?>
						
						<div class="form-group">
							<label for="this_enable_inp_adduser" class="pure-material-checkbox" style="margin-bottom: -5px;">
								<input type="checkbox" name="enable_inp_adduser" value="1" id="this_enable_inp_adduser"<?php if (isset($enable_inp_adduser) AND $enable_inp_adduser != "nop") { ?> checked<?php } ?>>
								<span><?php echo Translator('Activ_the_acc'); ?></span>
							</label>
						</div>
				</fieldset>
				<br><br>
			</form>
		<?php } elseif($page == "ManageUser") { 
			if ($TokenID == $_SESSION['token']) {
				header('Location: /users.php');
				exit();
			}

			if (checkLevel() == SUPERVISOR) {
				//recup_user_filtered_by_tokenid
				$GetUsers = $db->prepare('SELECT * FROM otp_users WHERE token = ?');
				$GetUsers->execute(array($TokenID));
				$CountUser = $GetUsers->rowCount();
			} else {
				//recup_user_filtered_by_tokenid
				$GetUsers = $db->prepare('SELECT * FROM otp_users WHERE token = ? AND corp = ?');
				$GetUsers->execute(array($TokenID, $_SESSION['corp']));
				$CountUser = $GetUsers->rowCount();
			}
			$usr = $GetUsers->fetch();
			
			//recup_donnees entreprise
			$recup_corp = $db->prepare('SELECT * FROM otp_companies WHERE corpid = ?');
			$recup_corp->execute(array($usr['corp']));
			
			$crp_data = $recup_corp->fetch();
			
			if ($CountUser == 0) { ?>
			<div class="alert alert-danger" role="alert">
				<i class="fas fa-exclamation-triangle"></i> <?php echo Translator('User_cannot_found'); ?>
			</div>
			<?php } else { ?>
			<ul class="nav nav-pills nav-fill">
				<li class="nav-item active">
					<a href="" data-target="#profile" data-toggle="tab" class="nav-link active"><?php echo Translator('view'); ?></a>
				</li>
				<li class="nav-item">
					<a href="" data-target="#connections" data-toggle="tab" class="nav-link"><?php echo Translator('Connections'); ?></a>
				</li>
				<li class="nav-item">
					<a href="" data-target="#edit" data-toggle="tab" class="nav-link"><?php echo Translator('editing'); ?></a>
				</li>
			</ul>

			<div class="tab-content">
				<div class="tab-pane active" id="profile">
					<style>
					html {
						overflow-x:hidden;
					}
					</style>


					<div class="row" style="margin-top: 5rem;width: 117%;">
						<div class="card-exer col-md-5">
							<div style="margin-left: auto; margin-right: auto; width: 5em;">
								<img src="/assets/images/exer_user_default.png" class="rounded-circle default_avatar_exer" alt="default user exer" style="position: relative; top: -5rem; max-height: 7rem; border: 1px solid #D5E3EC;">
							</div>
							
							<div class="text-center" style="margin-top: -4rem;">
								<h1 class="text-truncate"><?= $usr['firstname'] ?> <?= $usr['lastname'] ?></h1>
							</div>
							<p>
								<label>
									<i class="fal fa-envelope"></i>
									<?php echo Translator('Email'); ?> : <a title="<?php echo Translator('send_a_email_to'); ?>"<?= $usr['email'] ?>" href="mailto://<?= $usr['email'] ?>"><?= $usr['email'] ?></a>
								</label><br>
								<label>
									<i class="fal fa-user"></i>
									<?php echo Translator('user'); ?> : <?= $usr['username'] ?>
								</label><br>
								<label>
									<i class="fal fa-crown"></i>
									<?php echo Translator('AccessLevel'); ?> : <?php if ($usr['level'] ==1 ) { echo "Opérateur Help-Desk"; } elseif ($usr['level'] ==2 ) { echo Translator('Admin'); } elseif ($usr['level'] ==3 ) { echo  Translator('Supervisor'); } ?>
								</label>
							</p>
							<hr>
							<p>
								<label>
									<i class="fal fa-clock"></i>
									<?php echo Translator('last_connection'); ?> : <?php if ($usr['last_connected'] != "0000-00-00 00:00:00") { echo date_format(date_create($usr['last_connected']),"d/m/Y H:i"); } else { echo Translator('date_last_conenction'); } ?>
								</label>
								<label>
									<i class="fal fa-chart-network"></i>
									<?php echo Translator('IPAddressConnection'); ?> : <?php if (!empty($usr['lastip'])) { echo $usr['lastip']; } else { echo Translator('no_ip_connected'); } ?>
								</label>
							</p>
						</div>
						<div class="card-exer col-md-5">
							<div class="text-center">
								<?php
									if ($crp_data['logosrc'] == "not_defined" || $usr['corp'] == "NOT_DEFINED") {
										$LogoCompany = "/assets/images/exer_logo_black.png";
									} else {
										$LogoCompany = $crp_data['logosrc'];
									}
								?>
								<img src="<?= $LogoCompany ?>" style="min-height: 3.5rem;max-height: 3.5rem;margin-bottom:1rem;" alt="Logo <?= $crp_data['name'] ?>">

								<?php 
									if($usr['corp'] != "NOT_DEFINED") {
										echo "<h1 class=\"text-truncate\">".$crp_data['name']."</h1>";
									} else {
										echo "<hr><p>".Translator('GlobalSysMgntAccount') . "<br>" . Translator('user_licence') . $licence_home."</p>";
									}
								?>
							</div>

							<?php if($usr['corp'] != "NOT_DEFINED") { ?>
							<p>
								<label>
									<i class="fal fa-envelope"></i>
									<?php echo Translator('EmailContact'); ?> : <a title="<?php echo Translator('send_a_email_to'); ?>" <?= $crp_data['contact_email'] ?>" href="mailto://<?= $crp_data['contact_email'] ?>"><?= $crp_data['contact_email'] ?></a>
								</label><br>
							</p>
							<hr>

							<?php 
								// Licence informations
								$OTPusersCounter = $db->prepare('SELECT * FROM otp_tokens WHERE corpid = ?');
								$OTPusersCounter->execute(array($crp_data['corpid']));
								$countOTPUsers = $OTPusersCounter->rowCount();
							?>
							<p>
								<label>
									<i class="fal fa-file-certificate"></i>
									<?php echo Translator('Licensee'); ?> : <?= $crp_data['name'] ?>
								</label><br>
								<label>
									<i class="fal fa-users"></i>
									<?php echo Translator('AccessUsage'); ?> : <?= $countOTPUsers ?>/<?= $crp_data['users_max'] ?>
								</label><br>
								<label>
									<i class="fal fa-clock"></i>
								<?php 
							// Licence informations
									$Datefin = $crp_data['expire_date'];
									if (empty($Datefin)) {
										$BeforeExpireDate = $DumpExpireDateold;
										$Date_Expire_Date = str_replace('/', '-', $BeforeExpireDate);
										$Datefin = date('Y-m-d', strtotime($Date_Expire_Date));
									}
									$dateformateur = DateTime::createFromFormat('Y-m-d', $Datefin);
		                            if ($dateformateur == true) {
		                            	$Datefinale = $dateformateur->format('d/m/Y');
		                            }
		                            else {
		                            	$Datefinale = $Datefin;
		                            }

									?>
									<?php echo Translator('Licence_exp_date'); ?>:<?= $Datefinale ?>
								</label>
							</p>
							<?php } ?>
						</div>
					</div>
				</div>
				<div class="tab-pane" id="connections">
					<br>
					<?php 
						//Recuperation des connexions effectuées sur le système pour cet utilisateur
						$recup_connections_usr = $db->prepare('SELECT * FROM otp_connections WHERE userid = ? ORDER BY id DESC');
						$recup_connections_usr->execute(array($usr['id']));
						$count_connections = $recup_connections_usr->rowCount();
					?>
					<?php if ($count_connections == 0) { ?>
					<div class="alert alert-danger" role="alert">
						<i class="far fa-exclamation-circle"></i> <?php echo Translator('No_connec_syst'); ?>
					</div>
					<?php } else { ?>
					<div class="alert alert-info" role="alert">
						<i class="far fa-exclamation-circle"></i> <strong><?= $count_connections ?></strong> <?php if ($count_connections > 1) { echo Translator('Connections'); } else { echo Translator('Connection'); } ?>
					</div>

					<input type="text" id="searchboxTable" placeholder="<?php echo Translator('Search_for_a_connection'); ?>" title="<?php echo Translator('fill_this_field_with_keyword'); ?>">

					<script>
						$(document).ready(function() {
							$("#searchboxTable").on("keyup", function() {
								var value = $(this).val().toLowerCase();
								$("#byValDataT tr").filter(function() {
									$(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
								});
							});

							$("#searchboxTable").on("keyup", function() {
								var name = $(this).val();
								if (name.length >= 1) {
								var box = paginator({
									table: document.getElementById("container_table").getElementsByTagName("table")[0],
									box_mode: "list",
									rows_per_page: "0",
									get_rows: function () {
										return document.getElementById("table_otpexer").getElementsByTagName("tbody");
									},
								});
								$('.pgnt_tab').hide();
								return false;
								} else {
								var box = paginator({
									table: document.getElementById("container_table").getElementsByTagName("table")[0],
									box_mode: "list",
									rows_per_page: "10",
								});
								$('.pgnt_tab').show();
								return false;
								}
							});

							var box = paginator({
								table: document.getElementById("container_table").getElementsByTagName("table")[0],
								box_mode: "list",
								rows_per_page: "10",
							});
							document.getElementById("container_table").appendChild(box);
						});
					</script>
					
					<div class="table-responsive" id="container_table">
						<div class="table-responsive">
							<table id="table_otpexer" class="sortable-theme-bootstrap table-striped" data-sortable style="max-height: 170px;">
								<thead class="thead-light">
									<tr>
										<th class="vt-default-th" data-sorted-direction="descending"><?php echo Translator('IP_addr'); ?></th>
										<th><?php echo Translator('Login_date'); ?></th>
									</tr>
								</thead>
								<tbody id="byValDataT">
									<?php while ($recorver_connections = $recup_connections_usr->fetch()) { ?>
										<tr>
											<td><?= $recorver_connections['ipaddress'] ?></td>
											<td><?php if ($recorver_connections['connected_at'] != "0000-00-00 00:00:00") { echo date_format(date_create($recorver_connections['connected_at']),"d/m/Y H:i"); } else { echo Translator('no_connection_date'); } ?></td>
										</tr>
									<?php } ?>
								</tbody>
							</table>
						</div>
					</div>
					<br><br>
					<?php } ?>
				</div>
				
				<?php
				
				if (isset($_POST['save_formeditusr'])) {

					$requser = $db->prepare("SELECT * FROM otp_users WHERE token = ?");
					$requser->execute(array($TokenID));
					$user = $requser->fetch();
					
					if (isset($_POST['lastname_inp_adduser']) AND !empty($_POST['lastname_inp_adduser']) AND $_POST['lastname_inp_adduser'] != $user['lastname']) {
						$lastname_inp_adduser = htmlspecialchars($_POST['lastname_inp_adduser']);
						
						if ($lastnameexist == 0) {
							$insertname = $db->prepare("UPDATE otp_users SET lastname = ? WHERE token = ?");
							$insertname->execute(array($lastname_inp_adduser, $TokenID));
							
							addLogEventOTP("[SUCCESS] The WebUI account " . $_SESSION['username'] . " has modified details of " . $user['username'] . " (lastname)");
						}
					}
					
					if (isset($_POST['firstname_inp_adduser']) AND !empty($_POST['firstname_inp_adduser']) AND $_POST['firstname_inp_adduser'] != $user['firstname']) {
						$firstname_inp_adduser = htmlspecialchars($_POST['firstname_inp_adduser']);
						
						$insertlstname = $db->prepare("UPDATE otp_users SET firstname = ? WHERE token = ?");
						$insertlstname->execute(array($firstname_inp_adduser, $TokenID));
							
						addLogEventOTP("[SUCCESS] The WebUI account " . $_SESSION['username'] . " has modified details of " . $user['username'] . " (firstname)");
					}
					
					if (isset($_POST['username_inp_adduser']) AND !empty($_POST['username_inp_adduser']) AND $_POST['username_inp_adduser'] != $user['username']) {
						$username_inp_adduser = htmlspecialchars($_POST['username_inp_adduser']);
						$req_usrname = $db->prepare("SELECT * FROM otp_users WHERE username = ?");
						$req_usrname->execute(array($username_inp_adduser));
						$usrnameexist = $req_usrname->rowCount();
						if (strlen($username_inp_adduser) > 4) {	
							if ($usrnameexist == 0) {
								$insertusrname = $db->prepare("UPDATE otp_users SET username = ? WHERE token = ?");
								$insertusrname->execute(array($username_inp_adduser, $TokenID));
								
								addLogEventOTP("[SUCCESS] The WebUI account " . $_SESSION['username'] . " has modified details of " . $user['username'] . " (username)");
							} else {
								$Session->setFlash(Translator('user_already_exists'), "close", "error");
								
								header('Location: /users.php');
								exit();
							}
						} else {
							    $Session->setFlash(Translator('longer_username'), "close", "error");
								header('Location: /users.php');
								exit();
						}	
					}
					
					if (isset($_POST['email_inp_adduser']) AND !empty($_POST['email_inp_adduser']) AND $_POST['email_inp_adduser'] != $user['email']) {
						if (filter_var($_POST['email_inp_adduser'], FILTER_VALIDATE_EMAIL)) {
							$MailChecker = $db->prepare("SELECT * FROM otp_users WHERE email = ?");
							$MailChecker->execute(array($_POST['email_inp_adduser']));
							$MailExist = $MailChecker->rowCount();
							
							if ($MailExist == 0) {
							$insertemail = $db->prepare("UPDATE otp_users SET email = ? WHERE token = ?");
							$insertemail->execute(array($_POST['email_inp_adduser'], $TokenID));
							
							addLogEventOTP("[SUCCESS] The WebUI account " . $_SESSION['username'] . " has modified details of " . $user['username'] . " (email)");
							$Session->setFlash(Translator('Save_change2'), "check", "success");
							
							header('Location: /users.php');
							exit();
							} else {
								$Session->setFlash(Translator('email-already-exists'), "close", "error");
								header('Location: /users.php');
							    exit();
							}
						} else {
							    $Session->setFlash(Translator('invalid_email'), "close", "error");
								header('Location: /users.php');
							    exit();
						}
					}
					
					if (isset($_POST['confirm_password_inp_adduser']) AND !empty($_POST['confirm_password_inp_adduser']) AND (checkLevel() > 1)) {
						$confirm_password_inp_adduser = $_POST['confirm_password_inp_adduser'];
						if (strlen($confirm_password_inp_adduser) >= 6) {
							if ($_POST['password_inp_adduser'] == $_POST['confirm_password_inp_adduser']) {
								$encrypt_password = password_hash($confirm_password_inp_adduser, PASSWORD_BCRYPT);
								$update_password = $db->prepare("UPDATE otp_users SET password = ? WHERE token = ?");
								$update_password->execute(array($encrypt_password, $TokenID));
							   addLogEventOTP("[SUCCESS] The WebUI account " . $_SESSION['username'] . " has modified details of " . $user['username'] . " (password)");
							} else {
								$Session->setFlash(Translator('password_no_match'), "close", "error");
								header('Location: /users.php');
							    exit();
							}
						} else {
							$Session->setFlash(Translator('longer_password'), "close", "error");
							header('Location: /users.php');
							exit();
						}
					}	
					
					if (isset($_POST['level_inp_adduser']) AND !empty($_POST['level_inp_adduser']) AND ($_POST['level_inp_adduser'] != $user['level'])) {
						$level_inp_adduser 	= 	htmlspecialchars($_POST['level_inp_adduser']);			
						if ($level_inp_adduser == 1) {
							$UpdateLevel = $db->prepare("UPDATE otp_users SET level = ? WHERE token = ?");
							$UpdateLevel->execute(array($level_inp_adduser, $TokenID));
							addLogEventOTP("[SUCCESS] The WebUI account " . $_SESSION['username'] . " has modified details of " . $user['username'] . " (level = " . $level_inp_adduser . ")");
						}
						
						if (($level_inp_adduser == 2) and (checkLevel() > 1)) {
							$UpdateLevel = $db->prepare("UPDATE otp_users SET level = ? WHERE token = ?");
							$UpdateLevel->execute(array($level_inp_adduser, $TokenID));
							addLogEventOTP("[SUCCESS] The WebUI account " . $_SESSION['username'] . " has modified details of " . $user['username'] . " (level = " . $level_inp_adduser . ")");
						}
							
						if (($level_inp_adduser == 3) and (checkLevel() == SUPERVISOR)) {
							$UpdateLevel = $db->prepare("UPDATE otp_users SET level = ? WHERE token = ?");
							$UpdateLevel->execute(array($level_inp_adduser, $TokenID));
							$corp_inp_adduser	= "NOT_DEFINED";
							$UpdateCorp = $db->prepare("UPDATE otp_users SET corp = ? WHERE token = ?");
							$UpdateCorp->execute(array($corp_inp_adduser, $TokenID));
							addLogEventOTP("[SUCCESS] The WebUI account " . $_SESSION['username'] . " has modified details of " . $user['username'] . " (level = " . $level_inp_adduser . ")");
						}
					}
			
					if (isset($_POST['corp_inp_adduser']) AND !empty($_POST['corp_inp_adduser']) AND ($_POST['corp_inp_adduser'] != $user['corp']) AND (checkLevel() == SUPERVISOR)) {
						$corp_inp_adduser 	= 	htmlspecialchars($_POST['corp_inp_adduser']);
						$level_inp_adduser 	= 	htmlspecialchars($_POST['level_inp_adduser']);
						if ($level_inp_adduser == 3) {
							$corp_inp_adduser	= "NOT_DEFINED";
						}
						if (($level_inp_adduser == 2) AND ($_POST['corp_inp_adduser'] == "choseCorp")) {
								$Session->setFlash(Translator('choose_role'), "close", "error");
								header('Location: /users.php');
								exit();
						}
						if (($level_inp_adduser == 1) AND ($_POST['corp_inp_adduser'] == "choseCorp")) {
								$corp_inp_adduser	= "NOT_DEFINED";
						}
						$UpdateCorp = $db->prepare("UPDATE otp_users SET corp = ? WHERE token = ?");
						$UpdateCorp->execute(array($corp_inp_adduser, $TokenID));
						addLogEventOTP("[SUCCESS] Supervisor " . $_SESSION['username'] . " has modified details of " . $user['username'] . " (corpid=" . $corp_inp_adduser . ")");
					}

					$enable_inp_adduser	= 	htmlspecialchars($_POST['enable_inp_adduser']);
					if ($enable_inp_adduser != 1) {
							$enable_inp_adduser = 0 ;
					}
						
					if (($enable_inp_adduser != $user['enable']) AND (checkLevel() > 1)){
						$UpdateEnable = $db->prepare("UPDATE otp_users SET enable = ? WHERE token = ?");
						$UpdateEnable->execute(array($enable_inp_adduser, $TokenID));
						addLogEventOTP("[SUCCESS] The WebUI account " . $_SESSION['username'] . " has modified details of " . $user['username'] . " (enable=" . $enable_inp_adduser . ")");
					}

					$Session->setFlash(Translator('Save_change2'), "check", "success");
					header('Location: /users.php');
					exit();
				}						
				?>
				
				
				<div class="tab-pane" id="edit">
					<form method="POST">
						<br>
						<div class="contain_controlbtns__editusr" id="section_editusr__btncontrols__4e0eea5570c37ba1620c91284799da" style="display: block; position: absolute; top: 192px; right: 5rem;">
							<button id="save_editusr" type="submit" name="save_formeditusr" class="exerotpbtn btn-fab-mini btn-save ripple-effect ripple-dark" title="Enregistrer">
								<i class="fas fa-save" style="margin-bottom: 3px;"></i>
							</button>
						</div>
						
						<fieldset class="fieldset_exerotp">
							<legend class="legend_exerotp"><?php echo Translator('general_info'); ?></legend>
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label for="lastname_inp_adduser"><?php echo Translator('name'); ?>:</label>
											<input type="text" name="lastname_inp_adduser" autocomplete="off" class="form-control" id="lastname_inp_adduser" value="<?= $usr['lastname'] ?>" placeholder="<?= $usr['lastname'] ?>">
										</div>
									</div>
									
									<div class="col-md-6">
										<div class="form-group">
											<label for="firstname_inp_adduser"><?php echo Translator('First_name'); ?>:</label>
											<input type="text" name="firstname_inp_adduser" autocomplete="off" class="form-control" id="firstname_inp_adduser" value="<?= $usr['firstname'] ?>" placeholder="<?= $usr['firstname'] ?>">
										</div>
									</div>
								</div>
							
								<div class="form-group">
									<label for="username_inp_adduser"><?php echo Translator('User_name'); ?> :</label>
									<input type="text" name="username_inp_adduser" autocomplete="off" class="form-control" id="username_inp_adduser" value="<?= $usr['username'] ?>" placeholder="<?= $usr['username'] ?>">
								</div>
								
								<div class="form-group">
									<label for="email_inp_adduser"><?php echo Translator('Email'); ?> :</label>
									<input type="text" name="email_inp_adduser" autocomplete="off" class="form-control" id="email_inp_adduser" value="<?= $usr['email'] ?>" placeholder="<?= $usr['email'] ?>">
								</div>
								
								<div class="form-group">
									<label for="password_inp_adduser"><?php echo Translator('Password'); ?> : </label>
									<input type="password" name="password_inp_adduser" autocomplete="off" class="form-control" id="password_inp_adduser" placeholder="••••••">
								</div>
								
								<div class="form-group">
									<label for="confirm_password_inp_adduser"><?php echo Translator('Confirm_password'); ?> :</label>
									<input type="password" name="confirm_password_inp_adduser" autocomplete="off" class="form-control" id="confirm_password_inp_adduser" placeholder="••••••">
								</div>
						</fieldset>
						<br>
						<fieldset class="fieldset_exerotp">
							<legend class="legend_exerotp"><?php echo Translator('Access'); ?> </legend>
								<script>
									$(document).ready(function(){
										$('#level_inp_adduser').on('change', function() {
											if ( this.value == '3') {
												$("#affCorpAddUsr").hide();
											} else {
												$("#affCorpAddUsr").show();
											}
										});
									});
								</script>

								<div class="form-group">
									<label for="level_inp_adduser"><?php echo Translator('AccessLevel'); ?> :</label>
									<select class="form-control" name="level_inp_adduser" id="level_inp_adduser">
										<optgroup label=<?php echo Translator('currently'); ?>>
											<option value="<?= $usr['level'] ?>"><?php if ($usr['level'] ==1 ) { echo "Opérateur Help-Desk"; } elseif ($usr['level'] ==2 ) { echo Translator('Administrators'); } elseif ($usr['level'] ==3 ) { echo Translator('supervisor'); } ?></option>
										</optgroup>
										
										<optgroup label=<?php echo Translator('other'); ?>>
											<option value="2"><?php echo Translator('Admin'); ?></option>
											<option value="1"><?php echo Translator('Help-Desk_op'); ?></option>
											
											<?php if ($_SESSION['level'] == 3) { ?>
												<option value="3"><?php echo Translator('Supervisor'); ?></option>
											<?php } ?>
										</optgroup>
									</select>
								</div>
								
								<?php if (checkLevel() == SUPERVISOR) { ?>
								<div class="form-group" id="affCorpAddUsr">
									<label for="corp_inp_adduser"><?php echo Translator('Corporate_assign'); ?> :</label>
									
									<select class="form-control" name="corp_inp_adduser" id="corp_inp_adduser">
										<optgroup label="<?= Translator('System'); ?>">
											<option value="choseCorp">Global</option>
										</optgroup>
										<optgroup label="<?= Translator('plurial'); ?>">
										<?php 
											$corps_recorver = $db->query('SELECT * FROM otp_companies ORDER BY name ASC');
											while ($corp_recup = $corps_recorver->fetch()) {
										?>
										<option value="<?= $corp_recup['corpid'] ?>" <?php if ($corp_recup['corpid'] == $usr['corp']) { echo " selected"; } ?>><?= $corp_recup['name'] ?></option>
										<?php } ?>
										</optgroup>
									</select>
								</div>
								<?php } ?>
								
								<div class="form-group">
									<label for="this_enable_inp_adduser" class="pure-material-checkbox" style="margin-bottom: -5px;">
										<input type="checkbox" name="enable_inp_adduser" value="1" <?php if ($usr['enable'] == "1") { echo "checked"; } ?> id="this_enable_inp_adduser">
										<span><?php echo Translator('Activ_the_acc'); ?></span>
									</label>
								</div>
						</fieldset>
						<br><br>
					</form>
				</div>
			</div>
		<?php } ?>
		<?php } else { ?>
		<?php 
			if ($_SESSION['corp'] == "NOT_DEFINED") {
				$recup_all_users = $db->prepare('SELECT * FROM otp_users WHERE NOT username = ? ORDER BY id DESC');
				$recup_all_users->execute(array($_SESSION['username']));
			} else {
				$recup_all_users = $db->prepare('SELECT * FROM otp_users WHERE corp = ? AND NOT username = ? ORDER BY id DESC');
				$recup_all_users->execute(array($_SESSION['corp'], $_SESSION['username']));
			}
					
			$total_countusrs = $recup_all_users->rowCount(); //count des utilisateurs
			
			if ($total_countusrs == 0) { ?>
				<div class="alert alert-danger" role="alert">
					<i class="fas fa-exclamation-triangle"></i> <?php echo Translator('No_user_has_been_found'); ?>
				</div>
			<?php } else { ?>
				<div class="alert alert-info" role="alert">
				<i class="far fa-info-circle"></i>
					<?php echo Translator('Display'); ?> <strong><?= $total_countusrs ?></strong> <?php if ($total_countusrs > 1) { echo Translator('Users');} else { echo Translator('user');}   ?>
				</div>

				<input type="text" id="searchboxTable" placeholder= "<?php echo Translator('find_admin2'); ?>" title=<?php echo Translator('find_correct_admin'); ?>>

				<script>
					$(document).ready(function(){$("#searchboxTable").on("keyup",function(){var e=$(this).val().toLowerCase();$("#byValDataT tr").filter(function(){$(this).toggle($(this).text().toLowerCase().indexOf(e)>-1)})}),$("#searchboxTable").on("keyup",function(){if($(this).val().length>=1){paginator({table:document.getElementById("container_table").getElementsByTagName("table")[0],box_mode:"list",rows_per_page:"0",get_rows:function(){return document.getElementById("table_otpexer").getElementsByTagName("tbody")}});return $(".pgnt_tab").hide(),!1}paginator({table:document.getElementById("container_table").getElementsByTagName("table")[0],box_mode:"list",rows_per_page:"10"});return $(".pgnt_tab").show(),!1});var e=paginator({table:document.getElementById("container_table").getElementsByTagName("table")[0],box_mode:"list",rows_per_page:"10"});document.getElementById("container_table").appendChild(e)});
				</script>
				
				<div class="table-responsive" id="container_table">
					<table id="table_otpexer" class="sortable-theme-bootstrap table-striped" data-sortable>
						<thead>
							<tr>
								<?php if ($_SESSION['corp'] == "NOT_DEFINED") { ?>
									<th class="vt-default-th" data-sorted-direction="descending"><?php echo Translator('Company'); ?></th>
								<?php } ?>
								<th <?php if ($_SESSION['corp'] != "NOT_DEFINED") { echo 'class="vt-default-th" data-sorted-direction="descending"'; } ?>><?php echo Translator('user'); ?></th>
								<th><?php echo Translator('E-mail'); ?></th>
								<th><?php echo Translator('access_level'); ?></th>
								<th><?php echo Translator('Status'); ?></th>
								<th><?php echo Translator('last_connection'); ?></th>
								<th data-sortable="false"></th>
							</tr>
						</thead>
						<tbody id="byValDataT">
						<?php
							while ($rc_usr = $recup_all_users->fetch()) {
								if ($rc_usr['username'] != $_SESSION['username']) { ?>
								<tr>
									<?php if (checkLevel() == SUPERVISOR) { ?>
									<?php 
										$recup_companies_pr = $db->prepare('SELECT * FROM otp_companies WHERE corpid = ? ORDER BY name ASC');
										$recup_companies_pr->execute(array($rc_usr['corp']));
										
										$query_corp = $recup_companies_pr->fetch();

										if ($recup_companies_pr->rowCount() == 0) {
											$thisNameIsCorp = Translator('compagny_not_found');
										} else {
											$thisNameIsCorp = $query_corp['name'];
										}
									?>
									
									<td onclick="window.location.href='?page=ManageUser&TokenID=<?= $rc_usr['token'] ?>'">
									<?php if ($rc_usr['corp'] == "NOT_DEFINED") { echo "<strong>Global</strong>"; } else { echo $thisNameIsCorp; } ?>
									</td>
									<?php } ?>
									
									<td onclick="window.location.href='?page=ManageUser&TokenID=<?= $rc_usr['token'] ?>'"><?= $rc_usr['username'] ?></td>
									<td onclick="window.location.href='?page=ManageUser&TokenID=<?= $rc_usr['token'] ?>'"><?php if ($rc_usr['email'] != "N/A") { echo $rc_usr['email']; } else { echo "N/A"; } ?></td>
									<td onclick="window.location.href='?page=ManageUser&TokenID=<?= $rc_usr['token'] ?>'"><?php if ($rc_usr['level'] == 1) { echo "Opérateur Help-Desk"; } elseif ($rc_usr['level'] ==2 ) { echo Translator('Admin'); } elseif ($rc_usr['level'] == 3) { echo Translator('Supervisor'); } ?></td>
									<td onclick="window.location.href='?page=ManageUser&TokenID=<?= $rc_usr['token'] ?>'"><?php if ($rc_usr['enable'] == 1) { echo '<span class="badge badge-pill badge-success">'.Translator('Activate').'</span>'; } else { echo '<span class="badge badge-pill badge-danger">'.Translator('disabled').'</span>'; } ?></td>
									<td data-value="<?= strtotime($rc_usr['last_connected']) ?>" onclick="window.location.href='?page=ManageUser&TokenID=<?= $rc_usr['token'] ?>'"><?php if ($rc_usr['last_connected'] == "0000-00-00 00:00:00") { echo "N/A"; } else { ?><?php echo date_format(date_create($rc_usr['last_connected']),"d/m/Y H:i"); ?><?php } ?></td>
									<td>
										<?php $rand_client_modal = generateToken(9999); ?>
										<button type="button" class="exerotpbtn btn-sm btn-red ripple-effect ripple-white" data-toggle="modal" data-target="#confirm_delete_usradmin__<?= $rand_client_modal ?>"><i class="far fa-trash-alt dwnl_small_addelement_icon delete_action_button_item"></i></button>
									</td>
								</tr>

								<form method="POST">
									<div class="modal fade" id="confirm_delete_usradmin__<?= $rand_client_modal ?>" tabindex="-1" role="dialog" aria-labelledby="lblconfirm_delete_usradmin" aria-hidden="true">
										<div class="modal-dialog modal-lg" role="document">
											<div class="modal-content">
												<div class="modal-header">
													<h5 class="modal-title" id="lblconfirm_delete_usradmin"><i class="far fa-user-admin"></i><?php echo Translator('Delete_admin'); ?></h5>
													<button type="button" class="close" data-dismiss="modal" aria-label="Close">
														<span aria-hidden="true"><i class="far fa-times"></i></span>
													</button>
												</div>
												
												<div class="modal-body">
													<label><?php echo Translator('Confirm_remov_admin'); ?> <b><?= $rc_usr['lastname'] . " " .  $rc_usr['firstname'] . " (" . $rc_usr['username'] . ")"?></b> ?</label>
												</div>
												
												<div class="modal-footer">
													<?php
														if (isset($_POST['del_this_usradmin__' . $rc_usr['token']])) {
															$DeleteUserFormAdmin = $db->prepare('DELETE FROM otp_users WHERE token = ?');
															$DeleteUserFormAdmin->execute(array($rc_usr['token']));

															addLogEventOTP("[SUCCESS] The WebUI account " . $rc_usr['username'] . " has been successfully deleted by " . $_SESSION['username']);
															$Session->setFlash(Translator('The_admin'). " " . $rc_usr['username'] . " " . Translator('successful-delete'), "check", "success");

															header('Location: /users.php');
															exit();
														}
													?>
												
													<button type="button" class="exerotpbtn btn-cancel ripple-effect ripple-white" data-dismiss="modal"><?php echo Translator('Cancel'); ?></button>
													<button type="submit" name="del_this_usradmin__<?= $rc_usr['token'] ?>" class="exerotpbtn btn-green ripple-effect ripple-white"><?php echo Translator('Confirm'); ?></button>
												</div>
											</div>
										</div>
									</div>
								</form>
								<?php }
							} ?>
						</tbody>
					</table>
				</div>
				<br><br>
			<?php } ?>
		<?php } ?>
	</main>

<?php include 'inc/footer.php'; ?>