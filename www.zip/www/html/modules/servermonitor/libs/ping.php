<?php
// Dernière modification le : 20/04/2022
// Par: Laurent ASSELIN

include $_SERVER['DOCUMENT_ROOT'] . '/inc/class.exerotp.php';

if (isset($_SESSION['id'])) { 
	if (($_SESSION['level'] == 3) OR (($_SESSION['level'] == 1) AND ($_SESSION['corp'] == "NOT_DEFINED"))) {
		require '../autoload.php';
		$Config = new Config();


		$datas = array();

		if (count($Config->get('ping:hosts')) > 0)
			$hosts = $Config->get('ping:hosts');
		else
			$hosts = array('google.com', 'wikipedia.org');

		foreach ($hosts as $host)
		{
			exec('/bin/ping -qc 1 '.$host.' | awk -F/ \'/^rtt/ { print $5 }\'', $result);

			if (!isset($result[0]))
			{
				$result[0] = 0;
			}
			
			$datas[] = array(
				'host' => $host,
				'ping' => $result[0],
			);

			unset($result);
		}

		echo json_encode($datas);
		} else {
        header('Location: /');
        exit();
		}
	} else {
    header('Location: /'); 
    exit();
}
?>