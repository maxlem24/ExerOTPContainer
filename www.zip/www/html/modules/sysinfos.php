<?php
	// Dernières modifications le : 20/04/2022
	// Par: Laurent ASSELIN
	
	include $_SERVER['DOCUMENT_ROOT'] . '/inc/class.exerotp.php';
	include_once $_SERVER['DOCUMENT_ROOT'] . '/inc/translator.php';
	
	if (isset($_GET['ElementGet'])) {
		$ElementGet = htmlspecialchars($_GET['ElementGet']);
	} else {
		$ElementGet = NULL;
	}
?>

<?php if ($ElementGet == "CpuRamUsage") { ?>
<p>
	<b class="description"><?= Translator('Ram_memory_usage');?> </b><span class="result"> <?= number_format((float)get_server_memory_usage(), 2, '.', ''); ?>%</span><br>
</p>	
<?php } elseif ($ElementGet == "SystemLoad") { ?>
<p>
	<span class="description"><b><?= Translator('system_load');?> </b></span> <span class="result"><?= shapeSpace_system_load() ?></span><br>
</p>
<?php } elseif ($ElementGet == "SystemCores") { ?>
<p>
	<span class="description"><b><?= Translator('number_of_core');?></b></span> <span class="result"><?= shapeSpace_system_cores() ?></span><br>
</p>
<?php } elseif ($ElementGet == "HttpConnections") { ?>
<p>
	<span class="description"><b><?= Translator('number_of_http_connections');?></b></span> <span class="result"><?= shapeSpace_http_connections() ?></span><br>
</p>
<?php } elseif ($ElementGet == "MemoryUsage") { ?>
<p>
	<span class="description"><b><?= Translator('memory_usage');?></b></span> <span class="result"><?= number_format((float)shapeSpace_server_memory_usage(), 2, '.', ''); ?>%</span><br>
</p>
<?php } elseif ($ElementGet == "DiskUsage") { ?>
<p>
	<span class="description"><b><?= Translator('Disk_usage');?></b></span> <span class="result"><?= shapeSpace_disk_usage() ?></span><br>
</p>
<?php } elseif ($ElementGet == "ServerUptime") { ?>
<p>
	<span class="description"><b><?= Translator('operating_time');?></b></span> <span class="result"><?= shapeSpace_server_uptime() ?></span><br>
</p>
<?php } elseif ($ElementGet == "KernelVersion") { ?>
<p>
	<span class="description"><b><?= Translator('kernel_version');?></b></span> <span class="result"><?= shapeSpace_kernel_version() ?></span><br>
</p>
<?php } elseif ($ElementGet == "NumberProcesses") { ?>
<p>
	<span class="description"><b><?= Translator('Number_of_processes');?></b></span> <span class="result"><?= shapeSpace_number_processes() ?></span><br>
</p>
<?php } elseif ($ElementGet == "MemoryRamUsage") { ?>
<p>
	<span class="description"><b><?= Translator('Ram_memory_usage');?></b></span> <span class="result"><?= shapeSpace_memory_usage() ?></span><br>
</p>
<?php } elseif ($ElementGet == "TimeNow") { 
	$dtt = date('m/d/Y h:i:s a', time());
	$CurrentTime = ucfirst(strftime('%H:%M:%S',strtotime($dtt)));

	echo $CurrentTime;
} else {
	die(Translator('Cant_retrieve_data'));
}				