<?php
	// Dernière modification le : 07/04/2022
	// Par: Laurent ASSELIN

include_once $_SERVER['DOCUMENT_ROOT'] . '/inc/translator.php';
	
if (isset($_POST['reloggin_exerotp'])) {
	header('Location: /');
	exit();
}
?>

<?php 
	$module_page_name = Translator('Logout');
	$show_navbar = false;
	$show_creds_usr = false;

	include 'inc/header.php';
	$Session->setFlash(Translator('Your_session_logged'), "check", "success");
	
	addLogEventOTP("[INFORMATION] Account " . $_SESSION['username'] . " has been successfully logged out");
	
	//Suppresion des donnees de la session
	$_SESSION = array();
	session_destroy();
?>

	<main role="main" class="col-md-10 ml-sm-auto col-lg-10">
		<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
			<h1 class="h2"><i class="far fa-sign-out"></i> <?= $module_page_name ?></h1>
		</div>
		<div class="alert alert-info" role="alert">
			<i class="far fa-info-circle"></i>
			<?= Translator('Your_session_logged') ;?><br>
		</div>
		
		<form action="index.php">
			<div>
				<button type="submit" name="reloggin_exerotp" class="exerotpbtn btn-defaultexer ripple-effect ripple-white"><?= Translator('Log_in...'); ?></button>
			</div>
		</form>
	</main>
	
<?php include 'inc/footer.php'; ?>