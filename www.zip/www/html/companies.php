<?php

/**
 *   @category EXER OTP Appliance
 *   @author EXER SAS <support@exer.fr>
 *   @copyright 2023 EXER
 *   @api Companies Page
 *
 *	@editedBY Laurent Asselin
 *  @lastEdited 30/11/2023
 */

$sname = session_name();
if ($sname != 'EXEROTP_SESSID') {
	session_name('EXEROTP_SESSID');
}
session_start();

include_once $_SERVER['DOCUMENT_ROOT'] . '/inc/translator.php';

if ($_SESSION['corp'] != "NOT_DEFINED") {
	$module_page_name = Translator('my_compagny') . " > " . $_SESSION['corp_name'];
} else {
	$module_page_name = Translator('Companies');
}

if (isset($_GET['TokenID'])) {
	$TokenID = htmlspecialchars($_GET['TokenID']);

	if (empty($_GET['TokenID'])) {
		header('Location: /companies.php');
		exit();
	}
} else {
	$TokenID = NULL;
}

if (isset($_GET['page'])) {
	$page = htmlspecialchars($_GET['page']);
} else {
	$page = NULL;
}

$show_navbar 	= true;
$show_creds_usr = true;

include_once 'inc/header.php';


// API export CSV
if (checkLevel() != OPERATOR) {
	include_once $_SERVER['DOCUMENT_ROOT'] . '/inc/api/export_csv.php';
}
?>

<main role="main" class="col-md-10 ml-sm-auto col-lg-10">
	<?php
	if ($page == "ManageCorp") {
		if (empty($_GET['TokenID'])) {
			header('Location: /companies.php');
			exit();
		} elseif (checkLevel() == ADMIN || (checkLevel() == OPERATOR && $_SESSION['corp'] != "NOT_DEFINED")) {
			header('Location: /companies.php');
			exit();
		} else {
			//recup datas_this_corp selected
			$recup_selected_corp = $db->prepare('SELECT * FROM otp_companies WHERE token = ?');
			$recup_selected_corp->execute(array($TokenID));
			$count_selected_corp = $recup_selected_corp->rowCount();
			$query_corp_slt = $recup_selected_corp->fetch();

			if ($count_selected_corp == 0) {
				$error = Translator('company_not_found');
			} else { ?>
				<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
					<h1 class="h3"><?= $module_page_name ?> <exer class="text-secondary"><i class="far fa-chevron-right chevronexer_openform"></i></exer> <?= $query_corp_slt['name']; ?></h1>

					<div class="btn-group">
						<?php if (checkLevel() != OPERATOR) { ?>
							<?php if ($_SESSION['corp'] == "NOT_DEFINED") { ?>
								<div class="optionsmenu_b ">
									<div class="dropdown">
										<button class="exerotpbtn btn-defaultexer btn-sm ripple-effect ripple-white dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
											<label><?php echo Translator('Business_management') ?></label>
										</button>
										<div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButton">
											<div class="input-icon">
												<a class="dropdown-item" href="#" data-toggle="modal" data-target="#corpName">
													<?= Translator('Modify_company_name'); ?></a>
												<form class="form-horizontal" method="post" enctype="multipart/form-data">
											</div>
											<div class="input-icon">
												<a class="dropdown-item" href="#" data-toggle="modal" data-target="#changeLogoCorp">
													<?= Translator('Modify_company_logo'); ?></a>
												<form class="form-horizontal" method="post" enctype="multipart/form-data">
											</div>
											<div class="input-icon">
												<a class="dropdown-item" href="#" data-toggle="modal" data-target="#corpMail">
													<?= Translator('Edit_email_address'); ?>
												</a>
											</div>

											<div class="input-icon">
												<a class="dropdown-item" href="#" data-toggle="modal" data-target="#usrchangedate"><?= Translator('license_expiration_change'); ?></a>
												<form class="form-horizontal" method="post" enctype="multipart/form-data">
											</div>
											<div class="input-icon">
												<a class="dropdown-item" href="#" data-toggle="modal" data-target="#usrtogglemodal"><?= Translator('Licensee'); ?></a>
												<form class="form-horizontal" method="post" enctype="multipart/form-data">
											</div>

											</form>
										</div>
									</div>
								</div>

								<!-- modifier le nom de l'entreprise -->
								<div class="modal fade" id="corpName" tabindex="-1" role="dialog" aria-labelledby="changeLogoCorp" aria-hidden="true">
									<div class="modal-dialog modal-lg" role="document">
										<div class="modal-content">
											<div class="modal-header">
												<h5 class="modal-title" id="lblconfirm_view_ldapedit">
													<i class="far fa-pen"></i> <?= Translator('Modify_company_name'); ?> <strong><span id="corpName">
															<?= $query_corp_slt['name']; ?></span></strong> :
												</h5>
											</div>
											<form method="POST">
												<div class="modal-body">
													<label for="newName"><?= Translator('new_name_company'); ?>:</label>
													<input type="text" class="form-control" id="newName" name="newName">
												</div>
												<div class="modal-footer">
													<button type="button" class="exerotpbtn btn-white ripple-effect ripple-dark" data-dismiss="modal">
														<?= Translator('Cancel'); ?></button>
													<button type="submit" class="exerotpbtn btn-green ripple-effect ripple-white" name="sendNewNameCorp">
														<?= Translator('Send'); ?></button>
												</div>
											</form>
										</div>
									</div>
								</div>

								<?php
								if (isset($_POST['sendNewNameCorp'])) {
									$newName = $_POST['newName'];
									if (!empty($newName)) {
										// Vérifier si le nouveau nom existe déjà dans la base de données
										$checkName = $db->prepare("SELECT corpid FROM otp_companies WHERE name = ?");
										$checkName->execute(array($newName));
										$result = $checkName->fetch();
										if (!$result) {
											// Vérifier si le folder existe déjà dans la base de données
											$checkName = $db->prepare("SELECT corpid FROM otp_companies WHERE folder = ?");
											$checkName->execute(array($newName));
											$result = $checkName->fetch();
											
											if ((!$result) OR (strtolower($newName) == $query_corp_slt['folder'] )) {
												// Le nouveau nom n'existe pas encore dans la base de données, on peut faire la mise à jour
												// Ou si le nom est égal au Folder en cours
												$UpdateName = $db->prepare("UPDATE otp_companies SET name = ? WHERE corpid = ?");
												$UpdateName->execute(array($newName, $query_corp_slt['corpid']));
												addLogEventOTP("[SUCCESS] The company " . $query_corp_slt['name'] . " has been renamed " . $newName);
												$Session->setFlash(Translator('company_name_updated'), "check", "success");
												$actual_link = "https://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
												header('Location: ' . $actual_link);
												exit();
											} else {
												// Le nouveau nom existe déjà dans la base de données (dossier), afficher un message d'erreur
												$Session->setFlash(Translator('company_name_exists'), "close", "error");
												echo "<script>$(\"#corpName\").modal('show');</script>";
												$actual_link = "https://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
												header('Location: ' . $actual_link);
												exit();
											}
										} else {
											// Le nouveau nom existe déjà dans la base de données, afficher un message d'erreur
											$Session->setFlash(Translator('company_name_exists'), "close", "error");
											echo "<script>$(\"#corpName\").modal('show');</script>";
											$actual_link = "https://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
											header('Location: ' . $actual_link);
											exit();
										}
									} else {
										$Session->setFlash(Translator('empty_field'), "close", "error");
										echo "<script>$(\"#corpName\").modal('show');</script>";
										$actual_link = "https://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
										header('Location: ' . $actual_link);
										exit();
									}
								}


								?>
								<!-- Modale changer les domaines des email -->
								<form class="form-horizontal" method="post" enctype="multipart/form-data">
									<div class="modal fade" id="corpMail" tabindex="-1" role="dialog" aria-labelledby="changeDomainCorp" aria-hidden="true">
										<div class="modal-dialog modal-lg" role="document">
											<div class="modal-content">
												<div class="modal-header">
													<h5 class="modal-title" id="lblconfirm_view_ldapedit">
														<i class="far fa-pen"></i> <?= Translator('Modify_domain_mail') ?>
													</h5>
												</div>
												<div class="modal-body">
													<label for="newDomain"><?= Translator('new_domain_mail') ?></label>
													<div class="input-group">
														<input type="text" class="form-control" name="new_domain" id="newDomainInput" required>
														<div class="input-group-append">
															<button type="submit" class="btn btn-primary" name="saveNewMailDomain"><?= Translator('Save') ?></button>
														</div>
													</div>
													<small id="domainError" class="form-text text-danger d-none"><?= Translator('Invalid_domain_error') ?></small>
												</div>
												<div class="modal-footer d-flex justify-content-between">
													<button type="button" class="btn btn-secondary" data-dismiss="modal"><?= Translator('Cancel') ?></button>
												</div>
											</div>
										</div>
									</div>
								</form>

								<script>
									// Vérification du domaine en temps réel
									const domainInput = document.getElementById('newDomainInput');
									var saveButton = document.querySelector('button[name="saveNewMailDomain"]');
									var domainError = document.getElementById('domainError');

									if (domainInput) {
										domainInput.addEventListener('input', function() {
											var domain = this.value;

											if (!/^[A-Za-z0-9.-]*$/.test(domain)) {
												domainError.classList.remove('d-none');
												saveButton.disabled = true;
											} else {
												domainError.classList.add('d-none');
												saveButton.disabled = false;
											}
										});
									}	
								</script>
								<?php
								$query_otp = $db->prepare("SELECT id, email FROM otp_tokens WHERE corpid = ?");
								$query_otp->execute(array($query_corp_slt['corpid']));
								$emails = $query_otp->fetchAll(PDO::FETCH_ASSOC);
								if (isset($_POST['saveNewMailDomain'])) {
									$new_domain = $_POST['new_domain'];

									// Vérifier que le domaine est valide
									if (!filter_var($new_domain, FILTER_VALIDATE_DOMAIN)) {
										$error_msg = "Domaine invalide.";
									} else {

										// Mettre à jour les domaines des adresses e-mail dans la base de données
										foreach ($emails as $email) {
											$id = $email['id'];
											$existing_email = $email['email'];
											$updated_email = '';
											// Vérifier si l'utilisateur a une adresse e-mail existante
											if (!empty($existing_email) && $existing_email !== 'N/A') {
												list($username, $existing_domain) = explode('@', $existing_email);
												$updated_email = $username . '@' . $new_domain;
											} elseif ($existing_email === 'N/A') {
												// Laisser la valeur "N/A" pour les utilisateurs sans adresse e-mail
												$updated_email = 'N/A';
											}
											$query_update = $db->prepare("UPDATE otp_tokens SET email = :updated_email WHERE id = :id");
											$query_update->execute(array(':updated_email' => $updated_email, ':id' => $id));
										}
										addLogEventOTP("[SUCCESS] The company " . $query_corp_slt['name'] . " emails domain has been changed to : \"" . $new_domain . "\" by admin user : " . $_SESSION['username']);
										// Rediriger vers la page courante pour actualiser la liste des adresses e-mail
										header('Location: ' . $_SERVER['REQUEST_URI']);
										exit();
									}
								}
								?>

							<?php } else { ?>
								<a href="?page=AddThisCorpUser&choiceCorp=<?= $query_corp_slt['token'] ?>"><button class="exerotpbtn btn-defaultexer btn-sm ripple-effect ripple-white" title="<?= Translator('Add_user_for_client_company') ?>"><i class="far fa-layer-plus dwnl_small_addelement_icon"></i> <?= Translator('Create_user'); ?></button></a>
							<?php } ?>

							<div class="modal fade" id="changeLogoCorp" tabindex="-1" role="dialog" aria-labelledby="changeLogoCorp" aria-hidden="true">
								<div class="modal-dialog modal-lg" role="document">
									<div class="modal-content">
										<div class="modal-header">
											<h5 class="modal-title" id="lblconfirm_view_ldapedit">
												<i class="far fa-pen"></i> <?= Translator('Modify_company_logo'); ?> <strong><?= $query_corp_slt['name']; ?></strong> :
											</h5>
										</div>

										<?php
										if (isset($_POST['sendNewImgCorp'])) {
											if (($_FILES['import_newlogo_corp']) && $_FILES['import_newlogo_corp']['error'] === 0) {
												$NomDuFichier 	= $_FILES["import_newlogo_corp"]["name"];
												$taille_max		= 104850; //==100Ko
												$taille_fichier = filesize($_FILES['import_newlogo_corp']['tmp_name']);
												$type_logo 		= $_FILES["import_newlogo_corp"]["type"];
												if ($taille_fichier > $taille_max) {
													$Session->setFlash(Translator('size_file') . "" . Translator('current_size_file') . $taille_fichier . Translator('Bytes'), "close", "error");
													echo "<script>$(\"#changeLogoCorp\").modal('show');</script>";
													$actual_link = "https://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";

													header('Location: ' . $actual_link);
													exit();
												} else {
													$allowed = array("image/jpeg", "image/gif", "image/png", "image/jpg", "image/bmp");
													if (in_array($type_logo, $allowed)) {
														if (is_uploaded_file($_FILES["import_newlogo_corp"]["tmp_name"])) {
															$img_file = $_FILES["import_newlogo_corp"]["tmp_name"];
															$imgData = base64_encode(file_get_contents($img_file));
															$logo_corp = 'data: ' . mime_content_type($img_file) . ';base64,' . $imgData;

															$NewLogo = $db->prepare("UPDATE otp_companies SET logosrc = ? WHERE corpid = ?");
															$NewLogo->execute(array($logo_corp, $query_corp_slt['corpid']));

															$Session->setFlash(Translator('logo_imported'), "check", "success");
															$actual_link = "https://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";

															header('Location: ' . $actual_link);
															exit();
														} else {
															$Session->setFlash(Translator('An_error_occu') . "<br>" . Translator('the_file') . $NomDuFichier . Translator('not_uploaded'), "close", "error");
															echo "<script>$(\"#changeLogoCorp\").modal('show');</script>";
															$actual_link = "https://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";

															header('Location: ' . $actual_link);
															exit();
														}
													} else {
														$Session->setFlash(Translator('An_error_occu') . Translator('image_format'), "close", "error");
														echo "<script>$(\"#changeLogoCorp\").modal('show');</script>";
														$actual_link = "https://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";;

														header('Location: ' . $actual_link);
														exit();
													}
												}
											} else {
												$Session->setFlash(Translator('need_a_image'), "close", "error");
												echo "<script>$(\"#changeLogoCorp\").modal('show');</script>";
												$actual_link = "https://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";

												header('Location: ' . $actual_link);
												exit();
											}
										}
										?>

										<form method="POST" enctype="multipart/form-data">
											<div class="modal-body">
												<div class="formaddcorp">
													<label for="modify_users_max"><?= Translator('Send_new_logo'); ?> </label>

													<fieldset class="fieldset_exerotp">
														<div class="col-auto">
															<label class="sr-only" for="inlineFormInputGroup">Logo <b class="text-danger" title="<?= Translator('Field_required'); ?>" data-toggle="tooltip" data-placement="right"><i class="far fa-asterisk"></i></b></label>
															<div class="input-group mb-2">
																<div class="input-group-prepend">
																	<div class="input-group-text"><i class="far fa-upload"></i></div>
																</div>

																<input type="file" autocomplete="off" class="form-control" style="height: 44px;" name="import_newlogo_corp" accept="image/*" onchange="loadFile(event)">
															</div>
														</div>

														<div id="container_preview">
															<label><?= Translator('Overview'); ?></label><br>
															<div class="view_logs_servotp car_exerlogs">
																<img oncontextmenu="return false; return false" ondrag="return false; return false" onmousedown="return false; return false" id="output" class="preview_picture" alt=<?= Translator('image_not_upload'); ?>>
															</div>
															<br>
														</div>
													</fieldset>
													<hr>
													<b><?= Translator('Current_logo'); ?></b>
													<?php if ($query_corp_slt['logosrc'] != "not_defined") { ?>
														<p><img src="<?= $query_corp_slt['logosrc']; ?>" alt="<?= $query_corp_slt['name']; ?>" style="margin-top: 0.5rem;max-height: 4rem;"></p>
													<?php } else { ?>
														<div class="text-danger"><?= Translator('No_logo'); ?></div>
													<?php } ?>
												</div>
											</div>

											<div class="modal-footer">
												<button type="button" class="exerotpbtn btn-white ripple-effect ripple-dark" data-dismiss="modal"><?= Translator('Cancel'); ?></button>
												<button type="submit" name="sendNewImgCorp" class="exerotpbtn btn-green ripple-effect ripple-white"><?= Translator('Send'); ?></button>
											</div>
										</form>
									</div>
								</div>
							</div>
						<?php } ?>
					</div>
				</div>
				<?php
				if (checkLevel() != OPERATOR) {
					if (isset($_POST['submit_expire_date'])) {
						if (isset($_POST['modify_expire_date'])) {
							$checksyntaxdate = true;
							$checkdate = $_POST['modify_expire_date'];
							$dateformateur2 = DateTime::createFromFormat('Y-m-d', $checkdate);
							if ($dateformateur2 == true) {
								$checksyntaxdate = true;
							} else {
								$dateformateur3 = DateTime::createFromFormat('d/m/Y', $checkdate);
								if ($dateformateur3 == true) {
									$checksyntaxdate = true;
								} else {
									$checksyntaxdate = false;
								}
							}
							if ($checksyntaxdate == true) {
								$mod_expire_date = htmlspecialchars($_POST['modify_expire_date']);
								$insertname = $db->prepare("UPDATE otp_companies SET expire_date = ? WHERE corpid = ?");
								$insertname->execute(array($mod_expire_date, $query_corp_slt['corpid']));
							} else {
								$error_addcorp = Translator('valid_date');
							}
						}
					}
				}
				?>
				<?php
				if (checkLevel() != OPERATOR) {
					if (isset($_POST['submit_users_max'])) {
						if (isset($_POST['modify_users_max'])) {
							$mod_users_max = htmlspecialchars($_POST['modify_users_max']);
							if (is_numeric($mod_users_max)) {
								//for get a int, if isn't already the case
								$mod_users_max = $mod_users_max + 0;
								if ($mod_users_max <= $_SESSION['users_maximum'] and $mod_users_max > 0) {
									$recup_count_user_contains_corp = $db->prepare('SELECT * FROM otp_tokens WHERE corpid = ?');
									$recup_count_user_contains_corp->execute(array($query_corp_slt['corpid']));
									$corp_usrs_count = $recup_count_user_contains_corp->rowCount();

									if ($mod_users_max >= $corp_usrs_count) {
										// Check if the inp_addcorp_users_max is correct compared to the data we already have 
										// in fisrt part count the total already in base
										$recup_users_max = $db->prepare("SELECT users_max FROM otp_companies WHERE corpid != ?");
										$recup_users_max->execute(array($query_corp_slt['corpid']));
										$total = 0;
										$tmp = $recup_users_max->rowCount();
										$cmp = 0;

										while ($cmp < $tmp) {
											$data = $recup_users_max->fetch();
											$total = $total + $data[0];
											$cmp++;
										}

										$_SESSION['total'] = $total;

										//Then check if the total and the max given by the user dont exceed the max total
										$_SESSION['remaining'] = $_SESSION['users_maximum'] - $total;
										$total = $total + $mod_users_max;
										if ($total <= $_SESSION['users_maximum']) {
											// Modification des données dans la base 'otp_companies'
											$insertname = $db->prepare("UPDATE otp_companies SET users_max = ? WHERE corpid = ?");
											$insertname->execute(array($mod_users_max, $query_corp_slt['corpid']));

											// Modification du fichier otp.license contenue dans /home/companie
											$escaped_command = escapeshellcmd("rm /home/" . $query_corp_slt['folder'] . "/otp.license");
											shell_exec($escaped_command);
											$escaped_command = escapeshellcmd("touch /home/" . $query_corp_slt['folder'] . "/otp.license");
											shell_exec($escaped_command);

											shell_exec("echo 'Number of licenses max : " . $mod_users_max . "' > /home/" . $query_corp_slt['folder'] . "/otp.license");

											// Ajout dans les logs EXER OTP si tout est ok lors de la creation ==> otp_exer
											addLogEventOTP("[SUCCESS] The maximum number of users for " . $query_corp_slt['name'] . " has been modified");

											$Session->setFlash(Translator('succes_maximum_users') . " " . $query_corp_slt['name'] . " " .  Translator('has_been_modified'), "check", "success");
											$actual_link = "https://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";;

											header('Location: ' . $actual_link);
											exit();
										} else {
											if ($_SESSION['remaining'] < 0)
												$sentence_remaining = Translator('no_user_available');
											else {
												if ($_SESSION['remaining'] > 1)
													$sentence_remaining = Translator('it_stays') . $_SESSION['remaining'] . Translator('still_available');
												else
													$sentence_remaining = Translator('it_stays')  . $_SESSION['remaining'] . Translator('still_available');
											}
											$error_addcorp = Translator('no_user_available_to_assign') . ' ' . $sentence_remaining;
										}
									} else {
										$Session->setFlash(Translator('maximum_number_of_users') . $corp_usrs_count . ".", "close", "error");
										echo '<script>$("#usrtogglemodal").modal(\'show\');</script>';
										$actual_link = "https://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";

										header('Location: ' . $actual_link);
										exit();
									}
								} else {
									$Session->setFlash(Translator('maximum_number_of_users_too_large'), "close", "error");
									echo '<script>$("#usrtogglemodal").modal(\'show\');</script>';
									$actual_link = "https://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";

									header('Location: ' . $actual_link);
									exit();
								}
							} else {
								$Session->setFlash(Translator('maximum_number_of_users_positive'), "close", "error");
								echo '<script>$("#usrtogglemodal").modal(\'show\');</script>';
								$actual_link = "https://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";

								header('Location: ' . $actual_link);
								exit();
							}
						}
					}
				}
				?>

				<?php if (isset($error_addcorp)) { ?>
					<div class="alert alert-danger" role="alert">
						<i class="fas fa-exclamation-triangle"></i> <?= $error_addcorp ?>
					</div>
				<?php } ?>

				<?php if (checkLevel() != OPERATOR) { ?>
					<!-- Modal maxusrspe -->
					<div class="modal fade" id="usrtogglemodal" tabindex="-1" role="dialog" aria-labelledby="usrtogglemodal" aria-hidden="true">
						<div class="modal-dialog modal-lg" role="document">
							<div class="modal-content">
								<div class="modal-header">
									<h5 class="modal-title" id="lblconfirm_view_ldapedit"><i class="far fa-pen"></i> <?= Translator('Change_number_licences'); ?> <?= $query_corp_slt['name']; ?> :
								</div>

								<form method="POST">
									<div class="modal-body">
										<div class="formaddcorp">
											<?php
											$RecupUserMax = $db->prepare('SELECT * FROM otp_companies WHERE corpid = ?');
											$RecupUserMax->execute(array($query_corp_slt['corpid']));
											$DumpMaxUser = $RecupUserMax->fetch();
											?>

											<label for="modify_users_max"><?= Translator('Number_licences_issued'); ?>:</label>
											<input type="text" autofocus name="modify_users_max" autocomplete="off" class="form-control" id="modify_users_max" placeholder="ex : <?= $DumpMaxUser['users_max'] ?>" value="<?= $DumpMaxUser['users_max'] ?>">
										</div>
									</div>

									<div class="modal-footer">
										<button type="button" class="exerotpbtn btn-white ripple-effect ripple-dark" data-dismiss="modal"><?= Translator('Cancel'); ?></button>
										<button type="submit" name="submit_users_max" id="submit_users_max" class="exerotpbtn btn-green ripple-effect ripple-white"><?= Translator('Save'); ?></button>
									</div>
								</form>
							</div>
						</div>
					</div>
					<div class="modal fade" id="usrchangedate" tabindex="-1" role="dialog" aria-labelledby="usrchangedate" aria-hidden="true">
						<div class="modal-dialog modal-lg" role="document">
							<div class="modal-content">
								<div class="modal-header">
									<h5 class="modal-title" id="lblconfirm_view_ldapedit"><i class="far fa-calendar-alt"></i> <?= Translator('LicenseExpiryDate'); ?><?= $query_corp_slt['name']; ?> :
								</div>

								<form method="POST">
									<div class="modal-body">
										<div class="formaddcorp">
											<?php
											$Recupdatefin = $db->prepare('SELECT * FROM otp_companies WHERE corpid = ?');
											$Recupdatefin->execute(array($query_corp_slt['corpid']));
											$Dumpdatefin = $Recupdatefin->fetch();
											$Datefin = $Dumpdatefin['expire_date'];
											$dateformateur = DateTime::createFromFormat('Y-m-d', $Datefin);
											if ($dateformateur == true) {
												$Datefinale = $dateformateur->format('d/m/Y');
											} else {
												$Datefinale = $Datefin;
											}
											?>

											<label for="modify_expire_date"><?= Translator('current_license_end_date'); ?> <?= $Datefinale ?> </label>
											<input type="date" autofocus name="modify_expire_date" autocomplete="off" class="form-control" id="modify_expire_date">
										</div>
									</div>

									<div class="modal-footer">
										<button type="button" class="exerotpbtn btn-white ripple-effect ripple-dark" data-dismiss="modal"><?= Translator('Cancel'); ?></button>
										<button type="submit" name="submit_expire_date" id="submit_expire_date" class="exerotpbtn btn-green ripple-effect ripple-white"><?= Translator('Save'); ?></button>
									</div>

								</form>
							</div>
						</div>
					</div>
				<?php } ?>



				<?php
				// Get number of users in the company
				$recup_tokens = $db->prepare('SELECT * FROM otp_tokens WHERE corpid = ? ORDER BY id DESC');
				$recup_tokens->execute(array($query_corp_slt['corpid']));
				$count_token = $recup_tokens->rowCount();
				
				// Check if LDAP exists for this company
				$recup_all_ldap2 = $db->prepare('SELECT * FROM otp_ldap WHERE corpid = ?');
				$recup_all_ldap2->execute(array($query_corp_slt['corpid']));
				$count_ldap2 = $recup_all_ldap2->rowCount();

				if ($count_token != 0) {
				?>
					<div class="alert alert-info" role="alert">
						<i class="far fa-info-circle"></i>
						<?php
						// Get users max for this companies
						$recorver_corpclients = $db->prepare('SELECT users_max FROM otp_companies WHERE corpid = ?');
						$recorver_corpclients->execute(array($query_corp_slt['corpid']));
						$ft_rec_clients = $recorver_corpclients->fetch();
						$get_users_max = $ft_rec_clients['users_max'];
						?>
						<?= Translator('Client_company') . "<b>" . $count_token . "</b>"; ?> <?php if ($count_token != 1) {
																									echo Translator('Users');
																								} else {
																									echo Translator('user');
																								} ?> <?= Translator('Maximum'); ?><?php echo "<b>" . $get_users_max . "</b>" ?> <?php if ($get_users_max != 1) {
																																													echo Translator('Users');
																																												} else {
																																													echo Translator('user');
																																												} ?>
					</div>


					<?php if (checkLevel() == OPERATOR) { ?>
						<input type="text" id="searchboxTable" placeholder="<?= Translator('search_a_user'); ?> " title="<?= Translator('invalid_user'); ?>">
					<?php } else { ?>
						<div class="row justify-content-end">
							<div class="col-md-6">
							<input type="text" id="searchboxTable" placeholder="<?= Translator('search_a_user'); ?>" title="<?= Translator('invalid_user'); ?>">
							</div>
							<div class="col-md-3">
								<a href="?page=AddThisCorpUser&choiceCorp=<?= $query_corp_slt['token'] ?>"><button class="exerotpbtn btn-teal btn-sm btneditnusr ripple-effect ripple-white" title="<?= Translator('Add_user_for_client_company') ?>"><i class="far fa-layer-plus dwnl_small_addelement_icon"></i> <?= Translator('Create_user'); ?></button></a>
							</div>
							<div class="col-md-3">
								<?php if ($count_ldap2 != 0) { ?>
											<a type="button" href="ldap.php?page=AddLdapFromDirectory&TokenID=<?= $query_corp_slt['token'] ?>" class="exerotpbtn btn-teal btn-sm btneditnusr ripple-effect ripple-white"><i class="far fa-book-reader dwnl_small_addelement_icon"></i><?= Translator('add_LDAP_User'); ?></a>
								<?php } else { ?>	
											<a type="button" href="ldap.php?page=AddLdap&TokenID=<?= $query_corp_slt['token'] ?>" class="exerotpbtn btn-teal btn-sm btneditnusr ripple-effect ripple-white"><i class="far fa-book-reader dwnl_small_addelement_icon"></i><?= Translator('add_LDAP_User'); ?></a>
								<?php } ?>
							</div>
						</div>
					<?php }
				} ?>

				<form method="POST">
					<div class="table-responsive">

						<?php
						$user_translatorphp = Translator('user_checked');
						$users_translatorphp = Translator('users_checked');
						if ($count_token != 0) { ?>

							<script>
								var user_translator = <?php echo json_encode($user_translatorphp); ?>;
								var users_translator = <?php echo json_encode($users_translatorphp); ?>;

								function chcSelect() {
									var e = $('input[name="speUsrSelect[]"]:checked').length;
									$(".optionsmenu_p").show(),
										e > 1 ? $("#countChecks").html(e + " " + users_translator) : 0 == e ? $(".optionsmenu_p").hide() : $("#countChecks").html(e + " " + user_translator)
								}

								function toggle(e) {
									var t = document.querySelectorAll('input[type="checkbox"]');
									$(".optionsmenu_p").show();
									for (var n = 0; n < t.length; n++)
										if (t[n] != e) {
											t[n].checked = e.checked;
											var o = $('input[name="speUsrSelect[]"]:checked').length;
											o > 1 ? $("#countChecks").html(o + " " + users_translator) : 0 == o ? $(".optionsmenu_p").hide() : $("#countChecks").html(o + " " + user_translator)
										}
								}



								$(document).ready(function() {
									$("#searchboxTable").on("keyup", function() {
											var e = $(this).val().toLowerCase();
											$("#byValDataT tr").filter(function() {
												$(this).toggle($(this).text().toLowerCase().indexOf(e) > -1)
											})
										}),
										$("#searchboxTable").on("keyup", function() {
											if ($(this).val().length >= 1) {
												paginator({
													table: document.getElementById("container_table").getElementsByTagName("table")[0],
													box_mode: "list",
													rows_per_page: "0",
													get_rows: function() {
														return document.getElementById("table_otpexer").getElementsByTagName("tbody")
													}
												});
												return $(".pgnt_tab").hide(),
													$(".allCheck").hide(), !1
											}
											paginator({
												table: document.getElementById("container_table").getElementsByTagName("table")[0],
												box_mode: "list",
												rows_per_page: "10"
											});
											return $(".pgnt_tab").show(),
												$(".allCheck").show(), !1
										});
									var e = paginator({
										table: document.getElementById("container_table").getElementsByTagName("table")[0],
										box_mode: "list",
										rows_per_page: "10"
									});
									document.getElementById("container_table").appendChild(e)
								});
							</script>


							<?php
							if (checkLevel() != OPERATOR) {
								if (isset($_POST['deleteSelectedUsrCorp'])) {
									if (!empty($_POST['speUsrSelect'])) {
										foreach ($_POST['speUsrSelect'] as $speUsrSelect) {
											$recup_flw = $db->prepare('SELECT * FROM otp_tokens WHERE token = ?');
											$recup_flw->execute(array($speUsrSelect));
											$recup_data = $recup_flw->fetch();
											$countUsrFwl = $recup_flw->rowCount();

											if ($countUsrFwl == 0) {
												$Session->setFlash(Translator('User_cannot_found'), "close", "error");
												header('Location: /companies.php');
												exit();
											} else {
												// Suppression SQL de l'utilisateur
												$del_corp = $db->prepare('DELETE FROM otp_tokens WHERE token = ?');
												$del_corp->execute(array($speUsrSelect));

												$recup_corp = $db->prepare('SELECT * FROM otp_companies WHERE corpid = ?');
												$recup_corp->execute(array($recup_data['corpid']));
												$recup_name_corpfolder = $recup_corp->fetch();

												// Suppression du dossier utilisateur
												$escaped_command = escapeshellcmd("sudo rm -rf /home/" . $recup_name_corpfolder['folder'] . "/" . $recup_data['login']);
												shell_exec($escaped_command);

												// Ajout actions dans les logs d'EXER otp si les actions ont réussies
												addLogEventOTP("[SUCCESS] Selected users " . $recup_name_corpfolder['name'] . " have been succesfully deleted by " . $_SESSION['username']);

												$Session->setFlash(Translator('success_users_select') . $recup_name_corpfolder['name'] . Translator('delete_users_selected'), "check", "success");
												$actual_link = "https://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";

												header('Location: ' . $actual_link);
											}
										}
									}
								}


								if (isset($_POST['sendMailSelectedUsrCorp'])) {
									if (!empty($_POST['speUsrSelect'])) {


										$sendTotalCounter = count($_POST['speUsrSelect']);
										$i = 0;

										foreach ($_POST['speUsrSelect'] as $speUsrSelect) {
											$recup_flw = $db->prepare('SELECT * FROM otp_tokens WHERE token = ?');
											$recup_flw->execute(array($speUsrSelect));
											$recup_data = $recup_flw->fetch();
											$countUsrFwl = $recup_flw->rowCount();


											if ($countUsrFwl == 0) {
												$Session->setFlash(Translator('User_cannot_found'), "close", "error");
												$actual_link = "https://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";

												header('Location: ' . $actual_link);
											} else {
												if ($recup_data['email'] != "N/A") {
													$i++;
													$recup_mail = htmlspecialchars($recup_data['email']);
													/** 
													 *	Send mail 
													 **/
													$GetCompany = $db->prepare('SELECT * FROM otp_companies WHERE corpid = ?');
													$GetCompany->execute(array($recup_data['corpid']));

													if ($GetCompany->rowCount() == 1) {
														$Company = $GetCompany->fetch();

														$CorpName = $Company['name'];
														$CustomFQDN = $db->prepare('SELECT fqdn FROM otp_mailing WHERE corpid = ?');
														if ($_SESSION['corp'] == "NOT_DEFINED") {
															$CustomFQDN->execute(array($Company['corpid']));
														} else {
															$CustomFQDN->execute(array($_SESSION['corp']));
														}
														$ClientFQDN = $CustomFQDN->fetch();

														$ExternalShareForm = "/shareExternal.php?shareID=" . "{$recup_data['externalToken']}";

														if (!empty($ClientFQDN[0])) {
															$shareLink = $ClientFQDN[0] . $ExternalShareForm;
														} else {
															$shareLink = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://{$_SERVER['HTTP_HOST']}" . $ExternalShareForm;
														}

														if (isset($recup_data['login'])) {
															$OTPVar = array(
																'username'  =>  $recup_data['login'],
																'email'     =>  $recup_mail,
																'link'      =>  $shareLink,
																'company'   =>  $CorpName
															);

															$CheckMailing = $db->prepare('SELECT * FROM otp_mailing WHERE corpid = ?');
															$CheckMailing->execute(array($recup_data['corpid']));

															if ($CheckMailing->rowCount() == 1) {
																$Mailing = $CheckMailing->fetch();

																if (empty($Mailing['host'])) {
																	$Session->setFlash(Translator('inform_seting_server') . "<b>Maintenance</b>" . "<strong>" . Translator('SMTP_links') . "</strong>" . Translator('Send_OTP_email'), "close", "error");
																	header('Location: ' . $_SERVER["REQUEST_URI"]);
																	exit();
																} else {
																	SendMail($recup_mail, false, $Company['corpid'], $OTPVar);
																}
															} else {
																$Session->setFlash(Translator("configuration_mail_relay_not_found"), "close", "error");
																header('Location: ' . $_SERVER["REQUEST_URI"]);
																exit();
															}
														} else {
															$Session->setFlash(Translator("user_not_found"), "close", "error");
															header('Location: ' . $_SERVER["REQUEST_URI"]);
															exit();
														}
													} else {
														$Session->setFlash(Translator("company_not_found"), "close", "error");
														header('Location: ' . $_SERVER["REQUEST_URI"]);
														exit();
													}
												}
											}
										}




										if ($i != "0") {
											addLogEventOTP("[SUCCESS] Emails have been sent to " . $i . " user(s) on a total of " . $sendTotalCounter);

											$Session->setFlash(Translator("success_email_otp_send")  . $i . " " . Translator('users_on_a_total_of') . " " . $sendTotalCounter . " " . Translator('Email'), "check", "success");
											$actual_link = "https://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";

											header('Location: ' . $actual_link);
										} else {
											addLogEventOTP("[ERROR] No OTP E-mail was sent to the selected users because no Sending E-mail address was specified " . $sendTotalCounter);

											$Session->setFlash(Translator('no-email_address_send'), "change_history", "warning");
											$actual_link = "https://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";

											header('Location: ' . $actual_link);
											exit();
										}
									}
								}
							}
							?>




							<?php if (checkLevel() != OPERATOR) { ?>
								<div class="optionsmenu_p">
									<div class="dropdown">
										<button class="exerotpbtn btn-defaultexer btn-sm ripple-effect ripple-white dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
											<label id="countChecks"></label>
										</button>
										<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
											<a class="dropdown-item" href="#" data-toggle="modal" data-target="#confirmcorp_emails"><i class="far fa-envelope"></i> <?= Translator('Send_OTP_email'); ?></a>
											<form class="form-horizontal" method="post" enctype="multipart/form-data">
												<div class="input-icon">
													<i class="far fa-file-csv"></i>
													<input class="dropdown-item2" type="submit" name="CSVExport_Classic" value="<?= Translator('Export_to_CSV'); ?>" />
												</div>
												<div class="input-icon">
													<i class="far fa-file-spreadsheet"></i>
													<input class="dropdown-item2" type="submit" name="CSVExport_AzureMicrosoft" value="<?= Translator('Export_to_Azure'); ?>" />
												</div>
											</form>
											<a class="dropdown-item" href="#" data-toggle="modal" data-target="#confirmcorp_delete"><i class="far fa-trash-alt"></i> <?= Translator('Delete'); ?></a>
										</div>
									</div>
								</div>


								<!-- Modal confirmcorp_emails -->
								<div class="modal fade" id="confirmcorp_emails" tabindex="-1" role="dialog" aria-labelledby="lblview_ldap" aria-hidden="true">
									<div class="modal-dialog modal-lg" role="document">
										<div class="modal-content">
											<div class="modal-header">
												<h5 class="modal-title" id="lblconfirm_view_ldapedit"><i class="far fa-envelope"></i> <?= Translator('Send_OTP_email'); ?>
											</div>

											<div class="modal-body">
												<?= Translator('Send_link_on_email'); ?>
											</div>

											<div class="modal-footer">
												<button type="button" class="exerotpbtn btn-white ripple-effect ripple-dark" data-dismiss="modal"><?= Translator('Cancel'); ?></button>
												<button type="submit" name="sendMailSelectedUsrCorp" class="exerotpbtn btn-green ripple-effect ripple-white"><i class="fas fa-paper-plane"></i> <?= Translator('Send'); ?></button>
											</div>
										</div>
									</div>
								</div>

								<!-- Modal confirmcorp_delete -->
								<div class="modal fade" id="confirmcorp_delete" tabindex="-1" role="dialog" aria-labelledby="lblview_ldap" aria-hidden="true">
									<div class="modal-dialog modal-lg" role="document">
										<div class="modal-content">
											<div class="modal-header">
												<h5 class="modal-title" id="lblconfirm_view_ldapedit"><i class="far fa-trash-alt"></i> <?= Translator('Delete_selected_user'); ?>
											</div>

											<div class="modal-body">
												<?= Translator('Sure_delete_user'); ?>
											</div>

											<div class="modal-footer">
												<button type="button" class="exerotpbtn btn-white ripple-effect ripple-dark" data-dismiss="modal"><?= Translator('Cancel'); ?></button>
												<button type="submit" name="deleteSelectedUsrCorp" class="exerotpbtn btn-red ripple-effect ripple-white"><i class="fas fa-trash-alt"></i> <?= Translator('Delete'); ?></button>
											</div>
										</div>
									</div>
								</div>
						<?php }
						} ?>
						<?php
						if ($count_token == 0) {
							$error = Translator('compagny_has_not_created_user');
						} else {
							if ($count_token >= 150) {
								echo "
							<style>
							.pgnt_tab.pagination.justify-content-center {
								overflow: auto !important;
								max-width: 100% !important;
								justify-content: normal !important;
							}
							</style>
							";
							}
						?>

							<div class="table-responsive ms-h-50" id="container_table">
								<table id="table_otpexer" class="sortable-theme-bootstrap table-striped" data-sortable>
									<thead>
										<tr>
											<?php if (checkLevel() != OPERATOR) { ?>
												<th data-sortable="false">
													<label class="pure-material-checkbox allCheck" style="margin-bottom: -5px;">
														<input type="checkbox" name="selectUsr[]" onclick="toggle(this);">
														<span></span>
													</label>

												</th>
											<?php } ?>
											<th class="vt-default-th" data-sorted-direction="descending"> <?= Translator('user'); ?></th>
											<th><?= Translator('Email'); ?></th>
											<th><?= Translator('NFC_series_number'); ?></th>
											<th><?= Translator('last_connection'); ?></th>
											<th><?= Translator('Creation_date'); ?></th>
											<th data-sortable="false"></th>
										</tr>
									</thead>
									<tbody id="byValDataT">
										<?php
										while ($rc_tok_supervisor = $recup_tokens->fetch()) { ?>
											<tr>
												<?php if (checkLevel() != OPERATOR) { ?>
													<td>
														<label class="pure-material-checkbox" style="margin-bottom: -5px;">
															<input type="checkbox" name="speUsrSelect[]" value="<?= $rc_tok_supervisor['token'] ?>" onclick="chcSelect()" id="speUsrSelect[]">
															<span></span>
														</label>
													</td>
												<?php

												} ?>
												<td class="user-bold-cs" data-value="<?= $rc_tok_supervisor['login'] ?>" onclick="window.location.href='?page=ViewUser&TokenID=<?= $rc_tok_supervisor['token'] ?>'"><?= $rc_tok_supervisor['login'] ?></td>
												<td onclick="window.location.href='?page=ViewUser&TokenID=<?= $rc_tok_supervisor['token'] ?>'"><?php if ($rc_tok_supervisor['email'] == "N/A") {
																																					echo "<i>" . Translator('not_specified') . "</i>";
																																				} else {
																																					echo $rc_tok_supervisor['email'];
																																				} ?></td>
												<td onclick="window.location.href='?page=ViewUser&TokenID=<?= $rc_tok_supervisor['token'] ?>'"><?php if (!empty($rc_tok_supervisor['serialnumber_card'])) {
																																					echo $rc_tok_supervisor['serialnumber_card'];
																																				} else {
																																					echo "N/A";
																																				} ?></td>
												<td data-value="<?= strtotime($rc_tok_supervisor['otp_last_connected']) ?>" onclick="window.location.href='?page=ViewUser&TokenID=<?= $rc_tok_supervisor['token'] ?>'">
													<?php
													if (!empty($rc_tok_supervisor['otp_firewall'])) {
														if ($rc_tok_supervisor['otp_last_connected'] != "0000-00-00 00:00:00") {
															$Date = date_format(date_create($rc_tok_supervisor['otp_last_connected']), "d/m/Y H:i");
															echo "<label style='position:relative;top:4px;' title='" . Translator('last_connection') . $Date . "\n" . Translator('Firewall') . ": " . $rc_tok_supervisor['otp_firewall'] . "'>" . $Date . " (" . $rc_tok_supervisor['otp_firewall'] . ") </label>";
														} else {
															echo '<span class="text-danger">' . Translator('no_connect') . '</span>';
														}
													} else {
														echo '<span class="text-danger">' . Translator('no_connect') . '</span>';
													}
													?>
												</td>
												<td data-value="<?= strtotime($rc_tok_supervisor['created_at']) ?>" onclick="window.location.href='?page=ViewUser&TokenID=<?= $rc_tok_supervisor['token'] ?>'"><?php echo date_format(date_create($rc_tok_supervisor['created_at']), "d/m/Y H:i"); ?></td>

												<!-- Modal_confirm suppression user_corp -->
												<?php if (checkLevel() == ADMIN || checkLevel() == SUPERVISOR) { ?>
													<?php $rand_client_modal = generateToken(9999); ?>
													<div class="modal fade" id="confirm_delete_usrcorp__<?= $rand_client_modal ?>" tabindex="-1" role="dialog" aria-labelledby="lblconfirm_delete_fireclient" aria-hidden="true">
														<div class="modal-dialog modal-lg" role="document">
															<div class="modal-content">
																<div class="modal-header">

																	<h5 class="modal-title" id="lblconfirm_delete_fireclient"><i class="far fa-trash-alt"></i><?= Translator('Delete_user'); ?> </h5>
																	<button type="button" class="close" data-dismiss="modal" aria-label="Close">

																		<span aria-hidden="true"><i class="far fa-times"></i></span>
																	</button>
																</div>

																<div class="modal-body">
																	<label><?= Translator('Confirm_removal_user'); ?> <b><?= $rc_tok_supervisor['login'] ?></b> ?</label>
																</div>

																<div class="modal-footer">
																	<?php
																	if (isset($_POST['del_this_usrcorp__' . $rc_tok_supervisor['token']])) {
																		unset($_SESSION['token_access_deleteusrcorp']);
																		unset($_SESSION['login_access_deleteusrcorp']);
																		$_SESSION['token_access_deleteusrcorp'] = $rc_tok_supervisor['token'];
																		$_SESSION['login_access_deleteusrcorp']	= $rc_tok_supervisor['login'];

																		header('Location: inc/class.actions.php?VerbAction=DeleteUserCorp');
																		exit();
																	}
																	?>

																	<form method="POST">
																		<button type="button" class="exerotpbtn btn-cancel ripple-effect ripple-white" data-dismiss="modal"><?= Translator('Cancel'); ?></button>
																		<button type="submit" name="del_this_usrcorp__<?= $rc_tok_supervisor['token'] ?>" class="exerotpbtn btn-green ripple-effect ripple-white"><?= Translator('Confirm'); ?></button>
																	</form>
																</div>
															</div>
														</div>
													</div>
												<?php } ?>

												<td>
													<form method="POST">
														<?php if (checkLevel() == ADMIN || checkLevel() == SUPERVISOR) { ?>
															<a href="/companies.php?page=EditUser&TokenID=<?= $rc_tok_supervisor['token'] ?>"><button type="button" class="exerotpbtn btn-sm btn-green ripple-effect ripple-white" title=<?= Translator('Edit_OTP_user'); ?>><i class="far fa-pen dwnl_small_addelement_icon delete_action_button_item"></i></button></a>
															<button type="button" class="exerotpbtn btn-sm btn-red ripple-effect ripple-white" title="<?= Translator('Delete_user'); ?>" data-toggle="modal" data-target="#confirm_delete_usrcorp__<?= $rand_client_modal ?>"><i class="far fa-trash-alt dwnl_small_addelement_icon delete_action_button_item"></i></button>
														<?php } ?>
													</form>
												</td>
											</tr>
										<?php
										} ?>
									</tbody>
								</table>
							</div>
						<?php } ?>
					</div>
				</form>
			<?php }
			if (isset($error)) { ?>
				<br>
				<div class="row">
					<div class="col-md-6">
						<div class="alert alert-danger" role="alert">
							<i class="fas fa-exclamation-triangle"></i> <?= $error ?>
						</div>
					</div>

					<?php if (checkLevel() != OPERATOR) { ?>
						<div class="col-md-3">
							<a href="?page=AddThisCorpUser&choiceCorp=<?= $query_corp_slt['token'] ?>"><button class="exerotpbtn btn-teal btn-sm btneditnusr ripple-effect ripple-white" title="<?= Translator('Add_user_for_client_company') ?>"><i class="far fa-layer-plus dwnl_small_addelement_icon"></i> <?= Translator('Create_user'); ?></button></a>
						</div>
						<div class="col-md-3">
						<?php if ($count_ldap2 != 0) { ?>
										<a type="button" href="ldap.php?page=AddLdapFromDirectory&TokenID=<?= $query_corp_slt['token'] ?>" class="exerotpbtn btn-teal btn-sm btneditnusr ripple-effect ripple-white"><i class="far fa-book-reader dwnl_small_addelement_icon"></i><?= Translator('add_LDAP_User'); ?></a>
							<?php } else { ?>	
										<a type="button" href="ldap.php?page=AddLdap&TokenID=<?= $query_corp_slt['token'] ?>" class="exerotpbtn btn-teal btn-sm btneditnusr ripple-effect ripple-white"><i class="far fa-book-reader dwnl_small_addelement_icon"></i><?= Translator('add_LDAP_User'); ?></a>
							<?php } ?>
						</div>
					<?php } ?>
				</div>
			<?php }
		}
	} elseif ($page == "AddThisCorpUser") {
		if (isset($_GET['choiceCorp'])) {
			$choiceCorp = htmlspecialchars($_GET['choiceCorp']);
		} else {
			$choiceCorp = NULL;
		}

		if (!empty($_GET['choiceCorp'])) {
			$RecupTargetCorp = $db->prepare('SELECT * FROM otp_companies WHERE token = ?');
			$RecupTargetCorp->execute(array($choiceCorp));
			$dumpSpecifyCorp = $RecupTargetCorp->fetch();
		} else {
			$dumpSpecifyCorp = NULL;
		}

		$ExistCorp = $db->query('SELECT * FROM otp_companies');
		if ($ExistCorp->rowCount() == 0) {
			$Session->setFlash(Translator('create_compagny_first'), "close", "error");
			header('Location: /companies.php');
			exit();
		}

		if (checkLevel() == OPERATOR) {
			header('Location: /companies.php');
			exit();
		} else {
			if (isset($_POST['subm_this_add_corp'])) {
				// Déclaration variables filtrées
				if ($_SESSION['corp'] != "NOT_DEFINED") {
					$register_corp_sql = $_SESSION['corp'];
				} else {
					$corpinput_nameclient  = htmlspecialchars($_POST['corpinput_nameclient']);
					$register_corp_sql = $corpinput_nameclient;
				}

				$RecupNameCorpInfos = $db->prepare('SELECT * FROM otp_companies WHERE corpid = ?');
				$RecupNameCorpInfos->execute(array($register_corp_sql));
				$client_corp = $RecupNameCorpInfos->fetch();

				$login 			= htmlspecialchars($_POST['login']); // Champ nom_utilisateur
				$client  		= htmlspecialchars($client_corp['folder']); // Champ client

				if (empty($_POST['nametoken'])) {
					$nametoken 	= 	htmlspecialchars($_POST['login']); // Champ secrete_token vide, alors login par defaut
				} else {
					$nametoken 	= 	remove_accents(htmlspecialchars($_POST['nametoken'])); // Champ secrete_token
				}

				if (!isset($_POST['serialnumber_card']) and empty($_POST['serialnumber_card'])) {
					$serialnumber_card = "N/A";
				} else {
					$serialnumber_card = htmlspecialchars($_POST['serialnumber_card']);
				}

				if (empty($_POST['issuer'])) {
					if ($_SESSION['corp'] != "NOT_DEFINED") {
						$issuer 	= 	$_SESSION['corp_name'];
					} else {
						$issuer 	= 	htmlspecialchars($client_corp['name']);
					}
				} else {
					$issuer 		= 	remove_accents(htmlspecialchars($_POST['issuer']));
				}

				// Rendre l'adresse Email facultative
				$valid_email = true;
				if (!empty($_POST['email_usrcorp'])) {
					if (filter_var($_POST['email_usrcorp'], FILTER_VALIDATE_EMAIL)) {
						$valid_email = true;
						$email_usrcorp 	= 	htmlspecialchars($_POST['email_usrcorp']);
					} else {
						$error_createcorp = Translator('Sending_a_valid_email');
						$email_usrcorp 	= "N/A";
						$valid_email = false;
					}
				} else {
					$email_usrcorp 	= "N/A";
				}

				if (isset($_POST['login']) and $valid_email) {
					if (!empty($_POST['login'])) {
						//check if not exist username on otp datatbase
						$requusername = $db->prepare("SELECT * FROM otp_tokens WHERE login = ? AND corpid = ?");
						$requusername->execute(array($login, $client_corp['corpid']));
						$usernameexist = $requusername->rowCount();
						if ($usernameexist == 0) {
							if (($login == "_") || ($login == ".") || (($login == "_.") && ($login == "_."))) {
								$error_createcorp = Translator('characters_not_allowed');
							} elseif ((_s_has_special_chars($login) != 1)) {
								if ($_POST['login'] != "skel") {
									if ($_POST['issuer'] != "skel") {
										// transformation des variables en minuscule et remplacement des espaces par des underscores
										$array_spaces 	= 	array(" ", " ", " ", "'");
										$login_af 		= 	strtolower(str_replace($array_spaces, "_", $login));
										$client_af 		= 	strtolower(str_replace($array_spaces, "_", $client));
										$issuer_af 		= 	str_replace($array_spaces, "_", $issuer);
										$nametoken_af 	= 	str_replace($array_spaces, "_", $nametoken);
										$token 			= 	generateToken(9999);
										$externalToken 	= 	generateToken(9999);
										$datenow		=	date('Y-m-d H:i:s');

										$nomclient 		=	$client_af;
										$nomuser 		= 	$login_af;

										$TotalAllMaxToken = $db->prepare('SELECT * FROM otp_tokens WHERE corpid = ?');
										$TotalAllMaxToken->execute(array($client_corp['corpid']));
										$CountExistTokenByCorp = $TotalAllMaxToken->rowCount();

										if (($client_corp['users_max'] - $CountExistTokenByCorp) > 0) {
											// Création du token freerad depuis le script token.sh ==> /usr/local/bin/token.sh
											$output = shell_exec("sudo /usr/local/bin/token.sh -l '$login_af' -c '$client_af' -i '$issuer_af' -n '$nametoken_af' 2>&1");

											//addLogEventOTP("[SUCCESS]".$login_af." -c ".$client_af." -i ".$issuer_af." -n ".$nametoken_af);
											$answer = strstr($output, ' ', true);
											if (strcmp($answer, "Voici") == 0) {
												// récupération du secret dans le fichier utilisateur																												
												$handle = fopen('/home/' . $nomclient . '/' . $nomuser . '/.exer_authenticator', "r");

												if ($handle) {
													if (($buffer = fgets($handle)) != "e") {
														$secretkey = rtrim($buffer);

														if ($login_af != $nametoken_af) {
															$set = 'otpauth://totp/' . str_replace(' ', '%20', trim($nametoken)) . '?secret=' . str_replace(' ', '%20', trim($secretkey)) . '&issuer=' . str_replace(' ', '%20', trim($issuer)) . '';
														} else {
															$set = 'otpauth://totp/' . str_replace(' ', '%20', trim($login)) . '?secret=' . str_replace(' ', '%20', trim($secretkey)) . '&issuer=' . str_replace(' ', '%20', trim($issuer)) . '';
														}
													}
													fclose($handle);
												}
												// Génération du QR Code et stockage dans la base SQL
												$codeText = $set;
												ob_start();
												QRCode::png($codeText, null, QR_ECLEVEL_L, 8);
												$imageString = base64_encode(ob_get_contents());
												ob_end_clean();
												echo "<img class='QrCode' src='data:image/png;base64,$imageString'>";

												$base64_qrcode = "data:image/png;base64,$imageString";
												$ProtectQRCode = EncodePassword($base64_qrcode);

												// insertion des données dans la base 'otp_tokens'
												$insert_req = $db->prepare("INSERT INTO otp_tokens(userid, login, email, issuer, corpid, key_name, serialnumber_card, qr_code, created_at, token, externalToken) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
												$insert_req->execute(array($_SESSION['id'], $login_af, $email_usrcorp, $issuer, $register_corp_sql, $nametoken, $serialnumber_card, $ProtectQRCode, $datenow, $token, $externalToken));

												// ajout dans les logs otp_exer si tout est ok lors de la creation ==> otp_exer
												addLogEventOTP("[SUCCESS] The OTP user has been successfully created by " . $_SESSION['username'] . " (login=" . $login_af . "; company=" . $nomclient . ")");

												$Session->setFlash(Translator('the_Username') . " " . $login_af . " " . Translator('correctly_created'), "check", "success");

												header('Location: /companies.php?page=ViewUser&TokenID=' . $token);
												exit();
											} else {
												addLogEventOTP("[ERROR] The OTP user could not be created by " . $_SESSION['username'] . " (login=" . $login_af . "; company=" . $nomclient . ")");

												if (empty($output)) {
													$outputSplash = "Inconnu";
												} else {
													$outputSplash = $output;
												}

												$error_createcorp = Translator('unknow_error') . Translator('error_otp_user') . Translator('Error') . " . " . $outputSplash;
											}
										} else {
											$error_createcorp = Translator('no_more_license');
										}
									} else {
										$error_createcorp = Translator('name_not_available');
									}
								} else {
									$error_createcorp = Translator('name_not_available');
								}
							} else {
								$error_createcorp = Translator('characters_not_allowed');
							}
						} else {
							$error_createcorp = Translator('user_already_exists');
						}
					} else {
						$error_createcorp = Translator('Fill_all_fields');
					}
				}
			}
			?>

			<form method="POST" name="FormFireWall">
				<div class="formaddcorp">
					<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
						<h1 class="h3"><?= $module_page_name ?> <exer class="text-secondary"><i class="far fa-chevron-right chevronexer_openform"></i></exer> <i><?= Translator('Create_user'); ?></i></h1>

						<div class="btn-group">
							<button type="submit" name="subm_this_add_corp" id="subm_this_add_corp" class="exerotpbtn btn-green btn-sm ripple-effect ripple-white"><i class="far fa-save dwnl_small_addelement_icon"></i> <?= Translator('Confirm'); ?></button>
							<a href="/companies.php"><button type="button" class="exerotpbtn btn-red btn-sm ripple-effect ripple-white" style="margin-left:10px;"><i class="far fa-times dwnl_small_addelement_icon"></i> <?= Translator('Cancel'); ?></button></a>
						</div>
					</div>

					<?php if (isset($error_createcorp)) { ?>
						<div class="alert alert-danger" role="alert">
							<i class="fas fa-exclamation-triangle"></i> <?= $error_createcorp ?>
						</div>
					<?php } ?>

					<div id="submit_formfirewall_user">
						<fieldset class="fieldset_exerotp">
							<legend class="legend_exerotp"><?= Translator('General'); ?></legend>
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<label for="login"><?= Translator('User_name'); ?> :<b class="text-danger" title="<?= Translator('Field_required'); ?>" data-toggle="tooltip" data-placement="right"><i class="far fa-asterisk"></i></b></label>
										<input type="text" onkeydown="if(event.keyCode==32) return false;" name="login" autocomplete="off" class="form-control" id="login" value="<?php if (isset($login)) {
																																														echo $login;
																																													} ?>" placeholder="ex : john.doe">
									</div>
								</div>

								<div class="col-md-6">
									<div class="form-group">
										<label for="login"><?= Translator('Email'); ?> :</label>
										<input type="email" name="email_usrcorp" autocomplete="off" class="form-control" id="email_usrcorp" value="<?php if (isset($email_usrcorp)) {
																																						echo $email_usrcorp;
																																					} ?>" placeholder="ex : who@where">
									</div>
								</div>
							</div>

							<div class="form-group">
								<label for="serialnumber_card"><?= Translator('NFC_series_number'); ?> :</label>
								<input type="text" name="serialnumber_card" autocomplete="off" class="form-control" id="serialnumber_card" value="<?php if (isset($serialnumber_card)) {
																																						echo $serialnumber_card;
																																					} ?>" placeholder="ex : 8659609XXXXXX">
							</div>

							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<label for="issuer"><?= Translator('Issuer_default'); ?> :</label>
										<input type="text" name="issuer" autocomplete="off" placeholder="ex : <?= Translator('my_compagny'); ?>" class="form-control" id="issuer" value="<?php if (isset($issuer)) {
																																																echo $issuer;
																																															} ?>">
									</div>
								</div>

								<div class="col-md-6">
									<div class="form-group">
										<label for="issuer"><?= Translator('key_name_default'); ?> :</label>
										<input type="text" name="nametoken" autocomplete="off" class="form-control" value="<?php if (isset($nametoken)) {
																																echo $nametoken;
																															} ?>" placeholder="ex : <?= Translator('my_security_key'); ?>">
									</div>
								</div>
							</div>
						</fieldset>

						<?php if ($_SESSION['corp'] == "NOT_DEFINED") { ?>
							<br>
							<fieldset class="fieldset_exerotp">
								<legend class="legend_exerotp"><?= Translator('appli_company'); ?></legend>
								<i><?= Translator('registration_company'); ?></i>
								<hr style="margin-top: 11px; margin-bottom: 10px;">
								<div class="form-group">
									<label for="corpinput_nameclient"><?= Translator('Corporate_assign'); ?><b class="text-danger" title="<?= Translator('Field_required'); ?>" data-toggle="tooltip" data-placement="right"><i class="far fa-asterisk"></i></b></label>
									<select class="form-control" name="corpinput_nameclient" id="corpinput_nameclient">
										<?php
										$corps_recorver = $db->query('SELECT * FROM otp_companies ORDER BY id ASC');
										while ($corp_recup = $corps_recorver->fetch()) {
										?>
											<option <?php if ($corp_recup['corpid'] == $dumpSpecifyCorp['corpid']) {
														echo "selected ";
													} ?>value="<?= $corp_recup['corpid'] ?>"><?= $corp_recup['name'] ?> </option>
										<?php } ?>
									</select>
								</div>
							</fieldset>
							<br><br>
						<?php } ?>
					</div>
				</div>
			</form>
		<?php }	?>
		<?php } elseif ($page == "AddCorp") {
		if ($_SESSION['corp'] != "NOT_DEFINED" || checkLevel() == OPERATOR) {
			header('Location: /companies.php');
			exit();
		} else {
		?>
			<?php
			if (isset($_POST['submitform_corpclient'])) {
				//declaration variables filtrees
				$inp_addcorp_namecorp 	= 	htmlspecialchars($_POST['inp_addcorp_namecorp']);
				$inp_addcorp_email 		= 	htmlspecialchars($_POST['inp_addcorp_email']);
				$inp_addcorp_users_max	=	htmlspecialchars($_POST['inp_addcorp_users_max']);
				$inp_addcorp_expire_date = htmlspecialchars($_POST['inp_addcorp_expire_date']);

				if (isset($_POST['inp_addcorp_namecorp'], $_POST['inp_addcorp_email'], $_POST['inp_addcorp_expire_date'], $_POST['inp_addcorp_users_max'])) {
					if (!empty($_POST['inp_addcorp_namecorp']) and !empty($_POST['inp_addcorp_users_max'])) {
						$there_is_an_email = false;
						$there_is_a_date = false;
						$checksyntaxdate = true;
						if (!empty($_POST['inp_addcorp_email'])) {
							$there_is_an_email = true;
						}
						if (!empty($_POST['inp_addcorp_expire_date'])) {
							$there_is_a_date = true;
						}
						if ($there_is_a_date == true) {
							$checkdate = $_POST['inp_addcorp_expire_date'];
							$dateformateur2 = DateTime::createFromFormat('Y-m-d', $checkdate);
							if ($dateformateur2 == true) {
								$checksyntaxdate = true;
							} else {
								$dateformateur3 = DateTime::createFromFormat('d/m/Y', $checkdate);
								if ($dateformateur3 == true) {
									$checksyntaxdate = true;
								} else {
									$checksyntaxdate = false;
								}
							}
						}
						if ($checksyntaxdate == true) {
							if ((preg_match('/(?i)_mfa$/', $inp_addcorp_namecorp) == false) and (strcasecmp($inp_addcorp_namecorp, 'skel'))) {
								if (!$there_is_an_email or filter_var($inp_addcorp_email, FILTER_VALIDATE_EMAIL)) {
									if ($inp_addcorp_users_max <= $_SESSION['users_maximum'] and $inp_addcorp_users_max >= 0) {
										// Check if the inp_addcorp_users_max is correct compared to the data we already have 
										// in fisrt part count the total already in base
										$recup_users_max = $db->prepare("SELECT users_max FROM otp_companies");
										$recup_users_max->execute();
										$total = 0;
										$tmp = $recup_users_max->rowCount();
										$cmp = 0;

										while ($cmp < $tmp) {
											$data = $recup_users_max->fetch();
											$total = $total + $data[0];
											$cmp++;
										}

										$_SESSION['total'] = $total;

										// Then check if the total and the max given by the user dont exceed the max total
										$_SESSION['remaining'] = $_SESSION['users_maximum'] - $total;
										$total = $total + $inp_addcorp_users_max;
										if ($total <= $_SESSION['users_maximum']) {
											// check if not exist company on otp datatbase
											$reqcompany = $db->prepare("SELECT * FROM otp_companies WHERE name = ?");
											$reqcompany->execute(array($inp_addcorp_namecorp));
											$corpexist = $reqcompany->rowCount();

											if ($corpexist == 0) {
												// check if not exist email_company on otp datatbase
												$reqemail_corp = $db->prepare("SELECT * FROM otp_companies WHERE contact_email = ?");
												$reqemail_corp->execute(array($inp_addcorp_email));
												$emailcorpexist = $reqemail_corp->rowCount();
												if ($emailcorpexist == 0) {
													$gen_folder	= replace_special_chars(strtolower(str_replace(" ", "_", $inp_addcorp_namecorp)));
													$client = htmlspecialchars($gen_folder);

													// Put the otp.license file and create the folder for the companie
													$escaped_command = escapeshellcmd("sudo mkdir /home/" . $gen_folder);
													shell_exec($escaped_command);

													$escaped_command = escapeshellcmd("sudo chown freerad:freerad /home/" . $gen_folder);
													shell_exec($escaped_command);

													$escaped_command = escapeshellcmd("sudo touch /home/" . $gen_folder . "/otp.license");
													shell_exec($escaped_command);

													$escaped_command = escapeshellcmd("sudo chown freerad:freerad /home/" . $gen_folder . "/otp.license");
													shell_exec($escaped_command);
													shell_exec("echo 'Number of licenses max : " . $inp_addcorp_users_max . "' > /home/" . $gen_folder . "/otp.license");

													// Transformation des variables en minuscule et remplacement des espaces par des underscores
													$array_spaces 		= 	array(" ", " ", " ", "'");
													$client_af 			= 	strtolower(str_replace($array_spaces, "_", $client));
													$token 				= 	generateToken(9999);

													$verifcorpid        =   0;
													while ($verifcorpid == 0) {
														$corpid 	= 	rand(1, 2147483647);
														$query_verify_corp_id = $db->prepare("SELECT * FROM otp_companies WHERE corpid = ?");
														$query_verify_corp_id->execute(array($corpid));
														$corpidexist = $query_verify_corp_id->rowCount();
														if ($corpidexist == 0) {
															$verifcorpid = 1;
														}
													}
													$error_addcorp		=	"";

													if (($_FILES['import_logo_corp']) && $_FILES['import_logo_corp']['error'] === 0) {
														$NomDuFichier 	= $_FILES["import_logo_corp"]["name"];
														//$taille_max    	= 104857600; //==100Mo
														$taille_max		= 104850; //==100Ko
														$taille_fichier = filesize($_FILES['import_logo_corp']['tmp_name']);
														$type_logo 		= $_FILES["import_logo_corp"]["type"];

														if ($taille_fichier > $taille_max) {
															$error_addcorp = Translator('size_file') . Translator('current_size_file') . $taille_fichier . " " . Translator('Bytes');
														} else {
															$allowed = array("image/jpeg", "image/gif", "image/png", "image/jpg", "image/bmp");
															if (in_array($type_logo, $allowed)) {
																if (is_uploaded_file($_FILES["import_logo_corp"]["tmp_name"])) {
																	$img_file = $_FILES["import_logo_corp"]["tmp_name"];
																	$imgData = base64_encode(file_get_contents($img_file));
																	$logo_corp = 'data: ' . mime_content_type($img_file) . ';base64,' . $imgData;
																} else {
																	$error_addcorp = Translator('An_error_occu') . Translator('the_file') . $NomDuFichier . Translator('not_uploaded');
																}
															} else {
																$error_addcorp = Translator('valid_image') . Translator('image_format');
															}
														}
													} else {
														$logo_corp = "not_defined";
													}

													if ($error_addcorp == "") {
														$nomclient 			=	$client_af;
														$token 				= 	generateToken(9999);
														$created_at 		= 	return_date_all_actuelle();

														if (!empty($_POST['inp_addcorp_nbr_street']) and !empty($_POST['inp_addcorp_street']) and !empty($_POST['inp_addcorp_zipcode']) and !empty($_POST['inp_addcorp_city'])) {
															$adresse_complete 	= 	$inp_addcorp_nbr_street . ". " . $inp_addcorp_street . " - " . $inp_addcorp_zipcode . " " . $inp_addcorp_city;
														} else {
															$adresse_complete	=	"N/A";
														}
														if (!empty($_POST['inp_addcorp_expire_date'])) {
															$expiredate = $inp_addcorp_expire_date;
														} else {
															$BeforeExpireDate = $DumpExpireDateold;
															$Date_Expire_Date = str_replace('/', '-', $BeforeExpireDate);
															$expiredate = date('Y-m-d', strtotime($Date_Expire_Date));
														}


														if (!empty($_POST['inp_addcorp_email'])) {
															$inp_addcorp_email 		= 	htmlspecialchars($_POST['inp_addcorp_email']);
														} else {
															$inp_addcorp_email 		= 	"N/A";
														}



														$users_max 			=	$inp_addcorp_users_max;

														if ($users_max == "")
															$users_max = 0;


														$check_duplicate = $db->prepare("SELECT COUNT(*) FROM otp_companies WHERE folder = ? OR name = ?");
														$check_duplicate->execute(array($gen_folder, $inp_addcorp_namecorp));
														$is_duplicate = ($check_duplicate->fetchColumn() > 0);

														if (!$is_duplicate) {
															// Insertion des données dans la base 'otp_companies' de l'entreprise
															$insert_new_corp = $db->prepare("INSERT INTO otp_companies(corpid, name, folder, contact_email, logosrc, expire_date, created_at, token, users_max) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)");
															$insert_new_corp->execute(array($corpid, $inp_addcorp_namecorp, $gen_folder, $inp_addcorp_email, $logo_corp, $expiredate, $created_at, $token, $users_max));

															$gen_passwd_admin 	= generatePassword(30);
															$encrypt_password 	= password_hash($gen_passwd_admin, PASSWORD_BCRYPT);
															$token_usr 			= generateToken(9999);
															$username_admin		= "admin_" . $gen_folder;

															// Création d'un utilisateur admin pour gérer l'entreprise
															$insert_users = $db->prepare("INSERT INTO otp_users(corp, lastname, firstname, username, email, password, level, enable, token, created_at) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
															$insert_users->execute(array($corpid, "", Translator('Admin'), $username_admin, $inp_addcorp_email, $encrypt_password, "2", "1", $token_usr, $created_at));

															// Mailing Default registration
															if (isset($_SESSION['id'])) {
																$MailingConfs = $db->prepare('SELECT * FROM otp_mailing WHERE corpid = ?');
																$MailingConfs->execute(array($corpid));

																if ($MailingConfs->rowCount() == 0) {
																	$Sender = $inp_addcorp_namecorp;

																	$DefaultMailing = $db->prepare('INSERT INTO otp_mailing(corpid, host, transport, port, fqdn, issuer, sendmail, content, content_link, link_custom_btn1, link_custom_btn2, created_at, token) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
																	$DefaultMailing->execute(array($corpid, $GetRelayHost, "SMTPS", "25", $Mailing_CustomFQDN, $Sender, $SendMail, $Mailing_DefaultContent, $Mailing_DefaultContentLink, $Mailing_link_custom_btn1, $Mailing_link_custom_btn2, CurrentDateTime(), GenerateToken()));
																}
															}
														


															// Ajout dans les logs otp_exer si tout est ok lors de la création de l'entreprise
															addLogEventOTP("[SUCCESS] Company " . $inp_addcorp_namecorp .
																" (" . $gen_folder . ") has been correctly created by " . $_SESSION['username']);

															if ($users_max == 0) {
																$users_max = Translator('not_specified');
															}

															$_SESSION['transfered_inp_addcorp_namecorp'] = $inp_addcorp_namecorp;
															$_SESSION['transfered_inp_addcorp_users_max'] = $users_max;
															$_SESSION['transfered_gen_folder'] = $gen_folder;
															$_SESSION['transfered_adresse_complete'] = $adresse_complete;
															$_SESSION['transfered_inp_addcorp_email'] = $inp_addcorp_email;
															$_SESSION['transfered_logo_corp'] = $logo_corp;
															$_SESSION['transfered_users_max_corp'] = $users_max;
															$_SESSION['transfered_expire_date'] = $expiredate;
															$_SESSION['transfered_gen_passwd_admin'] = $gen_passwd_admin;
															$_SESSION['transfered_username_admin'] = $username_admin;

															$Session->setFlash(Translator('company_has_been_created'), "check", "success");
															header('Location: ?page=RecapAddCorp');
															exit();
														} else {
															// Le dossier ou le nom de l'entreprise existe déjà, définir une variable d'erreur appropriée
															$error_addcorp = Translator('folder-already-exists');
														}
													}
												} else {
													$error_addcorp = Translator('email-already-exists2');
												}
											} else {
												$error_addcorp = Translator('company-already-exists');
											}
										} else {
											if ($_SESSION['remaining'] < 0)
												$sentence_remaining = Translator('no_user_available');
											else {
												if ($_SESSION['remaining'] > 1)
													$sentence_remaining = Translator('it_stays') . $_SESSION['remaining'] . Translator('still_availables');
												else
													$sentence_remaining = Translator('it_stays') . $_SESSION['remaining'] . Translator('still_available');
											}
											$error_addcorp = Translator('no_user_available_to_assign') . ' ' . $sentence_remaining;
										}
									} else {
										$error_addcorp = Translator('maximum_number_of_users_too_large');
									}
								} else {
									$error_addcorp = Translator('invalid_email');
								}
							} else {
								$error_addcorp = Translator('name_not_available');
							}
						} else {
							$error_addcorp = Translator('valid_date');
						}
					} else {
						$error_addcorp = Translator('Fill_all_fields');
					}
				}
			}
			?>

			<form method="POST" enctype="multipart/form-data">
				<div class="formaddcorp">
					<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
						<h1 class="h3"><?= $module_page_name ?> <exer class="text-secondary"><i class="far fa-chevron-right chevronexer_openform"></i></exer> <i><?= Translator('Create_company'); ?></i></h1>

						<div class="btn-group">
							<button type="submit" name="submitform_corpclient" id="submitform_corpclient" class="exerotpbtn btn-green btn-sm ripple-effect ripple-white"><i class="far fa-save dwnl_small_addelement_icon"></i><?= Translator('Confirm'); ?></button>
							<a href="/companies.php"><button type="button" class="exerotpbtn btn-red btn-sm ripple-effect ripple-white" style="margin-left:10px;"><i class="far fa-times dwnl_small_addelement_icon"></i> <?= Translator('Cancel'); ?></button></a>
						</div>
					</div>

					<?php if (isset($error_addcorp)) { ?>
						<div class="alert alert-danger" role="alert">
							<i class="fas fa-exclamation-triangle"></i> <?= $error_addcorp ?>
						</div>
					<?php } ?>
					<fieldset class="fieldset_exerotp">
						<legend class="legend_exerotp"><?= Translator('general_info'); ?></legend>
						<b><?= Translator('the_company'); ?></b>
						<hr style="margin-top: -8px; margin-left: 90px;">
						<div class="form-group">
							<label for="inp_addcorp_namecorp"><?= Translator('Company_name'); ?>:<b class="text-danger" title=<?= Translator('Field_required'); ?> data-toggle="tooltip" data-placement="right"><i class="far fa-asterisk"></i></b></label>
							<input type="text" name="inp_addcorp_namecorp" autocomplete="off" class="form-control" id="inp_addcorp_namecorp" value="<?php if (isset($inp_addcorp_namecorp)) {
																																						echo $inp_addcorp_namecorp;
																																					} ?>" placeholder="ex : <?= Translator('my_compagny'); ?>">
							</div>
							<div class="form-group">
								<label for="inp_addcorp_email"><?= Translator('Email'); ?> </label>
								<input type="text" name="inp_addcorp_email" autocomplete="off" class="form-control" id="inp_addcorp_email" value="<?php if (isset($inp_addcorp_email)) {
																																						echo $inp_addcorp_email;
																																					} ?>" placeholder="ex : john.doe@example.com">
							</div>

							<div class="form-group">
								<label for="inp_addcorp_users_max"><?= Translator('Number_licences_issued'); ?> : <b class="text-danger" title=<?= Translator('Field_required'); ?> data-toggle="tooltip" data-placement="right"><i class="far fa-asterisk"></i></b></label>
								<input type="text" name="inp_addcorp_users_max" autocomplete="off" class="form-control" id="inp_addcorp_users_max" value="<?php if (isset($inp_addcorp_users_max)) {
																																								echo $inp_addcorp_users_max;
																																							} else {
																																								echo $_SESSION['remaining'];
																																							} ?>" placeholder="ex : 50">
							</div>

							<div class="form-group">
								<label for="inp_addcorp_expire_date"> <?= Translator('Licence_exp_date'); ?> :</label>
								<input type="date" name="inp_addcorp_expire_date" autocomplete="off" class="form-control" id="inp_addcorp_expire_date">
							</div>

					</fieldset>
					<br>
					<fieldset class="fieldset_exerotp">
						<legend class="legend_exerotp"><?= Translator('Company_logo'); ?>:</legend>

						<div class="col-auto">
							<label class="sr-only" for="inlineFormInputGroup"><?= Translator('logo'); ?><b class="text-danger" title=<?= Translator('Field_required'); ?> data-toggle="tooltip" data-placement="right"><i class="far fa-asterisk"></i></b></label>
							<div class="input-group mb-2">
								<div class="input-group-prepend">
									<div class="input-group-text"><i class="far fa-upload"></i></div>
								</div>

								<input type="file" autocomplete="off" class="form-control" style="height: 44px;" name="import_logo_corp" accept="image/*" onchange="loadFile(event)">
							</div>
						</div>

						<div id="container_preview">
							<label><?= Translator('view'); ?> :</label><br>
							<div class="view_logs_servotp car_exerlogs">
								<img oncontextmenu="return false; return false" ondrag="return false; return false" onmousedown="return false; return false" id="output" class="preview_picture" alt=<?= Translator('not_uploaded'); ?>>
							</div>
							<br>
						</div>
					</fieldset>
					<br><br>
				</div>
			</form>
		<?php }
	} elseif ($page == "InfosCorp") { ?>
		Comming soon...
	<?php } elseif ($page == "RecapAddCorp") {
		if (!isset($_SESSION['transfered_logo_corp'])) {
			header('Location: /companies.php');
			exit();
		}
	?>
		<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
			<h1 class="h3"><?= $module_page_name ?> <exer class="text-secondary"><i class="far fa-chevron-right chevronexer_openform"></i></exer> <i><?= Translator('Company_summary'); ?> <exer class="text-secondary"><i class="far fa-chevron-right chevronexer_openform"></i></exer> <?= $_SESSION['transfered_inp_addcorp_namecorp'] ?></i></h1>

			<div class="btn-group">
				<button type="button" id="btnPrint" name="submitform_corpclient" id="submitform_corpclient" class="exerotpbtn btn-defaultexer btn-sm ripple-effect ripple-white"><i class="far fa-print dwnl_small_addelement_icon"></i> <?= Translator('print'); ?></button>
				<a href="/companies.php"><button type="button" class="exerotpbtn btn-red btn-sm ripple-effect ripple-white" style="margin-left:10px;"><i class="far fa-times dwnl_small_addelement_icon"></i> <?= Translator('Close'); ?></button></a>

				<script>
					var loadFile = function(e) {
						var t = new FileReader,
							n = document.getElementById("container_preview");
						t.onload = function() {
							document.getElementById("output").src = t.result, n.style.display = "block"
						}, t.readAsDataURL(e.target.files[0])
					};

					function printElement(e) {
						var t, n = e.cloneNode(!0);
						(t = document.getElementById("printSection")) || ((t = document.createElement("div")).id = "printSection", document.body.appendChild(t));
						t.innerHTML = "", t.appendChild(n), window.print()
					}
					document.getElementById("btnPrint").onclick = function() {
						printElement(document.getElementById("printThis"))
					};
					var modal_qr_client_exerotp = document.getElementById("viewLargeQR_code"),
						qr_img = document.getElementById("preview_smallqrcode_client_otpexer"),
						large_qrcode_img = document.getElementById("large_qrcode_img"),
						captionText = document.getElementById("legend_qrcode");
					qr_img.onclick = function() {
						modal_qr_client_exerotp.style.display = "block", large_qrcode_img.src = this.src
					};
					var span_qr_close = document.getElementsByClassName("close_btnmodal_exerqr")[0];
					span_qr_close.onclick = function() {
						modal_qr_client_exerotp.style.display = "none"
					};
				</script>
			</div>
		</div>

		<div class="alert alert-success" role="alert">
			<i class="far fa-check"></i>
			<strong><?= Translator('Congratulations'); ?> </strong><?= Translator('company_has_been_created'); ?><br>
		</div>

		<div class="alert alert-info" role="alert">
			<i class="far fa-info-circle"></i>
			<?= Translator('Keep_informations'); ?>
		</div>

		<div id="printThis"><br>
			<fieldset class="border p-2">
				<legend class="w-auto"><?= Translator('details'); ?></legend>
				<div class="container text-left">
					<div class="form-group">
						<div class="row">
							<div class="col-lg-6">
								<h6><b><?= Translator('the_company'); ?></b>
									<hr style="margin-top: -8px; margin-left: 98px;">
								</h6>
								<div class="container">
									<label class="lbl_success_create_corp"><?= Translator('name'); ?> : <i><?= $_SESSION['transfered_inp_addcorp_namecorp'] ?></i></label><br>
									<label class="lbl_success_create_corp"><?= Translator('Email'); ?> : <i><?= $_SESSION['transfered_inp_addcorp_email'] ?></i></label><br>
									<label class="lbl_success_create_corp"><?= Translator('Max_user_cap'); ?> : <i><?= $_SESSION['transfered_users_max_corp'] ?></i></label><br>
									<label class="lbl_success_create_corp"><?= Translator('Expiry_date'); ?> : <i><?= $_SESSION['transfered_expire_date'] ?></i></label><br>
									<label class="lbl_success_create_corp"><?= Translator('System_folder'); ?> : <i><?= $_SESSION['transfered_gen_folder'] ?></i></label><br><br>
								</div>
							</div>
							<div class="col-lg-6">
								<h6><b><?= Translator('Admin_account_auto'); ?></b>
									<hr style="margin-top: -8px; margin-left: 355px;">
								</h6>
								<div class="container">
									<label class="lbl_success_create_corp"><?= Translator('user'); ?> : <?= $_SESSION['transfered_username_admin'] ?> </label><br>
									<label class="lbl_success_create_corp"><?= Translator('Email'); ?> : <?= $_SESSION['transfered_inp_addcorp_email'] ?> </label>
									<hr>
									<label class="lbl_success_create_corp"><?= Translator('Password_conf'); ?>
										<blockquote>
											<?= $_SESSION['transfered_gen_passwd_admin'] ?>
										</blockquote>
									</label>
									<br><label class="lbl_success_create_corp"><?= Translator('Statue_active'); ?></label><br>
								</div>
								<br>
								<?php if ($_SESSION['transfered_logo_corp'] == "not_defined") {
									echo '<b class="text-warning">' . Translator('No_logo') . '</b><br><br>';
								} else { ?>
									<img style="max-height: 90px;" src="<?= $_SESSION['transfered_logo_corp'] ?>" alt=<?= Translator('logo'); ?> <?= $_SESSION['corp_name'] ?>" height="150">
								<?php } ?>
							</div>
						</div>
					</div>
				</div>
			</fieldset>
			<?php
			//Supression de toutes les variables de sessions, puis rediger ensuite
			unset($_SESSION['transfered_login']);
			unset($_SESSION['transfered_issuer']);
			unset($_SESSION['transfered_nametoken']);
			unset($_SESSION['transfered_corpid']);
			unset($_SESSION['transfered_inp_addcorp_namecorp']);
			unset($_SESSION['transfered_gen_folder']);
			unset($_SESSION['transfered_adresse_complete']);
			unset($_SESSION['transfered_inp_addcorp_email']);
			unset($_SESSION['transfered_logo_corp']);
			unset($_SESSION['transfered_addcorp_expire']);
			unset($_SESSION['transfered_gen_passwd_admin']);
			unset($_SESSION['transfered_username_admin']);
			unset($_SESSION['transfered_name_usr']);
			?>
		</div>
	<?php } elseif ($page == "EditUser") { ?>
		<?php
		if (checkLevel() == SUPERVISOR) {
			// Recup_user_filtered_by_tokenid
			$GetOTPUsers = $db->prepare('SELECT * FROM otp_tokens WHERE token = ?');
			$GetOTPUsers->execute(array($TokenID));
			$count_tkn = $GetOTPUsers->rowCount();
		} else {
			// Recup_user_filtered_by_tokenid
			$GetOTPUsers = $db->prepare('SELECT * FROM otp_tokens WHERE token = ? AND corpid = ?');
			$GetOTPUsers->execute(array($TokenID, $_SESSION['corp']));
			$count_tkn = $GetOTPUsers->rowCount();
		}

		$GetOTPUserInfos = $GetOTPUsers->fetch();

		// Get corp Infos
		$ExistTokenCorp = $db->prepare('SELECT * FROM otp_companies WHERE corpid = ?');
		$ExistTokenCorp->execute(array($GetOTPUserInfos['corpid']));
		$countExCorp = $ExistTokenCorp->rowCount();
		$CORP_CE_DATA = $ExistTokenCorp->fetch();


		if (!isset($TokenID) || empty($TokenID) || $count_tkn == 0 || checkLevel() == OPERATOR) {
			header('Location: /companies.php');
			exit();
		}
		?>

		<?php
		if (isset($_POST['EditOTPUser'])) {
			//declaration variables filtrees
			if ($_SESSION['corp'] != "NOT_DEFINED") {
				$register_corp_sql	= $_SESSION['corp'];
			} else {
				$register_corp_sql	= $GetOTPUserInfos['corpid'];
			}

			$RecupNameCorpInfos = $db->prepare('SELECT * FROM otp_companies WHERE corpid = ?');
			$RecupNameCorpInfos->execute(array($register_corp_sql));
			$client_corp = $RecupNameCorpInfos->fetch();

			$login		= htmlspecialchars($_POST['login']); //champ nom_utilisateur
			$client		= htmlspecialchars($client_corp['folder']); //champ client

			if (empty($_POST['nametoken'])) {
				$nametoken 	= 	htmlspecialchars($_POST['login']); //champ secrete_token vide, alors login par defaut
			} else {
				$nametoken 	= 	remove_accents(htmlspecialchars($_POST['nametoken'])); //champ secrete_token
			}

			if (!isset($_POST['serialnumber_card']) and empty($_POST['serialnumber_card'])) {
				$serialnumber_card = "N/A";
			} else {
				$serialnumber_card = htmlspecialchars($_POST['serialnumber_card']);
			}

			if (empty($_POST['issuer'])) {
				if ($_SESSION['corp'] != "NOT_DEFINED") {
					$issuer 	= 	$_SESSION['corp_name'];
				} else {
					$issuer 	= 	htmlspecialchars($client_corp['name']);
				}
			} else {
				$issuer 		= 	remove_accents(htmlspecialchars($_POST['issuer']));
			}

			// Pour rendre l'Email pas obligatoire
			$valid_email = true;
			if (!empty($_POST['email_usrcorp'])) {
				if (filter_var($_POST['email_usrcorp'], FILTER_VALIDATE_EMAIL)) {
					$valid_email = true;
					$email_usrcorp 	= 	htmlspecialchars($_POST['email_usrcorp']);
				} else {
					$error = Translator('invalid_email');
					$email_usrcorp 	= "N/A";
					$valid_email = false;
				}
			} else {
				$email_usrcorp 	= "N/A";
			}

			if (isset($_POST['login']) and $valid_email) {
				if (!empty($_POST['login'])) {
					//check if not exist username on otp datatbase
					$requusername = $db->prepare("SELECT * FROM otp_tokens WHERE login = ? AND corpid = ? AND id != ?");
					$requusername->execute(array($login, $client_corp['corpid'], $GetOTPUserInfos['id']));
					$usernameexist = $requusername->rowCount();
					if ($usernameexist == 0) {
						if (($login == "_") || ($login == ".") || (($login == "_.") && ($login == "_."))) {
							$error = Translator('characters_not_allowed');
						} elseif ((_s_has_special_chars($login) != 1)) {
							if ($_POST['login'] != "skel") {
								if ($_POST['issuer'] != "skel") {
									// transformation des variables en minuscule et rempalcement des espaces par des underscores
									$array_spaces 	= 	array(" ", " ", " ", "'");
									$login_af 		= 	strtolower(str_replace($array_spaces, "_", $login));
									$client_af 		= 	strtolower(str_replace($array_spaces, "_", $client));
									$issuer_af 		= 	str_replace($array_spaces, "_", $issuer);
									$nametoken_af 	= 	str_replace($array_spaces, "_", $nametoken);
									$token 			= 	generateToken(9999);
									$externalToken 	= 	generateToken(9999);

									$nomclient 		=	$client_af;
									$nomuser 		= 	$login_af;

									$TotalAllMaxToken = $db->prepare('SELECT * FROM otp_tokens WHERE corpid = ?');
									$TotalAllMaxToken->execute(array($client_corp['corpid']));
									$CountExistTokenByCorp = $TotalAllMaxToken->rowCount();

									if (($client_corp['users_max'] - $CountExistTokenByCorp) >= 0) {
										// Modification dossier de l'utilisateur (si renommage)
										$CurrentOTPLogin = $GetOTPUserInfos['login'];
										if ($CurrentOTPLogin != $_POST['login']) {
											$userFolderPath = '/home/' . $nomclient . '/' . $CurrentOTPLogin;
											$UpdateNameOfuserFolder = shell_exec("sudo mv " . $userFolderPath . " /home/" . $nomclient . "/" . $login_af);
											$newUserFolderPath = "/home/" . $nomclient . "/" . $login_af;
										} else {
											$newUserFolderPath = '/home/' . $nomclient . '/' . $CurrentOTPLogin;
										}

										// Remplacement du secret en cas d'édition
										if (isset($_POST['secretOTPToken'])) {
											$secretOTPToken = strtoupper(htmlspecialchars($_POST['secretOTPToken']));
											if (!empty($secretOTPToken)) {
												if (preg_match('/[\'^£$%&*()}{@#~?><>,|=_+¬-]/', $secretOTPToken)) {
													$Session->setFlash(Translator('key_base32'), "close", "error");
													header('Location: ' . $_SERVER["REQUEST_URI"]);
													exit();
												} elseif (preg_match('/[a-z]/', $secretOTPToken)) {
													$Session->setFlash(Translator('key_base32_lowercase'), "close", "error");
													header('Location: ' . $_SERVER["REQUEST_URI"]);
													exit();
												} elseif (preg_match('/[0,1,8,9]/', $secretOTPToken)) {
													$Session->setFlash(Translator('key_base32_number'), "close", "error");
													header('Location: ' . $_SERVER["REQUEST_URI"]);
													exit();
												} else {
													$GetCurrentTOTPSecret 	= trim(shell_exec('head -1 ' . $newUserFolderPath . '/.exer_authenticator'));
													$UpdateTOTPSecret		= shell_exec("sed -i 's/" . $GetCurrentTOTPSecret . "/" . $secretOTPToken . "/g' " . $newUserFolderPath . "/.exer_authenticator");

													// Update QR Code
													$escaped_command = escapeshellcmd('sed -n "1 p" ' . $newUserFolderPath . '/.exer_authenticator');
													$GetExistToken = shell_exec($escaped_command);

													$secretkey = $GetExistToken;

													if ($login_af != $nametoken_af) {
														$set = 'otpauth://totp/' . str_replace(' ', '%20', trim($nametoken)) . '?secret=' . str_replace(' ', '%20', trim($secretkey)) . '&issuer=' . str_replace(' ', '%20', trim($issuer)) . '';
													} else {
														$set = 'otpauth://totp/' . str_replace(' ', '%20', trim($login)) . '?secret=' . str_replace(' ', '%20', trim($secretkey)) . '&issuer=' . str_replace(' ', '%20', trim($issuer)) . '';
													}

													// génération du qr code dans le fichier utilisateur
													$codeText = $set;
													ob_start();
													QRCode::png($codeText, null, QR_ECLEVEL_L, 8);
													$imageString = base64_encode(ob_get_contents());
													ob_end_clean();

													$base64_qrcode = "data:image/png;base64,$imageString";
													$ProtectQRCode =  EncodePassword($base64_qrcode);

													// Mise a jour du QR code dans la base 'otp_tokens'
													$UpdateQRCode = $db->prepare('UPDATE otp_tokens SET qr_code = ? WHERE token = ?');
													$UpdateQRCode->execute(array($ProtectQRCode, $TokenID));
												}
											} else {
												$Session->setFlash(Translator('Private_key'), "close", "error");
												header('Location: ' . $_SERVER["REQUEST_URI"]);
												exit();
											}
										}


										// insertion des données dans la base 'otp_tokens'
										$insert_req = $db->prepare("UPDATE otp_tokens SET userid = ?, login = ?, email = ?, issuer = ?, key_name = ?, serialnumber_card = ?, externalToken = ? WHERE token = ?");
										$insert_req->execute(array($_SESSION['id'], $login_af, $email_usrcorp, $issuer, $nametoken, $serialnumber_card, $externalToken, $TokenID));

										addLogEventOTP("[SUCCESS] Account " . $_SESSION['username'] . " changed the details of OTP user " . $login_af);
										$Session->setFlash(Translator('Save_change_otp'), "check", "success");
										header('Location: /companies.php?page=ViewUser&TokenID=' . $TokenID);
										exit();
									} else {
										$error = Translator('no_more_license');
									}
								} else {
									$error = Translator('name_not_available');
								}
							} else {
								$error = Translator('name_not_available');
							}
						} else {
							$error = Translator('characters_not_allowed');
						}
					} else {
						$error = Translator('user_already_exists');
					}
				} else {
					$error = Translator('Fill_all_fields');
				}
			}
		}

		?>



		<form method="POST" name="FormEditOTPUser">

			<div class="formaddcorp">
				<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
					<h1 class="h3"><?= $module_page_name ?> <exer class="text-secondary"><i class="far fa-chevron-right chevronexer_openform"></i></exer> <i><?= Translator('Edit_user'); ?><strong><?= $GetOTPUserInfos['login'] ?></strong></i></h1>

					<?php if (checkLevel() != OPERATOR) { ?>
						<div class="btn-group">
							<button type="submit" name="EditOTPUser" id="EditOTPUser" class="exerotpbtn btn-green btn-sm ripple-effect ripple-white"><i class="far fa-save dwnl_small_addelement_icon"></i> <?= Translator('Confirm'); ?></button>
							<a href="<?= $_SERVER['HTTP_REFERER'] ?>"><button type="button" class="exerotpbtn btn-red btn-sm ripple-effect ripple-white" style="margin-left:10px;"><i class="far fa-times dwnl_small_addelement_icon"></i><?= Translator('Undo_changes'); ?></button></a>
						</div>
					<?php } else {
						header('Location: /companies.php');
					}  ?>
				</div>

				<?php if (isset($error)) { ?>
					<div class="alert alert-danger" role="alert">
						<i class="fas fa-exclamation-triangle"></i> <?= $error ?>
					</div>
				<?php } ?>

				<div class="alert alert-info">
					<i class="fal fa-building"></i> <strong><?= Translator('Selected_company'); ?></strong> <?= $CORP_CE_DATA['name'] ?>
				</div>

				<div id="submit_formfirewall_user">
					<fieldset class="fieldset_exerotp">
						<legend class="legend_exerotp"><?= Translator('General'); ?></legend>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="login"><?= Translator('user'); ?> : <b class="text-danger" title=<?= Translator('Field_required'); ?> data-toggle="tooltip" data-placement="right"><i class="far fa-asterisk"></i></b></label>
									<input type="text" onkeydown="if(event.keyCode==32) return false;" name="login" autocomplete="off" class="form-control" id="login" value="<?php if (isset($GetOTPUserInfos['login'])) {
																																													echo $GetOTPUserInfos['login'];
																																												} else {
																																													echo $login;
																																												} ?>" placeholder="ex : john.doe">
								</div>
							</div>

							<div class="col-md-6">
								<div class="form-group">
									<label for="login"><?= Translator('Email'); ?> : </label>
									<input type="email" name="email_usrcorp" autocomplete="off" class="form-control" id="email_usrcorp" value="<?php if (isset($GetOTPUserInfos['email'])) {
																																					if ($GetOTPUserInfos['email'] != "N/A") {
																																						echo $GetOTPUserInfos['email'];
																																					}
																																				} else {
																																					echo $email_usrcorp;
																																				} ?>" placeholder="ex : who@where">
								</div>
							</div>
						</div>


						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="issuer"><?= Translator('Secret_key_name'); ?> : </label>
									<input type="text" name="nametoken" autocomplete="off" class="form-control" id="emmet_inp_token" value="<?php if (isset($GetOTPUserInfos['key_name'])) {
																																				echo $GetOTPUserInfos['key_name'];
																																			} else {
																																				echo $keyName;
																																			} ?>" placeholder="ex : <?= Translator('my_security_key'); ?>">
								</div>
							</div>

							<div class="col-md-6">
								<div class="form-group">
									<?php
									// Get super secret OTP token

									$nomclient	=	$CORP_CE_DATA['folder'];
									$nomuser	=	$GetOTPUserInfos['login'];
									$filename 	= 	"/home/$nomclient/$nomuser/.exer_authenticator";

									if (file_exists($filename)) {
										$handle = fopen('/home/' . $nomclient . '/' . $nomuser . '/.exer_authenticator', "r");
										if ($handle) {
											if (($buffer = fgets($handle)) != "e") {
												$secretkey = rtrim($buffer);
												$UserOTPSecreteKey = $secretkey;
											}
											fclose($handle);
										}
									} else {
										$UserOTPSecreteKey = Translator('unable_my_secret_key');
									}
									?>

									<label for="issuer"><?= Translator('Secret_key'); ?> : </label>
									<input type="text" name="secretOTPToken" autocomplete="off" value="<?php if (isset($UserOTPSecreteKey)) {
																											echo $UserOTPSecreteKey;
																										} else {
																											echo $inoutUserOTPSecreteKey;
																										} ?>" placeholder="ex : ZF3BHHVZDBOOOGX4ZNAPUHP5PA" class="form-control" id="secretkey">
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="issuer"><?= Translator('Issuer_default'); ?> : </label>
									<input type="text" name="issuer" autocomplete="off" value="<?php if (isset($GetOTPUserInfos['issuer'])) {
																									echo $GetOTPUserInfos['issuer'];
																								} else {
																									echo $issuer;
																								} ?>" placeholder="ex : <?= Translator('my_compagny'); ?>" class="form-control" id="issuer">
								</div>
							</div>

							<div class="col-md-6">
								<div class="form-group">
									<label for="serialnumber_card"><?= Translator('NFC_series_number'); ?> : </label>
									<input type="text" name="serialnumber_card" autocomplete="off" class="form-control" id="serialnumber_card" value="<?php if (isset($GetOTPUserInfos['serialnumber_card'])) {
																																							echo $GetOTPUserInfos['serialnumber_card'];
																																						} else {
																																							echo $serialnumber_card;
																																						} ?>" placeholder="ex : 8659609XXXXXX">
								</div>
							</div>
						</div>
					</fieldset>
					<br><br>
				</div>
			</div>
		</form>

	<?php } elseif ($page == "ViewUser") { ?>
		<?php
		if (checkLevel() == SUPERVISOR || checkLevel() == OPERATOR && $_SESSION['corp'] == "NOT_DEFINED") {
			// Recup_user_filtered_by_tokenid
			$recup_tokens = $db->prepare('SELECT * FROM otp_tokens WHERE token = ?');
			$recup_tokens->execute(array($TokenID));
			$count_tkn = $recup_tokens->rowCount();
		} else {
			// Recup_user_filtered_by_tokenid
			$recup_tokens = $db->prepare('SELECT * FROM otp_tokens WHERE token = ? AND corpid = ?');
			$recup_tokens->execute(array($TokenID, $_SESSION['corp']));
			$count_tkn = $recup_tokens->rowCount();
		}

		$tkn_rec = $recup_tokens->fetch();
		?>
		<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
			<h1 class="h3"><?= $module_page_name ?> <?php if (checkLevel() == SUPERVISOR || checkLevel() == OPERATOR && $_SESSION['corp'] == "NOT_DEFINED") { 
									$recup_corp_X = $db->prepare('SELECT * FROM otp_companies WHERE corpid = ?');
									$recup_corp_X->execute(array($tkn_rec['corpid']));
									$crp_data_X = $recup_corp_X->fetch();
				 ?>
				<exer class='text-secondary'><i class='far fa-chevron-right chevronexer_openform'></i></exer> <a href="?page=ManageCorp&TokenID=<?= $crp_data_X['token'] ?>"><?= $crp_data_X['name'] ?></a> <?php } ?> <exer class="text-secondary"><i class="far fa-chevron-right chevronexer_openform"></i></exer> <i><?= $tkn_rec['login'] ?></i></h1>

			<?php if (checkLevel() != OPERATOR) { ?>
				<a href="/companies.php?page=EditUser&TokenID=<?= $TokenID ?>"><button class="exerotpbtn btn-white btn-sm ripple-effect ripple-dark" title=<?= Translator('edit_user_file'); ?>><i class="far fa-pen dwnl_small_addelement_icon"></i> <?= Translator('Edit'); ?></button></a>
			<?php } ?>

			<!-- Modal_diag otp user -->
			<div class="modal fade" id="diag_otpconnection" tabindex="-1" role="dialog" aria-labelledby="lblconfirm_client" aria-hidden="true">
				<script src="/assets/scripts/toolset/vendor.js"></script>
				<div class="modal-dialog modal-lg" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title" id="lblconfirm_client"><i class="far fa-stethoscope"></i> <?= Translator('Diagnostic'); ?></h5>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true"><i class="far fa-times"></i></span>
							</button>
						</div>

						<style>
							.card-exer.clock {
								min-height: 7rem !important;
								height: 7rem !important;
							}

							.s6q00 {
								padding-left: 1.7rem !important;
								padding-right: 1.7rem !important;
							}
						</style>

						<div class="modal-body">
							<div class="row">
								<div class="col-md-12 s6q00">
									<label><?= Translator('Diag_OTP_connection'); ?></label>

									<div class="alert alert-warning" role="alert">
										<i class="fas fa-exclamation-triangle"></i><?= Translator('Note_codes_displayed'); ?>
									</div>
								</div>
								<div class="col-md-6">
									<div class="card-exer clock text-center">
										<div class="text-secondary">
											<?= Translator('Server_time'); ?>

										</div>
										<h1>
											<div id="GetHoureTimer">
												<div class="loader"></div>
											</div>
											<script type="text/javascript">
												setInterval('GetHoureTimer()', 1000);

												function GetHoureTimer() {
													$('#GetHoureTimer').load('/modules/sysinfos.php?ElementGet=TimeNow');
												}
											</script>
										</h1>
									</div>
								</div>
								<div class="col-md-6">
									<div class="card-exer clock text-center">
										<div class="text-secondary">
											<?= Translator('Computer_time'); ?>
										</div>
										<h1>
											<div id="time"></div>
											<script>
												function checkTime(i) {
													if (i < 10) {
														i = "0" + i;
													}
													return i;
												}

												function startTime() {
													var today = new Date();
													var h = today.getHours();
													var m = today.getMinutes();
													var s = today.getSeconds();

													m = checkTime(m);
													s = checkTime(s);
													document.getElementById('time').innerHTML = h + ":" + m + ":" + s;
													t = setTimeout(function() {
														startTime()
													}, 500);
												}
												startTime();
											</script>
										</h1>
									</div>
								</div>
								<div class="col-md-12 s6q00">
									<hr>
									<?php
									$recup_corp = $db->prepare('SELECT * FROM otp_companies WHERE corpid = ?');
									$recup_corp->execute(array($tkn_rec['corpid']));
									$crp_data = $recup_corp->fetch();

									$recup_folder_corp_client = $db->prepare('SELECT * FROM otp_companies WHERE corpid = ?');
									$recup_folder_corp_client->execute(array($tkn_rec['corpid']));
									$crp_folder = $recup_folder_corp_client->fetch();

									$nomclient	=	$crp_folder['folder'];
									$nomuser	=	$tkn_rec['login'];

									$filename = "/home/$nomclient/$nomuser/.exer_authenticator";

									if (file_exists($filename)) {
										$handle = fopen('/home/' . $nomclient . '/' . $nomuser . '/.exer_authenticator', "r");
										if ($handle) {
											if (($buffer = fgets($handle)) != "e") {
												$secretkey = rtrim($buffer); ?>
												<input type="hidden" size="50" value="<?= $secretkey ?>" id="secret" onchange="updateOtp();return false;" onKeyup="updateOtp();return false;" onClick="updateOtp();return false;" required="">

												<div class="row">
													<div class="col-md-6">
														<h4>OTP</h4>
														<div class="text-center" style="min-width:250px">
															<b style="color: #1197ef; float: right; font-size: large; display: flex; margin-right: -2.5rem;">
																<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="height: 28px; display: block; position: absolute;" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid">
																	<g transform="translate(50 50)">
																		<g ng-attr-transform="scale(0.62)">
																			<g transform="translate(-50 -50)">
																				<path fill="#1197ef" stroke="#1197ef" stroke-width="3" d="M50,14c19.85,0,36,16.15,36,36S69.85,86,50,86S14,69.85,14,50S30.15,14,50,14 M50,10c-22.091,0-40,17.909-40,40 s17.909,40,40,40s40-17.909,40-40S72.091,10,50,10L50,10z"></path>
																				<path fill="#137cc1" d="M52.78,42.506c-0.247-0.092-0.415-0.329-0.428-0.603L52.269,40l-0.931-21.225C51.304,18.06,50.716,17.5,50,17.5 s-1.303,0.56-1.338,1.277L47.731,40l-0.083,1.901c-0.013,0.276-0.181,0.513-0.428,0.604c-0.075,0.028-0.146,0.063-0.22,0.093V44h6 v-1.392C52.925,42.577,52.857,42.535,52.78,42.506z" transform="rotate(135.355 50 50)">
																					<animateTransform attributeName="transform" type="rotate" repeatCount="indefinite" values="0 50 50;360 50 50" keyTimes="0;1" dur="4.166666666666666s"></animateTransform>
																				</path>
																				<path fill="#1685cf" d="M58.001,48.362c-0.634-3.244-3.251-5.812-6.514-6.391c-3.846-0.681-7.565,1.35-9.034,4.941 c-0.176,0.432-0.564,0.717-1.013,0.744l-15.149,0.97c-0.72,0.043-1.285,0.642-1.285,1.383c0,0.722,0.564,1.321,1.283,1.363 l15.153,0.971c0.447,0.027,0.834,0.312,1.011,0.744c1.261,3.081,4.223,5.073,7.547,5.073c2.447,0,4.744-1.084,6.301-2.975 C57.858,53.296,58.478,50.808,58.001,48.362z M50,53.06c-1.688,0-3.06-1.373-3.06-3.06s1.373-3.06,3.06-3.06s3.06,1.373,3.06,3.06 S51.688,53.06,50,53.06z" transform="rotate(213.839 50 50)">
																					<animateTransform attributeName="transform" type="rotate" repeatCount="indefinite" values="0 50 50;360 50 50" keyTimes="0;1" dur="16.666666666666664s"></animateTransform>
																				</path>
																			</g>
																		</g>
																	</g>
																</svg>
																<span style="min-width:5em" id="updatingIn"><?= Translator('Calcul'); ?></span>
															</b>
															<h1 class="display-4" id="otp"></h1>
														</div>

														<h4><?= Translator('Info'); ?></h4>
														<table class="table table-striped table-sm table-bordered">
															<tr>
																<td>Unix époque / 30</td>
																<td>
																	<span class="label label-default" id='epoch'></span>
																</td>
															</tr>
															<tr>
																<td><?= Translator('HMAC'); ?></td>
																<td>
																	<span class="label label-default" id='hmac'></span>
																</td>
															</tr>
															<tr>
																<td><?= Translator('Seed_HEX'); ?></td>
																<td>
																	<span class="label label-default" id="secretHex"></span>
																</td>
															</tr>
															<tr>
																<td><?= Translator('Lenght_HEX'); ?></td>
																<td>
																	<span id="secretHexLength"></span>
																</td>
															</tr>
														</table>
													</div>
													<div class="col-md-6">
														<h4><?= Translator('Time_mark'); ?></h4>
														<span style="float:right; width:10rem">
															<label class="uifieldinputvt">
																<input size="2" min="1" max="50" type="number" id="skew" class="form-control" onchange="updateOtp();return false;" onKeyup="updateOtp();return false; " onClick="updateOtp();return false; " value="4" placeholder=" " required="">
																<span><?= Translator('Limit_bias'); ?></span>
																<h1>&nbsp </h1>
															</label>
														</span>
														<div class="label label-primary" id="otp2"></div>

													</div>
												</div>
									<?php
											}
											fclose($handle);
										}
									} else {
										echo "<hr>";
										echo "<div class='text-center'>";
										echo "<b class='text-danger'>" . Translator('unable_my_secret_key') . "</b>";
										echo "</div>";
									}
									?>
								</div>
							</div>
						</div>

						<div class="modal-footer">
							<form method="POST">
								<button type="button" class="exerotpbtn btn-white ripple-effect ripple-dark" data-dismiss="modal"><?= Translator('Close'); ?></button>
							</form>
						</div>
					</div>
				</div>
				<script src="/assets/scripts/toolset/app.js"></script>
			</div>
		</div>

		<?php if (isset($error)) { ?>
			<div class="alert alert-danger" role="alert">
				<i class="fas fa-exclamation-triangle"></i> <?= $error_recupdir ?>
			</div>
		<?php } ?>

		<?php
		if ($count_tkn == 0) { ?>
			<div class="alert alert-danger" role="alert">
				<i class="fas fa-exclamation-triangle"></i><?= Translator('No_user_has_been_found'); ?>
			</div>
		<?php } else { ?>
			<div class="row">
				<div class="col-lg-3 text-center">
					<?php
					if (strpos($tkn_rec['qr_code'], 'data:image/png') !== false) {
						$ReturnQRCode = $tkn_rec['qr_code'];
					} else {
						$ReturnQRCode = DecodePassword($tkn_rec['qr_code']);
					}
					?>
					<img oncontextmenu="return false; return false" ondrag="return false; return false" onmousedown="return false; return false" id="preview_smallqrcode_client_otpexer" style="padding: 0;" src="<?= $ReturnQRCode ?>" alt="QR Code d'authentification de '<?= $tkn_rec['login'] . "'\n" ?>Si le QR code n'est pas généré, contactez Exer" class="img-thumbnail qr_preview_imlg_show"><br>
					<!-- Preview QR_Code_OTPEXER_client -->
					<div id="viewLargeQR_code" class="modal_viewLargeQR_code">
						<span class="close_btnmodal_exerqr" title=<?= Translator('Close_QR_code'); ?>>&times;</span>
						<img oncontextmenu="return false; return false" ondrag="return false; return false" onmousedown="return false; return false" class="modal_viewLargeQR_code__content" id="large_qrcode_img">
						<div id="legend_qrcode"><?= Translator('View_QR_auth_code'); ?><?= $tkn_rec['login'] ?>"</div>
					</div>

					<script>
						var modal_qr_client_exerotp = document.getElementById("viewLargeQR_code");
						var qr_img = document.getElementById("preview_smallqrcode_client_otpexer");
						var large_qrcode_img = document.getElementById("large_qrcode_img");
						var captionText = document.getElementById("legend_qrcode");
						qr_img.onclick = function() {
							modal_qr_client_exerotp.style.display = "block";
							large_qrcode_img.src = this.src;
						}

						var span_qr_close = document.getElementsByClassName("close_btnmodal_exerqr")[0];

						span_qr_close.onclick = function() {
							modal_qr_client_exerotp.style.display = "none";
						}
					</script>

					<figcaption class="figure-caption text-center"><?= Translator('QR_auth_code'); ?></figcaption>
					<hr>
					<div class="text-left">
						<label class="w-100">
							<b><?= Translator('Name_key'); ?></b> <?= $tkn_rec['key_name'] ?><br>
							<b><?= Translator('Issuer'); ?></b> <?= $tkn_rec['issuer'] ?><br>
							<b><?= Translator('Email'); ?></b> <?php if ($tkn_rec['email'] == "N/A") {
																	echo "N/A";
																} else {
																	echo "<a title=" . Translator('Send_a_message_to') . $tkn_rec['email'] . "' href='mailto://" . $tkn_rec['email'] . "'>" . $tkn_rec['email'] . "</a>";
																} ?><br><br>
							<b><?= Translator('Client_company2'); ?></b> <?= $crp_data['name'] ?><br>
							<b><?= Translator('User_name'); ?> :</b> <?= $tkn_rec['login'] ?>
							<hr>
						</label>

						<?php
						if (isset($_POST['del_this_usrcorp__' . $tkn_rec['token']])) {
							unset($_SESSION['token_access_deleteusrcorp']);
							unset($_SESSION['login_access_deleteusrcorp']);
							$_SESSION['token_access_deleteusrcorp'] = $tkn_rec['token'];
							$_SESSION['login_access_deleteusrcorp']	= $tkn_rec['login'];

							header('Location: inc/class.actions.php?VerbAction=DeleteUserCorp');
							exit();
						}

						if (isset($_POST['change_token_this_user'])) {
							unset($_SESSION['ch_token_usr']);
							unset($_SESSION['ch_token_tk']);
							$_SESSION['ch_token_usr'] 	= $tkn_rec['login'];
							$_SESSION['ch_token_tk'] 	= $tkn_rec['token'];

							if ($_SESSION['level'] == "3") {
								header('Location: inc/class.changesecret.php?Method=EditSpecificUser&CorpID=' . $tkn_rec['corpid'] . '&TokenID=' . $tkn_rec['token']);
								exit();
							} else {
								header('Location: inc/class.changesecret.php');
								exit();
							}
						}
						?>

						<!-- Modal share_public_link -->
						<div class="modal fade" id="share_public_link" tabindex="-1" role="dialog" aria-labelledby="share_public_link" aria-hidden="true">
							<div class="modal-dialog modal-lg" role="document">
								<div class="modal-content">
									<div class="modal-header">
										<h5 class="modal-title" id="share_public_link"><i class="far fa-share-alt"></i> <?= Translator('Share_public_link'); ?></h5>
										<button type="button" class="close" data-dismiss="modal" aria-label="Close">
											<span aria-hidden="true"><i class="far fa-times"></i></span>
										</button>
									</div>

									<div class="modal-body">
										<label class="font-weight-light alert alert-light" style="color: black; margin: -15px;">
											<?= Translator('Auto_retri_send_mail'); ?>
										</label>
										<hr>
										<?php
										$CustomFQDN = $db->prepare('SELECT fqdn FROM otp_mailing WHERE corpid = ?');
										if ($_SESSION['corp'] == "NOT_DEFINED") {
											$CustomFQDN->execute(array($tkn_rec['corpid']));
										} else {
											$CustomFQDN->execute(array($_SESSION['corp']));
										}
										$ClientFQDN = $CustomFQDN->fetch();

										$ExternalShareForm = "/shareExternal.php?shareID=" . "{$tkn_rec['externalToken']}";

										if (!empty($ClientFQDN[0])) {
											$ExternalAccessLink = $ClientFQDN[0] . $ExternalShareForm;
										} else {
											$ExternalAccessLink = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://{$_SERVER['HTTP_HOST']}" . $ExternalShareForm;
										}

										if (isset($_POST['submit_message'])) {
											$recup_mail = htmlspecialchars($_POST['send_email_add']);
											if (!empty($_POST['send_email_add'])) {
												if (filter_var($_POST['send_email_add'], FILTER_VALIDATE_EMAIL)) {
													/** 
													 *	Send mail 
													 **/
													$GetCompany = $db->prepare('SELECT * FROM otp_companies WHERE corpid = ?');
													$GetCompany->execute(array($tkn_rec['corpid']));

													if ($GetCompany->rowCount() == 1) {
														$Company = $GetCompany->fetch();

														$CorpName = $Company['name'];

														$CustomFQDN = $db->prepare('SELECT fqdn FROM otp_mailing WHERE corpid = ?');
														if ($_SESSION['corp'] == "NOT_DEFINED") {
															$CustomFQDN->execute(array($tkn_rec['corpid']));
														} else {
															$CustomFQDN->execute(array($_SESSION['corp']));
														}
														$ClientFQDN = $CustomFQDN->fetch();

														$ExternalShareForm = "/shareExternal.php?shareID=" . "{$tkn_rec['externalToken']}";

														if (!empty($ClientFQDN[0])) {
															$ExternalAccessLink = $ClientFQDN[0] . $ExternalShareForm;
														} else {
															$ExternalAccessLink = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://{$_SERVER['HTTP_HOST']}" . $ExternalShareForm;
														}

														if (isset($tkn_rec['login'])) {
															$OTPVar = array(
																'username'  =>  $tkn_rec['login'],
																'email'     =>  $recup_mail,
																'link'      =>  $ExternalAccessLink,
																'company'   =>  $CorpName
															);

															SendMail($recup_mail, false, $Company['corpid'], $OTPVar);

															addLogEventOTP("[INFORMATION] A welcome email has been sent to " . $recup_mail . " by " . $_SESSION['username']);
															$Session->setFlash(Translator('the_message_has_been_send') . $recup_mail . Translator('please_verify_spam'), "check", "success");
															header('Location: ' . $_SERVER["REQUEST_URI"]);
															exit();
														} else {
															$Session->setFlash(Translator('No_user_match'), "close", "error");
															header('Location: ' . $_SERVER["REQUEST_URI"]);
															exit();
														}
													} else {
														$Session->setFlash(Translator('No_business_found'), "close", "error");
														header('Location: ' . $_SERVER["REQUEST_URI"]);
														exit();
													}
												} else {
													$Session->setFlash(Translator('invalid_email'), "close", "error");
													header('Location: ' . $_SERVER["REQUEST_URI"]);
													exit();
												}
											} else {
												$Session->setFlash(Translator('specify_address_mail'), "close", "error");
												header('Location: ' . $_SERVER["REQUEST_URI"]);
												exit();
											}
										}
										?>
										<?= Translator('Single_use_URL'); ?>
										<div class="form-group">
											<div class="row">
												<div class="col-md-11">
													<input title=<?= Translator('copy_url'); ?> type="text" autocomplete="off" class="form-control" readonly value="<?= $ExternalAccessLink ?>">
												</div>

												<div class="col-md-1">
													<a style="margin-left: -20px;" href="<?= $ExternalAccessLink ?>" target="_blank" name="submit_message" class="exerotpbtn btn-defaultexer btn-fab-mini ripple-effect ripple-white" title=<?= Translator('open_link'); ?>><i class="fas fa-external-link" style="position: relative; left: 2px; top: 2px;"></i></a>
												</div>
											</div>
										</div>
										<form method="POST">
											<?= Translator('Send_form_mail'); ?>
											<div class="form-group">
												<div class="row">
													<div class="col-md-11">
														<input type="email" name="send_email_add" autofocus="true" autocomplete="off" class="form-control" placeholder=<?= Translator('Email'); ?> value="<?php if ($tkn_rec['email'] != "N/A") {
																																																				echo $tkn_rec['email'];
																																																			} ?>">
													</div>

													<div class="col-md-1">
														<button style="margin-left: -20px;" type="submit" name="submit_message" class="exerotpbtn btn-green btn-fab-mini ripple-effect ripple-white" title=<?= Translator('Send_a_message'); ?>><i class="fas fa-paper-plane" style="position: relative; left: -1px; top: -3px;"></i></button>
													</div>
												</div>
											</div>
										</form>
									</div>

									<div class="modal-footer">
										<form method="POST">
											<button type="button" class="exerotpbtn btn-white ripple-effect ripple-dark" data-dismiss="modal"><?= Translator('Close'); ?></button>
										</form>
									</div>
								</div>
							</div>
						</div>

						<?php if (checkLevel() == ADMIN || checkLevel() == SUPERVISOR) { ?>
							<!-- Modal_confirm changeToken corp.client -->
							<div class="modal fade" id="confirm_changekey" tabindex="-1" role="dialog" aria-labelledby="lblconfirm_client" aria-hidden="true">
								<div class="modal-dialog modal-lg" role="document">
									<div class="modal-content">
										<div class="modal-header">
											<h5 class="modal-title" id="lblconfirm_client"><i class="far fa-redo"></i> <?= Translator('Renew_secret'); ?></h5>
											<button type="button" class="close" data-dismiss="modal" aria-label="Close">
												<span aria-hidden="true"><i class="far fa-times"></i></span>
											</button>
										</div>

										<div class="modal-body">
											<label>
												<?= Translator('Sure_renew_secret_key'); ?> <b><?= $tkn_rec['key_name'] ?></b> ?<br>
												<b class="text-danger"><?= Translator('Reinstal_key_user'); ?></b>
											</label>
										</div>

										<div class="modal-footer">
											<form method="POST">
												<button type="button" class="exerotpbtn btn-defaultexer ripple-effect ripple-white" data-dismiss="modal"><?= Translator('Cancel'); ?></button>
												<button type="submit" name="change_token_this_user" class="exerotpbtn btn-red ripple-effect ripple-white"><?= Translator('Confirm'); ?></button>
											</form>
										</div>
									</div>
								</div>
							</div>

							<!-- Modal_confirm suppression user_corp -->
							<?php $rand_client_modal = generateToken(9999); ?>
							<div class="modal fade" id="confirm_delete_thisclient" tabindex="-1" role="dialog" aria-labelledby="lblconfirm_delete_thisclient" aria-hidden="true">
								<div class="modal-dialog modal-lg" role="document">
									<div class="modal-content">
										<div class="modal-header">
											<h5 class="modal-title" id="lblconfirm_delete_thisclient"><i class="far fa-trash-alt"></i><?= Translator('Delete_user'); ?></h5>
											<button type="button" class="close" data-dismiss="modal" aria-label="Close">
												<span aria-hidden="true"><i class="far fa-times"></i></span>
											</button>
										</div>

										<div class="modal-body">
											<label><?= Translator('Confirm_removal_user'); ?><b><?= $tkn_rec['login'] ?></b> ?</label>
										</div>

										<div class="modal-footer">
											<?php
											if (isset($_POST['del_this_usrcorp'])) {
												unset($_SESSION['token_access_deleteusrcorp']);
												unset($_SESSION['login_access_deleteusrcorp']);
												unset($_SESSION['redirect_url']);
												$HideToken = $_SERVER['QUERY_STRING'];
												$replacementChar = '';
												$limit = 13;
												$replacementString = str_repeat($replacementChar, strlen($HideToken) - $limit);
												$_SESSION['redirect_url']	= $_SERVER['SCRIPT_NAME'] . "?" . substr_replace($HideToken, $replacementString, $limit);

												$_SESSION['token_access_deleteusrcorp'] = $tkn_rec['token'];
												$_SESSION['login_access_deleteusrcorp']	= $tkn_rec['login'];

												header('Location: inc/class.actions.php?VerbAction=DeleteUserCorp');
												exit();
											}
											?>

											<form method="POST">
												<button type="button" class="exerotpbtn btn-cancel ripple-effect ripple-white" data-dismiss="modal"><?= Translator('Cancel'); ?></button>
												<button type="submit" name="del_this_usrcorp" class="exerotpbtn btn-green ripple-effect ripple-white"><?= Translator('Confirm'); ?></button>
											</form>
										</div>
									</div>
								</div>
							</div>
						<?php } ?>

						<?php if (checkLevel() == ADMIN || checkLevel() == SUPERVISOR) { ?>
							<div class="container-btnsusrcorp">
								<button type="button" class="exerotpbtn btn-teal btn-sm ripple-effect ripple-white" data-toggle="modal" data-target="#confirm_changekey" title=<?= Translator('renew_secret'); ?>><i class="far fa-redo dwnl_small_addelement_icon"></i><?= Translator('Renew_secrecy'); ?></button>
							</div>
						<?php } ?>

						<div class="row container-btnsusrcorp">

							<div class="col-md-6">
								<button type="button" class="exerotpbtn btn-defaultexer btn-sm ripple-effect ripple-white" data-toggle="modal" data-target="#share_public_link" title=<?= Translator('Share_public_link'); ?> class="far fa-share-alt dwnl_small_addelement_icon"></i> <?= Translator('Share...'); ?></button>
							</div>
							<?php if (checkLevel() == ADMIN || checkLevel() == SUPERVISOR) { ?>
								<div class="col-md-6">
									<button type="button" class="exerotpbtn btn-red btn-sm ripple-effect ripple-white" data-toggle="modal" data-target="#confirm_delete_thisclient" title=<?= Translator('Delete'); ?>><i class="far fa-trash-alt dwnl_small_addelement_icon"></i> <?= Translator('Delete'); ?></button>
								</div>
							<?php } ?>
							<div class="col-md-12">
								<button class="exerotpbtn btn-green btn-sm ripple-effect ripple-white" title=<?= Translator('diagnose_otp_connection'); ?> data-toggle="modal" data-target="#diag_otpconnection"><i class="far fa-stethoscope dwnl_small_addelement_icon"></i> <?= Translator('Diagnose'); ?></button>
							</div>
						</div>
					</div>
				</div>

				<div class="col-lg-9">
					<div class="row">
						<div class="col-md-12" style="margin-bottom: 1rem;">
							<div class="card">
								<div class="card-body fhjFd45">
									<h6><?= Translator('Intro'); ?></h6>
									<p class="card-text">
										<?= Translator('Use_secret_key'); ?>
										<br>

										<?php
										$OTPmailing = $db->prepare('SELECT * FROM otp_mailing WHERE corpid = ?');
										$OTPmailing->execute(array($tkn_rec['corpid']));
										$Mailing = $OTPmailing->fetch();

										if ($OTPmailing->rowCount() == 1) {
										?>
											<br>
									<div class="storebtnotp social-btns">
										<a target="_blank" and rel="noopener noreferrer" href="<?= $Mailing['link_custom_btn1'] ?>">
											<img src="/assets/images/appstore.png" class="fsdKGJD3" alt="AppStore Download">
										</a>
										<a target="_blank" and rel="noopener noreferrer" href="<?= $Mailing['link_custom_btn2'] ?>">
											<img src="/assets/images/playstore.png" class="fsdKGJD3" alt="Playstore Download">
										</a><br>
									</div>
								<?php } ?>
								</p>
								</div>
							</div>
						</div>
						<div class="col-md-6">
							<div class="card">
								<div class="card-body">
									<h6><?= Translator('Secret_key'); ?></h6>
									<p class="card-text">
										<i>
											<?= Translator('secret_key_generate'); ?>
										</i>
										<br><br>
									<div class="text-center">
										<a href="#" id="Gvh5Fa"><?= Translator('Display_secret_key'); ?></a>
									</div>
									<script>
										$('#Gvh5Fa').click(function() {
											$('#mgHfjvf2').show();
											$('#Gvh5Fa').hide();
											setTimeout(function() {
												$('#mgHfjvf2').hide();
												$('#Gvh5Fa').show();
											}, 2500);
										});
									</script>

									<h6 class="text-center" id="mgHfjvf2">
										<?php
										$filename = "/home/$nomclient/$nomuser/.exer_authenticator";

										if (file_exists($filename)) {
											$handle = fopen('/home/' . $nomclient . '/' . $nomuser . '/.exer_authenticator', "r");
											if ($handle) {
												if (($buffer = fgets($handle)) != "e") {
													$secretkey = rtrim($buffer);
													echo "<b>" . $secretkey . "</b>";
												}
												fclose($handle);
											}
										} else {
											unset($_SESSION['ch_token_usr']);
											unset($_SESSION['ch_token_tk']);
											$_SESSION['ch_token_usr'] 	= $tkn_rec['login'];
											$_SESSION['ch_token_tk'] 	= $tkn_rec['token'];

											if (checkLevel() == SUPERVISOR) {
												header('Location: inc/class.changesecret.php?Method=EditSpecificUser&CorpID=' . $tkn_rec['corpid'] . '&TokenID=' . $tkn_rec['token']);
												exit();
											} else {
												header('Location: inc/class.changesecret.php');
												exit();
											}
											echo "<hr>";
											echo "<b class='text-danger text-center'>" . Translator('unable_my_secret_key') . "</b>";
											echo "<hr>";
										}
										?>
									</h6>
									</p>
								</div>
							</div>
						</div>
						<div class="col-md-6">
							<div class="card">
								<div class="card-body">
									<?php
									$filename_2 = "/home/$nomclient/$nomuser/.exer_authenticator";
									if (file_exists($filename_2)) {
									?>
										<?php
										$array_spaces = array(" ", " ", " ");

										$run_getlignes_proc 	= shell_exec('cat /home/' . $nomclient . '/' . $nomuser . '/.exer_authenticator | wc -l');
										$run_getlignes_proc2 	= str_replace($array_spaces, "", $run_getlignes_proc);
										$run_getlignes 		 	= trim(preg_replace('/\s+/', ' ', $run_getlignes_proc2));

										if ($run_getlignes == "10") {
											$codes_restants = "5";
										} elseif ($run_getlignes == "9") {
											$codes_restants = "4";
										} elseif ($run_getlignes == "8") {
											$codes_restants = "3";
										} elseif ($run_getlignes == "7") {
											$codes_restants = "2";
										} elseif ($run_getlignes == "6") {
											$codes_restants = "1";
										} else {
											$codes_restants = "0";
										}
										?>

										<h6>
											<?= Translator('Emergency_codes'); ?>
											<span class="badge badge-secondary badge-pill">
												<?= $codes_restants ?>
											</span>
										</h6>
									<?php } ?>

									<p class="card-text">
										<?php if ($codes_restants != 0) { ?>
											<?= Translator('Emergency_codes_display'); ?> :<br><br>
										<?php } ?>
									<div class="text-center">
										<a href="#collapseExample" data-toggle="collapse" role="button" aria-expanded="false" aria-controls="collapseExample"><?= Translator('Display_emergency'); ?></a>
									</div>
									<div class="collapse" id="collapseExample"><br>
										<ul class="list-group">
											<?php
											if (file_exists($filename_2)) {
												$out = shell_exec("grep -s -A 5 TOTP_AUTH /home/$nomclient/$nomuser/.exer_authenticator");
												$arrayout = preg_split("/[\s,]+/", $out);
												$code = 0;

												$array_spaces = array(" ", " ", " ");
												$run_getlignes_proc = shell_exec('cat /home/' . $nomclient . '/' . $nomuser . '/.exer_authenticator | wc -l');
												$run_getlignes_proc2 = str_replace($array_spaces, "", $run_getlignes_proc);
												$run_getlignes 		 = trim(preg_replace('/\s+/', ' ', $run_getlignes_proc2));

												if ($run_getlignes == "10") {
													while ($code < 5) {
														$code++;
														echo '<li class="list-group-item" style="padding: 1rem;"> Code #' . $code . ' : ';
														echo '<b>' . $arrayout[$code + 1] . '</b>';
														echo '</li>';
													}
												} elseif ($run_getlignes == "9") {
													while ($code < 4) {
														$code++;
														echo '<li class="list-group-item" style="padding: 1rem;"> Code #' . $code . ' : ';
														echo '<b>' . $arrayout[$code + 1] . '</b>';
														echo '</li>';
													}
												} elseif ($run_getlignes == "8") {
													while ($code < 3) {
														$code++;
														echo '<li class="list-group-item" style="padding: 1rem;"> Code #' . $code . ' : ';
														echo '<b>' . $arrayout[$code + 1] . '</b>';
														echo '</li>';
													}
												} elseif ($run_getlignes == "7") {
													while ($code < 2) {
														$code++;
														echo '<li class="list-group-item" style="padding: 1rem;"> Code #' . $code . ' : ';
														echo '<b>' . $arrayout[$code + 1] . '</b>';
														echo '</li>';
													}
												} elseif ($run_getlignes == "6") {
													while ($code < 1) {
														$code++;
														echo '<li class="list-group-item" style="padding: 1rem;"> Code #' . $code . ' : ';
														echo '<b>' . $arrayout[$code + 1] . '</b>';
														echo '</li>';
													}
												} else {
													echo "<div class='text-center'><hr>";
													echo Translator('no_backup_code');
													echo "<hr></div>";
												}
											} else {
												echo "<b class'text-center text-danger'>" . Translator('unable_backup_code') . "</b>";
											}
											?>
										</ul>
									</div>
									</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		<?php } ?>
	<?php } else { ?>
		<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
			<h1 class="h3"><?= $module_page_name ?></h1>

			<?php if ($_SESSION['level'] != OPERATOR) { ?>
				<div class="btn-group">
					<?php if ($_SESSION['corp'] == "NOT_DEFINED") { ?>
						<a href="?page=AddCorp"><button class="exerotpbtn btn-defaultexer btn-sm ripple-effect ripple-white" title=<?= Translator('Add_compagny'); ?>><i class="far fa-plus dwnl_small_addelement_icon"></i> <?= Translator('Create_company'); ?></button></a>  
					<?php } else { ?>
						<div class="optionsmenu_b ">
							<div class="dropdown">
								<button class="exerotpbtn btn-defaultexer btn-sm ripple-effect ripple-white dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
									<label><?php echo Translator('Business_management') ?></label>
								</button>
								<div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButton">
									<div class="input-icon">
										<a class="dropdown-item" href="#" data-toggle="modal" data-target="#corpMail">
											<?= Translator('Edit_email_address'); ?>
										</a>
									</div>
									<div class="input-icon">
										<a class="dropdown-item" href="#" data-toggle="modal" data-target="#changeLogoCorp">
											<?= Translator('Modify_company_logo'); ?>
										</a>
									</div>
								</div>
							</div>
						</div>

						<?php
						$query_otp = $db->prepare("SELECT id, email FROM otp_tokens WHERE corpid = ?");
						$query_otp->execute(array($_SESSION['corp']));
						$emails = $query_otp->fetchAll(PDO::FETCH_ASSOC);

						if (isset($_POST['saveNewMailDomain'])) {
							$new_domain = $_POST['new_domain'];

							// Vérifier que le domaine est valide
							if (!filter_var($new_domain, FILTER_VALIDATE_DOMAIN)) {
								$error_msg = "Domaine invalide.";
							} else {

								// Mettre à jour les domaines des adresses e-mail dans la base de données
								foreach ($emails as $email) {
									$id = $email['id'];
									$existing_email = $email['email'];
									$updated_email = '';

									// Vérifier si l'utilisateur a une adresse e-mail existante
									if (!empty($existing_email) && $existing_email !== 'N/A') {
										list($username, $existing_domain) = explode('@', $existing_email);
										$updated_email = $username . '@' . $new_domain;
									} elseif ($existing_email === 'N/A') {
										// Laisser la valeur "N/A" pour les utilisateurs sans adresse e-mail
										$updated_email = 'N/A';
									}

									$query_update = $db->prepare("UPDATE otp_tokens SET email = :updated_email WHERE id = :id");
									$query_update->execute(array(':updated_email' => $updated_email, ':id' => $id));
								}

								addLogEventOTP("[SUCCESS] The company " . $_SESSION['corp_name'] . " emails domain has been changed to : \"" . $new_domain . "\" by admin user : " . $_SESSION['username']);
								// Rediriger vers la page courante pour actualiser la liste des adresses e-mail
								header('Location: ' . $_SERVER['REQUEST_URI']);
								exit();
							}
						}
						?>


						<!-- Modale de modification des domaines des adresses e-mail en masse -->
						<form class="form-horizontal" method="post" enctype="multipart/form-data">
							<div class="modal fade" id="corpMail" tabindex="-1" role="dialog" aria-labelledby="changeDomainCorp" aria-hidden="true">
								<div class="modal-dialog modal-lg" role="document">
									<div class="modal-content">
										<div class="modal-header">
											<h5 class="modal-title" id="lblconfirm_view_ldapedit">
												<i class="far fa-pen"></i> <?= Translator('Modify_domain_mail') ?>
											</h5>
										</div>
										<div class="modal-body">
											<label for="newDomain"><?= Translator('new_domain_mail') ?></label>
											<div class="input-group">
												<input type="text" class="form-control" name="new_domain" id="newDomainInput" required>
												<div class="input-group-append">
													<button type="submit" class="btn btn-primary" name="saveNewMailDomain"><?= Translator('Save') ?></button>
												</div>
											</div>
											<small id="domainError" class="form-text text-danger d-none"><?= Translator('Invalid_domain_error') ?></small>
										</div>
										<div class="modal-footer d-flex justify-content-between">
											<button type="button" class="btn btn-secondary" data-dismiss="modal"><?= Translator('Cancel') ?></button>
										</div>
									</div>
								</div>
							</div>
						</form>

						<script>
							// Vérification du domaine en temps réel
							var domainInput = document.getElementById('newDomainInput');
							var saveButton = document.querySelector('button[name="saveNewMailDomain"]');
							var domainError = document.getElementById('domainError');

							domainInput.addEventListener('input', function() {
								var domain = this.value;

								if (!/^[A-Za-z0-9.-]*$/.test(domain)) {
									domainError.classList.remove('d-none');
									saveButton.disabled = true;
								} else {
									domainError.classList.add('d-none');
									saveButton.disabled = false;
								}
							});
						</script>

						<script>
							window.onload=function() {
								const selectAllCheckbox = document.querySelector('#allCheck');
								const checkboxes = document.querySelectorAll('input[type="checkbox"]');
								const selectedItems = document.querySelector('#selected-items');
								const el = document.querySelector('#validate-items');

								if (el) {
										el.addEventListener('click', function() {
										const modal = document.querySelector('.modal');
										modal.style.display = 'none';
									});
								}


								if (el) {
										el.addEventListener('click', function() {
										const editedValues = document.querySelectorAll('#selected-items input[type="text"]');
										editedValues.forEach(function(input) {
											const id = input.parentElement.parentElement.querySelector('input[name="item"]').id;
											const label = document.querySelector('label[for="' + id + '"]');
											label.innerHTML = input.value;
										});
										modal.style.display = 'none';
										});
								}

								if (selectAllCheckbox) {
									selectAllCheckbox.addEventListener('change', function(event) {
									checkboxes.forEach(function(checkbox) {
										checkbox.checked = event.target.checked;
									});
									updateSelectedItems();
									});
								}	

								checkboxes.forEach(function(checkbox) {
									checkbox.addEventListener('change', function(event) {
										updateSelectedItems();
									});
								});

								function updateSelectedItems() {
									const checkedItems = document.querySelectorAll('input[name="item"]:checked');
									selectedItems.innerHTML = '';
									if (checkedItems.length > 0) {
										selectedItems.innerHTML = '<p>Éléments sélectionnés :</p><ul>';
										checkedItems.forEach(function(item) {
											const label = document.querySelector('label[for="' + item.id + '"]');
											selectedItems.innerHTML += '<li><input type="text" value="' + label.innerHTML + '"></li>';
										});
										selectedItems.innerHTML += '</ul>';
									}
								}

								const openModalButton = document.querySelector('#open-modal');
								const modal = document.querySelector('.modal');
								const closeModalButton = modal.querySelector('.close');

								if (openModalButton) {
									openModalButton.addEventListener('click', function() {
										modal.style.display = 'block';
									});
								}

								if (closeModalButton) {
									closeModalButton.addEventListener('click', function() {
										modal.style.display = 'none';
									});
								}
								window.addEventListener('click', function(event) {
									if (event.target == modal) {
										modal.style.display = 'none';
									}
								});

								const itemList = document.querySelector('#item-list');

								itemList.addEventListener('click', function(event) {
									const target = event.target;
									if (target.nodeName === 'LI') {
										const itemValue = target.textContent;
										const modal = document.createElement('div');
										modal.classList.add('modal');
										modal.innerHTML = `
											<div class="modal-content">
												<span class="close">&times;</span>
												<form>
												<label for="item-value">Nouvelle valeur :</label>
												<input type="text" id="item-value" value="${itemValue}">
												<input type="submit" value="Modifier">
												</form>
											</div>
											`;
										document.body.appendChild(modal);

										const closeModalButton = modal.querySelector('.close');
										closeModalButton.addEventListener('click', function() {
											modal.remove();
										});

										const form = modal.querySelector('form');
										form.addEventListener('submit', function(event) {
											event.preventDefault();
											const newValue = form.querySelector('#item-value').value;
											target.textContent = newValue;
											modal.remove();

										});
									}
								});
							}();

							function updateSelectedItems() {
								const checkedItems = document.querySelectorAll('input[name="item"]:checked');
								selectedItems.innerHTML = '';
								if (checkedItems.length > 0) {
									selectedItems.innerHTML = '<p>Éléments sélectionnés :</p><ul>';
									checkedItems.forEach(function(item) {
										const label = document.querySelector('label[for="' + item.id + '"]');
										selectedItems.innerHTML += '<li><input type="text" value="' + label.innerHTML + '"></li>';
									});
									selectedItems.innerHTML += '</ul>';
								}
							}

							const openModalButton = document.querySelector('#open-modal');
							const itemList = document.querySelector('#item-list');

							itemList.addEventListener('click', function(event) {
								const target = event.target;
								if (target.nodeName === 'LI') {
									const itemValue = target.textContent;
									const modal = document.createElement('div');
									modal.classList.add('modal');
									modal.setAttribute('id', 'item-modal');
									modal.innerHTML = `
										<div class="modal-content">
											<span class="close">&times;</span>
											<form>
											<label for="item-value">Nouvelle valeur :</label>
											<input type="text" id="item-value" value="${itemValue}">
											<input type="submit" value="Modifier">
											</form>
										</div>
										`;
									document.body.appendChild(modal);

									const closeModalButton = modal.querySelector('.close');
									closeModalButton.addEventListener('click', function() {
										modal.remove();
									});

									const form = modal.querySelector('form');
									form.addEventListener('submit', function(event) {
										event.preventDefault();
										const newValue = form.querySelector('#item-value').value;
										target.textContent = newValue;
										modal.remove();
									});
								}
							});

							openModalButton.addEventListener('click', function() {
								const modal = document.querySelector('#item-modal');
								modal.style.display = 'block';
							});

							window.addEventListener('click', function(event) {
								const modal = document.querySelector('#item-modal');
								if (event.target == modal) {
									modal.style.display = 'none';
								}
							});
						</script>

						<div class="modal fade" id="changeLogoCorp" tabindex="-1" role="dialog" aria-labelledby="changeLogoCorp" aria-hidden="true">
							<div class="modal-dialog modal-lg" role="document">
								<div class="modal-content">
									<div class="modal-header">
										<h5 class="modal-title" id="lblconfirm_view_ldapedit"><i class="far fa-pen"></i> <?= Translator('Modify_company_logo'); ?> <b><?= $_SESSION['corp_name']; ?></b> :
									</div>

									<?php
									if (isset($_POST['sendNewImgCorp'])) {
										if (($_FILES['import_newlogo_corp']) && $_FILES['import_newlogo_corp']['error'] === 0) {
											$NomDuFichier 	= $_FILES["import_newlogo_corp"]["name"];
											$taille_max		= 104850; //==100Ko
											$taille_fichier = filesize($_FILES['import_newlogo_corp']['tmp_name']);
											$type_logo 		= $_FILES["import_newlogo_corp"]["type"];

											if ($taille_fichier > $taille_max) {
												$Session->setFlash(Translator('size_file') . "<br>" . Translator('current_size_file') . $taille_fichier . " " . Translator('Bytes'), "close", "error");
												echo "<script>$(\"#changeLogoCorp\").modal('show');</script>";
												$actual_link = "https://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";

												header('Location: ' . $actual_link);
												exit();
											} else {
												$allowed = array("image/jpeg", "image/gif", "image/png", "image/jpg", "image/bmp");
												if (in_array($type_logo, $allowed)) {
													if (is_uploaded_file($_FILES["import_newlogo_corp"]["tmp_name"])) {
														$img_file = $_FILES["import_newlogo_corp"]["tmp_name"];
														$imgData = base64_encode(file_get_contents($img_file));
														$logo_corp = 'data: ' . mime_content_type($img_file) . ';base64,' . $imgData;

														$NewLogo = $db->prepare("UPDATE otp_companies SET logosrc = ? WHERE corpid = ?");
														$NewLogo->execute(array($logo_corp, $_SESSION['corp']));

														$Session->setFlash(Translator('logo_imported'), "check", "success");
														$actual_link = "https://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
														header('Location: ' . $actual_link);
													} else {
														$Session->setFlash(Translator('An_error_occu') . "<br>" . Translator('the_file') . " " . $NomDuFichier . " " . Translator('not_uploaded'), "close", "error");
														echo "<script>$(\"#changeLogoCorp\").modal('show');</script>";
														$actual_link = "https://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";

														header('Location: ' . $actual_link);
														exit();
													}
												} else {
													$Session->setFlash(Translator('valid_image') . "<br>" . Translator('image_format'), "close", "error");
													echo "<script>$(\"#changeLogoCorp\").modal('show');</script>";
													$actual_link = "https://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";

													header('Location: ' . $actual_link);
													exit();
												}
											}
										} else {
											$Session->setFlash(Translator('need_a_image'), "close", "error");
											echo "<script>$(\"#changeLogoCorp\").modal('show');</script>";
											$actual_link = "https://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";

											header('Location: ' . $actual_link);
											exit();
										}
									}
									?>

									<form method="POST" enctype="multipart/form-data">
										<div class="modal-body">
											<div class="formaddcorp">
												<label for="modify_users_max"><?= Translator('Send_new_logo'); ?></label>

												<fieldset class="fieldset_exerotp">
													<div class="col-auto">
														<label class="sr-only" for="inlineFormInputGroup">Logo <b class="text-danger" title=<?= Translator('Field_required'); ?> data-toggle="tooltip" data-placement="right"><i class="far fa-asterisk"></i></b></label>
														<div class="input-group mb-2">
															<div class="input-group-prepend">
																<div class="input-group-text"><i class="far fa-upload"></i></div>
															</div>

															<input type="file" autocomplete="off" class="form-control" style="height: 44px;" name="import_newlogo_corp" accept="image/*" onchange="loadFile(event)">
														</div>
													</div>

													<div id="container_preview">
														<label><?= Translator('view'); ?> :</label><br>
														<div class="view_logs_servotp car_exerlogs">
															<img oncontextmenu="return false; return false" ondrag="return false; return false" onmousedown="return false; return false" id="output" class="preview_picture" alt=<?= Translator('not_uploaded'); ?>>
														</div>
														<br>
													</div>
												</fieldset>
											</div>
										</div>

										<div class="modal-footer">
											<button type="button" class="exerotpbtn btn-white ripple-effect ripple-dark" data-dismiss="modal"><?= Translator('Cancel'); ?></button>
											<button type="submit" name="sendNewImgCorp" class="exerotpbtn btn-green ripple-effect ripple-white"><?= Translator('Send'); ?></button>
										</div>
									</form>
								</div>
							</div>
						</div>
					<?php } ?>
				</div>
			
			<?php } ?>
			</div>


			<?php
			if (checkLevel() == SUPERVISOR || checkLevel() == OPERATOR && $_SESSION['corp'] == "NOT_DEFINED") {
				$recup_all_companies = $db->query('SELECT * FROM otp_companies ORDER BY id DESC');
				$count_companies = $recup_all_companies->rowCount();

				$recup_count_user_contains_corp = $db->query('SELECT * FROM otp_tokens ORDER BY id DESC');
				$corp_usrs_count = $recup_count_user_contains_corp->rowCount();

				if ($count_companies == 0) { ?>

					<div class="alert alert-danger" role="alert">
						<i class="fas fa-exclamation-triangle"></i> <?= Translator('no_company_created'); ?>
					</div>
				<?php } else {
					if ($count_companies >= 150) {
						echo "
						<style>
						.pgnt_tab.pagination.justify-content-center {
							overflow: auto !important;
							max-width: 100% !important;
							justify-content: normal !important;
						}
						</style>
						";
					}
				?>
					<?php
					$recup_users_max = $db->prepare("SELECT users_max FROM otp_companies");
					$recup_users_max->execute();
					$tt = $recup_users_max->rowCount();
					$cmp = 0;
					$missing_info = false;

					while ($cmp < $tt and !$missing_info) {
						$data = $recup_users_max->fetch();
						if ($data[0] == 0)
							$missing_info = true;
						$cmp++;
					}

					if ($missing_info) { ?>
						<div class="alert alert-danger" role="alert">
							<i class="fas fa-exclamation-triangle"></i>
							<?= Translator('maximum_number_users'); ?>
						</div>
					<?php } ?>

					<div class="alert alert-info" role="alert">

						<i class="far fa-info-circle"></i>
						<?= Translator('Display'); ?> <strong><?= $count_companies ?></strong> <?php if ($count_companies > 1) {
																									echo Translator('plurial');
																								} else {
																									echo Translator('Company');
																								} ?> <?= Translator('which'); ?> <strong> <?= $corp_usrs_count  ?></strong><?php if ($corp_usrs_count > 1) {
																																											echo Translator('Users');
																																										} else {
																																											echo Translator('user');
																																										} ?>.
					</div>

					<input type="text" id="searchboxTable" placeholder="<?= Translator('search_a_compagny'); ?>" title="<?= Translator('invalid_compagny'); ?>">

					<script>
						$(document).ready(function() {
							$("#searchboxTable").on("keyup", function() {
								var value = $(this).val().toLowerCase();
								$("#byValDataT tr").filter(function() {
									$(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
								});
							});

							$("#searchboxTable").on("keyup", function() {
								var name = $(this).val();
								if (name.length >= 1) {
									var box = paginator({
										table: document.getElementById("container_table").getElementsByTagName("table")[0],
										box_mode: "list",
										rows_per_page: "0",
										get_rows: function() {
											return document.getElementById("table_otpexer").getElementsByTagName("tbody");
										},
									});
									$('.pgnt_tab').hide();
									$(".allCheck").hide();
									return false;
								} else {
									var box = paginator({
										table: document.getElementById("container_table").getElementsByTagName("table")[0],
										box_mode: "list",
										rows_per_page: "10",
									});
									$('.pgnt_tab').show();
									$(".allCheck").show();
									return false;
								}
							});

							var box = paginator({
								table: document.getElementById("container_table").getElementsByTagName("table")[0],
								box_mode: "list",
								rows_per_page: "10",
							});
							document.getElementById("container_table").appendChild(box);
						});
					</script>

					<div class="table-responsive" id="container_table">
						<table id="table_otpexer" class="sortable-theme-bootstrap table-striped" data-sortable>
							<thead>
								<tr>
									<th class="vt-default-th" data-sorted-direction="descending"><?= Translator('Company'); ?></th>
									<th><?= Translator('folder'); ?></th>
									<th><?= Translator('Number_users'); ?></th>
									<th><?= Translator('Number_licences'); ?></th>
									<th><?= Translator('Creation_date'); ?></th>
									<th><?= Translator('Licence_exp_date'); ?> </th>
									<th data-sortable="false"> </th>
								</tr>
							</thead>
							<tbody id="byValDataT">
								<?php
								while ($recorver_datas_corp = $recup_all_companies->fetch()) { ?>
									<tr>
										<td onclick="window.location.href='?page=ManageCorp&TokenID=<?= $recorver_datas_corp['token'] ?>'">
											<?= $recorver_datas_corp['name']; ?>
										</td>
										<td onclick="window.location.href='?page=ManageCorp&TokenID=<?= $recorver_datas_corp['token'] ?>'">
											<?= $recorver_datas_corp['folder']; ?>
										</td>

										<?php
											//Get users max for this companies
											$recup_users_max_corp = $db->prepare('SELECT users_max FROM otp_companies WHERE corpid = ?');
											$recup_users_max_corp->execute(array($recorver_datas_corp['corpid']));
											$crp_folder = $recup_users_max_corp->fetch();
											$users_max_corp = $crp_folder['users_max'];

											$recup_count_user_contains_corp = $db->prepare('SELECT * FROM otp_tokens WHERE corpid = ? ORDER BY id DESC');
											$recup_count_user_contains_corp->execute(array($recorver_datas_corp['corpid']));
											$corp_usrs_count = $recup_count_user_contains_corp->rowCount();
										?>
										
										<td data-value="<?= $corp_usrs_count ?>" onclick="window.location.href='?page=ManageCorp&TokenID=<?= $recorver_datas_corp['token'] ?>'">

											<?php
											if (($users_max_corp - $corp_usrs_count) == 0 and $corp_usrs_count != 0) {
												//if max users reached
												if ($corp_usrs_count > 1) {
													$multiple_usrs = Translator('Users');
												} else {
													$multiple_usrs = Translator('user');
												}
												echo "<label class='text-danger'>" . $corp_usrs_count . ' ' . $multiple_usrs . "</label>";
											} else if (($users_max_corp - $corp_usrs_count) < 3 and $corp_usrs_count != 0) {
												//if max users close to the max
												if ($corp_usrs_count > 1) {
													$multiple_usrs = Translator('Users');
												} else {
													$multiple_usrs = Translator('user');
												}
												echo "<label class='text-warning'>" . $corp_usrs_count . ' ' . $multiple_usrs . "</label>";
											} else {
												if ($corp_usrs_count > 1) {
													$multiple_usrs = Translator('Users');
												} else {
													$multiple_usrs = Translator('user');
												}
												echo $corp_usrs_count . ' ' . $multiple_usrs;
											}
											?>
										</td>
										<td data-value="<?= $users_max_corp ?>" onclick="window.location.href='?page=ManageCorp&TokenID=<?= $recorver_datas_corp['token'] ?>'">
											<?php
											//use users_max
											if ($users_max_corp == 0)
												echo '<label class="text-danger">' . Translator('no_info') . '</label>';
											else {
												if ($users_max_corp > 1) {
													$multiple_usrs = Translator('Users');
												} else {
													$multiple_usrs = Translator('user');
												}
												echo $users_max_corp . ' ' . $multiple_usrs;
											}
											?>
										</td>
										<td data-value="<?= strtotime($recorver_datas_corp['created_at']) ?>" onclick="window.location.href='?page=ManageCorp&TokenID=<?= $recorver_datas_corp['token'] ?>'">
											<?php
											$datenow = date('Y-m-d');
											if ($recorver_datas_corp['created_at'] == $datenow) {
												echo Translator('today');
											} else {
												echo date_format(date_create($recorver_datas_corp['created_at']), "d/m/Y");
											}
											?>
										</td>
										<td data-value="<?= strtotime($recorver_datas_corp['expire_date']) ?>" onclick="window.location.href='?page=ManageCorp&TokenID=<?= $recorver_datas_corp['token'] ?>'">
											<?php
											$datenow = date('Y-m-d');
											$datecomparetoday = date('d/m/Y');
											$expire_to_print = $recorver_datas_corp['expire_date'];
											if (empty($expire_to_print)) {
												$BeforeExpireDate = $DumpExpireDateold;
												$Date_Expire_Date = str_replace('/', '-', $BeforeExpireDate);
												$expire_to_print = date('Y-m-d', strtotime($Date_Expire_Date));
												$update_empty_date = $db->prepare('UPDATE otp_companies SET expire_date = ? WHERE corpid = ?');
												$update_empty_date->execute(array($expire_to_print, $recorver_datas_corp['corpid']));
											}
											$dateformateur = DateTime::createFromFormat('Y-m-d', $expire_to_print);
											if ($dateformateur == true) {
												$Date_to_print = $dateformateur->format('d/m/Y');
											} else {
												$Date_to_print = $expire_to_print;
											}
											if ($Date_to_print == $datecomparetoday) {
												echo "<label class='text-danger'>" . Translator("today") . "</label>";
											} else {
												if (empty($recorver_datas_corp['expire_date'])) {
													if (strtotime($expire_to_print) - strtotime($datenow) < 0) {
														echo "<label class='text-danger'> $Date_to_print </label>";
													} elseif (strtotime($expire_to_print) - strtotime($datenow) < 5184000) {
														echo "<label class='text-warning'> $Date_to_print </label>";
													} else {
														echo  $Date_to_print;
													}
												} elseif (strtotime($recorver_datas_corp['expire_date']) - strtotime($datenow) < 0) {
													echo "<label class='text-danger'>$Date_to_print  </label>";
												} elseif (strtotime($recorver_datas_corp['expire_date']) - strtotime($datenow) < 5184000) {
													echo "<label class='text-warning'>  $Date_to_print </label>";
												} else {
													echo  $Date_to_print;
												}
											}
											?>
										</td>

										<?php if (checkLevel() != OPERATOR) { ?>
											<!-- Modal_confirm suppression corp -->
											<?php $rand_client_modal = generateToken(9999); ?>
											<div class="modal fade" id="confirm_delete_fireclient__<?= $rand_client_modal ?>" tabindex="-1" role="dialog" aria-labelledby="lblconfirm_delete_fireclient" aria-hidden="true">
												<div class="modal-dialog modal-lg" role="document">
													<div class="modal-content">
														<div class="modal-header">
															<h5 class="modal-title" id="lblconfirm_delete_fireclient"><i class="far fa-trash-alt"></i> <?= Translator('Delete_company'); ?></h5>
															<button type="button" class="close" data-dismiss="modal" aria-label="Close">
																<span aria-hidden="true"><i class="far fa-times"></i></span>
															</button>
														</div>

														<div class="modal-body">
															<label><?= Translator('Confirm_remov_buiness'); ?> <b><?= $recorver_datas_corp['name']; ?></b> ?</label><br>
															<b class="text-danger"><?= Translator('Warning'); ?></b>
														</div>

														<div class="modal-footer">
															<?php
															if (isset($_POST['del_this_company__' . $recorver_datas_corp['token']])) {
																unset($_SESSION['token_access_deletecorp']);
																$_SESSION['token_access_deletecorp'] = $recorver_datas_corp['token'];

																header('Location: inc/class.actions.php?VerbAction=DeleteCompany');
																exit();
															}
															?>

															<form method="POST">
																<button type="button" class="exerotpbtn btn-cancel ripple-effect ripple-white" data-dismiss="modal"><?= Translator('Cancel'); ?></button>
																<button type="submit" name="del_this_company__<?= $recorver_datas_corp['token'] ?>" class="exerotpbtn btn-green ripple-effect ripple-white"><?= Translator('Confirm'); ?></button>
															</form>
														</div>
													</div>
												</div>
											</div>
										<?php } ?>
										<td>
											<?php if (checkLevel() == SUPERVISOR) { ?>
												<button type="button" class="exerotpbtn btn-sm btn-red ripple-effect ripple-white" data-toggle="modal" data-target="#confirm_delete_fireclient__<?= $rand_client_modal ?>" title=<?= Translator('Delete_company'); ?>><i class="far fa-trash-alt dwnl_small_addelement_icon delete_action_button_item"></i></button>
											<?php } ?>
										</td>
									</tr>
								<?php } ?>
							</tbody>
						</table>
					</div>
				<?php } ?>
				<?php } else {
				$recorver_corpclients = $db->prepare('SELECT * FROM otp_companies WHERE corpid = ? ORDER BY id DESC');
				$recorver_corpclients->execute(array($_SESSION['corp']));
				$count_corp = $recorver_corpclients->rowCount();

				$recup_tokens = $db->prepare('SELECT * FROM otp_tokens WHERE corpid = ? ORDER BY id DESC');
				$recup_tokens->execute(array($_SESSION['corp']));
				$count_token = $recup_tokens->rowCount();

				if ($count_corp == 0) { ?>
					<div class="alert alert-danger" role="alert">
						<i class="fas fa-exclamation-triangle"></i> <?= Translator('Data_recovery'); ?>
					</div>
					<?php } else {
					$recorver_corpclients = $db->prepare('SELECT * FROM otp_companies WHERE corpid = ? ORDER BY id DESC');
					$recorver_corpclients->execute(array($_SESSION['corp']));
					$count_corp = $recorver_corpclients->rowCount();
					$ft_rec_clients = $recorver_corpclients->fetch();

					if ($count_corp == 0) {
						$error_recupdir = Translator('cant_find_folder');
					} elseif ($count_token == 0) {
						$error_recupdir = Translator('compagny_has_not_created_user');
					} else {
						// Correction décalage pagination >= 150 utilisateurs
						if ($count_token >= 150) {
							echo "
								<style>
								.pgnt_tab.pagination.justify-content-center {
									overflow: auto !important;
									max-width: 100% !important;
									justify-content: normal !important;
								}
								</style>
								";
						}
					?>
						<div class="alert alert-info" role="alert">
							<i class="far fa-info-circle"></i>
							<?php
							//Get users max users required by corp
							$recorver_corpclients = $db->prepare('SELECT users_max FROM otp_companies WHERE corpid = ?');
							$recorver_corpclients->execute(array($_SESSION['corp']));
							$ft_rec_clients = $recorver_corpclients->fetch();
							$get_users_max = $ft_rec_clients['users_max'];
							?>
							<?= Translator('the_company'); ?> <?= $_SESSION['corp_name'] ?><?= Translator('count'); ?> <?php echo $count_token . "</b>"; ?> <?php if ($count_token != 1) {
																																								echo Translator('Users');
																																							} else {
																																								echo Translator('user');
																																							} ?> <?= Translator('for_up_to'); ?> <?php echo $get_users_max ?> <?php if ($get_users_max != 1) {
																																																								echo Translator('Users');
																																																							} else {
																																																								echo Translator('user');
																																																							} ?>
						</div>
											
						<?php if (checkLevel() != 1) { 
							// Check if LDAP exists for this company
							$recup_all_ldap2 = $db->prepare('SELECT * FROM otp_ldap WHERE corpid = ?');
							$recup_all_ldap2->execute(array($_SESSION['corp']));
							$count_ldap2 = $recup_all_ldap2->rowCount();
							?>
							<div class="row justify-content-end">
								<div class="col-md-6">
										<input type="text" id="searchboxTable" placeholder="<?= Translator('search_a_user'); ?>" title="<?= Translator('invalid_user'); ?>">
								</div>
								<div class="col-md-3">
									<a href="?page=AddThisCorpUser&choiceCorp=<?= $query_corp_slt['token'] ?>"><button class="exerotpbtn btn-teal btn-sm btneditnusr ripple-effect ripple-white" title="<?= Translator('Add_user_for_client_company') ?>"><i class="far fa-layer-plus dwnl_small_addelement_icon"></i> <?= Translator('Create_user'); ?></button></a>
								</div>
								<div class="col-md-3">
										<?php if ($count_ldap2 != 0) { ?>
														<a type="button" href="ldap.php?page=AddLdapFromDirectory" class="exerotpbtn btn-teal btn-sm btneditnusr ripple-effect ripple-white"><i class="far fa-book-reader dwnl_small_addelement_icon"></i><?= Translator('add_LDAP_User'); ?></a>
											<?php } else { ?>	
														<a type="button" href="ldap.php?page=AddLdap" class="exerotpbtn btn-teal btn-sm btneditnusr ripple-effect ripple-white"><i class="far fa-book-reader dwnl_small_addelement_icon"></i><?= Translator('add_LDAP_User'); ?></a>
											<?php } ?>
								</div>
							</div>
							<?php } else { ?>
								<div class="row">
									<div class="col-md-6">
										<input type="text" id="searchboxTable" placeholder="<?= Translator('search_a_user'); ?>" title="<?= Translator('invalid_user'); ?>">
									</div>
								</div>
							<?php } ?>		

						


						<form method="POST" enctype="multipart/form-data">
							<?php
							$user_translatorphp  = Translator('user_checked');
							$users_translatorphp = Translator('users_checked');
							?>
							<script>
								var user_translator = <?php echo json_encode($user_translatorphp); ?>;
								var users_translator = <?php echo json_encode($users_translatorphp); ?>;

								function chcSelect() {
									var e = $('input[name="speUsrSelect[]"]:checked').length;
									$(".optionsmenu_p").show(),
										e > 1 ? $("#countChecks").html(e + " " + users_translator) : 0 == e ? $(".optionsmenu_p").hide() : $("#countChecks").html(e + " " + user_translator)
								}

								function toggle(e) {
									var t = document.querySelectorAll('input[type="checkbox"]');
									$(".optionsmenu_p").show();
									for (var n = 0; n < t.length; n++)
										if (t[n] != e) {
											t[n].checked = e.checked;
											var o = $('input[name="speUsrSelect[]"]:checked').length;
											o > 1 ? $("#countChecks").html(o + " " + users_translator) : 0 == o ? $(".optionsmenu_p").hide() : $("#countChecks").html(o + " " + user_translator)
										}
								}



								$(document).ready(function() {
									$("#searchboxTable").on("keyup", function() {
										var value = $(this).val().toLowerCase();
										$("#byValDataT tr").filter(function() {
											$(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
										});
									});

									$("#searchboxTable").on("keyup", function() {
										var name = $(this).val();
										if (name.length >= 1) {
											var box = paginator({
												table: document.getElementById("container_table").getElementsByTagName("table")[0],
												box_mode: "list",
												rows_per_page: "0",
												get_rows: function() {
													return document.getElementById("table_otpexer").getElementsByTagName("tbody");
												},
											});
											$('.pgnt_tab').hide();
											$(".allCheck").hide();
											return false;
										} else {
											var box = paginator({
												table: document.getElementById("container_table").getElementsByTagName("table")[0],
												box_mode: "list",
												rows_per_page: "10",
											});
											$('.pgnt_tab').show();
											$(".allCheck").show();
											return false;
										}
									});

									var box = paginator({
										table: document.getElementById("container_table").getElementsByTagName("table")[0],
										box_mode: "list",
										rows_per_page: "10",
									});
									document.getElementById("container_table").appendChild(box);
								});
							</script>

							<?php
							if (isset($_POST['deleteSelectedUsrCorp'])) {
								if (!empty($_POST['speUsrSelect'])) {
									foreach ($_POST['speUsrSelect'] as $speUsrSelect) {
										$recup_flw = $db->prepare('SELECT * FROM otp_tokens WHERE token = ?');
										$recup_flw->execute(array($speUsrSelect));
										$recup_data = $recup_flw->fetch();
										$countUsrFwl = $recup_flw->rowCount();

										if ($countUsrFwl == 0) {
											$Session->setFlash(Translator('No_user_has_been_found'), "close", "error");
											header('Location: /companies.php');
											exit();
										} else {
											//Suppression SQL de l'utilisateur
											$del_corp = $db->prepare('DELETE FROM otp_tokens WHERE token = ?');
											$del_corp->execute(array($speUsrSelect));

											$recup_corp = $db->prepare('SELECT * FROM otp_companies WHERE corpid = ?');
											$recup_corp->execute(array($recup_data['corpid']));
											$recup_name_corpfolder = $recup_corp->fetch();

											//Suppression du dossier de l'utilisateur
											$escaped_command = escapeshellcmd("sudo rm -rf /home/" . $recup_name_corpfolder['folder'] . "/" . $recup_data['login']);
											shell_exec($escaped_command);

											//Ajout actions dans les logs d'EXER otp si les actions ont réussies
											addLogEventOTP("[SUCCESS] Selected users in " . $recup_name_corpfolder['name'] . " have been succesfully deleted by " . $_SESSION['username']);

											$Session->setFlash(Translator('success_users_select') . $recup_name_corpfolder['name'] . Translator('delete_users_selected'), "check", "success");
											$actual_link = "https://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";

											header('Location: ' . $actual_link);
										}
									}
								}
							}

							if (isset($_POST['sendMailSelectedUsrCorpBySpecifiy'])) {
								if (checkLevel() != SUPERVISOR) {
									if (!empty($_POST['speUsrSelect'])) {
										$sendTotalCounter = count($_POST['speUsrSelect']);
										$i = 0;

										foreach ($_POST['speUsrSelect'] as $speUsrSelect) {
											$recup_flw = $db->prepare('SELECT * FROM otp_tokens WHERE token = ?');
											$recup_flw->execute(array($speUsrSelect));
											$countUsrFwl = $recup_flw->rowCount();

											if ($countUsrFwl == 0) {
												$Session->setFlash(Translator('User_cannot_found'), "close", "error");
												header('Location: /companies.php');
												exit();
											} else {
												while ($recup_dataToken = $recup_flw->fetch()) {
													if ($recup_dataToken['email'] != "N/A") {
														$i++;
														$recup_mail = htmlspecialchars($recup_dataToken['email']);

														$CustomFQDN = $db->prepare('SELECT fqdn FROM otp_mailing WHERE corpid = ?');
														$CustomFQDN->execute(array($recup_dataToken['corpid']));
														$ClientFQDN = $CustomFQDN->fetch();

														$ExternalShareForm = "/shareExternal.php?shareID=" . "{$recup_dataToken['externalToken']}";

														if (!empty($ClientFQDN[0])) {
															$shareLink = $ClientFQDN[0] . $ExternalShareForm;
														} else {
															$shareLink = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://{$_SERVER['HTTP_HOST']}" . $ExternalShareForm;
														}

														/** 
														 *	Send mail 
														 **/
														$GetCompany = $db->prepare('SELECT * FROM otp_companies WHERE corpid = ?');
														$GetCompany->execute(array($recup_dataToken['corpid']));

														if ($GetCompany->rowCount() == 1) {
															$Company = $GetCompany->fetch();

															$CorpName = $Company['name'];

															if (isset($recup_dataToken['login'])) {
																$CheckMailing = $db->prepare('SELECT * FROM otp_mailing WHERE corpid = ?');
																$CheckMailing->execute(array($Company['corpid']));

																if ($CheckMailing->rowCount() != 0) {
																	$Mailing = $CheckMailing->fetch();

																	$OTPVar = array(
																		'username'  =>  $recup_dataToken['login'],
																		'email'     =>  $recup_mail,
																		'link'      =>  $shareLink,
																		'company'   =>  $CorpName
																	);

																	if (!empty($Mailing['host'])) {
																		SendMail($recup_mail, false, $Company['corpid'], $OTPVar);
																	} else {
																		$Session->setFlash(Translator('inform_seting_server') . "<b>" . Translator('Maintenance') . "</b> >" . "<b>" . Translator('SMTP_links') . "</b>" . Translator('to_send_an_email'), "close", "error");
																		header('Location: ' . $_SERVER["REQUEST_URI"]);
																		exit();
																	}
																} else {
																	$Session->setFlash(Translator('configuration_mail_relay_not_found'), "close", "error");
																	header('Location: ' . $_SERVER["REQUEST_URI"]);
																	exit();
																}
															} else {
																$Session->setFlash(Translator('User_cannot_found'), "close", "error");
																header('Location: ' . $_SERVER["REQUEST_URI"]);
																exit();
															}
														}
													}
												}
											}
										}

										if ($i != "0") {
											addLogEventOTP("[SUCCESS] Emails have been sent to " . $i . " user(s) on a total of " . $sendTotalCounter);
											$Session->setFlash(Translator("success_email_otp_send")  . $i . " " . Translator('users_on_a_total_of') . " " . $sendTotalCounter . " " . Translator('Email'), "check", "success");
											header('Location: /companies.php');
											exit();
										} else {
											$Session->setFlash(Translator('no-email_address_send'), "change_history", "warning");
											header('Location: /companies.php');
											exit();
										}
									}
								} else {
									$Session->setFlash(Translator('action_required_permissions'), "close", "error");
									header('Location: /companies.php');
									exit();
								}
							}
							?>

							<div class="optionsmenu_p">
								<div class="dropdown">
									<button class="exerotpbtn btn-defaultexer btn-sm ripple-effect ripple-white dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
										<label id="countChecks"></label>
									</button>
									<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
										<a class="dropdown-item" href="#" data-toggle="modal" data-target="#confirmcorp_emails"><i class="far fa-envelope"></i> <?= Translator('Send_OTP_email'); ?></a>

										<?php if (checkLevel() != OPERATOR) { ?>
											<div class="input-icon">
												<i class="far fa-file-csv"></i>
												<input class="dropdown-item2" type="submit" name="CSVExport_Classic" value="<?= Translator('Export_to_CSV'); ?>" />
											</div>
											<div class="input-icon">
												<i class="far fa-file-spreadsheet"></i>
												<input class="dropdown-item2" type="submit" name="CSVExport_AzureMicrosoft" value="<?= Translator('Export_to_Azure'); ?>" />
											</div>
											<a class="dropdown-item" href="#" data-toggle="modal" data-target="#confirmcorp_delete"><i class="far fa-trash-alt"></i> <?= Translator('Delete'); ?></a>
										<?php } ?>
									</div>
								</div>
							</div>
							<!-- Modal confirmcorp_emails -->
							<div class="modal fade" id="confirmcorp_emails" tabindex="-1" role="dialog" aria-labelledby="lblview_ldap" aria-hidden="true">
								<div class="modal-dialog modal-lg" role="document">
									<div class="modal-content">
										<div class="modal-header">
											<h5 class="modal-title" id="lblconfirm_view_ldapedit"><i class="far fa-envelope"></i><?= Translator('Send_OTP_email'); ?>
										</div>

										<div class="modal-body">
											<?= Translator('Send_link_on_email'); ?>
										</div>

										<div class="modal-footer">
											<button type="button" class="exerotpbtn btn-white ripple-effect ripple-dark" data-dismiss="modal"><?= Translator('Cancel'); ?></button>
											<button type="submit" name="sendMailSelectedUsrCorpBySpecifiy" class="exerotpbtn btn-green ripple-effect ripple-white"><i class="fas fa-paper-plane"></i><?= Translator('Send'); ?></button>
										</div>
									</div>
								</div>
							</div>

							<?php if (checkLevel() != OPERATOR) { ?>
								<!-- Modal confirmcorp_delete -->
								<div class="modal fade" id="confirmcorp_delete" tabindex="-1" role="dialog" aria-labelledby="lblview_ldap" aria-hidden="true">
									<div class="modal-dialog modal-lg" role="document">
										<div class="modal-content">
											<div class="modal-header">
												<h5 class="modal-title" id="lblconfirm_view_ldapedit"><i class="far fa-trash-alt"></i> <?= Translator('Delete_selected_user'); ?>
											</div>

											<div class="modal-body">
												<?= Translator('Sure_delete_user'); ?>
											</div>

											<div class="modal-footer">
												<button type="button" class="exerotpbtn btn-white ripple-effect ripple-dark" data-dismiss="modal"><?= Translator('Cancel'); ?></button>
												<button type="submit" name="deleteSelectedUsrCorp" class="exerotpbtn btn-red ripple-effect ripple-white"><i class="fas fa-trash-alt"></i> <?= Translator('Delete'); ?></button>
											</div>
										</div>
									</div>
								</div>
							<?php } ?>

							<div class="table-responsive ms-h-50" id="container_table">
								<table id="table_otpexer" class="sortable-theme-bootstrap table-striped" data-sortable>
									<thead>
										<tr>
											<th data-sortable="false">

												<label class="pure-material-checkbox allCheck" style="margin-bottom: -5px;">
													<input type="checkbox" name="selectUsr[]" onclick="toggle(this);">
													<span></span>
												</label>
											</th>
											<th class="vt-default-th" data-sorted-direction="descending"><?= Translator('user'); ?></th>
											<th><?= Translator('Email'); ?></th>
											<th><?= Translator('NFC_series_number'); ?></th>
											<th><?= Translator('last_connection'); ?></th>
											<th><?= Translator('Creation_date'); ?></th>
											<th data-sortable="false"></th>
										</tr>
									</thead>
									<tbody id="byValDataT">
										<?php
										while ($rc_tok = $recup_tokens->fetch()) { ?>
											<tr>
												<td>
													<label class="pure-material-checkbox" style="margin-bottom: -5px;">
														<input type="checkbox" name="speUsrSelect[]" value="<?= $rc_tok['token'] ?>" onclick="chcSelect()" id="speUsrSelect[]">
														<span></span>
													</label>
												</td>
												<td onclick="window.location.href='?page=ViewUser&TokenID=<?= $rc_tok['token'] ?>'"><?= $rc_tok['login'] ?></td>
												<td onclick="window.location.href='?page=ViewUser&TokenID=<?= $rc_tok['token'] ?>'"><?php if ($rc_tok['email'] == "N/A") {
																																		echo "N/A";
																																	} else {
																																		echo $rc_tok['email'];
																																	} ?></td>
												<td onclick="window.location.href='?page=ViewUser&TokenID=<?= $rc_tok['token'] ?>'">
													<?php if (!empty($rc_tok['serialnumber_card'])) {
														echo $rc_tok['serialnumber_card'];
													} else {
														echo "N/A";
													} ?>
												</td>

												<td data-value="<?= strtotime($rc_tok['otp_last_connected']) ?>" onclick="window.location.href='?page=ViewUser&TokenID=<?= $rc_tok['token'] ?>'">
													<?php
													if (!empty($rc_tok['otp_firewall'])) {
														if ($rc_tok['otp_last_connected'] != "0000-00-00 00:00:00") {
															$Date = date_format(date_create($rc_tok['otp_last_connected']), "d/m/Y H:i");
															echo "<label style='position:relative;top:4px;' title=" . Translator('last_connection') . " : " . $Date . "\n" . Translator('last_firewall') . " : " . $rc_tok['otp_firewall'] . "'>" . Translator('THE') . $Date . " (" . $rc_tok['otp_firewall'] . ")" . "</label>";
														} else {
															echo '<span class="text-danger">' . Translator('no_connect') . '</span>';
														}
													} else {
														echo '<span class="text-danger">' . Translator('no_connect') . '</span>';
													}
													?>
												</td>

												<td data-value="<?= strtotime($rc_tok['created_at']) ?>" onclick="window.location.href='?page=ViewUser&TokenID=<?= $rc_tok['token'] ?>'"><?php echo date_format(date_create($rc_tok['created_at']), "d/m/Y H:i"); ?></td>

												<td>
													<?php $rand_client_modal = generateToken(9999); ?>
													<form method="POST">
														<?php if (checkLevel() == ADMIN || checkLevel() == SUPERVISOR) { ?>
															<a href="/companies.php?page=EditUser&TokenID=<?= $rc_tok['token'] ?>"><button type="button" class="exerotpbtn btn-sm btn-green ripple-effect ripple-white" title="Éditer l'utilisateur OTP"><i class="far fa-pen dwnl_small_addelement_icon delete_action_button_item"></i></button></a>
															<button type="button" class="exerotpbtn btn-sm btn-red ripple-effect ripple-white" title=<?= Translator('Delete_user'); ?> data-toggle="modal" data-target="#confirm_delete_usrcorp__<?= $rand_client_modal ?>"><i class="far fa-trash-alt dwnl_small_addelement_icon delete_action_button_item"></i></button>
														<?php } ?>
													</form>
												</td>
											</tr>

											<?php if (checkLevel() != OPERATOR) { ?>
												<!-- Modal_confirm suppression user_corp -->
												<div class="modal fade" id="confirm_delete_usrcorp__<?= $rand_client_modal ?>" tabindex="-1" role="dialog" aria-labelledby="lblconfirm_delete_fireclient" aria-hidden="true">
													<div class="modal-dialog modal-lg" role="document">
														<div class="modal-content">
															<div class="modal-header">
																<h5 class="modal-title" id="lblconfirm_delete_fireclient"><i class="far fa-trash-alt"></i> <?= Translator('Delete_user'); ?></h5>
																<button type="button" class="close" data-dismiss="modal" aria-label="Close">
																	<span aria-hidden="true"><i class="far fa-times"></i></span>
																</button>
															</div>

															<div class="modal-body">
																<label><?= Translator('Confirm_removal_user'); ?><b><?= $rc_tok['login'] ?></b> ?</label>
															</div>

															<div class="modal-footer">
																<?php
																if (isset($_POST['del_this_usrcorp__' . $rc_tok['token']])) {
																	unset($_SESSION['token_access_deleteusrcorp']);
																	unset($_SESSION['login_access_deleteusrcorp']);
																	$_SESSION['token_access_deleteusrcorp'] = $rc_tok['token'];
																	$_SESSION['login_access_deleteusrcorp']	= $rc_tok['login'];

																	header('Location: inc/class.actions.php?VerbAction=DeleteUserCorp');
																	exit();
																}
																?>

																<form method="POST">
																	<button type="button" class="exerotpbtn btn-cancel ripple-effect ripple-white" data-dismiss="modal"><?= Translator('Cancel'); ?></button>
																	<button type="submit" name="del_this_usrcorp__<?= $rc_tok['token'] ?>" class="exerotpbtn btn-green ripple-effect ripple-white"><?= Translator('Confirm'); ?></button>
																</form>
															</div>
														</div>
													</div>
												</div>
											<?php } ?>
										<?php
										} ?>
									</tbody>
								</table>
							</div>
						</form>
			<?php }
				}
			} ?>
			<?php if (isset($error_recupdir)) { ?>
				<div class="alert alert-danger" role="alert">
					<i class="fas fa-exclamation-triangle"></i> <?= $error_recupdir ?>
				</div>
			<?php } ?>
		<?php } ?>
</main>

<script>
	function printElement(elem) {
		var domClone = elem.cloneNode(true);
		var $printSection = document.getElementById("printSection");

		if (!$printSection) {
			var $printSection = document.createElement("div");

			$printSection.id = "printSection";
			document.body.appendChild($printSection);
		}

		$printSection.innerHTML = "";
		$printSection.appendChild(domClone);
		window.print();
	}
</script>

<?php include 'inc/footer.php'; ?>