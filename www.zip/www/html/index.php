<?php 
	// Dernière modification le : 01/06/2022
	// Par: Laurent ASSELIN
	
	include_once $_SERVER['DOCUMENT_ROOT'] . '/inc/translator.php';
	$module_page_name = Translator('Overview');

	$show_navbar = true;
	$show_creds_usr = true;
	include 'inc/header.php';
?>

	<main role="main" class="col-md-10 ml-sm-auto col-lg-10">
		<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
			<h1 class="h2"><?= $module_page_name ?></h1>
		</div>

		<style>
		html {
			overflow-x:hidden;
		}
		</style>


		<div class="row" style="margin-top: 4rem;">
			<div class="card-exer col-md-4">
				<div style="margin-left: auto; margin-right: auto; width: 5em;">
					<img src="/assets/images/exer_user_default.png" class="rounded-circle default_avatar_exer" alt="default user exer" style="position: relative; top: -5rem; max-height: 7rem; border: 1px solid #D5E3EC;">
				</div>
				
				<div class="text-center" style="margin-top: -4rem;">
					<h1 class="text-truncate"><?= $_SESSION['firstname'] ?> <?= $_SESSION['lastname'] ?></h1>
				</div>
				<p>
					<label>
						<i class="fal fa-envelope"></i>
						<?= Translator('Email'); ?> : <a href="mailto://<?= $_SESSION['email'] ?>"><?= $_SESSION['email'] ?></a>
					</label><br>
					<label>
						<i class="fal fa-user"></i>
						<?= Translator('user'); ?> : <?= $_SESSION['username'] ?>
					</label><br>
					<label>
						<i class="fal fa-crown"></i>
						<?= Translator('AccessLevel'); ?> : <?php if ($_SESSION['level'] ==1 ) { echo Translator('Help-Desk_op'); } elseif ($_SESSION['level'] ==2 ) { echo Translator('Administrators'); } elseif ($_SESSION['level'] ==3 ) { echo Translator('Supervisor'); } ?>
					</label>
				</p>
				<hr>
				<p>
					<label>
						<i class="fal fa-clock"></i>
						<?= Translator('last_connection'); ?> : <?php if ($_SESSION['last_connected'] != "0000-00-00 00:00:00") { echo date_format(date_create($_SESSION['last_connected']),"d/m/Y H:i"); } else { echo "<i>".Translator('date_last_conenction')."</i>"; } ?>
					</label>
					<label>
						<i class="fal fa-chart-network"></i>
						<?= Translator('IPAddressConnection'); ?> : <?php if (!empty($_SESSION['lastip'])) { echo $_SESSION['lastip']; } else { echo "<i>".Translator('no_ip_connected')."</i>"; } ?>
					</label>
				</p>
			</div>
			<div class="col-md-7">
				<div class="row" style="width: 125%;">
					<div class="card-exer col-md-10" style="flex: none;max-width: 86.88888%;">
						<div class="text-center">
							<?php
								// Récupération des données de l'entreprise
								$CorpInfos = $db->prepare('SELECT * FROM otp_companies WHERE corpid = ?');
								$CorpInfos->execute(array($_SESSION['corp']));
								
								$crp_data = $CorpInfos->fetch();

								if ($crp_data['logosrc'] == "not_defined" || $_SESSION['corp'] == "NOT_DEFINED") {
									$LogoCompany = "/assets/images/exer_logo_black.png";
								} else {
									$LogoCompany = $crp_data['logosrc'];
								}
							?>
							<img src="<?= $LogoCompany ?>" style="min-height: 3.5rem;max-height: 3.5rem;margin-bottom:1rem;" alt="Logo <?= $crp_data['name'] ?>">

							<?php 
								if($_SESSION['corp'] != "NOT_DEFINED") {
									echo "<h1 class=\"text-truncate\">".$crp_data['name']."</h1>";
								} else {
									echo "<p>".Translator('GlobalSysMgntAccount').".<br><i class=\"fal fa-file-certificate\"></i> ".Translator('LicenseUse')." : " . $licence_home."</p>";
								}
							?>
						</div>

						<?php if ($_SESSION['corp'] != "NOT_DEFINED") { ?>
						<p>
							<label>
								<i class="fal fa-envelope"></i>
								<?= Translator('EmailContact'); ?> : <a href="mailto://<?= $crp_data['contact_email'] ?>"><?= $crp_data['contact_email'] ?></a>
							</label><br>
						</p>
						<hr>
						
						<?php 
							// Licence informations
							$OTPusersCounter = $db->prepare('SELECT * FROM otp_tokens WHERE corpid = ?');
							$OTPusersCounter->execute(array($crp_data['corpid']));
							$countOTPUsers = $OTPusersCounter->rowCount();
							$Datefin = $crp_data['expire_date'];
							if (empty($Datefin)) {
										$BeforeExpireDate = $DumpExpireDateold;
										$Date_Expire_Date = str_replace('/', '-', $BeforeExpireDate);
										$Datefin = date('Y-m-d', strtotime($Date_Expire_Date));
							}
							$dateformateur = DateTime::createFromFormat('Y-m-d', $Datefin);
		                    if ($dateformateur == true) {
		                        $Datefinale = $dateformateur->format('d/m/Y');
		                    }
		                    else {
		                        $Datefinale = $Datefin;
		                    }

						?>
						<p>
							<label>
								<i class="fal fa-file-certificate"></i>
								<?= Translator('Licensee'); ?> : <?= $crp_data['name'] ?> 
							</label><br>
							<label>
								<i class="fal fa-users"></i>
								<?= Translator('AccessUsage'); ?> : <?= $countOTPUsers ?>/<?= $crp_data['users_max'] ?>
							</label><br>
							<! -- samuel - ajout de l'affichage de la date d'expiration -->
							<label>
								<i class="fal fa-clock"></i>
								<?= Translator('LicenseExpiryDate'); ?> : <?= $Datefinale ?>
							</label>
						</p>
						<?php } else { ?>
						<hr>
						<p>
							<label>
								<i class="fal fa-users"></i>
								<?= Translator('MaximumNumberOfUsers'); ?> : <?= $_SESSION['users_maximum'] ?>
							</label><br>
							<label>
								<i class="fal fa-clock"></i>
								<?= Translator('LicenseExpiryDate'); ?> : <?= $DumpExpireDateold ?>
							</label>
						</p>
						<?php } ?>
					</div>
					<div class="card-exer col-md-5">
						<div class="text-center">
							<h3><?= Translator('MyAccount'); ?></h3>
							<i class="fal fa-user hgt-ico"></i>
							<p class="text-secondary">
								<?= Translator('HomeAccountDescription'); ?>
							</p>
							<div class="f-foward-of-card">
								<a href="account.php" title="<?= Translator('MyAccount'); ?>">
									<?= Translator('ManageAccount'); ?>
									<i class="fal fa-angle-right"></i>
								</a>
							</div>
						</div>
					</div>
					<div class="card-exer col-md-5">
						<div class="text-center">
							<h3><?= Translator('Company'); ?></h3>
							<i class="fal fa-building hgt-ico"></i>
							<p class="text-secondary">
								<?= Translator('HomeCompanyDescription'); ?>
							</p>
							<div class="f-foward-of-card">
								<a href="companies.php" title="<?= Translator('Company'); ?>">
									<?= Translator('ManageOrganization'); ?>
									<i class="fal fa-angle-right"></i>
								</a>
							</div>
						</div>
					</div>
					<div class="card-exer col-md-5">
						<div class="text-center">
							<h3><?= Translator('Firewall'); ?></h3>
							<i class="fal fa-shield-alt hgt-ico"></i>
							<p class="text-secondary">
								<?= Translator('HomeFwDescription'); ?>
							</p>
							<div class="f-foward-of-card">
								<a href="firewall.php" title="<?= Translator('Firewall'); ?>">
									<?= Translator('ManageFirewall'); ?>
									<i class="fal fa-angle-right"></i>
								</a>
							</div>
						</div>
					</div>
					<div class="card-exer col-md-5">
						<div class="text-center">
							<h3><?= Translator('LDAPInterconnection'); ?></h3>
							<i class="fal fa-book-open hgt-ico"></i>
							<p class="text-secondary">
								<?= Translator('HomeLDAPDescription'); ?>
							</p>
							<div class="f-foward-of-card">
								<a href="ldap.php" title="<?= Translator('LDAPInterconnection'); ?>">
									<?= Translator('ManageLDAP'); ?>
									<i class="fal fa-angle-right"></i>
								</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<br><br>
	</main>

<?php include 'inc/footer.php'; ?>
