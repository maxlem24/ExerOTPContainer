<?php 
	// Dernière modification le : 07/10/2022
	// Par: Laurent ASSELIN
	
	include_once $_SERVER['DOCUMENT_ROOT'] . '/inc/translator.php';
	$module_page_name = Translator('Firewall');

	$show_navbar = true;
	$show_creds_usr = true;
	include 'inc/header.php'; 
	
	if (isset($_GET['page'])) {
		$page = htmlspecialchars($_GET['page']);
	} else {
		$page = NULL;
	}

	
	if (isset($_GET['camefrom'])) {
		$camefrom = htmlspecialchars($_GET['camefrom']);
	} else {
		$camefrom = NULL;
	}

	if ($_SESSION['level'] == 3 AND isset($_SESSION['id'])) {
		if (isset($_GET['TokenID'])) {
			$TokenID = htmlspecialchars($_GET['TokenID']);
		} else {
			$TokenID = NULL;
		}
	} else {
		$TokenID = $_SESSION['corp_token'];
	}
?>
	
	<main role="main" class="col-md-10 ml-sm-auto col-lg-10">
	<?php if ($page == "AddFirewall") { 
		if ($camefrom == "CreateNow") {
			$ExistTokenCorp = $db->prepare('SELECT * FROM otp_companies WHERE token = ?');
			$ExistTokenCorp->execute(array($TokenID));
			$countExCorp = $ExistTokenCorp->rowCount();
			$CORP_CE_DATA = $ExistTokenCorp->fetch();

			if ($_SESSION['level'] == 3) {
				$getCorpRef = $CORP_CE_DATA['corpid'];
			} else {
				$getCorpRef = $_SESSION['corp'];
			}

			$GetLdapDirectory = $db->prepare('SELECT * FROM otp_ldap WHERE corpid = ?');
			$GetLdapDirectory->execute(array($getCorpRef));
			$counterExistLdap = $GetLdapDirectory->rowCount();
			$GET_LDAP_DATA = $GetLdapDirectory->fetch();

			if (empty($TokenID) AND $_SESSION['level'] == 3) {
				$Session->setFlash(Translator('no_compagny_firewall'), "close", "error");
				header('Location: /firewall.php');
				exit();
			} elseif ($countExCorp == 0 AND $_SESSION['level'] == 3) {
				$Session->setFlash(Translator('company_not_found'), "close", "error");
				header('Location: /firewall.php');
				exit();
			}
			$ExistCorp = $db->query('SELECT * FROM otp_companies');
			if ($ExistCorp->rowCount() == 0) {
				$Session->setFlash(Translator('No_compagny_config'), "close", "error");
				header('Location: /firewall.php');
				exit();
			}
		?>
			<?php 
				if ($_SESSION['level'] == 1) {
					header('Location: /');
					exit();
				}
			
				if (isset($_POST['submitform_firewalluser'])) {
					if (isset($_POST['fireinput_shortname'], $_POST['fireinput_ip_or_fqdn_addr'], $_POST['emmet_inp_token'])) {
						//declaration variables filtrees
						if (filter_var($_POST['fireinput_ip_or_fqdn_addr'], FILTER_VALIDATE_IP)) {
							$fireinput_ip_or_fqdn_addr 	= 	htmlspecialchars($_POST['fireinput_ip_or_fqdn_addr']);
						} else {
							$Session->setFlash(Translator("valid_ip_firewall"), "close", "error");
							header('Location: '.$actual_link);
							exit();
						}
						$emmet_inp_token 			= 	htmlspecialchars($_POST['emmet_inp_token']);

						if (!empty($_POST['fireinput_ip_or_fqdn_addr']) AND !empty($_POST['emmet_inp_token'])) {
							//check if not exist ip_address on otp database_firewall
							$reqipsearch = $db->prepare("SELECT * FROM otp_firewall WHERE ipaddr = ?");
							$reqipsearch->execute(array($fireinput_ip_or_fqdn_addr));
							$ipaddrexist = $reqipsearch->rowCount();

							if ($_SESSION['level'] == 3) {
								$fireinput_nameclient 		= 	htmlspecialchars($CORP_CE_DATA['folder']);
							} else {
								$fireinput_nameclient 		= 	htmlspecialchars($_SESSION['corp_folder']);
							}

							if (empty($_POST['fireinput_shortname'])) {
								$fireinput_shortname = $fireinput_nameclient;
							} else {
								$fireinput_shortname = remove_special_chars($_POST['fireinput_shortname']);
							}

							$array_spaces 				= 	array(" ", " ", " ");
							$fireinput_shortname_proc	=	strtolower(str_replace($array_spaces, "_", $fireinput_shortname));
							$fireinput_nameclient_proc	=	strtolower(str_replace($array_spaces, "_", $fireinput_nameclient));
								
							if ($ipaddrexist == 0) {
								//check if not exist short_name on otp database_firewall
								$reqshortsearch = $db->prepare("SELECT * FROM otp_firewall WHERE short_name = ?");
								$reqshortsearch->execute(array($fireinput_shortname));
								$shortname_exist = $reqshortsearch->rowCount();
									
								if ($shortname_exist == 0) {
									$tokenID 	= 	generateToken(9999);
									$created_at	= 	return_date_all_actuelle();
										
									if ($_SESSION['level'] == 3 AND isset($_SESSION['id'])) {
										$corpid_db 	= htmlspecialchars($CORP_CE_DATA['folder']);
										$recup_corp = $db->prepare('SELECT * FROM otp_companies WHERE folder = ?');
										$recup_corp->execute(array($corpid_db));
										$ft_corp = $recup_corp->fetch();
											
										$corpid 	= $ft_corp['corpid'];
									} else {
										$corpid		=	htmlspecialchars($_SESSION['corp']);
									}
										
									if ($_POST['fireinput_ip_or_fqdn_addr'] != "127.0.0.1") {
										if ($_POST['fireinput_ip_or_fqdn_addr'] != "0.0.0.0") {
											if ($_POST['fireinput_shortname'] != "skel") {
												if ($_SESSION['level'] == 3 AND isset($_SESSION['id'])) {
													$FolderClient = htmlspecialchars($CORP_CE_DATA['folder']);
												} else {	
													$FolderClient = $_SESSION['corp_folder'];
												}

												$GetInfosCorp = $db->prepare('SELECT * FROM otp_companies WHERE folder = ?');
												$GetInfosCorp->execute(array($FolderClient));
												$GetDataCorp = $GetInfosCorp->fetch();

												$RecupExistLdapEx = $db->prepare('SELECT * FROM otp_ldap WHERE corpid = ?');
												$RecupExistLdapEx->execute(array($GetDataCorp['corpid']));
												$GetDataCorpLdap = $RecupExistLdapEx->fetch();
												$counterExistLdapEx = $RecupExistLdapEx->rowCount();
												
												// Creation de la Base LDAP si Non pré-Existante dans la base SQL
												
												if (isset($_POST['ldap_join'])) {
													if ($counterExistLdapEx == 0) {
														if (isset($_POST['ldapinput_namebase'], $_POST['ldapinput_uri'], $_POST['ldapinput_uriproto'], $_POST['ldapinput_loginpam_attr'], $_POST['ldapinput_bind_all'], $_POST['ldapinput_bind_password'], $_POST['ldapinput_bind_cpassword'])) {
															$ldapinput_namebase				=	htmlspecialchars($_POST['ldapinput_namebase']);
															$ldapinput_uri					=	htmlspecialchars($_POST['ldapinput_uri']);
															$ldapinput_uriproto				=	htmlspecialchars($_POST['ldapinput_uriproto']);
															if (!empty($_POST['ldapinput_uri2'])) {
																$ldapinput_uri2				=	htmlspecialchars($_POST['ldapinput_uri2']);
															} else {
																$ldapinput_uri2				=	"";
															}
															
															$ldapinput_uriproto				=	htmlspecialchars($_POST['ldapinput_uriproto']);
															if ($_POST['ldapinput_uriproto'] == "1") {
																$Resultldapinput_uriproto		=	"on";
															} else {
																$Resultldapinput_uriproto		=	"off";
															}
															
															$ldapinput_loginpam_attr		=	htmlspecialchars($_POST['ldapinput_loginpam_attr']);
															$ldapinput_bind_password		=	htmlspecialchars($_POST['ldapinput_bind_password']);
															$ldapinput_bind_cpassword		=	htmlspecialchars($_POST['ldapinput_bind_cpassword']);
															$ldapinput_bind_all				=	htmlspecialchars($_POST['ldapinput_bind_all']);
							
															if (!empty($_POST['ldapinput_namebase']) AND !empty($_POST['ldapinput_uri']) AND !empty($_POST['ldapinput_bind_all']) AND !empty($_POST['ldapinput_bind_password']) AND !empty($_POST['ldapinput_bind_cpassword'])) {
																// Check if not exist namebase on otp database_ldap
																$reqexistnamebase = $db->prepare("SELECT * FROM otp_ldap WHERE base_dn = ? AND corpid = ?");
																$reqexistnamebase->execute(array($ldapinput_namebase, $_SESSION['corp']));
																$namebase_exist = $reqexistnamebase->rowCount();
																
																if (!empty($_POST['ldapinput_loginpam_attr'])) {
																	$ldapinput_loginpam_attr_req = $ldapinput_loginpam_attr;
																} else {
																	$ldapinput_loginpam_attr_req = "samaccountname";
																}
																	
																if ($namebase_exist == 0) {
																	// Check if not exist loginattribute on otp database_ldap
																	$reqexistloginattribute = $db->prepare("SELECT * FROM otp_ldap WHERE loginattribute = ? AND corpid = ?");
																	$reqexistloginattribute->execute(array($ldapinput_loginpam_attr_req, $_SESSION['corp']));
																	$login_exist = $reqexistloginattribute->rowCount();
																		
																	if ($login_exist == 0) {
																		if ($ldapinput_bind_password == $ldapinput_bind_cpassword) {
																			$token					= 	generateToken(9999);
																			$created_at				= 	return_date_all_actuelle();
																			
																			$final_uri 				= 	$ldapinput_uri;
																			$final_uri2 			= 	$ldapinput_uri2;
																			
																			$sslproto				= 	$Resultldapinput_uriproto;
																			$final_bind_fin		 	= 	$ldapinput_bind_all;
																			$ldapinput_namebases1 	= 	$ldapinput_namebase;
																			
																			$ldapinput_namebase_shell 	= 	$ldapinput_namebases1;
																			$final_bind_fin_shell		= 	$final_bind_fin;
							
																			$RecupInfosLdapCorp = $db->prepare('SELECT * FROM otp_companies WHERE corpid = ?');
																			$RecupInfosLdapCorp->execute(array($corpid));
																			$query_ldap = $RecupInfosLdapCorp->fetch();
																			
																			if (!empty($_POST['ldapinput_uri2'])) {
																				if (filter_var($ldapinput_uri2, FILTER_VALIDATE_IP) OR filter_var($ldapinput_uri2, FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME)) {
																					//Creation Interco LDAP avec Annuaire de Secours
																					$InsertCmdlet = "sudo /usr/local/bin/ldap_pam.sh -b '" . $ldapinput_namebase_shell . "' -u " . $final_uri . " -v " . $final_uri2 . " -s " . $sslproto . " -d '" . $final_bind_fin_shell . "' -p '" . $ldapinput_bind_cpassword . "' -c " . $query_ldap['folder'] . " -l " . $ldapinput_loginpam_attr_req;
														
																					$RunCmdlet = $InsertCmdlet;
																					$insert_srv_ldapauth = shell_exec($RunCmdlet);
																																										
																					if ($insert_srv_ldapauth != 0) {
																						$Session->setFlash(Translator('impossible_LDAP_inter'), "close", "error");
																						header('Location: /firewall.php');
																						exit;
																					} else {
																						//Insertion des données dans la base 'otp_ldap' du nouvel utilisateur
																						$insert_ldap = $db->prepare("INSERT INTO otp_ldap(corpid, client, loginattribute, base_dn, ldap_uri, ldap_uri2, sslproto, binddn, created_at, token) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
																						$insert_ldap->execute(array($corpid, $fireinput_shortname, $ldapinput_loginpam_attr_req, $ldapinput_namebase_shell, $final_uri, $final_uri2, $sslproto, $final_bind_fin_shell, $created_at, $token));
																
																						//Ajout Client RADIUS 2FA dans le fichier clients.conf => interaction avec "nas_client_apache_mfa.sh"
																						$insert_srv_client_firewall = shell_exec("sudo /usr/local/bin/nas_client_apache_mfa.sh -i '$fireinput_ip_or_fqdn_addr' -c '$fireinput_nameclient_proc' -s '$emmet_inp_token' -n '$fireinput_shortname_proc'");
																						if ($insert_srv_client_firewall != 2) {
																							//Insertion des données dans la base 'opt_firewall' du nouvel utilisateur
																							$insert_fire = $db->prepare("INSERT INTO otp_firewall(corpid, short_name, client, ipaddr, secret, 2auth, tokenID, created_at) VALUES(?, ?, ?, ?, ?, ?, ?, ?)");
																							$insert_fire->execute(array($corpid, $fireinput_shortname, $fireinput_nameclient, $fireinput_ip_or_fqdn_addr, $emmet_inp_token, 1, $tokenID, $created_at));
																											
																							//Ajout dans les logs de la création du firewall
																							addLogEventOTP("[SUCCESS] The RADIUS client"." ". $fireinput_shortname.  "("  . $fireinput_nameclient . ")"." ". "has been correctly created by"." " . $_SESSION['username'] . ".");																						}
																					}
																					} else {
																						$Session->setFlash(Translator("Ip_fqdn_format"), "close", "error");
																						header('Location: /firewall.php');
																						exit();
																					}
			
																					//Ajout dans les logs de la création d'une nouvelle interconnexion LDAP
																					addLogEventOTP("[SUCCESS] A new LDAP connection named "." ". $ldapinput_namebase_shell ." "."has been created by"." ". $_SESSION['username'] . ".");
																					
																					$Session->setFlash(Translator('firewall_added_with_interconnexion'), "check", "success");
																					header('Location: /firewall.php');
																					exit();
																				} else {
																				if (filter_var($ldapinput_uri, FILTER_VALIDATE_IP) OR filter_var($ldapinput_uri, FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME)) {
																					//Creation Interco LDAP sans Annuaire de Secours
																					$InsertCmdlet = "sudo /usr/local/bin/ldap_pam.sh -b '" . $ldapinput_namebase_shell . "' -u " . $final_uri . " -s " . $sslproto . " -d '" . $final_bind_fin_shell . "' -p '" . $ldapinput_bind_cpassword . "' -c " . $query_ldap['folder'] . " -l " . $ldapinput_loginpam_attr_req;
																					$RunCmdlet = $InsertCmdlet;
																					$insert_srv_ldapauth = shell_exec($RunCmdlet);
																																										
																					if ($insert_srv_ldapauth != 0) {
																						$Session->setFlash(Translator('impossible_LDAP_inter'), "close", "error");
																						header('Location: /firewall.php');
																						exit();
																					} else {
																						//Insertion des données dans la base 'otp_ldap' du nouvel utilisateur
																						$insert_ldap = $db->prepare("INSERT INTO otp_ldap(corpid, client, loginattribute, base_dn, ldap_uri, sslproto, binddn, created_at, token) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)");
																						$insert_ldap->execute(array($corpid, $fireinput_shortname, $ldapinput_loginpam_attr_req, $ldapinput_namebase_shell, $final_uri, $sslproto, $final_bind_fin_shell, $created_at, $token));
																
																						//Ajout Client RADIUS 2FA dans le fichier clients.conf => interaction avec "nas_client_apache_mfa.sh"
																						$insert_srv_client_firewall = shell_exec("sudo /usr/local/bin/nas_client_apache_mfa.sh -i '$fireinput_ip_or_fqdn_addr' -c '$fireinput_nameclient_proc' -s '$emmet_inp_token' -n '$fireinput_shortname_proc'");
																						if ($insert_srv_client_firewall != 2) {
																							//Insertion des données dans la base 'opt_firewall' du nouvel utilisateur
																							$insert_fire = $db->prepare("INSERT INTO otp_firewall(corpid, short_name, client, ipaddr, secret, 2auth, tokenID, created_at) VALUES(?, ?, ?, ?, ?, ?, ?, ?)");
																							$insert_fire->execute(array($corpid, $fireinput_shortname, $fireinput_nameclient, $fireinput_ip_or_fqdn_addr, $emmet_inp_token, 1, $tokenID, $created_at));
																												
																							//Ajout dans les logs de la création du firewall
																							addLogEventOTP("[SUCCESS] The RADIUS client"." ". $fireinput_shortname . " ("  . $fireinput_nameclient . ")". " "."has been correctly created by"." ". $_SESSION['username'] . ".");
																						}
																					}	
																				} else {
																					$Session->setFlash(Translator("Ip_fqdn_format"), "close", "error");
																					header('Location: /firewall.php');
																					exit();
																				}
			
																				//Ajout dans les logs de la création d'une interconnexion LDAP
																				addLogEventOTP("[SUCCESS] A new LDAP connection named"." ". $ldapinput_namebase_shell ." "."has been correctly created by" ." ". $_SESSION['username'] . ".");
																				
																				$Session->setFlash(Translator('firewall_added_with_interconnexion'), "check", "success");
																				header('Location: /firewall.php');
																				exit();
																			}
																		} else {
																			$error = Translator('password_no_match');
																		}
																	} else {
																		$error = Translator('Pam_exist');
																	}
																} else {
																	$error =Translator('Already_LDAP_domain_name');
																}
															} else {
																$error = Translator('Fill_all_fields_LDAP');
															}
														}
													}
													
													if ($counterExistLdap == 0 AND $_SESSION['level'] == 3) {
														$Session->setFlash(Translator('firewall_added_with_interconnexion_client'), "check", "success");
														header('Location: /firewall.php');
													} else {
														$Session->setFlash(Translator("firewall_added_with_existing"), "check", "success");
														header('Location: /firewall.php');
														exit();
													}
												} elseif ((isset($_POST['ldap_prejoin'])) AND ($counterExistLdapEx != 0)) {
													$loginattribute = $GetDataCorpLdap['loginattribute'];
													$base_dn 		= $GetDataCorpLdap['base_dn'];
													$ldap_uri 		= $GetDataCorpLdap['ldap_uri'];
													$ldap_uri2 		= $GetDataCorpLdap['ldap_uri2'];
													$sslproto 		= $GetDataCorpLdap['sslproto'];
													$binddn 		= $GetDataCorpLdap['binddn'];

													$array_ldap_passwd 	 	= array("bindpw");
													$InsertCmdlet 			= 'grep -r bindpw /etc/pam_ldap_'.$GetDataCorp['folder'].'.conf';
													$RunCmdlet 				= escapeshellcmd($InsertCmdlet);
													$ldap_password_proc 	= shell_exec($RunCmdlet);
													$ldap_password_proc2 	= str_replace($array_ldap_passwd, "", $ldap_password_proc);
													$ldap_password 		 	= trim(preg_replace('/\s+/', ' ', $ldap_password_proc2));
													
													// Ajout firewall avec config LDAP déjà dans la base SQL
														
													if (!empty($ldap_uri2)) {
														// Ajout LDAP double
														$InsertCmdlet = "sudo /usr/local/bin/ldap_pam.sh -b '" . $base_dn . "' -u " . $ldap_uri . " -v " . $ldap_uri2 . " -s " . $sslproto . " -d '" . $binddn . "' -p '" . $ldap_password . "' -c " . $GetDataCorp['folder'] . " -l " . $loginattribute;
														$RunCmdlet = $InsertCmdlet;
														$insert_srv_ldapauth = shell_exec($RunCmdlet);
													} else {
														// Ajout LDAP simple
														$InsertCmdlet = "sudo /usr/local/bin/ldap_pam.sh -b '" . $base_dn . "' -u " . $ldap_uri . " -s " . $sslproto . " -d '" . $binddn . "' -p '" . $ldap_password . "' -c " . $GetDataCorp['folder'] . " -l " . $loginattribute;
														$RunCmdlet = $InsertCmdlet;
														$insert_srv_ldapauth = shell_exec($RunCmdlet);
													}

													//Ajout Client RADIUS 2FA dans le fichier clients.conf => interaction avec "nas_client_apache_mfa.sh"
													$insert_srv_client_firewall = shell_exec("sudo /usr/local/bin/nas_client_apache_mfa.sh -i '$fireinput_ip_or_fqdn_addr' -c '$fireinput_nameclient_proc' -s '$emmet_inp_token' -n '$fireinput_shortname_proc'");
													if ($insert_srv_client_firewall != 2) {
														//Insertion des données dans la base 'opt_firewall' du nouvel utilisateur
														$insert_fire = $db->prepare("INSERT INTO otp_firewall(corpid, short_name, client, ipaddr, secret, tokenID, created_at) VALUES(?, ?, ?, ?, ?, ?, ?)");
														$insert_fire->execute(array($corpid, $fireinput_shortname, $fireinput_nameclient, $fireinput_ip_or_fqdn_addr, $emmet_inp_token, $tokenID, $created_at));
														
														if (isset($_POST['ldap_prejoin'])) {
															// Update oAuth with Firewall
															$UpdateFireStat = $db->prepare('UPDATE otp_firewall SET 2auth = ? WHERE tokenID = ?');
															$UpdateFireStat->execute(array(1, $tokenID));
														}
																			
														//Ajout dans les logs de la création du firewall
														addLogEventOTP("[SUCCESS] The RADIUS client"." ". $fireinput_shortname . " ("  . $fireinput_nameclient . ")". " "."has been correctly created by"." ". $_SESSION['username'] . ".");
																																					
														$Session->setFlash(Translator('firewall_config'), "check", "success");
														header('Location: /firewall.php');
														exit();
													} else {
														$Session->setFlash(Translator('Firewall_error'), "close", "error");
														header('Location: /firewall.php');
														exit();
													}

													// Update oAuth with Firewall
													$UpdateFireStat = $db->prepare('UPDATE otp_firewall SET 2auth = ? WHERE tokenID = ?');
													$UpdateFireStat->execute(array(1, $tokenID));
												} else {
													//Ajout client RADIUS en OTP seul dans le fichier clients.conf => interaction avec "nas_client_apache.sh"
													$insert_srv_client_firewall = shell_exec("sudo /usr/local/bin/nas_client_apache.sh -i '$fireinput_ip_or_fqdn_addr' -c '$fireinput_nameclient_proc' -s '$emmet_inp_token' -n '$fireinput_shortname_proc'");
													if ($insert_srv_client_firewall != 2) {
														//Insertion des données dans la base 'opt_firewall' du nouvel utilisateur
														$insert_fire = $db->prepare("INSERT INTO otp_firewall(corpid, short_name, client, ipaddr, secret, tokenID, created_at) VALUES(?, ?, ?, ?, ?, ?, ?)");
														$insert_fire->execute(array($corpid, $fireinput_shortname, $fireinput_nameclient, $fireinput_ip_or_fqdn_addr, $emmet_inp_token, $tokenID, $created_at));

														
														if (isset($_POST['ldap_prejoin'])) {
															// Update oAuth with Firewall
															$UpdateFireStat = $db->prepare('UPDATE otp_firewall SET 2auth = ? WHERE tokenID = ?');
															$UpdateFireStat->execute(array(1, $tokenID));
														}
																			
														//Ajout dans les logs de la création du firewall
														addLogEventOTP("[SUCCESS] The RADIUS client"." ". $fireinput_shortname . " ("  . $fireinput_nameclient . ")". " "."has been correctly created by"." ". $_SESSION['username'] . ".");														
														
														$Session->setFlash(Translator('firewall_config'), "check", "success");
														header('Location: /firewall.php');
														exit();
													} else {
														$Session->setFlash(Translator('Firewall_error'), "close", "error");
														header('Location: /firewall.php');
														exit();
													}
												}
											} else {
												$error = Translator('short_service_name');
											}
										} else {
											$error = Translator('refused_IP_addr');
										}
									} else {
										$error = Translator('Local_IP_refused');
									}
								} else {
									$error = Translator("short_service_name_allowed");
								}
							} else {
								$error = Translator("IP_already_exits");
							}
						} else {
							$error = Translator('Fill_all_fields');
						}
					}
				}
			?>
			
			<form method="POST" name="FormFireWall">
				<div class="formaddfirewall">
					<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
						<h1 class="h2"><?= $module_page_name ?> <exer class="text-secondary"><i class="far fa-chevron-right chevronexer_openform"></i></exer> <i><?= Translator('Create_firewall');?></i></h1>
						
						<div class="btn-group">
							<button type="submit" name="submitform_firewalluser" id="submitform_firewalluser" class="exerotpbtn btn-green btn-sm ripple-effect ripple-white"><i class="far fa-save dwnl_small_addelement_icon"></i> <?= Translator('Confirm');?></button>
							<a href="/firewall.php"><button type="button" class="exerotpbtn btn-red btn-sm ripple-effect ripple-white" style="margin-left:10px;"><i class="far fa-times dwnl_small_addelement_icon"></i> <?= Translator('Cancel');?></button></a>
						</div>
					</div>
					
					<?php if (isset($error)) { ?>
						<div class="alert alert-danger" role="alert">
							<i class="fas fa-exclamation-triangle"></i> <?= $error ?>
						</div>
					<?php } ?>

					<div class="alert alert-info">
						<i class="fal fa-building"></i> <strong><?= Translator('Selected_company');?></strong><?= $CORP_CE_DATA['name'] ?>
					</div>
					
					<fieldset class="fieldset_exerotp">
						<legend class="legend_exerotp"><?= Translator('Info');?></legend>
						<div id="submit_formfirewall_user">
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<label for="fireinput_shortname"><?= Translator('Short_name');?> :</label>
										<input type="text" name="fireinput_shortname" autocomplete="off" class="form-control" id="fireinput_shortname" value="<?php if (isset($fireinput_shortname)) { echo $fireinput_shortname; } ?>" placeholder= "<?= Translator('my_service');?>">
									</div>
								</div>

								<div class="col-md-6">
									<div class="form-group">
										<label for="fireinput_ip_or_fqdn_addr"><?= Translator('IP_addr');?> : <b class="text-danger" title=<?= Translator('Field_required');?> data-toggle="tooltip" data-placement="right"><i class="far fa-asterisk"></i></b></label>
										<input type="text" name="fireinput_ip_or_fqdn_addr" autocomplete="off" class="form-control" id="fireinput_ip_or_fqdn_addr" value="<?php if (isset($fireinput_ip_or_fqdn_addr)) { echo $fireinput_ip_or_fqdn_addr; } ?>" placeholder="ex : A.B.C.D">
									</div>
								</div>
							</div>
							
							<div class="form-group">
								<label for="emmet_inp_firewall"><?= Translator('RADIUS_secret');?> : <b class="text-danger" title=<?= Translator('Field_required');?> data-toggle="tooltip" data-placement="right"><i class="far fa-asterisk"></i></b></label>
								
								<div class="row">
									<div class="col-lg-8">
										<input type="text" name="emmet_inp_token" autocomplete="off" class="form-control" id="emmet_inp_firewall" value="<?php if (isset($emmet_inp_firewall)) { echo $emmet_inp_firewall; } ?>">
									</div>
										
									<div class="col-lg-4">
										<div class="row">
											<div class="col-lg-7">
												<input style="display: none;" type="number" autocomplete="off" class="form-control" value="25" name="length" style="width: 110%;" placeholder="<?= Translator('current_size_key');?>">
											</div>
											
											<div class="col-lg-5">
												<button type="button" style="position: relative; top: 5px;" onclick="generate(); return verif_champ(document.FormFireWall.length.value);" class="exerotpbtn btn-defaultexer btn-sm ripple-effect ripple-white"><i class="far fa-sync dwnl_small_addelement_icon"></i> <?= Translator('Generate');?></button>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</fieldset>

					<script>
						window.onload = function () { 
							generate();
						};

						function generate() {
							FormFireWall.emmet_inp_token.value = randomPassword(FormFireWall.length.value);
						}

						function verif_champ(champ) {
							if (champ != "") {
								if (champ <10 ) {
									alert('<?= Translator('enter_10_characters'); ?>');
									document.getElementById("emmet_inp_firewall").value = Translator('Error');
									document.getElementById("emmet_inp_token").value = Translator('Error');
									return false;
								}
							} else {
								alert('<?= Translator('generate_key_size'); ?>');
								return false;
							}
						}
					</script>

					<br>
					<fieldset class="fieldset_exerotp">
						<legend class="legend_exerotp"><?= Translator('Two_factor');?></legend>
						
						<?php if ($counterExistLdap == 0) { ?>
							<label class="pure-material-checkbox" id="ldapcheckbox" style="margin-bottom: -5px;">
								<input type="checkbox" id="ldap_join" data-backdrop="static" data-keyboard="false" data-toggle="modal" data-target="#edit_infos_client" name="ldap_join">
								<span><?= Translator('Enable_dual_fac_auth');?></span>
							</label>
							<label class="text-success" id="ldapcheckboxsuccess">
								<i class="fas fa-check"></i> <?= Translator('LDAP_info_saved');?> —
								<a href="#" data-backdrop="static" data-keyboard="false" data-toggle="modal" data-target="#edit_infos_client"><?= Translator('Edit_LDAP_info');?></a>
							</label>
						<?php } else { ?>
							<label class="pure-material-checkbox" style="margin-bottom: -5px;">
								<input type="checkbox" name="ldap_prejoin" value="1">
								<span><?= Translator('Enable_dual_fac_auth_ex');?></span>
							</label>
						<?php } ?>
					</fieldset>
				</div>

				<?php if ($counterExistLdap == 0) { ?>
					<!-- Modal_add ldapclient -->
					<div class="modal fade" id="edit_infos_client" tabindex="-1" role="dialog" aria-labelledby="lblview_ldap" aria-hidden="true">
						<div class="modal-dialog modal-lg" role="document">
							<div class="modal-content">
								<div class="modal-header">
									<h5 class="modal-title" id="lblconfirm_view_ldapedit"><i class="far fa-pen"></i> <?= Translator('Add_new_lDAP_inter');?> : 
								</div>
								
								<div class="modal-body">
									<div class="card-none">
										<form method="POST" id="addLdapByFirewall" name="addLdapByFirewall">
											<div class="card-body-none">
												<style>#ldapcheckboxsuccess, #successactiveldapoauth {display:none;}</style>
												<script>
												function uncheck() {
													document.getElementById("ldap_join").checked = false;
												}

												$(document).ready(function() {
													$("#section_addldap__btncontrols_editing").hide();
													$("#savemodal_ldap").click(function() {
														$("#ldapcheckbox").hide();
														$("#ldapcheckboxsuccess").show();
														$("#successactiveldapoauth").show();
														$("#section_addldap__btncontrols").hide();
														$("#section_addldap__btncontrols_editing").show();
													});
												});

												$("#fireinput_shortname").bind("keyup paste", function() {
													$("#fireinput_shortname2").val($(this).val());
												});
												</script>

												<div class="alert alert-info">
													<?= Translator('Enabling_feature_auth');?>
												</div>

												<div class="alert alert-success" id="successactiveldapoauth">
													<i class="fas fa-check"></i> <?= Translator('Dual_fac_auth');?>
												</div>

												<div class="contain_controlbtns__addldap" id="section_addldap__btncontrols" style="display: block; position: absolute; top: 90px; left: 77%;">
													<button data-toggle="modal" data-dismiss="modal" id="savemodal_ldap" type="button" class="exerotpbtn btn-fab-mini btn-save ripple-effect ripple-dark" title=<?= Translator('Save');?>>
														<i class="far fa-save" style="margin-bottom: 3px;"></i>
													</button>
													
													<button type="button" id="cancel_addldap" onclick="uncheck()" data-dismiss="modal" class="exerotpbtn btn-fab-mini btn-cancel ripple-effect ripple-dark" title=<?= Translator('Cancel');?>>
														<i class="far fa-times" style="margin-bottom: 3px;"></i>
													</button>
												</div>

												<div class="contain_controlbtns__addldap" id="section_addldap__btncontrols_editing" style="display: block; position: absolute; top: 150px; left: 77%;">
													<button data-toggle="modal" data-dismiss="modal" id="savemodal_ldap" type="button" class="exerotpbtn btn-fab-mini btn-save ripple-effect ripple-dark" title=<?= Translator('Save_configuration');?>>
														<i class="far fa-save" style="margin-bottom: 3px;"></i>
													</button>

													<script>
													function confirmLDAP_Delete() {
														var result = confirm(Translator("delete_data_ldap_from")); 
														if (result == true) { 
															$("#edit_infos_client").modal('hide');

															$("#ldapcheckbox").show();
															$("#ldapcheckboxsuccess").hide();
															$("#successactiveldapoauth").hide();
															$("#section_addldap__btncontrols").show();
															$("#section_addldap__btncontrols_editing").hide();

															document.getElementById("ldap_join").checked = false;

															$("#addLdapByFirewall")[0].reset();
														} else { 
															$("#edit_infos_client").modal('show');
														}
													}
													</script>
													
													<button type="button" id="cancel_addldap" onclick="confirmLDAP_Delete()" class="exerotpbtn btn-fab-mini btn-cancel ripple-effect ripple-dark" title=<?= Translator('delete_informations_formulaire');?>>
														<i class="far fa-trash-alt" style="margin-bottom: 3px;"></i>
													</button>
												</div>
													<fieldset class="fieldset_exerotp">
														<legend class="legend_exerotp"><?= Translator('general');?></legend>
														<div id="submit_formfirewall_user">
															<div class="form-group">
																<label for="ldapinput_namebase"><?= Translator('LDAP_domain_name');?> : <b class="text-danger" title=<?= Translator('Field_required');?> data-toggle="tooltip" data-placement="right"><i class="far fa-asterisk"></i></b></label>
																<input type="text" name="ldapinput_namebase" autocomplete="off" class="form-control" id="ldapinput_namebase" value="<?php if (isset($ldapinput_namebase)) { echo $ldapinput_namebase; } ?>" placeholder="ex : DC=mycompany,DC=com">
															</div>
															<div class="form-group">
																<label for="ldapinput_loginpam_attr"><?= Translator('Unique_ID');?> : <b class="text-danger" title=<?= Translator('Field_required');?> data-toggle="tooltip" data-placement="right"><i class="far fa-asterisk"></i></b></label>
																<input type="text" name="ldapinput_loginpam_attr" autocomplete="off" class="form-control" id="ldapinput_loginpam_attr" value="<?php if (isset($ldapinput_loginpam_attr)) { echo $ldapinput_loginpam_attr; } ?>" placeholder="<?= Translator('by_default');?>">
															</div>
														</div>
													</fieldset>
													</div>

													<div class="card-body-none">
														<fieldset class="fieldset_exerotp">
															<legend class="legend_exerotp"><?= Translator('LDAP_serv');?></legend>
															<i><?= Translator('Method_used_optimal');?></i>
															<hr style="margin-top: 11px; margin-bottom: 10px;">
															<div id="uriFormLdapAddresses">
																<div class="row">
																	<div class="col-md-6">
																		<div class="form-group">
																			<label for="ldapinput_uri"><?= Translator('Primary_address');?> : <b class="text-danger" title=<?= Translator('Field_required');?> data-toggle="tooltip" data-placement="right"><i class="far fa-asterisk"></i></b></label>
																			<div class="input-group mb-2">
																				<input type="text" name="ldapinput_uri" autocomplete="off" class="form-control" id="ldapinput_uri" value="<?php if (isset($ldapinput_uri)) { echo $ldapinput_uri; } ?>" placeholder="ex : X.X.X.X">
																			</div>
																		</div>
																	</div>
																	<div class="col-md-6">
																		<div class="form-group">
																			<label for="ldapinput_uri2"><?= Translator('Secondary_address');?> : </label>
																			<div class="input-group mb-2">
																				<input type="text" name="ldapinput_uri2" autocomplete="off" class="form-control" id="ldapinput_uri2" value="<?php if (isset($ldapinput_uri2)) { echo $ldapinput_uri2; } ?>" placeholder="ex : X.X.X.X">
																			</div>
																		</div>
																	</div>
																</div>
																<div class="form-group">
																	<label for="ldapinput_uriproto"><?= Translator('SSL_protocols');?> : <b class="text-danger" title=<?= Translator('Field_required');?> data-toggle="tooltip" data-placement="right"><i class="far fa-asterisk"></i></b></label>
																	<div class="input-group mb-2">
																		<select class="form-control" name="ldapinput_uriproto" id="ldapinput_uriproto">
																			<optgroup label="Protocoles LDAP">
																				<option value="0">Plaintext (LDAP)</option>
																				<option value="1">TLS (LDAPS)</option>
																			</optgroup>
																		</select>
																	</div>
																</div>
															</div>
														</fieldset>
													</div>
												</div>
												<br>
												<fieldset class="fieldset_exerotp">
													<legend class="legend_exerotp"><?= Translator('Bind_auth');?></legend>
													<i style="margin-bottom: 20px;"><?= Translator('DN_bind_user_autho');?></i>
													<hr style="margin-top: 11px; margin-bottom: 10px;">
													<div class="form-group">
														<label for="ldapinput_bind_dncn"><?= Translator('DN_bind');?> : <b class="text-danger" title=<?= Translator('Field_required');?> data-toggle="tooltip" data-placement="right"><i class="far fa-asterisk"></i></b></label>
														<input type="text" name="ldapinput_bind_all" autocomplete="off" class="form-control" id="ldapinput_bind_all" value="<?php if (isset($ldapinput_bind_all)) { echo $ldapinput_bind_all; } ?>" placeholder="ex : CN=test,CN=Users,DC=mycompany,DC=com">
													</div>
													
													<div class="row">
														<div class="col-md-6">
															<div class="form-group">
																<label for="ldapinput_bind_password"><?= Translator('Password');?> : <b class="text-danger" title=<?= Translator('Field_required');?> data-toggle="tooltip" data-placement="right"><i class="far fa-asterisk"></i></b></label>
																<input type="password" name="ldapinput_bind_password" autocomplete="off" class="form-control" id="ldapinput_bind_password">
															</div>
														</div>
														
														<div class="col-md-6">
															<div class="form-group">
																<label for="ldapinput_bind_cpassword"><?= Translator('Confirm_password');?><b class="text-danger" title=<?= Translator('Field_required');?> data-toggle="tooltip" data-placement="right"><i class="far fa-asterisk"></i></b></label>
																<input type="password" name="ldapinput_bind_cpassword" autocomplete="off" class="form-control" id="ldapinput_bind_cpassword">
															</div>
														</div>
													</div>
												</fieldset>
												</div>
											</form>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				<?php }
		} else { ?>
			<?php if ($_SESSION['level'] == 3) {
				if (isset($_POST['nextsubmit_infoscorp'])) {
					if (!empty($_POST['fireinput_nameclient'])) {
						header('Location: /firewall.php?page=AddFirewall&camefrom=CreateNow&TokenID=' . htmlspecialchars($_POST['fireinput_nameclient']));
						exit();
					} else {
						$Session->setFlash(Translator('Fill_all_fields'), "close", "error");
						header('Location: '.$actual_link);
						exit();
					}
				} ?>

				<form method="POST">
					<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
						<h1 class="h2"><?= $module_page_name ?> <exer class="text-secondary"><i class="far fa-chevron-right chevronexer_openform"></i></exer> <i><?= Translator('Create_firewall');?></i></h1>
						
						<div class="btn-group">
							<button type="submit" name="nextsubmit_infoscorp" class="exerotpbtn btn-green btn-sm ripple-effect ripple-white"><i class="far fa-arrow-right dwnl_small_addelement_icon"></i> <?= Translator('next');?></button>
							<a href="/firewall.php"><button type="button" class="exerotpbtn btn-red btn-sm ripple-effect ripple-white" style="margin-left:10px;"><i class="far fa-times dwnl_small_addelement_icon"></i> <?= Translator('Cancel');?></button></a>
						</div>
					</div>

					<fieldset class="fieldset_exerotp">
						<legend class="legend_exerotp"><?= Translator('Corporate_assign');?></legend>
						<i><?= Translator('Select_client_comp');?> : </i>
						<hr style="margin-top: 11px; margin-bottom: 10px;">
						<div class="form-group">
							<select class="form-control" name="fireinput_nameclient" id="fireinput_nameclient">
								<?php 
									$corps_recorver = $db->query('SELECT * FROM otp_companies ORDER BY id ASC');
									while ($corp_recup = $corps_recorver->fetch()) {
								?>
									<option value="<?= $corp_recup['token'] ?>"><?= $corp_recup['name'] ?> </option>
								<?php } ?>
							</select>
						</div>
					</fieldset>
				</form>
			<?php } elseif ($_SERVER['REQUEST_URI'] != "/firewall.php?page=AddFirewall&camefrom=CreateNow") {
				header('Location: /firewall.php?page=AddFirewall&camefrom=CreateNow');
				exit();
			} ?>
		<?php } ?>

		
	<?php } else { ?>
		<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
			<h1 class="h2"><?= $module_page_name ?></h1>
			
			<?php if ($_SESSION['level'] !=1) { ?>
			<div class="btn-group">
				<a href="?page=AddFirewall"><button id="add_fireclient_firewall" class="exerotpbtn btn-defaultexer btn-sm ripple-effect ripple-white"><i class="far fa-plus dwnl_small_addelement_icon"></i> <?= Translator('Create_firewall');?></button></a>
			</div>
			<?php } ?>
		</div>

		<?php 
			if (checkLevel() != ADMIN) {
				if (checkLevel() == OPERATOR && $_SESSION['corp'] == "NOT_DEFINED") {
					$recup_all_firewall = $db->query('SELECT * FROM otp_firewall ORDER BY id DESC');
				} elseif (checkLevel() == OPERATOR && $_SESSION['corp'] != "NOT_DEFINED") {
					$recup_all_firewall = $db->prepare('SELECT * FROM otp_firewall WHERE corpid = ? ORDER BY id DESC');
					$recup_all_firewall->execute(array($_SESSION['corp']));
				} else {
					$recup_all_firewall = $db->query('SELECT * FROM otp_firewall ORDER BY id DESC');
				}
			} else {
				$recup_all_firewall = $db->prepare('SELECT * FROM otp_firewall WHERE corpid = ? ORDER BY id DESC');
				$recup_all_firewall->execute(array($_SESSION['corp']));
			}
			
			$count_firewall = $recup_all_firewall->rowCount();
			if ($count_firewall == 0) { ?>

				<div class="alert alert-danger" role="alert">
					<i class="fas fa-exclamation-triangle"></i> <?= Translator('No_firewall_config');?>
				</div>
				<?php } else { ?>
					<div class="alert alert-info" role="alert">
						<i class="far fa-info-circle"></i>
						<?= Translator('Display'); echo "<strong> ". $count_firewall . " </strong>"; if ($count_firewall >1) { echo Translator('fires'); } else { echo Translator('fire'); } ?>.
					</div>
					
					<input type="text" id="searchboxTable" placeholder= "<?= Translator('find_a_firewall');?>" title="<?= Translator('find_a_firewall');?>">

					<script>
						$(document).ready(function() {
							$("#searchboxTable").on("keyup", function() {
								var value = $(this).val().toLowerCase();
								$("#byValDataT tr").filter(function() {
									$(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
								});
							});

							$("#searchboxTable").on("keyup", function() {
								var name = $(this).val();
								if (name.length >= 1) {
								var box = paginator({
									table: document.getElementById("container_table").getElementsByTagName("table")[0],
									box_mode: "list",
									rows_per_page: "0",
									get_rows: function () {
										return document.getElementById("table_otpexer").getElementsByTagName("tbody");
									},
								});
								$('.pgnt_tab').hide();
								return false;
								} else {
								var box = paginator({
									table: document.getElementById("container_table").getElementsByTagName("table")[0],
									box_mode: "list",
									rows_per_page: "10",
								});
								$('.pgnt_tab').show();
								return false;
								}
							});

							var box = paginator({
								table: document.getElementById("container_table").getElementsByTagName("table")[0],
								box_mode: "list",
								rows_per_page: "10",
							});
							document.getElementById("container_table").appendChild(box);
						});
					</script>
					
					<div class="table-responsive" id="container_table">
						<table id="table_otpexer" class="sortable-theme-bootstrap table-striped" data-sortable>
							<thead>
								<tr>
									<?php if ($_SESSION['corp'] == "NOT_DEFINED") { ?>
										<th class="vt-default-th" data-sorted-direction="descending"><?= Translator('Company');?></th>
									<?php } ?>
									
									<th <?php if ($_SESSION['corp'] != "NOT_DEFINED") { echo 'class="vt-default-th" data-sorted-direction="descending"'; } ?>><?= Translator('name');?></th>
									<th><?= Translator('IP_addr');?></th>
									<th><?= Translator('double_auth');?></th>
									<th><?= Translator('Creation_date');?></th>
									<th data-sortable="false"> </th>
								</tr>
							</thead>
							<tbody id="byValDataT">
							<?php 
								while ($recorver_datas_fireclient = $recup_all_firewall->fetch()) { ?>
								<tr>
									<?php 
									$corps_recorver = $db->prepare('SELECT * FROM otp_companies WHERE corpid = ?');
									$corps_recorver->execute(array($recorver_datas_fireclient['corpid']));
									$recover_corp = $corps_recorver->fetch();
									
									if ($_SESSION['level'] != 2 AND $_SESSION['corp'] == "NOT_DEFINED") { ?>
									<td>
										<?= $recover_corp['name']; ?>
									</td>
									<?php } ?>
									<td><?= $recorver_datas_fireclient['short_name'] ?></td>
									<td><a title="Accéder au pare-feu" target="_blank" href="//<?= $recorver_datas_fireclient['ipaddr'] ?>"><?= $recorver_datas_fireclient['ipaddr'] ?></a></td>			
									<td>
										<?php if ($recorver_datas_fireclient['2auth'] != 0) { ?>
											<label class="badge badge-success"><?= Translator('Actv');?></label>
										<?php } else { ?>
											<label class="badge badge-danger"><?= Translator('Deactv');?></label>
										<?php } ?>
									</td>

									<td>
										<?=  date_format(date_create($recover_corp['created_at']),"d/m/Y"); ?>
									</td>

									<?php
										$rand_client_modal = generateToken(9999);
									?>
									<?php if (checkLevel() != OPERATOR) { ?>
										<!-- Modal_confirm suppression fireclient -->
										<div class="modal fade" id="confirm_delete_fireclient__<?= $rand_client_modal ?>" tabindex="-1" role="dialog" aria-labelledby="lblconfirm_delete_fireclient" aria-hidden="true">
											<div class="modal-dialog modal-lg" role="document">
												<div class="modal-content">
													<div class="modal-header">
														<h5 class="modal-title" id="lblconfirm_delete_fireclient"><i class="far fa-trash-alt"></i> <?= Translator('Remove_firewall');?></h5>
														<button type="button" class="close" data-dismiss="modal" aria-label="Close">
															<span aria-hidden="true"><i class="far fa-times"></i></span>
														</button>
													</div>
															
													<div class="modal-body">
														<label><?= Translator('Confirm_remov_firewall');?> <b><?= $recorver_datas_fireclient['short_name']; ?> </b> <?= Translator('Belonging_client');?> <b><?= $recorver_datas_fireclient['client']; ?> </b> ?</label>
													</div>
															
													<div class="modal-footer">
														<?php
															if (isset($_POST['del_this_firewall__' . $recorver_datas_fireclient['tokenID']])) {
																unset($_SESSION['token_access_deletefirewall']);
																unset($_SESSION['folderFireDelete']);
																$_SESSION['folderFireDelete'] = $recover_corp['name'];
																$_SESSION['token_access_deletefirewall'] = $recorver_datas_fireclient['tokenID'];

																header('Location: inc/class.actions.php?VerbAction=DeleteFirewall');
																exit();
															}
														?>
															
														<form method="POST">
															<button type="button" class="exerotpbtn btn-cancel ripple-effect ripple-white" data-dismiss="modal"><?= Translator('Cancel');?></button>
															<button type="submit" name="del_this_firewall__<?= $recorver_datas_fireclient['tokenID'] ?>" class="exerotpbtn btn-green ripple-effect ripple-white"><?= Translator('Confirm');?></button>
														</form>
													</div>
												</div>
											</div>
										</div>
										<?php } ?>
										
										<!-- Modal_viewinfos fireclient -->
										<div class="modal fade" id="view_infos_client__<?= $rand_client_modal ?>" tabindex="-1" role="dialog" aria-labelledby="lblview_fireclient" aria-hidden="true">
											<div class="modal-dialog modal-lg" role="document">
												<div class="modal-content">
													<div class="modal-header">
														<h5 class="modal-title" id="lblconfirm_view_fireclient"><i class="far fa-shield-alt"></i> <?= Translator('Viewing_firewall');?> <b><?= $recorver_datas_fireclient['short_name']; ?></b></h5>
														<button type="button" class="close" data-dismiss="modal" aria-label="Close">
															<span aria-hidden="true"><i class="far fa-times"></i></span>
														</button>
													</div>
													
													<a href="javascript:void()" title="<?= Translator('print')?>" class="btn_print_firewall" id="btnPrint__<?= $recorver_datas_fireclient['tokenID'] ?>"><i class="far fa-print fa-2x"></i></a>
													
													<div id="printThis__<?= $recorver_datas_fireclient['tokenID'] ?>">
														<div class="modal-body">
															<div class="card">
																<h5 class="card-header"> <?= Translator('Radius_firewall');?> <?= $recorver_datas_fireclient['short_name'] ?></h5>
																<div class="card-body">
																	<label><b><?= Translator('Service_name');?> :</b> <?= $recorver_datas_fireclient['short_name'] ?> </label><br>
																	<label><b><?= Translator('Client_2');?> :</b> <?= $recorver_datas_fireclient['client'] ?></label><br>
																	<label><b><?= Translator('IP_addr');?> :</b> <?= $recorver_datas_fireclient['ipaddr'] ?></label><br>
																	<label><b><?= Translator('RADIUS_secret');?> :</b> <?= $recorver_datas_fireclient['secret'] ?></label><br>
																	<label><b><?= Translator('Creation_date');?> :</b> <?php if ($recorver_datas_fireclient['created_at'] != "0000-00-00 00:00:00") { echo date_format(date_create($recorver_datas_fireclient['created_at']),"d/m/Y  H:i"); } else { echo Translator('no_creation_date'); } ?></label>
																</div>
															</div>
														</div>
													</div>			
													
													<div class="modal-footer">
														<button type="button" class="exerotpbtn btn-white ripple-effect ripple-dark" data-dismiss="modal"><?= Translator('Close');?></button>
													</div>
												</div>
											</div>
										</div>

										<td>
											<button type="button" name="view_infos_client__<?= $rand_client_modal ?>" data-toggle="modal" data-target="#view_infos_client__<?= $rand_client_modal ?>" title=<?= Translator('Viewing_firewall');?> class="exerotpbtn btn-defaultexer btn-sm ripple-effect ripple-black"><i class="far fa-eye dwnl_small_addelement_icon delete_action_button_item"></i></button>
											
											<?php if (checkLevel() != OPERATOR) { ?>
											<button type="button" class="exerotpbtn btn-sm btn-red ripple-effect ripple-white" data-toggle="modal" data-target="#confirm_delete_fireclient__<?= $rand_client_modal ?>" title=<?= Translator('Delete');?>><i class="far fa-trash-alt dwnl_small_addelement_icon delete_action_button_item"></i></button>
											<?php } ?>
										</td>
									</tr>
									<script>
										document.getElementById("btnPrint__<?= $recorver_datas_fireclient['tokenID'] ?>").onclick = function () {
											printElement(document.getElementById("printThis__<?= $recorver_datas_fireclient['tokenID'] ?>"));
										}
													
										function printElement(elem) {
											var domClone = elem.cloneNode(true);		
											var $printSection = document.getElementById("printSection");
														
											if (!$printSection) {
												var $printSection = document.createElement("div");
												
												$printSection.id = "printSection";
												document.body.appendChild($printSection);
											}
														
											$printSection.innerHTML = "";
											$printSection.appendChild(domClone);
											window.print();
										}
									</script>
							<?php } ?>
							</tbody>
						</table>
					</div>
				<?php
			}
		?>		
		
	<?php } ?>
	</main>

<?php include 'inc/footer.php'; ?>