<?php
	// Dernière modification le : 27/04/2022
	// Par: Laurent Asselin
	
	include_once $_SERVER['DOCUMENT_ROOT'] . '/inc/translator.php';
	$module_page_name = Translator('OTPAudit');

	$show_navbar 		= true;
	$show_creds_usr 	= true;

	include_once 'inc/header.php';

	if (checkLevel() == ADMIN) {
		header('Location: /');
		exit();
	} elseif (checkLevel() == OPERATOR && $_SESSION['corp'] != "NOT_DEFINED") {
		header('Location: /');
		exit();
	}
?>

	<style>
	body {
		overflow: hidden;
	}
	.table-responsive {
		max-height: 600px !important;
	}
	</style>

	<main role="main" class="col-md-10 ml-sm-auto col-lg-10">
		<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
			<h1 class="h2"><?= $module_page_name ?></h1>
		</div>

		<input type="text" id="searchboxTable" placeholder="<?= Translator('research'); ?>" title="<?= Translator('fill_this_field_with_keyword'); ?>">

		<script>
			$(document).ready(function() {
				$("#searchboxTable").on("keyup", function() {
					var value = $(this).val().toLowerCase();
					$("#byValDataT tr").filter(function() {
					$(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
					});
				});

				$("#searchboxTable").on("keyup", function() {
					var name = $(this).val();
					if (name.length >= 1) {
						var box = paginator({
							table: document.getElementById("container_table").getElementsByTagName("table")[0],
								box_mode: "list",
								rows_per_page: "0",
								get_rows: function () {
								return document.getElementById("table_otpexer").getElementsByTagName("tbody");
							},
						});
						$('.pgnt_tab').hide();
						$(".allCheck").hide();
						return false;
					} else {
						var box = paginator({
							table: document.getElementById("container_table").getElementsByTagName("table")[0],
							box_mode: "list",
							rows_per_page: "10",
					});
					$('.pgnt_tab').show();
					$(".allCheck").show();
					return false;
					}
				});

				var box = paginator({
					table: document.getElementById("container_table").getElementsByTagName("table")[0],
					box_mode: "list",
					rows_per_page: "10",
				});
				document.getElementById("container_table").appendChild(box);
			});
		</script>

		<div class="table-responsive" id="table_logsexer">
			<table id="table_otpexer" class="sortable-theme-bootstrap table-striped" data-sortable>
				<thead class="thead-light">
					<tr>
						<th class="vt-default-th" data-sorted-direction="descending"><?= Translator('Date'); ?></th>
						<th><?= Translator('Type'); ?></th>
						<th><?= Translator('Mess_comm'); ?></th>
					</tr>
				</thead>
				<tbody id="byValDataT">
					<?php
					$f = new ReverseFile("/var/www/logs_otp/actions_otp.log");

					$i=0;
					foreach ($f as $line) {
						$tab = explode(' ', $line);
							
						if (isset($tab[0],$tab[7])) {
							$i++;
							$date_log = $tab[0] . " " . $tab[1] . " " . $tab[2]. " " . $tab[3] . " " . $tab[4];
							$array_replace = array('[', ']');
							$Date = str_replace($array_replace, "", $date_log);

							$old_date_timestamp = strtotime($Date);
							$new_date = date(Translator('date_format'), $old_date_timestamp);
							
							switch ($tab[6]) {
								case '[ERROR]':
									$LabStatus 	= "Error";
									$Status 	= "danger";
									break;
								case '[SUCCESS]':
									$LabStatus 	= "Success";
									$Status 	= "success";
									break;
								case '[INFORMATION]':
									$LabStatus 	= "Information";
									$Status 	= "info";
									break;
								
								default:
									$LabStatus	= "Unknown";
									$Status		= "secondary";
									break;
							}

							$Message = explode($tab[6], $line);
							if (isset($Message[1])) {
								$LabMessage = $Message[1];
							} else {
								$LabMessage = "N/A";
												}
							
							echo "<tr>";
							echo '
							<td data-value="'.$old_date_timestamp.'" style="min-width: 12rem;">
							'.$new_date.'
							</td>';
							echo '<td><span class="badge badge-'.$Status.'">'.$LabStatus.'</span></td>';
							
							echo "<td>".$LabMessage."</td>";
							echo "</tr>";
							}
						}
					?>
				</tbody>
			</table>
		</div>
	</main>

<?php include 'inc/footer.php'; ?>