<?php
	// Derni�re modification le : 18/05/2022
	// Par: Laurent ASSELIN
	
	$module_page_name = "Application";
	$show_navbar = true;
	$show_creds_usr = true;
	include 'inc/header.php';
	include 'inc/translator.php';
?>
<html>
	<head></head>
	
	<body onselectstart="return false" oncontextmenu="return false" ondragstart="return false">
		<iframe src="/" style="position:fixed; top:0px; left:0px; bottom:0px; right:0px; width:100%; height:100%; border:none; margin:0; padding:0; overflow:hidden; z-index:999999;">
			<?= Translator('Browser_not_support'); ?>
		</iframe>
	</body>
</html>
<?php 
	include 'inc/footer.php';
?>