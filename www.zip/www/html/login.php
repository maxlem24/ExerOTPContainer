<?php 
	// Dernière modification le : 18/01/2023
	// Par: Laurent ASSELIN
	
	include_once $_SERVER['DOCUMENT_ROOT'] . '/inc/translator.php';
	$module_page_name = Translator('Login');

	$show_navbar = false;
	$show_creds_usr = false;
	include 'inc/header.php';
		
	if (isset($_SESSION['id'])) {
		header('Location: /');
		exit();
	}
	
	if(isset($_POST['submit'])) {
		$username = htmlspecialchars($_POST['username']);
		$password = $_POST['password'];

		if (!empty($_POST['username']) AND !empty($_POST['password'])) {
			$Connection = $db->prepare('SELECT * FROM otp_users WHERE (username = :username OR email = :email)');
			$Connection->execute([
				'username' 	=> $username,
				'email'		=> $username
			]);
			$info_user = $Connection->fetch();

			if (password_verify($_POST['password'], $info_user['password'])) {
				$_SESSION['corp']	= $info_user['corp'];
				$_SESSION['level']	= $info_user['level'];

				if ($_SESSION['level'] == 2 && ($_SESSION['corp'] == "NOT_DEFINED" || $_SESSION['corp'] == "choseCorp")) {
					$error = Translator('bad_configuration_user')."<br>".Translator('administrator_assit');
					addLogEventOTP("[ERROR] Roles assigned to " . $username . " are incorrects. No company assigned to this company admin... (NOT DEFINED)");
				} elseif (checkLevel() == SUPERVISOR && $_SESSION['corp'] != "NOT_DEFINED") {
					$error = Translator('bad_configuration_user')."<br>".Translator('administrator_assit');
					addLogEventOTP("[ERROR] Roles assigned to " . $username . " are incorrects. No company assigned to this company admin... (NOT DEFINED)");
				} else {
					####
					## Récupération des données de la session
					####
					$_SESSION['id']				= $info_user['id'];
					$_SESSION['lastname']		= $info_user['lastname'];
					$_SESSION['firstname']		= $info_user['firstname'];
					$_SESSION['username']		= $info_user['username'];
					$_SESSION['email']			= $info_user['email'];
					$_SESSION['password']		= $info_user['password'];
					$_SESSION['lastip']			= $info_user['lastip'];
					$_SESSION['last_connected']	= $info_user['last_connected'];
					$_SESSION['enable']			= $info_user['enable'];
					
					if ($_SESSION['enable'] != 0) {
						//Enregistrement date
						$date_actuelle  =  date('Y-m-d H:i:s');
						$recovery_last_connection = $db->prepare("UPDATE otp_users SET last_connected = NOW() WHERE id = {$_SESSION['id']} LIMIT 1");
						$recovery_last_connection->execute(array($date_actuelle, $_SESSION['id']));

						$insert_this_connection = $db->prepare("INSERT INTO otp_connections(userid, ipaddress, connected_at) VALUES(?, ?, ?)");
						$insert_this_connection->execute(array($_SESSION['id'], $ip_get, return_date_all_actuelle()));														
						
						//Enregistrement adresse ip du client
						$recovery_last_connection = $db->prepare("UPDATE otp_users SET lastip = ? WHERE id = ?");
						$recovery_last_connection->execute(array($ip_get, $_SESSION['id']));

						addLogEventOTP("[INFORMATION] New connection made by " . $_SESSION['username']);
						$Session->setFlash(Translator('you_are_connected'), "check", "success");
					}
					
					if (!empty($_GET['NextPage'])) {
						header('Location: ' . $NextPage);
						exit();
					} else {
						header('Location: /');
						exit();
					}
				}
			} else {
				$error = Translator('bad_password_or_login');
				addLogEventOTP("[ERROR] Connection attempt for " .$username." failed : incorrect user or password");
			}
		} else {
			$error = Translator('bad_password_or_login');
			addLogEventOTP("[ERROR] Connection attempt for ".$username." failed : user or password empty");
		}
	}
?>

<!DOCTYPE html>
<html lang="fr">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="description" content="Exer OTP - Application de génération OTP EXER">
		<meta name="author" content="Exer SAS">
		<title><?= $WhiteLabel ?> - <?= $module_page_name ?></title>

		<link rel="canonical" href="/">
		
		<link rel="shortcut icon" type="image/x-icon" href="/assets/images/favicon.ico" /> 
		<link rel="icon" href="/assets/images/favicon.ico" />

		<link rel="stylesheet" href="/assets/styles/notexer.css">
		<link rel="stylesheet" href="/assets/libs/fontawesome/css/all.css">
		<link rel="stylesheet" href="/assets/styles/login_exerotp.css">
	</head>

	<form class="form-signin rowf logo_exer_animation fadeIn" method="POST">
		<div class="logo-border-exer">
			<img class="mb-4 text-center" src="/assets/images/brandmark.png" alt="Logo <?= $WhiteLabel ?>" height="50" style="max-height: 45px;">
		</div>

		<div class="formlogin-border-exer">
			<label for="inputEmail" class="sr-only"><?php echo Translator('UsernameOrEmail'); ?></label>
			<input type="text" name="username" id="inputEmail" class="form-control ripple-effect ripple-dark" value="<?php if (isset($username)){ echo $username; } ?>" placeholder="<?php echo Translator('UsernameOrEmail'); ?>" <?php if (!isset($username)){ echo "autofocus"; } ?>>
			<label for="inputPassword" class="sr-only"><?php echo Translator('Password'); ?></label>
			<input type="password" name="password" id="inputPassword" class="form-control ripple-effect ripple-dark" placeholder="<?php echo Translator('Password'); ?>" <?php if (isset($username)){ echo "autofocus"; } ?>>
			<br>
			<button class="btnlogin exerotpbtn ripple-effect ripple-dark btn-block" type="submit" name="submit"><?php echo Translator('Login'); ?></button>
			<br><br>
			<?php if (isset($error)) { ?>
			<div class="alert alert-danger" role="alert">
				<i class="fas fa-info-circle"></i> <?= $error ?>
			</div>
			<?php } ?>
		</div>
	</form>
</body>

</html>

<footerexer>
	&copy; <?= date('Y') ?> <?= $WhiteLabel ?> - <?= Translator('AllRightReserved'); ?>
</footerexer>
	
<?php include 'inc/footer.php'; ?>