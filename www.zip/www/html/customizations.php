<?php
	// Dernières Modifications le 20/07/2023
	// Par : Laurent ASSELIN

	include_once $_SERVER['DOCUMENT_ROOT'] . '/inc/translator.php';
	$module_page_name = Translator('Customizations');

	$show_navbar = true;
	$show_creds_usr = true;
	include 'inc/header.php';

	const Transport_SMTPS = 1;
	const Transport_STARTTLS = 2;
	
	if (isset($_GET['camefrom'])) {
		$camefrom = htmlspecialchars($_GET['camefrom']);
	} else {
		$camefrom = NULL;
	}

	// Mailing Default registration
	if (isset($_SESSION['id'])) {
		$SystemAllCompanies = $db->query('SELECT * FROM otp_companies');
		
		while ($SysCompanies = $SystemAllCompanies->fetch()) {
			$MailingConfs = $db->prepare('SELECT * FROM otp_mailing WHERE corpid = ?');
			$MailingConfs->execute(array($SysCompanies['corpid']));
			
			$Sender = $SysCompanies['name'];

			if ($MailingConfs->rowCount() == 0) {
				$DefaultMailing = $db->prepare('INSERT INTO otp_mailing(corpid, host, transport, port, fqdn, issuer, sendmail, content, content_link, link_custom_btn1, link_custom_btn2, subject, created_at, token) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
				$DefaultMailing->execute(array($SysCompanies['corpid'], $GetRelayHost, 0, "25", $Mailing_CustomFQDN, $Sender, $SendMail, $Mailing_DefaultContent, $Mailing_DefaultContentLink, $Mailing_link_custom_btn1, $Mailing_link_custom_btn2, $Mailing_Subject, CurrentDateTime(), GenerateToken()));
			}
		}
	}
?>
	
	<main role="main" class="col-md-10 ml-sm-auto col-lg-10">
		<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
			<h1 class="h2"><?= $module_page_name ?></h1>
		</div>
		<?php
	if (checkLevel() == ADMIN) { ?>
		<div class="modal fade" id="mailTester" tabindex="-1" role="dialog" aria-labelledby="lblmailTester" aria-hidden="true">
			<div class="modal-dialog modal-lg" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title" id="lblmailTester"><i class="far fa-file-envelope"></i> <?= Translator('Send_test_email');?></h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true"><i class="far fa-times"></i></span>
						</button>
					</div>
					
					<form name="mailtesterForm" method="post">
						<?php 
							if (isset($_POST['testMailSender'])) {
								if (isset($_POST['mailing_sendmail_test'])) {
									if (!empty($_POST['mailing_sendmail_test'])) {
										$SendMailTest = htmlspecialchars($_POST['mailing_sendmail_test']);
	
										if (filter_var($SendMailTest, FILTER_VALIDATE_EMAIL)) {
											$MailingConfs = $db->prepare('SELECT * FROM otp_mailing WHERE corpid = ?');
											$MailingConfs->execute(array($_SESSION['corp']));

											if ($MailingConfs->rowCount() == 1) {
												$MailingConf = $MailingConfs->fetch();

												if (!empty($MailingConf['host'])) {
													SendMail($SendMailTest, true, $_SESSION['corp']);
	
													$Session->setFlash(Translator('Send_test_email_ok')." <b>".$SendMailTest."</b>.", "check", "success");
													header('Location: /customizations.php');
													exit();
												} else {
													$Session->setFlash(Translator('config_email'), "close", "error");
													header('Location: /customizations.php');
													exit();
												}
											} else {
												$Session->setFlash(translator('config_email'), "close", "error");
												header('Location: /customizations.php');
												exit();
											}
										} else {
											$Session->setFlash(Translator('invalid_email'), "close", "error");
											header('Location: /customizations.php');
											exit();
										}
									} else {
										$Session->setFlash(Translator('Sending_email'), "close", "error");
										header('Location: /customizations.php');
										exit();
									}
								}
							}
						?>
						<div class="modal-body">
							<label><?= Translator('Send_test_mess');?></label>
							<div class="form-group">
								<input type="mail" name="mailing_sendmail_test" placeholder="<?= Translator('Email');?>" autocomplete="off" class="form-control">
							</div>
						</div>
																			
						<div class="modal-footer">
							<button type="button" class="exerotpbtn btn-white ripple-effect ripple-white" data-dismiss="modal"><?= Translator('Cancel');?></button>
							<button type="submit" name="testMailSender" class="exerotpbtn btn-green ripple-effect ripple-white"><?= Translator('Send');?></button>
						</div>
					</form>
				</div>
			</div>
		</div>

		<div class="modal fade" id="resetConf" tabindex="-1" role="dialog" aria-labelledby="lblresetConf" aria-hidden="true">
			<div class="modal-dialog modal-lg" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title" id="lblresetConf"><i class="far fa-redo"></i> <?= Translator('Reset_custom_set');?></h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true"><i class="far fa-times"></i></span>
						</button>
					</div>
					
					<form name="resetConfForm" method="post">
						<?php 
							if (isset($_POST['resetMailConf'])) {
								ResetMailingConf($_SESSION['corp']);

								$Session->setFlash(Translator('parameter_reset'), "check", "success");
								header('Location: customizations.php');
								exit();
							}
						?>
						<div class="modal-body">
							<label><?= Translator('Result_comp_reset');?></label>
						</div>
																			
						<div class="modal-footer">
							<button type="button" class="exerotpbtn btn-white ripple-effect ripple-white" data-dismiss="modal"><?= Translator('Cancel');?></button>
							<button type="submit" name="resetMailConf" class="exerotpbtn btn-red ripple-effect ripple-white"><?= Translator('Confirm');?></button>
						</div>
					</form>
				</div>
			</div>
		</div>

		<form method="POST" enctype="multipart/form-data">
			<?php
				if (isset($_POST['saveMailingSettings'])) {
					echo "<script>include('/assets/scripts/main.mail.js');</script>";

					if (isset($_POST['mailing_srvaddress'], $_POST['mailing_encryptionSendMail'], $_POST['mailing_port'], $_POST['mailing_recipient'], $_POST['mailing_sendmail'])) {
						// Declare form variable
						$SrvAddress			= htmlspecialchars($_POST['mailing_srvaddress']);
						$SendMailEncryption	= htmlspecialchars($_POST['mailing_encryptionSendMail']);
						$Port				= htmlspecialchars($_POST['mailing_port']);
						$Recipient			= htmlspecialchars($_POST['mailing_recipient']);
						$SendEMail			= htmlspecialchars($_POST['mailing_sendmail']);

						if (isset($_POST['mailing_custom_btn_1'], $_POST['mailing_custom_btn_2'])) {
							$BenCustomBtn1		= htmlspecialchars($_POST['mailing_custom_btn_1']);
							$BenCustomBtn2		= htmlspecialchars($_POST['mailing_custom_btn_2']);

							if (!empty($_POST['mailing_custom_btn_1']) && !empty($_POST['mailing_custom_btn_2'])) {
								if (filter_var($BenCustomBtn1, FILTER_VALIDATE_URL) && filter_var($BenCustomBtn2, FILTER_VALIDATE_URL)) {
									$CustomBtn1		= $BenCustomBtn1;
									$CustomBtn2		= $BenCustomBtn2;
								} else {
									$error = Translator('enter_URL_addresses_OTP');
									$BangContinue = false;
								}
							} else {
								$CustomBtn1		= "https://apps.apple.com/fr/app/authenticator/id766157276";
								$CustomBtn2		= "https://play.google.com/store/apps/details?id=org.fedorahosted.freeotp";
							}
						}

						if (isset($_POST['mailing_content']) && !empty($_POST['mailing_content'])) {
							$Content		= htmlspecialchars($_POST['mailing_content']);
							$BangContinue 	= true;
						} else {
							$Content		= NULL;
							$BangContinue 	= true;
						}
						
						if (isset($_POST['mailing_content_link']) && !empty($_POST['mailing_content_link'])) {
							$ContentLink	= htmlspecialchars($_POST['mailing_content_link']);
							$BangContinue 	= true;
						} else {
							$ContentLink	= NULL;
							$BangContinue 	= true;
						}

						if (isset($_POST['mailing_custom_subject']) && !empty($_POST['mailing_custom_subject'])) {
							$CustomSubject = htmlspecialchars($_POST['mailing_custom_subject']);
							$BangContinue = true;
						} else {
							$CustomSubject	= NULL;
							$BangContinue = true;
						}

						if (isset($_POST['mailing_custom_fqdn']) && !empty($_POST['mailing_custom_fqdn'])) {
							$FieldCustomFQDN = htmlspecialchars($_POST['mailing_custom_fqdn']);
	
							if (filter_var($FieldCustomFQDN, FILTER_VALIDATE_URL)) {
								$CustomFQDN	= $FieldCustomFQDN;
								$BangContinue = true;
							} else {
								$BangContinue = false;
								$error = Translator('choose_Serv_FQDN');
							}
						} else {
							$CustomFQDN	= NULL;
							$BangContinue = true;
						}
						
						if (isset($BangContinue) && $BangContinue == true) {
							if (!empty($SrvAddress) && !empty($Port) && !empty($Recipient) && !empty($SendEMail)) {
								if (filter_var($SrvAddress, FILTER_VALIDATE_IP) || filter_var($SrvAddress, FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME)) {
									if (filter_var($Port, FILTER_VALIDATE_INT)) {
										if ($SendMailEncryption == 1) {
											$ToContinue = true;
											$Encryption = Transport_SMTPS;
										} elseif ($SendMailEncryption == 2) {
											$ToContinue = true;
											$Encryption = Transport_STARTTLS;
										} else {
											$ToContinue = true;
											$Encryption = 0;
										}

											if (filter_var($SendEMail, FILTER_VALIDATE_EMAIL)) {
																				
												$MailingConfs = $db->prepare('SELECT * FROM otp_mailing WHERE corpid = ?');
												$MailingConfs->execute(array($_SESSION['corp']));

												if ($MailingConfs->rowCount() == 1) {
													$MailingConf = $MailingConfs->fetch();
													// Check SMTP Auth (if set)
													if (isset($_POST['mailing_auth_username']) && !empty($_POST['mailing_auth_username'])) {
														$AuthUsername	= htmlspecialchars($_POST['mailing_auth_username']);
														if (isset($_POST['mailing_auth_password']) && !empty($_POST['mailing_auth_password'])) {
															$AuthPassword	= EncodePassword($_POST['mailing_auth_password']);
														} else {
															$AuthPassword	= $MailingConf['auth_password'];
														}
													} else {
														$AuthUsername	= NULL;
														$AuthPassword	= NULL;
													}
													// Update settings
													$UpdateMailing = $db->prepare('UPDATE otp_mailing SET host = ?, transport = ?, port = ?, fqdn = ?, issuer = ?, sendmail = ?, auth_user = ?, auth_password = ?, content = ?, content_link = ?, link_custom_btn1 = ?, link_custom_btn2 = ?, subject = ? WHERE corpid = ?');
													$UpdateMailing->execute(array($SrvAddress, $Encryption, $Port, $CustomFQDN, $Recipient, $SendEMail, $AuthUsername, $AuthPassword, $Content, $ContentLink, $CustomBtn1, $CustomBtn2, $CustomSubject, $_SESSION['corp']));
													
													$Session->setFlash(Translator('Save_change2'), "check", "success");
													header('Location: /customizations.php');
													exit();
												}
											} else {
												$error = Translator('Sending_a_valid_email');
											}
									} else {
										$error = Translator('Field_connect_port');
									}
								} else {
									$error = Translator("valid_SMTP_links_");
								}
							} else {
								$error = Translator('Fill_all_fields');
							}
					} 
				}
			}
			?>

			<?php if (isset($error)) { ?>
			<div class="alert alert-danger" role="alert">
				<i class="fas fa-exclamation-triangle"></i> <?= $error ?>
			</div>
			<?php } ?>

			<?php
				$MailingConfs = $db->prepare('SELECT * FROM otp_mailing WHERE corpid = ?');
				$MailingConfs->execute(array($_SESSION['corp']));

				if ($MailingConfs->rowCount() == 1) {
					$MailingConf = $MailingConfs->fetch();

					$Exist_SrvAddress 	= $MailingConf['host'];
					$Exist_Port 		= $MailingConf['port'];
					$Exist_Transport 	= $MailingConf['transport'];
					$Exist_Issuer 		= $MailingConf['issuer'];
					$Exist_Sendmail 	= $MailingConf['sendmail'];
					$Exist_AuthUsername = $MailingConf['auth_user'];
					$Exist_ContentMail1 = $MailingConf['content'];
					$Exist_ContentMail2 = $MailingConf['content_link'];
					$Exist_CustomFQDN	= $MailingConf['fqdn'];
					$Exist_CustomBtn1	= $MailingConf['link_custom_btn1'];
					$Exist_CustomBtn2	= $MailingConf['link_custom_btn2'];
					$Exist_Subject		= $MailingConf['subject'];
				}
				
				if ($MailingConf['host'] == NULL) {
					// Make auto no replying address
					$SendEMail = "no-reply@";
					$SendEMail.= shell_exec('cat /etc/mailname');

					if (empty($_SESSION['corp_name'])) {
						$Recipient = trim($licence_home);
					} else {
						$Recipient = $_SESSION['corp_name'];
					}
				}

			//	if (!empty($MailingConf['auth_user']) || !empty($MailingConf['auth_password']) || (!empty($_POST['mailing_auth_username']) || !empty($_POST['mailing_auth_password']))) {
			//		echo "<script>include('/assets/scripts/main.opCheck.js');</script>";
			//	}

			?>
			
			<div class="contain_controlbtns__editusr" style="display:block;position:absolute;right:10%;margin-top: -4px;">
				<button type="submit" name="saveMailingSettings" class="exerotpbtn btn-fab-mini btn-save ripple-effect ripple-white" data-toggle="tooltip" data-placement="bottom" title=<?= Translator('Save');?>>
					<i class="fas fa-save" style="margin-bottom: 3px;"></i>
				</button>
				<span data-toggle="tooltip" data-placement="bottom">
					<button type="button" data-toggle="modal" data-target="#resetConf" class="exerotpbtn btn-defaultexer btn-fab-mini ripple-effect ripple-white" style="margin-left: 0.5rem;" title=<?= Translator('default_configuration');?>>
						<i class="fas fa-redo" style="margin-bottom: 3px;"></i>
					</button>
				</span>
				<?php if (!empty($MailingConf['host']) && !empty($MailingConf['port'])) { ?>
				<span data-toggle="tooltip" data-placement="bottom">
					<button type="button" data-toggle="modal" data-target="#mailTester" class="exerotpbtn btn-defaultexer btn-fab-mini ripple-effect ripple-white" style="margin-left: 0.5rem;" title=<?= Translator('Send_test_email');?>>
						<i class="fas fa-envelope" style="margin-bottom: 3px;"></i>
					</button>
				</span>
				<?php } ?>
			</div>
			
			<fieldset class="fieldset_exerotp">
				<legend class="legend_exerotp"><i class="far fa-wrench"></i> <?= Translator('SMTP_links');?></legend>
				<b><?= Translator('Server_set');?></b>
				<hr style="margin-top: -8px; margin-left: 170px;"> 
				<div class="row" style="margin-top: -1rem;">
					<div class="col-md-4">
						<span><?= Translator('SMTP_serv');?></span>
						<input type="text" name="mailing_srvaddress" autocomplete="off" class="form-control ghsEZ" placeholder="Serveur SMTP" value="<?php if (isset($SrvAddress)) { echo $SrvAddress; } else { echo $Exist_SrvAddress; } ?>"> 
						
						<span><?= Translator('Transport');?></span>
						<select class="form-control ghsEZ" name="mailing_encryptionSendMail">
							<option value="0"<?php if ((isset($SendMailEncryption) && $SendMailEncryption == 0) || ($MailingConf['transport'] == 0)) { echo "selected"; } ?>>SMTP</option>
							<option value="1"<?php if ((isset($SendMailEncryption) && $SendMailEncryption == 1) || ($MailingConf['transport'] == 1)) { echo "selected"; } ?>>SMTPS</option>
							<option value="2"<?php if ((isset($SendMailEncryption) && $SendMailEncryption == 2) || ($MailingConf['transport'] == 2)) { echo "selected"; } ?>>STARTTLS</option>
						</select>

						<span><?= Translator('Connect_port');?></span>
						<input type="text" name="mailing_port" autocomplete="off" class="form-control ghsEZ" placeholder="Port" value="<?php if (isset($Port)) { echo $Port; } else { echo $Exist_Port; } ?>">
					</div>
							<div class="col-md-4">
								<span><?= Translator('Issuer');?>:</span>
								<input type="text" name="mailing_recipient" autocomplete="off" class="form-control ghsEZ" placeholder="ex : John Smith" value="<?php if (isset($Recipient)) { echo $Recipient; } else { echo $Exist_Issuer; } ?>">
								<span><?= Translator('Username2');?></span>
								<input type="text" name="mailing_auth_username" autocomplete="off" class="form-control ghsEZ" placeholder="" value="<?php if (isset($AuthUsername)) { echo $AuthUsername; } else { echo $Exist_AuthUsername; } ?>">
								<span><?= Translator('Password');?> :</span>
								<input type="password" name="mailing_auth_password" autocomplete="off" class="form-control ghsEZ" placeholder="<?php if (!empty($MailingConf['auth_password'])) { echo "••••••••"; } else { echo ""; } ?>">
							</div>
							<div class="col-md-4">
								<span><?= Translator('Sending_email');?></span>
								<input type="text" name="mailing_sendmail" autocomplete="off" class="form-control ghsEZ" placeholder="ex : no-reply@mycorp.org" value="<?php if (isset($SendEMail)) { echo $SendEMail; } else { echo $Exist_Sendmail; } ?>">
								<span><br><br><i style="margin-bottom: 20px;"><?= Translator('SMTP_Tips1'); ?><br><?= Translator('SMTP_Tips2'); ?><br><?= Translator('SMTP_Tips3'); ?><br><?= Translator('SMTP_Tips4'); ?></i></span>
								
							</div>

				</div>
			</fieldset><br>
			
			<link rel="stylesheet" href="/assets/libs/wysiwyg-editor/css/editor.style.css">

			<fieldset class="fieldset_exerotp">
				<legend class="legend_exerotp w-70"><i class="far fa-mail-bulk"></i> <?= Translator('Custom_email_mess');?></legend>
				<b><?= Translator('Custom_subject');?></b>
				<input type="text" name="mailing_custom_subject" autocomplete="off" class="form-control ghsEZ" placeholder="<?= Translator('Unique_link');?>" value="<?php if (isset($CustomSubject)) { echo $CustomSubject; } else { echo $Exist_Subject; } ?>">

				<b><?= Translator('Custom_FQDN_serv');?></b>
				<input type="text" name="mailing_custom_fqdn" autocomplete="off" class="form-control ghsEZ" placeholder="ex : gateway.example.com" value="<?php if (isset($CustomFQDN)) { echo $CustomFQDN; } else { echo $Exist_CustomFQDN; } ?>">
				<b><?= Translator('Cont_of_the_mail');?></b><br>
				<span><?= Translator('Custom_email');?></span>
				<textarea name="mailing_content" class="exerEditor">
				<?php
					if (isset($Content)) {
						echo $Content;
					} else {
						echo $Exist_ContentMail1;
					}
				?>
				</textarea>
			</fieldset>
			<br>
			<fieldset class="fieldset_exerotp">
				<legend class="legend_exerotp w-70"><i class="far fa-mail-bulk"></i> <?= Translator('Custom_OTP_plug');?></legend>
				<b><?= Translator('Exte_QR_code');?></b><br>
				<span><?= Translator('Custom_mess_exte');?></span>
				<textarea name="mailing_content_link" class="exerEditor">
				<?php 
					if (isset($ContentLink)) {
						echo $ContentLink;
					} else {
						echo $Exist_ContentMail2;
					}
				?>
				</textarea>
				<br>
				<b><?= Translator('OTP_gene_app');?></b>
				<hr style="margin-top: -8px; margin-left: 230px; margin-bottom: -0.5rem"> 
				<div class="row">
					<div class="col-md-6">
						<span><?= Translator('iOS_link') ; ?></span>
						<input type="text" name="mailing_custom_btn_1" autocomplete="off" class="form-control ghsEZ" value="<?php if (isset($CustomBtn1)) { echo $CustomBtn1; } else { echo $Exist_CustomBtn1; } ?>">
					</div>
					<div class="col-md-6">
						<span><?= Translator('Android_link') ; ?></span>
						<input type="text" name="mailing_custom_btn_2" autocomplete="off" class="form-control ghsEZ" value="<?php if (isset($CustomBtn2)) { echo $CustomBtn2; } else { echo $Exist_CustomBtn2; } ?>">
					</div>
				</div>
			</fieldset>
		</form>
		<script type="text/javascript" src="/assets/libs/wysiwyg-editor/js/editor.app.js"></script>
		<script>new FroalaEditor(".exerEditor",{events:{"image.beforeUpload":function(e){var a=this;if(e.length){var r=new FileReader;r.onload=function(e){var r=e.target.result;a.image.insert(r,null,null,a.image.get())},r.readAsDataURL(e[0])}return a.popups.hideAll(),!1}},language:"fr",key:"AV:4~?3xROKLJKYHROLDXDR@d2YYGR_Bc1A8@5@4:1B2D2F2F1?1?2A3@1C1"});</script>
		<br><br>
	<?php } else { ?>
		<?php if (checkLevel() == SUPERVISOR) {
				$GetAllCustoms = $db->query('SELECT * FROM otp_mailing ORDER BY id DESC');
			} elseif (checkLevel() == OPERATOR && $_SESSION['corp'] == "NOT_DEFINED") {
				$GetAllCustoms = $db->query('SELECT * FROM otp_mailing ORDER BY id DESC');
			} else {
				$GetAllCustoms = $db->prepare('SELECT * FROM otp_mailing WHERE corpid = ? ORDER BY id DESC');
				$GetAllCustoms->execute(array($_SESSION['corp']));
			}
				
			$CountCustoms = $GetAllCustoms->rowCount();
			if ($CountCustoms == 0) { ?>

			<div class="alert alert-danger" role="alert">
				<i class="fas fa-exclamation-triangle"></i> <?= Translator('Custom_avail');?>
			</div>
			<?php } else { ?>
			<div class="alert alert-info" role="alert">
				<i class="far fa-info-circle"></i>
				<?= Translator('Display');?> <?php echo "<strong>" . $CountCustoms . "</strong> "; if ($CountCustoms >1) { echo Translator('Customizations'); } else { echo Translator('Customization'); } ?>.
			</div>
				
			<input type="text" id="searchboxTable" placeholder="<?= Translator('find_a_customization');?>" title="<?= Translator('complete_this_field');?>">

			<script>
				$(document).ready(function() {
					$("#searchboxTable").on("keyup", function() {
						var value = $(this).val().toLowerCase();
						$("#byValDataT tr").filter(function() {
							$(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
						});
					});

					$("#searchboxTable").on("keyup", function() {
						var name = $(this).val();
						if (name.length >= 1) {
							var box = paginator({
								table: document.getElementById("container_table").getElementsByTagName("table")[0],
								box_mode: "list",
								rows_per_page: "0",
								get_rows: function () {
									return document.getElementById("table_otpexer").getElementsByTagName("tbody");
								},
							});
							$('.pgnt_tab').hide();
							return false;
						} else {
							var box = paginator({
								table: document.getElementById("container_table").getElementsByTagName("table")[0],
								box_mode: "list",
								rows_per_page: "10",
							});
							$('.pgnt_tab').show();
							return false;
						}
					});

					var box = paginator({
						table: document.getElementById("container_table").getElementsByTagName("table")[0],
						box_mode: "list",
						rows_per_page: "10",
					});
					document.getElementById("container_table").appendChild(box);
				});
			</script>
						
			<div class="table-responsive" id="container_table">
				<table id="table_otpexer" class="sortable-theme-bootstrap table-striped" data-sortable>
					<thead>
						<tr>
							<th class="vt-default-th" data-sorted-direction="descending"><?= Translator('Company');?></th>
							<th><?= Translator('Server');?></th>
							<th><?= Translator('Issuer');?></th>
							<th><?= Translator('Sending_mail');?></th>
							<th><?= Translator('Creation_date');?></th>
							<th data-sortable="false"> </th>
						</tr>
					</thead>
					<tbody id="byValDataT">
					<?php 
						while ($Customs = $GetAllCustoms->fetch()) { ?>
						<?php 
							$corps_recorver = $db->prepare('SELECT * FROM otp_companies WHERE corpid = ?');
							$corps_recorver->execute(array($Customs['corpid']));
							$recover_corp = $corps_recorver->fetch();
						?>

						<?php if ($recover_corp['corpid'] == $Customs['corpid']) { ?>
						<tr>
							<td>
								<?= $recover_corp['name']; ?>
							</td>
							<?php 
								if (!empty($Customs['port'])) {
									$PortConf = $Customs['port'];
								} else {
									$PortConf = NULL;
								}
								$SMTPConf = NULL;
								if (!empty($Customs['auth_user']) && !empty($Customs['auth_password'])) {
									$authset = "With Auth";
								} else {
									$authset = "No Auth";
								}
								switch ($Customs['transport']) {
									case 0:
										$SMTPConf = "SMTP";
										break;
									case 1:
										$SMTPConf = "SMTPS";
										break;
									case 2:
										$SMTPConf = "STARTTLS";
										break;
								}
							?>
							<td><?php if (!empty($Customs['host'])) { echo $Customs['host'] . " (" . $SMTPConf ." : " . $PortConf . " - " . $authset . ")"; } else { echo Translator('not_specified'); } ?></td>
							<td>
								<?php 
									if (!empty($Customs['issuer'])) {
										echo $Customs['issuer'];
									} else {
										echo "<i>".Translator('not_specified')."</i>";
									}
								?>
							</td>
							<td>
								<?php 
									if (!empty($Customs['sendmail'])) {
										echo $Customs['sendmail'];
									} else {
										echo "<i>".Translator('not_specified')."</i>";
									}	
								?>
							</td>
							<td>
								<?php if ($Customs['created_at'] != "0000-00-00 00:00:00") { echo   date_format(date_create($Customs['created_at']),"d/m/Y"); } else { echo Translator('unknow'); } ?>
							</td>

							<?php
								$rand_client_modal = generateToken(9999);
							?>
								<!-- Modal_viewinfos customisations -->
								<div class="modal fade" id="view_infos_client__<?= $rand_client_modal ?>" tabindex="-1" role="dialog" aria-labelledby="lblview_customisations" aria-hidden="true">
									<div class="modal-dialog modal-lg" role="document">
										<div class="modal-content">
											<div class="modal-header">
												<h5 class="modal-title" id="lblconfirm_view_customisations"><i class="far fa-paint-brush"></i> <?= Translator('customization_of');?> <b><?= $recover_corp['name']; ?></b></h5>
												<button type="button" class="close" data-dismiss="modal" aria-label="Close">
													<span aria-hidden="true"><i class="far fa-times"></i></span>
												</button>
											</div>
											<div id="printThis__<?= $Customs['tokenID'] ?>">
												<div class="modal-body">
													<fieldset class="fieldset_exerotp">
														<legend class="legend_exerotp"><i class="far fa-wrench"></i> <?= Translator('SMTP_links');?></legend>
														<b><?= Translator('Server_set');?> :</b>
														<hr style="margin-top: -8px; margin-left: 170px;">
														<b><?= Translator('SMTP_serv');?> :</b>
														<span><?= $Customs['host'] ?></span><br>
														<b><?= Translator('Serv_FQDN');?> :</b>
														<span><?= $Customs['fqdn'] ?></span><br>
														<?php if (!empty($Customs['auth_user']) && !empty($Customs['auth_password'])) {
															$authset = "With Auth";
														} else {
															$authset = "No Auth";
														}
														?>
														<b><?= Translator('Transport');?> :</b>
														<span><?php switch ($Customs['transport']) {
															case 0:
																echo "SMTP (". $authset .")";
																break;
															case 1:
																echo "SMTPS (". $authset .")";
																break;
															case 2:
																echo "STARTTLS (". $authset .")";
																break;
															}			
														?></span><br>
														<b><?= Translator('Connect_port');?> :</b>
														<span><?= $Customs['port'] ?></span><br>
														<b><?= Translator('Issuer');?> :</b>
														<span><?= $Customs['issuer'] ?></span><br>
														<b><?= Translator('Sending_email');?> :</b>
														<span><?= $Customs['sendmail'] ?></span><br>
														<b><?= Translator('Subject');?> :</b>
														<span><?php if (!empty($Customs['subject'])) { echo $Customs['subject']; } else { echo Translator('Unique_link'); } ?></span>
													</fieldset>
													<br>
													<fieldset class="fieldset_exerotp">
														<legend class="legend_exerotp w-70"><i class="far fa-mail-bulk"></i> <?= Translator('Custom_email_mess');?></legend>
														<b><?= Translator('Cont_of_the_mail');?></b><br>
														<span><?= Translator('Custom_email');?></span>
														<hr>
														<code style="color: #495057 !important; font-family: inherit !important; font-size: inherit !important;">
															<?= htmlspecialchars_decode($Customs['content']); ?>
														</code>
														<hr>
													</fieldset>
													<br>
													<fieldset class="fieldset_exerotp">
														<legend class="legend_exerotp w-70"><i class="far fa-mail-bulk"></i> <?= Translator('Custom_OTP_plug');?></legend>
														<b><?= Translator('Exte_QR_code');?></b><br>
														<span><?= Translator('Custom_mess_exte');?></span>
														<hr>
														<code style="color: #495057 !important; font-family: inherit !important; font-size: inherit !important;">
															<?= htmlspecialchars_decode($Customs['content_link']); ?>
														</code>
														<hr>
														<br>
														<b><?= Translator('OTP_gene_app');?></b>
														<hr style="margin-top: -8px; margin-left: 230px; margin-bottom: -0.5rem"> 
														<div class="row">
															<div class="col-md-6">
																<span><?= Translator('iOS_link');?></span>
																<a href="<?= $Customs['link_custom_btn1']; ?>"><?= $Customs['link_custom_btn1']; ?></a>
															</div>
															<div class="col-md-6">
																<span><?= Translator('Android_link');?></span>
																<a href="<?= $Customs['link_custom_btn2']; ?>"><?= $Customs['link_custom_btn2']; ?></a>
															</div>
														</div>
													</fieldset>
												</div>
											</div>			
											
											<div class="modal-footer">
												<button type="button" class="exerotpbtn btn-white ripple-effect ripple-dark" data-dismiss="modal"><?= Translator('Close');?></button>
											</div>
										</div>
									</div>
								</div>
								
								<?php if (checkLevel() == SUPERVISOR) { ?>
								<!-- Modal_viewinfos customisations -->
								<div class="modal fade" id="edit_infos_client__<?= $Customs['token'] ?>" tabindex="-1" role="dialog" aria-labelledby="lblview_customisations" aria-hidden="true">
									<div class="modal-dialog modal-lg" role="document">
										<div class="modal-content">
											<div class="modal-header">
												<h5 class="modal-title" id="lblconfirm_view_customisations"><i class="far fa-paint-brush"></i> <?= Translator('Edit_business_perso');?> <b><?= $recover_corp['name']; ?></b></h5>
												<button type="button" class="close" data-dismiss="modal" aria-label="Close">
													<span aria-hidden="true"><i class="far fa-times"></i></span>
												</button>
											</div>

											<div class="modal-body">
												<form method="POST" enctype="multipart/form-data">
													<?php
														if (isset($_POST['saveMailingSettings__' . $Customs['token']])) {
															if (isset($_POST['mailing_srvaddress'], $_POST['mailing_encryptionSendMail'], $_POST['mailing_port'], $_POST['mailing_recipient'], $_POST['mailing_sendmail'])) {
																// Declare form variable
																$SrvAddress			= htmlspecialchars($_POST['mailing_srvaddress']);
																$SendMailEncryption	= htmlspecialchars($_POST['mailing_encryptionSendMail']);
																$Port				= htmlspecialchars($_POST['mailing_port']);
																$Recipient			= htmlspecialchars($_POST['mailing_recipient']);
																$SendEMail			= htmlspecialchars($_POST['mailing_sendmail']);

																if (isset($_POST['mailing_custom_btn_1'], $_POST['mailing_custom_btn_2'])) {
																	$BenCustomBtn1		= htmlspecialchars($_POST['mailing_custom_btn_1']);
																	$BenCustomBtn2		= htmlspecialchars($_POST['mailing_custom_btn_2']);

																	if (!empty($_POST['mailing_custom_btn_1']) && !empty($_POST['mailing_custom_btn_2'])) {
																		if (filter_var($BenCustomBtn1, FILTER_VALIDATE_URL) && filter_var($BenCustomBtn2, FILTER_VALIDATE_URL)) {
																			$CustomBtn1		= $BenCustomBtn1;
																			$CustomBtn2		= $BenCustomBtn2;
																		} else {
																			$error = Translator('OTP_generation_applications');
																			$BangContinue = false;
																		}
																	} else {
																		$CustomBtn1		= "https://apps.apple.com/fr/app/authenticator/id766157276";
																		$CustomBtn2		= "https://play.google.com/store/apps/details?id=org.fedorahosted.freeotp";
																	}
																}

																if (isset($_POST['mailing_content']) && !empty($_POST['mailing_content'])) {
																	$Content		= htmlspecialchars($_POST['mailing_content']);
																	$BangContinue 	= true;
																} else {
																	$Content		= NULL;
																	$BangContinue 	= true;
																}
																
																if (isset($_POST['mailing_content_link']) && !empty($_POST['mailing_content_link'])) {
																	$ContentLink	= htmlspecialchars($_POST['mailing_content_link']);
																	$BangContinue 	= true;
																} else {
																	$ContentLink	= NULL;
																	$BangContinue 	= true;
																}
																
																if (isset($_POST['mailing_custom_subject']) && !empty($_POST['mailing_custom_subject'])) {
																	$CustomSubject = htmlspecialchars($_POST['mailing_custom_subject']);
																	$BangContinue = true;
																} else {
																	$CustomSubject = NULL;
																	$BangContinue = true;
																}

																if (isset($_POST['mailing_custom_fqdn']) && !empty($_POST['mailing_custom_fqdn'])) {
																	$FieldCustomFQDN = htmlspecialchars($_POST['mailing_custom_fqdn']);
																	if (filter_var($FieldCustomFQDN, FILTER_VALIDATE_URL)) {
																		$CustomFQDN	= $FieldCustomFQDN;
																		$BangContinue = true;
																	} else {
																		$BangContinue = false;
																		$error = Translator('invalid_FQDN');
																		$error.= "<script>$('#edit_infos_client__".$Customs['token']."').modal('show');</script>";
																	}
																} else {
																	$CustomFQDN	= NULL;
																	$BangContinue = true;
																}
																
																if (isset($BangContinue) && $BangContinue == true) {
																	if (!empty($SrvAddress) && !empty($Port) && !empty($Recipient) && !empty($SendEMail)) {
																		if (filter_var($SrvAddress, FILTER_VALIDATE_IP) || filter_var($SrvAddress, FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME)) {
																			if (filter_var($Port, FILTER_VALIDATE_INT)) {
																				if ($SendMailEncryption == 1) {
																					$ToContinue = true;
																					$Encryption = Transport_SMTPS;
																				} elseif ($SendMailEncryption == 2) {
																					$ToContinue = true;
																					$Encryption = Transport_STARTTLS;
																				} else {
																					$ToContinue = true;
																					$Encryption = 0;
																				}
						
																				if (filter_var($SendEMail, FILTER_VALIDATE_EMAIL)) {
																					
																					$MailingConfs = $db->prepare('SELECT * FROM otp_mailing WHERE corpid = ?');
																					$MailingConfs->execute(array($Customs['corpid']));
																					
																					if ($MailingConfs->rowCount() == 1) {
																						$MailingConf = $MailingConfs->fetch();																					
																						// Check SMTP Auth (if set)
																						if (isset($_POST['mailing_auth_username']) && !empty($_POST['mailing_auth_username'])) {
																							$AuthUsername	= htmlspecialchars($_POST['mailing_auth_username']);
																							if (isset($_POST['mailing_auth_password']) && !empty($_POST['mailing_auth_password'])) {
																								$AuthPassword	= EncodePassword($_POST['mailing_auth_password']);
																							} else {
																								$AuthPassword	= $MailingConf['auth_password'];
																							}
																						} else {
																							$AuthUsername	= NULL;
																							$AuthPassword	= NULL;
																						}
																							// Update settings
																							$UpdateMailing = $db->prepare('UPDATE otp_mailing SET host = ?, transport = ?, port = ?, fqdn = ?, issuer = ?, sendmail = ?, auth_user = ?, auth_password = ?, content = ?, content_link = ?, link_custom_btn1 = ?, link_custom_btn2 = ?, subject = ? WHERE corpid = ?');
																							$UpdateMailing->execute(array($SrvAddress, $Encryption, $Port, $CustomFQDN, $Recipient, $SendEMail, $AuthUsername, $AuthPassword, $Content, $ContentLink, $CustomBtn1, $CustomBtn2, $CustomSubject, $Customs['corpid']));
																							
																							$Session->setFlash(Translator('Save_change_compagny').$recover_corp['name'].Translator('has_been_saved'), "check", "success");
																							header('Location: /customizations.php');
																						}
																					} else {
																						$error = Translator('Sending_a_valid_email');
																						$error.= "<script>$('#edit_infos_client__".$Customs['token']."').modal('show');</script>";
																					}
																			
																			} else {
																				$error = Translator('Field_connect_port');
																				$error.= "<script>$('#edit_infos_client__".$Customs['token']."').modal('show');</script>";
																			}
																		} else {
																			$error =Translator('valid_SMTP_links_');
																			$error.= "<script>$('#edit_infos_client__".$Customs['token']."').modal('show');</script>";
																		}
																	} else {
																		$error = Translator('Fill_all_fields');
																		$error.= "<script>$('#edit_infos_client__".$Customs['token']."').modal('show');</script>";
																	}
																}
															}
														}
													?>

													<?php if (isset($error)) { ?>
													<div class="alert alert-danger" role="alert">
														<i class="fas fa-exclamation-triangle"></i> <?= $error ?>
													</div>
													<?php } ?>

													<?php
														$MailingConfs = $db->prepare('SELECT * FROM otp_mailing WHERE corpid = ?');
														$MailingConfs->execute(array($Customs['corpid']));

														if ($MailingConfs->rowCount() == 1) {
															$MailingConf = $MailingConfs->fetch();

															$Exist_SrvAddress 	= $MailingConf['host'];
															$Exist_Port 		= $MailingConf['port'];
															$Exist_Transport 	= $MailingConf['transport'];
															$Exist_Issuer 		= $MailingConf['issuer'];
															$Exist_Sendmail 	= $MailingConf['sendmail'];
															$Exist_AuthUsername = $MailingConf['auth_user'];
															$Exist_ContentMail1 = $MailingConf['content'];
															$Exist_ContentMail2 = $MailingConf['content_link'];
															$Exist_CustomFQDN	= $MailingConf['fqdn'];
															$Exist_CustomBtn1	= $MailingConf['link_custom_btn1'];
															$Exist_CustomBtn2	= $MailingConf['link_custom_btn2'];
															$Exist_Subject		= $MailingConf['subject'];
														}
														
														if ($MailingConf['host'] == NULL) {
															// Make auto no replying address
															$SendEMail = "no-reply@";
															$SendEMail.= shell_exec('cat /etc/mailname');

															if (empty($recover_corp['name'])) {
																$Recipient = trim($licence_home);
															}
														}

													//	if (!empty($MailingConf['auth_user']) || !empty($MailingConf['auth_password']) || (!empty($_POST['mailing_auth_username']) || !empty($_POST['mailing_auth_password']))) {
													//		echo "<script>include('/assets/scripts/main.opCheck.js');</script>";
													//	}

													?>
													
													<div class="contain_controlbtns__editusr" style="display:block;position:absolute;right:10%;margin-top: -4px;">
														<button type="submit" name="saveMailingSettings__<?= $Customs['token'] ?>" class="exerotpbtn btn-fab-mini btn-save ripple-effect ripple-white" data-toggle="tooltip" data-placement="bottom" title= <?= Translator('Save_change3');?>>
															<i class="fas fa-save" style="margin-bottom: 3px;"></i>
														</button>
														<span data-toggle="tooltip" data-placement="bottom">
															<button type="button" data-dismiss="modal" style="margin-left: 0.5rem;" class="exerotpbtn btn-fab-mini btn-cancel ripple-effect ripple-white" data-toggle="tooltip" title=<?= Translator('Undo_changes');?>>
																<i class="fas fa-times" style="margin-bottom: 3px;"></i>
															</button>
														</span>
														<span data-toggle="tooltip" data-placement="bottom">
															<button type="button" data-toggle="modal" data-target="#resetConf__<?= $Customs['token'] ?>" class="exerotpbtn btn-defaultexer btn-fab-mini ripple-effect ripple-white" style="margin-left: 0.5rem;" title=<?= Translator('default_configuration');?>>
																<i class="fas fa-redo" style="margin-bottom: 3px;"></i>
															</button>
														</span>
														<?php if (!empty($MailingConf['host']) && !empty($MailingConf['port'])) { ?>
														<span data-toggle="tooltip" data-placement="bottom">
															<button type="button" data-toggle="modal" data-target="#mailTester__<?= $Customs['token'] ?>" class="exerotpbtn btn-defaultexer btn-fab-mini ripple-effect ripple-white" style="margin-left: 0.5rem;" title=<?= Translator('Send_test_email');?>>
																<i class="fas fa-envelope" style="margin-bottom: 3px;"></i>
															</button>
														</span>
														<?php } ?>
													</div>
													
													<fieldset class="fieldset_exerotp">
														<legend class="legend_exerotp"><i class="far fa-wrench"></i> <?= Translator('SMTP_links');?></legend>
														<b><?= Translator('Server_set');?></b>
														<hr style="margin-top: -8px; margin-left: 170px;"> 
														<div class="row" style="margin-top: -1rem;">
															<div class="col-md-4">
																<span><?= Translator('SMTP_serv');?></span>
																<input type="text" name="mailing_srvaddress" autocomplete="off" class="form-control ghsEZ" placeholder="Serveur SMTP" value="<?php if (isset($SrvAddress)) { echo $SrvAddress; } else { echo $Exist_SrvAddress; } ?>"> 
																
																<span><?= Translator('Transport');?></span>
																<select class="form-control ghsEZ" name="mailing_encryptionSendMail">
																	<option value="0"<?php if ((isset($SendMailEncryption) && $SendMailEncryption == 0) || ($MailingConf['transport'] == 0)) { echo "selected"; } ?>>SMTP</option>
																	<option value="1"<?php if ((isset($SendMailEncryption) && $SendMailEncryption == 1) || ($MailingConf['transport'] == 1)) { echo "selected"; } ?>>SMTPS</option>
																	<option value="2"<?php if ((isset($SendMailEncryption) && $SendMailEncryption == 2) || ($MailingConf['transport'] == 2)) { echo "selected"; } ?>>STARTTLS</option>
																</select>

																<span><?= Translator('Connect_port');?></span>
																<input type="text" name="mailing_port" autocomplete="off" class="form-control ghsEZ" placeholder="Port" value="<?php if (isset($Port)) { echo $Port; } else { echo $Exist_Port; } ?>">
															</div>
																	<div class="col-md-4">
																		<span><?= Translator('Issuer');?>:</span>
																		<input type="text" name="mailing_recipient" autocomplete="off" class="form-control ghsEZ" placeholder="ex : John Smith" value="<?php if (isset($Recipient)) { echo $Recipient; } else { echo $Exist_Issuer; } ?>">
																		<span><?= Translator('Username2');?></span>
																		<input type="text" name="mailing_auth_username" autocomplete="off" class="form-control ghsEZ" placeholder="" value="<?php if (isset($AuthUsername)) { echo $AuthUsername; } else { echo $Exist_AuthUsername; } ?>">
																		<span><?= Translator('Password');?> :</span>
																		<input type="password" name="mailing_auth_password" autocomplete="off" class="form-control ghsEZ" placeholder="<?php if (!empty($MailingConf['auth_password'])) { echo "••••••••"; } else { echo ""; } ?>">
																	</div>
																	<div class="col-md-4">
																		<span><?= Translator('Sending_email');?></span>
																		<input type="text" name="mailing_sendmail" autocomplete="off" class="form-control ghsEZ" placeholder="ex : no-reply@mycorp.org" value="<?php if (isset($SendEMail)) { echo $SendEMail; } else { echo $Exist_Sendmail; } ?>">
																		<span><br><br><i style="margin-bottom: 20px;"><?= Translator('SMTP_Tips1'); ?><br><?= Translator('SMTP_Tips2'); ?><br><?= Translator('SMTP_Tips3'); ?><br><?= Translator('SMTP_Tips4'); ?></i></span>
																		
																	</div>

														</div>
													</fieldset><br>
													
													<link rel="stylesheet" href="/assets/libs/wysiwyg-editor/css/editor.style.css">

													<fieldset class="fieldset_exerotp">
														<legend class="legend_exerotp w-70"><i class="far fa-mail-bulk"></i> <?= Translator('Custom_email_mess');?></legend>
														<b><?= Translator('Custom_subject');?></b>
														<input type="text" name="mailing_custom_subject" autocomplete="off" class="form-control ghsEZ" placeholder="<?= Translator('Unique_link');?>" value="<?php if (isset($CustomSubject)) { echo $CustomSubject; } else { echo $Exist_Subject; } ?>">
													
														<b><?= Translator('Custom_FQDN_serv');?></b>
														<input type="text" name="mailing_custom_fqdn" autocomplete="off" class="form-control ghsEZ" placeholder="ex : gateway.example.com" value="<?php if (isset($CustomFQDN)) { echo $CustomFQDN; } else { echo $Exist_CustomFQDN; } ?>">
														<b><?= Translator('Cont_of_the_mail');?></b><br>
														<span><?= Translator('Custom_email');?></span> 
														<textarea class="exerEditor" name="mailing_content">
														<?php
															if (isset($Content)) {
																echo $Content;
															} else {
																echo $Exist_ContentMail1;
															}
														?>
														</textarea>
													</fieldset>
													<br>
													<fieldset class="fieldset_exerotp">
														<legend class="legend_exerotp w-70"><i class="far fa-mail-bulk"></i> <?= Translator('Custom_OTP_plug');?></legend>
														<b><?= Translator('Exte_QR_code');?></b><br>
														<span><?= Translator('Custom_mess_exte');?></span>
														<textarea class="exerEditor" name="mailing_content_link">
														<?php 
															if (isset($ContentLink)) {
																echo $ContentLink;
															} else {
																echo $Exist_ContentMail2;
															}
														?>
														</textarea>
														<br>
														<b><?= Translator('OTP_gene_app');?></b>
														<hr style="margin-top: -8px; margin-left: 230px; margin-bottom: -0.5rem"> 
														<div class="row">
															<div class="col-md-6">
																<span><?= Translator('iOS_link');?></span>
																<input type="text" name="mailing_custom_btn_1" autocomplete="off" class="form-control ghsEZ" value="<?php if (isset($CustomBtn1)) { echo $CustomBtn1; } else { echo $Exist_CustomBtn1; } ?>">
															</div>
															<div class="col-md-6">
																<span><?= Translator('Android_link');?></span>
																<input type="text" name="mailing_custom_btn_2" autocomplete="off" class="form-control ghsEZ" value="<?php if (isset($CustomBtn2)) { echo $CustomBtn2; } else { echo $Exist_CustomBtn2; } ?>">
															</div>
														</div>
													</fieldset>
												</form>
											</div>
										</div>
									</div>
								</div>

								<div class="modal fade" id="mailTester__<?= $Customs['token'] ?>" tabindex="-1" role="dialog" aria-labelledby="lblmailTester" aria-hidden="true">
									<div class="modal-dialog modal-lg" role="document">
										<div class="modal-content">
											<div class="modal-header">
												<h5 class="modal-title" id="lblmailTester"><i class="far fa-file-envelope"></i> <?= Translator('Send_test_mail_comp');?> <b><?= $recover_corp['name']; ?></b></h5>
												<button type="button" class="close" data-dismiss="modal" aria-label="Close">
													<span aria-hidden="true"><i class="far fa-times"></i></span>
												</button>
											</div>
											
											<form name="mailtesterForm" method="post">
												<?php 
													if (isset($_POST['testMailSender__' . $Customs['token']])) {
														if (isset($_POST['mailing_sendmail_test'])) {
															if (!empty($_POST['mailing_sendmail_test'])) {
																$SendMailTest = htmlspecialchars($_POST['mailing_sendmail_test']);
							
																if (filter_var($SendMailTest, FILTER_VALIDATE_EMAIL)) {
																	$MailingConfs = $db->prepare('SELECT * FROM otp_mailing WHERE corpid = ?');
																	$MailingConfs->execute(array($Customs['corpid']));

																	if ($MailingConfs->rowCount() == 1) {
																		$MailingConf = $MailingConfs->fetch();

																		if (!empty($MailingConf['host'])) {
																			SendMail($SendMailTest, true, $Customs['corpid']);
							
																			$Session->setFlash(Translator('Send_test_email_ok')." <b>".$SendMailTest."</b>.", "check", "success");
																			header('Location: /customizations.php');
																		} else {
																			$Session->setFlash(Translator('config_email'), "close", "error");
																			header('Location: /customizations.php');
																			exit();
																		}
																	} else {
																		$Session->setFlash(Translator('config_email'), "close", "error");
																		header('Location: /customizations.php');
																		exit();
																	}
																} else {
																	$Session->setFlash(Translator('Sending_a_valid_email'), "close", "error");
																	header('Location: /customizations.php');
																	exit();
																}
															} else {
																$Session->setFlash(Translator('specify_ending_email'), "close", "error");
																header('Location: /customizations.php');
																exit();
															}
														}
													}
												?>
												<div class="modal-body">
													<label><?= Translator('Send_test_mess');?></label>
													<div class="form-group">
														<input type="mail" name="mailing_sendmail_test" autocomplete="off" class="form-control">
													</div>
												</div>
																									
												<div class="modal-footer">
													<button type="button" class="exerotpbtn btn-white ripple-effect ripple-white" data-dismiss="modal"><?= Translator('Cancel');?></button>
													<button type="submit" name="testMailSender__<?= $Customs['token'] ?>" class="exerotpbtn btn-green ripple-effect ripple-white"><?= Translator('Send');?></button>
												</div>
											</form>
										</div>
									</div>
								</div>

								<div class="modal fade" id="resetConf__<?= $Customs['token'] ?>" style="z-index: 999999;" tabindex="-1" role="dialog" aria-labelledby="lblresetConf" aria-hidden="true">
									<div class="modal-dialog modal-lg" role="document">
										<div class="modal-content">
											<div class="modal-header">
												<h5 class="modal-title" id="lblresetConf"><i class="far fa-redo"></i> <?= Translator('Reset_custom_set_for');?> <b><?= $recover_corp['name']; ?></b>?</h5>
												<button type="button" class="close" data-dismiss="modal" aria-label="Close">
													<span aria-hidden="true"><i class="far fa-times"></i></span>
												</button>
											</div>
											
											<form name="resetConfForm" method="post">
												<?php 
													if (isset($_POST['resetMailConf__' . $Customs['token']])) {
														ResetMailingConf($Customs['corpid']);

														$Session->setFlash(Translator('parameter_reset'), "check", "success");
														header('Location: customizations.php');
													}
												?>
												<div class="modal-body">
													<label><?= Translator('Result_comp_reset');?><label>
												</div>
																									
												<div class="modal-footer">
													<button type="button" class="exerotpbtn btn-white ripple-effect ripple-white" data-dismiss="modal"><?= Translator('Cancel');?></button>
													<button type="submit" name="resetMailConf__<?= $Customs['token'] ?>" class="exerotpbtn btn-red ripple-effect ripple-white"><?= Translator('Confirm');?></button>
												</div>
											</form>
										</div>
									</div>
								</div>
								<?php } ?>

								<td>
									<button type="button" name="view_infos_client__<?= $rand_client_modal ?>" data-toggle="modal" data-target="#view_infos_client__<?= $rand_client_modal ?>" title=<?= Translator('View_information');?> class="exerotpbtn btn-defaultexer btn-sm ripple-effect ripple-black"><i class="far fa-eye dwnl_small_addelement_icon delete_action_button_item"></i></button>
									
									<?php if (checkLevel() == SUPERVISOR) { ?>
									<button type="button" name="edit_infos_client__<?= $Customs['token'] ?>" data-toggle="modal" data-backdrop="static" data-keyboard="false" data-target="#edit_infos_client__<?= $Customs['token'] ?>" title=<?= Translator('Edit_perso');?> class="exerotpbtn btn-defaultexer btn-sm ripple-effect ripple-black"><i class="far fa-pen dwnl_small_addelement_icon delete_action_button_item"></i></button>
									<?php } ?>
								</td>
							</tr>
						<?php } } ?>
					</tbody>
				</table>
				
				<script type="text/javascript" src="/assets/libs/wysiwyg-editor/js/editor.app.js"></script>
				<script>new FroalaEditor(".exerEditor",{events:{"image.beforeUpload":function(e){var a=this;if(e.length){var r=new FileReader;r.onload=function(e){var r=e.target.result;a.image.insert(r,null,null,a.image.get())},r.readAsDataURL(e[0])}return a.popups.hideAll(),!1}},language:"fr",key:"AV:4~?3xROKLJKYHROLDXDR@d2YYGR_Bc1A8@5@4:1B2D2F2F1?1?2A3@1C1"});</script>
			</div>
		<?php } ?>
	<?php } ?>
	</main>

<?php include 'inc/footer.php'; ?>